#!/usr/bin/env bash
# Build + prepare the self-contained server (run on the server, or locally then upload).
set -euo pipefail
cd "$(dirname "$0")/.."
npm ci
npx drizzle-kit migrate            # apply database migrations
npx next build
cp -r public .next/standalone/public
cp -r .next/static .next/standalone/.next/static
cp .env .next/standalone/.env 2>/dev/null || true
echo "✓ Built. Start with:  pm2 start ecosystem.config.cjs   (or: node .next/standalone/server.js)"
