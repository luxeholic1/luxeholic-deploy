#!/usr/bin/env bash
# One-shot installer for a fresh Ubuntu 22.04 / 24.04 VPS (e.g. BookMyHost "luxeholic-web", 160.22.109.18).
#   1. Point DNS first: A records @ and www → this server's IP, for every domain in DOMAINS.
#   2. Upload luxeholic-complete.zip to /root, then:   unzip -o luxeholic-complete.zip -d /var/www/luxeholic && sudo bash /var/www/luxeholic/deploy/install.sh
# Safe to run again for updates (keeps .env, database and uploads).
set -euo pipefail
APP=/var/www/luxeholic
UPLOADS=/var/www/luxeholic-uploads
DOMAINS="${DOMAINS:-luxeholic.in www.luxeholic.in luxeholic.co.nz www.luxeholic.co.nz}"
PRIMARY="${PRIMARY:-luxeholic.in}"
EMAIL="${CERT_EMAIL:-karykalita1012@gmail.com}"
[ "$(id -u)" = 0 ] || { echo "Run with sudo"; exit 1; }
cd "$APP"

echo "▸ 1/7 System packages"
export DEBIAN_FRONTEND=noninteractive
apt-get update -qq
apt-get install -y -qq nginx postgresql certbot python3-certbot-nginx curl unzip ufw >/dev/null
if ! command -v node >/dev/null || [ "$(node -p 'process.versions.node.split(".")[0]')" -lt 20 ]; then
  curl -fsSL https://deb.nodesource.com/setup_22.x | bash - >/dev/null && apt-get install -y -qq nodejs >/dev/null
fi
command -v pm2 >/dev/null || npm i -g pm2 >/dev/null
# 2 GB swap so the build doesn't run out of memory on small plans
if ! swapon --show | grep -q . && [ "$(free -m | awk '/Mem/{print $2}')" -lt 3500 ]; then
  fallocate -l 2G /swapfile && chmod 600 /swapfile && mkswap /swapfile >/dev/null && swapon /swapfile && echo '/swapfile none swap sw 0 0' >> /etc/fstab
fi

echo "▸ 2/7 Database"
if [ ! -f .env ]; then
  DBPASS=$(openssl rand -hex 16)
  sudo -u postgres psql -qtc "select 1 from pg_roles where rolname='luxeholic'" | grep -q 1 \
    && sudo -u postgres psql -qc "alter user luxeholic with password '$DBPASS';" \
    || sudo -u postgres psql -qc "create user luxeholic with password '$DBPASS';"
  sudo -u postgres psql -qtc "select 1 from pg_database where datname='luxeholic'" | grep -q 1 || sudo -u postgres psql -qc "create database luxeholic owner luxeholic;"
  ADMINPW="Lx-$(openssl rand -hex 5)!"
  cat > .env <<ENV
NEXT_PUBLIC_SITE_URL="https://$PRIMARY"
DATABASE_URL="postgresql://luxeholic:$DBPASS@localhost:5432/luxeholic"
AUTH_SECRET="$(openssl rand -base64 48 | tr -d '\n')"
CRON_SECRET="$(openssl rand -hex 24)"
SUPER_ADMIN_EMAIL="karykalita1012@gmail.com"
SUPER_ADMIN_PASSWORD="$ADMINPW"
UPLOAD_DIR="$UPLOADS"
PAYU_MODE="test"
PHONEPE_MODE="sandbox"
SMTP_PORT="465"
MAIL_FROM="Luxeholic <sales@luxeholic.com.au>"
ENV
  chmod 600 .env
  printf "Team login: https://%s/team/login\nEmail: karykalita1012@gmail.com\nPassword: %s\n(change it after first login, then delete this file)\n" "$PRIMARY" "$ADMINPW" > /root/LUXEHOLIC-FIRST-LOGIN.txt
  chmod 600 /root/LUXEHOLIC-FIRST-LOGIN.txt
fi
mkdir -p "$UPLOADS" /var/backups /var/www/luxeholic-wp-uploads

echo "▸ 3/7 Build (3–6 min)"
set -a; . ./.env; set +a
npm ci --no-audit --no-fund --loglevel=error
npx drizzle-kit migrate
npx next build
rm -rf .next/standalone/public .next/standalone/.next/static
cp -r public .next/standalone/public
cp -r .next/static .next/standalone/.next/static
cp .env .next/standalone/.env
cp -r drizzle .next/standalone/drizzle

echo "▸ 4/7 Start app (pm2) — first start creates teams, super admin, categories and Hindi texts"
pm2 startOrReload ecosystem.config.cjs --update-env >/dev/null
pm2 save >/dev/null
pm2 startup systemd -u root --hp /root >/dev/null 2>&1 || true
for i in $(seq 1 30); do curl -fs -o /dev/null http://127.0.0.1:3000/robots.txt && break; sleep 2; done

echo "▸ Old WooCommerce store → products + images (background; ~1–3 h for 31k products)"
if [ "${SKIP_WOO:-0}" != 1 ] && ! grep -q '"done":true' .woo-import.json 2>/dev/null; then
  nohup bash -c 'set -a; . ./.env; set +a; npm run -s import:woo && WP_UPLOADS_DIR=/var/www/luxeholic-wp-uploads npm run -s mirror:images && echo "=== ALL DONE ==="' > /var/log/luxeholic-import.log 2>&1 &
  echo "  running — progress: tail -f /var/log/luxeholic-import.log   (switch luxeholic.in DNS only after ALL DONE)"
fi

echo "▸ 5/7 Nginx"
cp deploy/nginx.conf /etc/nginx/sites-available/luxeholic
ln -sf /etc/nginx/sites-available/luxeholic /etc/nginx/sites-enabled/luxeholic
rm -f /etc/nginx/sites-enabled/default
nginx -t -q && systemctl reload nginx
ufw allow OpenSSH >/dev/null; ufw allow 'Nginx Full' >/dev/null; ufw --force enable >/dev/null

echo "▸ 6/7 HTTPS certificates"
IP=$(curl -fs4 https://api.ipify.org || hostname -I | awk '{print $1}')
OK=""; SKIP=""
for d in $DOMAINS; do
  if getent ahostsv4 "$d" | awk '{print $1}' | grep -qx "$IP"; then OK="$OK -d $d"; else SKIP="$SKIP $d"; fi
done
if [ -n "$OK" ]; then
  certbot --nginx --non-interactive --agree-tos -m "$EMAIL" --redirect --expand --cert-name luxeholic $OK || echo "  ! certbot failed — rerun this script once DNS has spread"
fi
[ -n "$SKIP" ] && echo "  ! DNS not pointing here yet (no HTTPS for):$SKIP — rerun this script later"

echo "▸ 7/7 Scheduled jobs"
CRON_SECRET=$(grep '^CRON_SECRET=' .env | cut -d'"' -f2)
( crontab -l 2>/dev/null | grep -v '/api/cron/' | grep -v 'pg_dump' ; cat <<CRON
30 0 * * *  curl -fsS "http://127.0.0.1:3000/api/cron/daily?key=$CRON_SECRET" -H "Host: $PRIMARY" >/dev/null
0 */6 * * * curl -fsS -m 290 "http://127.0.0.1:3000/api/cron/sync?key=$CRON_SECRET" -H "Host: $PRIMARY" >/dev/null
15 * * * *  curl -fsS "http://127.0.0.1:3000/api/cron/cleanup?key=$CRON_SECRET" -H "Host: $PRIMARY" >/dev/null
0 21 * * *  sudo -u postgres pg_dump luxeholic | gzip > /var/backups/luxeholic-\$(date +\%F).sql.gz && find /var/backups -name 'luxeholic-*' -mtime +14 -delete
CRON
) | crontab -

echo
echo "✓ Luxeholic is running.  https://$PRIMARY   ·   https://luxeholic.co.nz (NZD)"
[ -f /root/LUXEHOLIC-FIRST-LOGIN.txt ] && cat /root/LUXEHOLIC-FIRST-LOGIN.txt
echo "Next: Team → Settings for PayU/PhonePe/SMTP keys; Team → Import → WooCommerce to bring old products."
