/**
 * Bulk-import every product from the old WooCommerce store (31k+). Resumable.
 *   npm run import:woo                     → https://luxeholic.in
 *   WOO_URL=https://old.example npm run import:woo
 * Progress is kept in .woo-import.json — rerun to continue where it stopped.
 * Run this BEFORE pointing luxeholic.in's DNS to the new server.
 */
import { existsSync, readFileSync, writeFileSync } from "fs";
import { fetchWooPage, wooToListing } from "../src/lib/importers/woocommerce";
import { importListings } from "../src/lib/listings";

const base = (process.env.WOO_URL || "https://luxeholic.in").replace(/\/+$/, "");
const STATE = ".woo-import.json";
type S = { base: string; next: number; pages: number; created: number; updated: number; failed: number; done: boolean };
const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));

async function main() {
  let s: S = existsSync(STATE) ? JSON.parse(readFileSync(STATE, "utf8")) : { base, next: 1, pages: 0, created: 0, updated: 0, failed: 0, done: false };
  if (s.base !== base) s = { base, next: 1, pages: 0, created: 0, updated: 0, failed: 0, done: false };
  if (s.done && !process.argv.includes("--again")) { console.log(`Already finished: ${s.created} created, ${s.updated} updated. Use --again to re-sync.`); return; }
  if (s.done) Object.assign(s, { next: 1, done: false });
  for (;;) {
    let page: Awaited<ReturnType<typeof fetchWooPage>> | null = null;
    for (let a = 1; a <= 5 && !page; a++) {
      try { page = await fetchWooPage(base, s.next); }
      catch (e) { console.warn(`page ${s.next} attempt ${a}: ${(e as Error).message}`); await sleep(3000 * a); }
    }
    if (!page) throw new Error(`Gave up on page ${s.next}. Rerun to continue.`);
    s.pages = page.totalPages || s.pages;
    if (page.items.length) {
      const r = await importListings(page.items.map((p) => wooToListing(p)), { mode: "upsert", defaultStatus: "ACTIVE", dryRun: false, source: "woocommerce" });
      s.created += r.created; s.updated += r.updated; s.failed += r.failed;
    }
    console.log(`page ${s.next}/${s.pages || "?"} · ${s.created} created · ${s.updated} updated · ${s.failed} failed`);
    const last = page.items.length < 100 || (s.pages && s.next >= s.pages);
    s.next++; s.done = !!last;
    writeFileSync(STATE, JSON.stringify(s));
    if (last) break;
  }
  try { const { seedHindi } = await import("../src/lib/i18n/seed-hi"); await seedHindi(() => {}); } catch { /* optional */ }
  console.log(`✓ Done: ${s.created} created, ${s.updated} updated, ${s.failed} failed.`);
}
main().then(() => process.exit(0), (e) => { console.error(e.message ?? e); process.exit(1); });
