/**
 * One-command local preview — no PostgreSQL install needed.
 *   npm install
 *   npm run setup:local     (creates .env, embedded database, demo data)
 *   npm run dev             → http://localhost:3000   and   http://localhost:3000/team/login
 * Works on Windows, macOS and Linux.
 */
import { existsSync, readFileSync, writeFileSync } from "fs";
import { randomBytes } from "crypto";

const ADMIN_PW = "Luxeholic@Admin1";

if (!existsSync(".env")) {
  writeFileSync(".env", [
    `DATABASE_URL="pglite:./.localdb"`,
    `AUTH_SECRET="${randomBytes(36).toString("base64url")}"`,
    `CRON_SECRET="${randomBytes(12).toString("hex")}"`,
    `NEXT_PUBLIC_SITE_URL="http://localhost:3000"`,
    `SUPER_ADMIN_EMAIL="karykalita1012@gmail.com"`,
    `SUPER_ADMIN_PASSWORD="${ADMIN_PW}"`,
    `# Add PAYU_KEY / PAYU_SALT (test mode) to try online payments locally`,
    "",
  ].join("\n"));
  console.log("✓ created .env (embedded database)");
}
for (const line of readFileSync(".env", "utf8").split(/\r?\n/)) {
  const m = line.match(/^\s*([A-Z0-9_]+)\s*=\s*"?(.*?)"?\s*$/);
  if (m && !process.env[m[1]]) process.env[m[1]] = m[2];
}

(async () => {
  const url = process.env.DATABASE_URL!;
  if (url.startsWith("pglite:")) {
    const { PGlite } = await import("@electric-sql/pglite");
    const { drizzle } = await import("drizzle-orm/pglite");
    const { migrate } = await import("drizzle-orm/pglite/migrator");
    const client = new PGlite(url.slice(7));
    await migrate(drizzle(client), { migrationsFolder: "drizzle" });
    await client.close();
  } else {
    const { Pool } = await import("pg");
    const { drizzle } = await import("drizzle-orm/node-postgres");
    const { migrate } = await import("drizzle-orm/node-postgres/migrator");
    const pool = new Pool({ connectionString: url });
    await migrate(drizzle(pool), { migrationsFolder: "drizzle" });
    await pool.end();
  }
  console.log("✓ database ready");

  // Local preview: demo catalogue + demo team, and a ready-to-use super admin password
  process.env.SEED_DEMO = "1";
  process.env.SUPER_ADMIN_PASSWORD ||= ADMIN_PW;
  process.env.LOCAL_PREVIEW = "1";
  await import("./seed");
})().catch((e) => { console.error(e); process.exit(1); });
