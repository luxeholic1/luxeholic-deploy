/**
 * Copy every product image still served from the old WordPress (…/wp-content/uploads/…) onto this server,
 * so the same URLs keep working after DNS moves here (Nginx serves /wp-content/uploads/ from WP_UPLOADS_DIR).
 *   npm run mirror:images      (resumable — skips files already downloaded)
 * Run BEFORE switching luxeholic.in DNS.
 */
import { existsSync, mkdirSync, writeFileSync, statSync } from "fs";
import path from "path";
import { sql } from "drizzle-orm";
import { db } from "../src/db";

const DIR = process.env.WP_UPLOADS_DIR || "/var/www/luxeholic-wp-uploads";
const HOST = /^https?:\/\/(www\.)?luxeholic\.in\/wp-content\/uploads\//i;
const CONC = Number(process.env.MIRROR_CONCURRENCY || 8);

async function main() {
  const rows = await db.execute(sql`select distinct jsonb_array_elements_text(images) as u from products`);
  const urls = (rows.rows as { u: string }[]).map((r) => r.u).filter((u) => HOST.test(u));
  console.log(`${urls.length} images on the old store`);
  let i = 0, got = 0, skip = 0, fail = 0;
  const worker = async () => {
    for (;;) {
      const u = urls[i++]; if (!u) return;
      const rel = decodeURIComponent(u.replace(HOST, "").split("?")[0]);
      if (rel.includes("..")) { fail++; continue; }
      const file = path.join(DIR, rel);
      if (existsSync(file) && statSync(file).size > 0) { skip++; continue; }
      try {
        const r = await fetch(u, { signal: AbortSignal.timeout(60000), headers: { "User-Agent": "LuxeholicMirror/1.0" } });
        if (!r.ok) throw new Error(String(r.status));
        mkdirSync(path.dirname(file), { recursive: true });
        writeFileSync(file, Buffer.from(await r.arrayBuffer()));
        got++;
      } catch { fail++; }
      const n = got + skip + fail;
      if (n % 500 === 0) console.log(`${n}/${urls.length} · ${got} downloaded · ${skip} already there · ${fail} failed`);
    }
  };
  await Promise.all(Array.from({ length: CONC }, worker));
  console.log(`✓ ${got} downloaded, ${skip} already there, ${fail} failed (rerun to retry failures).`);
}
main().then(() => process.exit(0), (e) => { console.error(e); process.exit(1); });
