/**
 * Move the products listed on the current luxeholic.in (WooCommerce) onto the new site.
 *
 *   npm run import:luxeholic                      # live pull from https://luxeholic.in
 *   npm run import:luxeholic -- --url https://old.luxeholic.in
 *   npm run import:luxeholic -- --file scripts/data/luxeholic-in-snapshot.json
 *   add --archive-demo to hide the demo catalogue, --dry-run to only report.
 *
 * Re-running is safe: products are matched by SKU.
 */
import { readFileSync } from "node:fs";
import { and, sql, eq } from "drizzle-orm";
import { db, schema } from "../src/db";
import { importListings } from "../src/lib/listings";
import { fetchWooStore, wooToListing, type WooStoreProduct } from "../src/lib/importers/woocommerce";

const arg = (k: string) => { const i = process.argv.indexOf(k); return i > -1 ? process.argv[i + 1] : undefined; };
const flag = (k: string) => process.argv.includes(k);

async function main() {
  const file = arg("--file");
  const url = arg("--url") ?? "https://luxeholic.in";
  const raw: WooStoreProduct[] = file ? JSON.parse(readFileSync(file, "utf8")) : await fetchWooStore(url);
  console.log(`Fetched ${raw.length} products from ${file ?? url}`);
  const rows = raw.map((p) => wooToListing(p));
  const r = await importListings(rows, { mode: "upsert", defaultStatus: "ACTIVE", dryRun: flag("--dry-run"), source: "woocommerce" });
  for (const x of r.results) console.log(`${x.action.padEnd(6)} ${x.sku.padEnd(18)} ${String(x.category ?? "").padEnd(18)} ${String(x.status ?? "").padEnd(7)} ₹${(x.price ?? 0) / 100}  ${x.title.slice(0, 50)}${x.notes.length ? "  — " + x.notes.join("; ") : ""}`);
  console.log(`✓ created ${r.created}, updated ${r.updated}, failed ${r.failed}${flag("--dry-run") ? " (dry run)" : ""}`);
  if (flag("--archive-demo") && !flag("--dry-run")) {
    const a = await db.update(schema.products).set({ status: "ARCHIVED" })
      .where(and(sql`${schema.products.tags} ? 'demo'`, eq(schema.products.status, "ACTIVE"))).returning({ id: schema.products.id });
    console.log(`✓ archived ${a.length} demo products`);
  }
  process.exit(0);
}
main().catch((e) => { console.error(e); process.exit(1); });
