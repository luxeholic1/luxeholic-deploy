/** Apply database migrations (works with PostgreSQL and the embedded local database). `npm run migrate` */
(async () => {
  const url = process.env.DATABASE_URL!;
  if (!url) throw new Error("DATABASE_URL is not set");
  if (url.startsWith("pglite:")) {
    const { PGlite } = await import("@electric-sql/pglite");
    const { drizzle } = await import("drizzle-orm/pglite");
    const { migrate } = await import("drizzle-orm/pglite/migrator");
    const client = new PGlite(url.slice(7));
    await migrate(drizzle(client), { migrationsFolder: "drizzle" });
    await client.close();
  } else {
    const { Pool } = await import("pg");
    const { drizzle } = await import("drizzle-orm/node-postgres");
    const { migrate } = await import("drizzle-orm/node-postgres/migrator");
    const pool = new Pool({ connectionString: url });
    await migrate(drizzle(pool), { migrationsFolder: "drizzle" });
    await pool.end();
  }
  console.log("✓ database up to date");
})().catch((e) => { console.error(e); process.exit(1); });
