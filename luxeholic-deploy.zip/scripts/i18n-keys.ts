/**
 * Lists every English UI string the storefront can show, and checks each has a Hindi translation.
 *   npm run i18n:check            → fails (exit 1) if any string is missing from src/lib/i18n/hi.ts
 *   npm run i18n:check -- --list  → prints the keys as JSON (used to write the dictionary)
 */
import { readFileSync, readdirSync, statSync } from "node:fs";
import { join } from "node:path";
import { HI } from "../src/lib/i18n/hi";
import { POLICY_PAGES } from "../src/lib/site";
import { PRICE_TIERS } from "../src/lib/money";
import { ORDER_LABEL, PAY_LABEL } from "../src/lib/order-labels";
import { MARKETPLACES } from "../src/components/store/marketplaces";

const ROOTS = ["src/app/(store)", "src/components/store", "src/app/not-found.tsx", "src/app/team/login/form.tsx", "src/lib/orders.ts", "src/lib/auth.ts", "src/lib/money.ts"];
const files: string[] = [];
const walk = (p: string) => { if (statSync(p).isDirectory()) readdirSync(p).forEach((f) => walk(join(p, f))); else if (/\.(tsx?|ts)$/.test(p)) files.push(p); };
ROOTS.forEach(walk);

const keys = new Set<string>();
const unq = (s: string) => JSON.parse(`"${s}"`) as string;
for (const f of files) {
  const src = readFileSync(f, "utf8");
  // t("…"), tr("…")
  for (const m of src.matchAll(/\b(?:t|tr)\(\s*"((?:[^"\\]|\\.)*)"/g)) keys.add(unq(m[1]));
  // messages returned to the shopper by server actions / validation
  if (/actions\.ts$|orders\.ts$|auth\.ts$/.test(f)) {
    for (const m of src.matchAll(/\b(?:error|ok):\s*"((?:[^"\\]|\\.)*)"/g)) keys.add(unq(m[1]));
    for (const m of src.matchAll(/(?:regex|min)\([^)]*?,\s*"((?:[^"\\]|\\.)*)"\)/g)) keys.add(unq(m[1]));
    for (const m of src.matchAll(/\?\?\s*"((?:[^"\\]|\\.)*)"/g)) if (/\s/.test(m[1])) keys.add(unq(m[1]));
    for (const m of src.matchAll(/return "((?:[^"\\]|\\.)*)";/g)) keys.add(unq(m[1]));
  }
  // const lists of labels shown through t(x)
  for (const m of src.matchAll(/const (?:STATES|INTERESTS|TIMES|SORTS|STEPS|ITEMS|TABS)\b[^=]*=\s*(\[[\s\S]*?\])(?: as const)?;/g)) {
    for (const s of m[1].matchAll(/"((?:[^"\\]|\\.)*)"/g)) if (/[A-Za-z]{2}/.test(s[1]) && !/^\/|^[a-z]+(-[a-z]+)*$|^[A-Z_]+$/.test(s[1])) keys.add(unq(s[1]));
  }
  for (const m of src.matchAll(/const (?:LABEL|T|C)\b: Record<string, string> = (\{[\s\S]*?\});/g)) {
    for (const s of m[1].matchAll(/:\s*"((?:[^"\\]|\\.)*)"/g)) keys.add(unq(s[1]));
  }
}
POLICY_PAGES.forEach((p) => keys.add(p.title));
PRICE_TIERS.forEach((p) => keys.add(p.name));
Object.values(ORDER_LABEL).forEach((v) => keys.add(v));
Object.values(PAY_LABEL).forEach((v) => keys.add(v));
MARKETPLACES.forEach((m) => { keys.add(m.name); keys.add(m.note); });
// data that arrives at runtime and goes through t()
["morning", "afternoon", "evening", "Instagram", "Facebook", "Pinterest", "YouTube", "Sales", "Marketing", "Procurement", "Inventory", "Tech Support", "Alliances",
 "YES Bank Ltd", "Atta, Noida, Uttar Pradesh", "Use at least 10 characters.", "Use letters and at least one number."].forEach((k) => keys.add(k));
keys.delete("");

const list = [...keys].sort();
if (process.argv.includes("--list")) { console.log(JSON.stringify(list, null, 1)); process.exit(0); }
const missing = list.filter((k) => !(k in HI));
const unused = Object.keys(HI).filter((k) => !keys.has(k));
console.log(`i18n: ${list.length} strings · Hindi ${list.length - missing.length}/${list.length}${unused.length ? ` · ${unused.length} unused` : ""}`);
if (missing.length) { console.log("Missing Hindi:\n" + missing.map((m) => "  " + JSON.stringify(m)).join("\n")); process.exit(1); }
