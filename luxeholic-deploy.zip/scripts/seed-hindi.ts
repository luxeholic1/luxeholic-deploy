/** Hindi translations for the current catalogue, hero and site texts.  npm run seed:hindi */
import { seedHindi } from "../src/lib/i18n/seed-hi";
seedHindi().then(() => process.exit(0), (e) => { console.error(e); process.exit(1); });
