/** CLI runner for VPS crontab:  npx tsx scripts/cron.ts daily|sync|cleanup */
import { runJob } from "../src/lib/jobs";
runJob(process.argv[2] ?? "daily").then((r) => { console.log(JSON.stringify(r, null, 2)); process.exit(0); }).catch((e) => { console.error(e); process.exit(1); });
