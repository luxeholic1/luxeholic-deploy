/**
 * Seed: teams + panel access, super admin, category tree, vendors, settings.
 *   npm run db:seed                 → production-safe seed (no demo data)
 *   SEED_DEMO=1 npm run db:seed     → also demo products, demo staff & tasks (local preview only)
 */
import { eq } from "drizzle-orm";
import { db, schema } from "../src/db";
import { hashPassword } from "../src/lib/auth";
import { tempPassword } from "../src/lib/crypto";
import { SUPER_ADMIN_EMAIL } from "../src/lib/site";
import { seedEssentials, TEAMS } from "../src/lib/setup";
import { todayIST, addDays } from "../src/lib/dates";
import { luxuryRound } from "../src/lib/money";


async function main() {
  await seedEssentials();
  if (process.env.SEED_DEMO === "1") await demo();
  console.log("Done.");
  if (process.env.LOCAL_PREVIEW === "1") {
    console.log(`
  Run:  npm run dev
  Store:  http://localhost:3000
  Team:   http://localhost:3000/team/login
          Super Admin → ${SUPER_ADMIN_EMAIL} / ${process.env.SUPER_ADMIN_PASSWORD}
          Sales (or any team) → sales@luxeholic.in / Luxeholic@2026
`);
  }
  process.exit(0);
}

async function demo() {
  const cats = await db.select().from(schema.categories);
  const id = (slug: string) => cats.find((c) => c.slug === slug)!.id;
  const [sunsky] = await db.select().from(schema.vendors).where(eq(schema.vendors.slug, "sunsky"));
  const [bg] = await db.select().from(schema.vendors).where(eq(schema.vendors.slug, "brandsgateway"));
  const P: [string, string, number, string, string?, string?][] = [
    // [title, sub-category, price ₹, material/desc hint, brand, gender]
    ["The Thinker in Obsidian Resin", "resin-sculptures", 4890, "hand-finished resin with a deep obsidian lacquer"],
    ["Gilded Gorilla Statement Sculpture", "resin-sculptures", 18900, "resin cast, hand-applied 24k-tone gold leaf"],
    ["Aurelia Abstract Couple", "abstract-figurines", 6400, "matte ivory resin with brushed-brass base"],
    ["Monolith Geometric Face", "abstract-figurines", 3290, "faceted resin in charcoal stone finish"],
    ["Regal Lion Bust", "animal-sculptures", 12500, "weighted resin with antique bronze patina"],
    ["Galloping Mare in Champagne", "animal-sculptures", 27500, "large-format resin, champagne metallic"],
    ["Serene Buddha, Stone Finish", "spiritual-art", 5600, "resin with hand-rubbed sandstone texture"],
    ["Lotus Ganesha in Brass Tone", "spiritual-art", 8900, "cold-cast resin with brass-tone finish"],
    ["Golden Hour Canvas Diptych", "wall-art", 14900, "hand-embellished canvas, floating frame"],
    ["Marble Mist Bookends (Pair)", "tabletop-accents", 2990, "marbled resin, felt-lined base"],
    ["Fluted Travertine Vase", "vases-planters", 3990, "travertine-effect ceramic"],
    ["Noir Ribbed Planter, Large", "vases-planters", 7400, "matte black stoneware"],
    ["Amber Glass Candle Lantern", "candles-holders", 2490, "hand-blown amber glass, brass cap"],
    ["Orbit Marble Table Lamp", "lamps-lighting", 16900, "white marble base, linen drum shade"],
    ["Minimal Brass Wall Clock", "clocks", 4590, "brushed brass rim, silent sweep movement"],
    ["Arched Bronze-Frame Mirror", "mirrors", 21900, "bevelled glass, powder-coated bronze frame"],
    ["Onyx Valet Tray", "trays-bowls-boxes", 3490, "polished resin onyx effect"],
    ["Crystal Whisky Decanter Set", "tableware-barware", 9900, "lead-free crystal, four tumblers"],
    ["Quilted Leather Shoulder Bag", "handbags", 89500, "Italian calf leather, gold-tone hardware", "Valentino", "female"],
    ["Signature Monogram Tote", "handbags", 142000, "coated canvas with leather trims", "Gucci", "female"],
    ["Silk Wrap Midi Dress", "womens-clothing", 46500, "100% silk crêpe de chine", "Ermanno Scervino", "female"],
    ["Tailored Wool Blazer", "mens-clothing", 58900, "virgin wool, half-canvas construction", "Emporio Armani", "male"],
    ["Cotton Piqué Polo", "mens-clothing", 13900, "pure cotton piqué, embroidered logo", "Ralph Lauren", "male"],
    ["Leather Low-Top Sneakers", "designer-shoes", 38900, "nappa leather, rubber sole", "Philipp Plein", "male"],
    ["Chronograph Steel Watch", "watches", 34900, "stainless steel, sapphire-coated crystal", "Hugo Boss", "male"],
    ["Rose Gold Mesh Watch", "watches", 21900, "rose-gold-tone mesh bracelet", "Michael Kors", "female"],
    ["Cat-Eye Acetate Sunglasses", "sunglasses", 18900, "acetate frame, UV400 lenses", "Prada", "female"],
    ["Saffiano Bifold Wallet", "wallets-leather", 24900, "saffiano leather, eight card slots", "Prada", "male"],
    ["Reversible Leather Belt", "belts", 16900, "reversible calf leather, signature buckle", "Calvin Klein", "male"],
    ["Printed Silk Twill Scarf", "scarves-stoles", 12900, "silk twill, hand-rolled edges", "Versace", "female"],
    ["The Housewarming Box", "gift-sets", 7900, "fluted vase, amber candle lantern and onyx tray, gift-wrapped", "Luxeholic"],
    ["Vision AI Smart Glasses", "ai-smart-glasses", 15900, "open-ear audio, voice assistant, polarised lenses"],
    ["Titan Rugged 5G Phone", "rugged-phones", 32900, "IP68/IP69K, 10,000 mAh, night-vision camera"],
    ["Aura Smart Ring", "smart-wearables", 11900, "titanium shell, sleep & heart-rate tracking"],
    ["Studio ANC Headphones", "premium-audio", 9490, "active noise cancelling, 50-hour battery"],
    ["Walnut Wireless Charging Dock", "desk-travel-tech", 4290, "solid walnut, 15W Qi charging for three devices"],
  ];
  for (const [i, [title, sub, rupees, hint, brand, gender]] of P.entries()) {
    const fashion = Boolean(brand) && brand !== "Luxeholic";
    const slug = title.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/(^-|-$)/g, "");
    const price = luxuryRound(rupees * 100);
    await db.insert(schema.products).values({
      slug, title, sku: `DEMO-${String(i + 1).padStart(3, "0")}`, categoryId: id(sub), price,
      compareAtPrice: i % 5 === 0 ? luxuryRound(price * 1.25) : null,
      brand: brand ?? "Luxeholic", vendorId: fashion ? bg.id : sunsky.id, vendorSku: `DEMO-V${i + 1}`,
      shortDescription: `Crafted in ${hint}.`,
      description: `${title} — ${hint}. Chosen by the Luxeholic curators for its proportion, finish and presence in a room.\n\nEvery piece is inspected before dispatch, packed in protective luxury packaging and shipped fully insured across India.\n\nDemo product — replace with synced vendor catalogue before launch.`,
      stock: 3 + (i % 7), status: "ACTIVE", isFeatured: i % 4 === 0, isNewArrival: i % 3 === 0,
      material: hint.split(",")[0], gender: gender ?? null, ageGroup: gender ? "adult" : null,
      mpn: `DEMO-V${i + 1}`, dispatchDays: fashion ? 3 : 2, deliveryDays: fashion ? 10 : 12, tags: ["demo"],
    }).onConflictDoNothing();
  }
  console.log("✓ demo products");

  // Demo staff — one lead per team
  const teams = await db.select().from(schema.teams);
  const people: Record<string, string> = { sales: "Dhruv Chopra", marketing: "Aisha Kapoor", procurement: "Rohan Mehta", inventory: "Neha Verma", "tech-support": "Arjun Rao", alliances: "Kabir Singh" };
  const pw = await hashPassword("Luxeholic@2026");
  for (const t of teams) {
    await db.insert(schema.staff).values({ name: people[t.slug] ?? t.name + " Lead", email: `${t.slug}@luxeholic.in`, passwordHash: pw, role: "TEAM_LEAD", teamId: t.id, mustChangePassword: false })
      .onConflictDoNothing({ target: schema.staff.email });
  }
  console.log("✓ demo staff (password Luxeholic@2026)");

  const [admin] = await db.select().from(schema.staff).where(eq(schema.staff.email, SUPER_ADMIN_EMAIL));
  const t = (slug: string) => teams.find((x) => x.slug === slug)!.id;
  const today = todayIST();
  await db.insert(schema.tasks).values([
    { title: "Call & confirm all pending COD orders", teamId: t("sales"), createdById: admin.id, dueDate: today, recurrence: "WEEKDAYS", isTemplate: true, priority: "HIGH", dueTime: "11:00" },
    { title: "Post 1 reel + 3 stories featuring new arrivals", teamId: t("marketing"), createdById: admin.id, dueDate: today, recurrence: "DAILY", isTemplate: true },
    { title: "Place vendor orders for yesterday's paid orders", teamId: t("procurement"), createdById: admin.id, dueDate: today, recurrence: "WEEKDAYS", isTemplate: true, priority: "URGENT", dueTime: "10:30" },
    { title: "Review new synced drafts & publish 20 products", teamId: t("inventory"), createdById: admin.id, dueDate: today, recurrence: "WEEKDAYS", isTemplate: true },
    { title: "Clear support inbox (response < 4h)", teamId: t("tech-support"), createdById: admin.id, dueDate: today, recurrence: "DAILY", isTemplate: true },
    { title: "Shortlist 3 Indian artisan resin studios as new vendors", teamId: t("alliances"), createdById: admin.id, dueDate: addDays(today, 3), priority: "MEDIUM" },
    { title: "Diwali gifting campaign plan", description: "Gift guide page, coupon DIWALI10, Google Shopping budget split.", teamId: t("marketing"), createdById: admin.id, dueDate: addDays(today, 2), priority: "HIGH" },
    { title: "Weekly growth review", kind: "MEETING", teamId: null, createdById: admin.id, dueDate: addDays(today, 1), dueTime: "17:00", recurrence: "WEEKLY", isTemplate: true },
  ]);
  await db.insert(schema.coupons).values({ code: "WELCOME10", description: "10% off the first order", percentOff: 10, minSubtotal: 300000 }).onConflictDoNothing();
  console.log("✓ demo tasks & coupon");
}

main().catch((e) => { console.error(e); process.exit(1); });
