import type { Config } from "tailwindcss";
export default {
  content: ["./src/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        ink: { DEFAULT: "#0E0D0B", soft: "#2A2723", mute: "#6B655C" },
        ivory: { DEFAULT: "#F7F3EC", deep: "#EFE8DC", line: "#E2D9C9" },
        gold: { DEFAULT: "#A8834A", light: "#C9A86A", dark: "#7E6133" },
      },
      fontFamily: {
        display: ["'Cormorant Garamond'", "'Noto Serif Devanagari'", "Georgia", "serif"],
        sans: ["Jost", "'Noto Sans Devanagari'", "system-ui", "sans-serif"],
      },
      letterSpacing: { luxe: "0.28em" },
      keyframes: {
        fadeUp: { "0%": { opacity: "0", transform: "translateY(14px)" }, "100%": { opacity: "1", transform: "none" } },
        marquee: { "0%": { transform: "translateX(0)" }, "100%": { transform: "translateX(-50%)" } },
      },
      animation: { fadeUp: "fadeUp .9s cubic-bezier(.2,.7,.2,1) both", marquee: "marquee 40s linear infinite" },
    },
  },
  plugins: [],
} satisfies Config;
