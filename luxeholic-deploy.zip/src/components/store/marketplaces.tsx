import type { Settings } from "@/lib/settings";
import { getI18n } from "@/lib/i18n/server";

export const MARKETPLACES = [
  { key: "amazon", name: "Amazon", note: "Amazon.in" },
  { key: "flipkart", name: "Flipkart", note: "Flipkart.com" },
  { key: "blinkit", name: "Blinkit", note: "Quick delivery app" },
  { key: "walmart", name: "Walmart", note: "Walmart.com" },
] as const;

/** "Also on" — shows where else Luxeholic sells. Names are set in our own type (no third-party logos). */
export async function MarketplaceStrip({ links }: { links: Settings["marketplaces"] }) {
  const { t } = await getI18n();
  return (
    <section className="border-y border-ivory-line bg-white/50" aria-labelledby="also-on">
      <div className="container-lx grid items-center gap-8 py-12 lg:grid-cols-[1fr_2.2fr] lg:py-14">
        <div>
          <p id="also-on" className="eyebrow">{t("Also available on")}</p>
          <p className="h-display mt-3 text-3xl sm:text-4xl">{t("Find Luxeholic wherever you shop.")}</p>
          <p className="mt-2 text-sm text-ink-mute">{t("Same pieces, same care — on India’s favourite marketplaces. Buy direct here for the full collection and pay-10%-now delivery.")}</p>
        </div>
        <ul className="grid grid-cols-2 gap-px overflow-hidden border border-ivory-line bg-ivory-line sm:grid-cols-4">
          {MARKETPLACES.map((m) => {
            const url = links[m.key];
            const body = (
              <>
                <span className="font-display text-[26px] leading-none">{t(m.name)}</span>
                <span className="mt-2 text-[11px] uppercase tracking-[0.16em] text-ink-mute">{url ? t("Visit our store →") : t(m.note)}</span>
              </>
            );
            return (
              <li key={m.key} className="bg-ivory">
                {url ? (
                  <a href={url} target="_blank" rel="noopener noreferrer" className="flex h-full flex-col items-center justify-center px-4 py-7 text-center transition hover:bg-white">{body}</a>
                ) : (
                  <div className="flex h-full flex-col items-center justify-center px-4 py-7 text-center">{body}</div>
                )}
              </li>
            );
          })}
        </ul>
      </div>
    </section>
  );
}
