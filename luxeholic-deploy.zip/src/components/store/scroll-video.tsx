"use client";
import Link from "next/link";
import { useEffect, useRef, useState } from "react";

export type Beat = { at: number; eyebrow?: string; title: string; text?: string }; // at = 0..1 of the film
export type ScrollFilm = {
  id: string; src: string; srcMobile?: string; webm?: string; poster: string;
  heading: string; eyebrow: string; beats: Beat[]; cta?: { href: string; label: string };
  screens?: number; // scroll length in viewport heights (longer = slower scrub)
};

/**
 * Scroll-scrubbed film: the section pins, and scrolling moves the video forward/backward frame by frame.
 * Videos are encoded with a keyframe every 6 frames so seeking stays smooth.
 * Reduced-motion users (and browsers that can't seek) get a normal muted autoplay loop.
 */
export function ScrollVideo({ film }: { film: ScrollFilm }) {
  const wrap = useRef<HTMLDivElement>(null);
  const video = useRef<HTMLVideoElement>(null);
  const [p, setP] = useState(0);
  const [src, setSrc] = useState(film.src);
  const [still, setStill] = useState(false);

  useEffect(() => {
    if (film.srcMobile && window.matchMedia("(max-width: 767px)").matches) setSrc(film.srcMobile);
    setStill(window.matchMedia("(prefers-reduced-motion: reduce)").matches);
  }, [film.srcMobile]);

  useEffect(() => {
    if (still) return;
    const el = wrap.current, v = video.current;
    if (!el || !v) return;
    let raf = 0, target = 0, shown = -1;
    const measure = () => {
      const r = el.getBoundingClientRect();
      const total = r.height - window.innerHeight;
      target = Math.min(1, Math.max(0, -r.top / Math.max(1, total)));
    };
    const tick = () => {
      // ease toward the scroll position so the scrub feels like a camera move, not a jump
      const next = shown < 0 ? target : shown + (target - shown) * 0.18;
      if (Math.abs(next - shown) > 0.0004) {
        shown = next;
        setP(next);
        if (v.duration && !v.seeking) v.currentTime = next * (v.duration - 0.05);
      }
      raf = requestAnimationFrame(tick);
    };
    const onScroll = () => measure();
    measure();
    v.pause();
    raf = requestAnimationFrame(tick);
    window.addEventListener("scroll", onScroll, { passive: true });
    window.addEventListener("resize", onScroll);
    return () => { cancelAnimationFrame(raf); window.removeEventListener("scroll", onScroll); window.removeEventListener("resize", onScroll); };
  }, [still, src]);

  const active = [...film.beats].reverse().find((b) => p >= b.at) ?? film.beats[0];
  const screens = film.screens ?? 5;

  return (
    <section ref={wrap} aria-label={film.heading} data-film={JSON.stringify(film.beats)} className="relative bg-ink text-ivory" style={{ height: still ? "auto" : `${screens * 100}vh` }}>
      <div className={still ? "relative" : "sticky top-0 h-screen overflow-hidden"}>
        <video
          ref={video}
          key={src}
          poster={film.poster}
          muted
          playsInline
          preload="auto"
          autoPlay={still}
          loop={still}
          className={`${still ? "aspect-video" : "absolute inset-0 h-full"} w-full object-cover`}
          aria-hidden="true"
        >
          <source src={src} type="video/mp4" />
          {film.webm && <source src={film.webm} type="video/webm" />}
        </video>
        <div className="pointer-events-none absolute inset-0 bg-gradient-to-t from-ink/85 via-ink/10 to-ink/40" />
        <div className="absolute inset-x-0 top-0 pt-24 lg:pt-32">
          <div className="container-lx flex items-center justify-between text-[10.5px] uppercase tracking-[0.24em] text-ivory/80">
            <span>{film.eyebrow}</span>
            {!still && <span data-role="pct" className="tabular-nums">{String(Math.round(p * 100)).padStart(2, "0")}%</span>}
          </div>
        </div>
        <div className="absolute inset-x-0 bottom-0 pb-10 sm:pb-14">
          <div className="container-lx">
            <div key={active.title} data-role="beat" className="max-w-xl animate-fadeUp">
              <p data-role="eyebrow" className="eyebrow !text-gold-light">{active.eyebrow}</p>
              <h2 data-role="title" className="h-display mt-3 text-4xl sm:text-6xl">{active.title}</h2>
              <p data-role="text" className="mt-3 max-w-md text-sm leading-relaxed text-ivory/80 sm:text-base">{active.text}</p>
            </div>
            {film.cta && (
              <Link href={film.cta.href} data-role="cta" style={{ display: !still && p <= 0.82 ? "none" : undefined }} className="btn-light pointer-events-auto mt-6 animate-fadeUp">{film.cta.label}</Link>
            )}
            {!still && (
              <div className="mt-8 h-px w-full bg-ivory/20">
                <div data-role="bar" className="h-px bg-gold-light" style={{ width: `${p * 100}%` }} />
              </div>
            )}
          </div>
        </div>
      </div>
    </section>
  );
}
