"use client";
import { useEffect } from "react";
import { useCart } from "./cart";

export function ClearBag() {
  const { clear, ready } = useCart();
  useEffect(() => { if (ready) clear(); }, [ready, clear]);
  return null;
}
