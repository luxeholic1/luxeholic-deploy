"use client";
import Link from "next/link";
import { Minus, Plus, X } from "lucide-react";
import { useCart } from "./cart";
import { ProductImage } from "./art";
import { useMoney, usePrefs, useT } from "@/lib/i18n/client";
import { brandName } from "@/lib/i18n/config";

export function BagDrawer({ advancePercent }: { advancePercent: number }) {
  const { items, open, setOpen, subtotal, setQty, remove } = useCart();
  const t = useT();
  const formatINR = useMoney();
  const { locale } = usePrefs();
  if (!open) return null;
  return (
    <div className="fixed inset-0 z-50">
      <div className="absolute inset-0 bg-ink/40" onClick={() => setOpen(false)} />
      <aside className="absolute inset-y-0 right-0 flex w-full max-w-md flex-col bg-ivory animate-fadeUp" aria-label={t("Shopping bag")}>
        <div className="flex items-center justify-between border-b border-ivory-line px-6 py-5">
          <p className="eyebrow text-ink">{t("Your bag")}</p>
          <button onClick={() => setOpen(false)} aria-label={t("Close bag")}><X size={18} strokeWidth={1.4} /></button>
        </div>
        {items.length === 0 ? (
          <div className="flex flex-1 flex-col items-center justify-center px-8 text-center">
            <p className="h-display text-3xl italic">{t("Your bag is waiting.")}</p>
            <p className="mt-3 text-sm text-ink-mute">{t("Begin with a piece that makes you pause.")}</p>
            <Link href="/shop" onClick={() => setOpen(false)} className="btn-ink mt-8">{t("Discover the collection")}</Link>
          </div>
        ) : (
          <>
            <ul className="flex-1 divide-y divide-ivory-line overflow-y-auto px-6">
              {items.map((i) => (
                <li key={i.productId + (i.variantId ?? "")} className="flex gap-4 py-5">
                  <Link href={`/p/${i.slug}`} onClick={() => setOpen(false)} className="h-28 w-[88px] shrink-0 overflow-hidden bg-ivory-deep">
                    <ProductImage src={i.image} seed={i.slug} alt={i.missing ? "" : i.title} />
                  </Link>
                  <div className="flex min-w-0 flex-1 flex-col">
                    {i.brand && <p className="eyebrow !text-[10px]">{brandName(i.brand, locale)}</p>}
                    <p className="mt-0.5 line-clamp-2 text-sm">{i.missing ? t("Saved piece") : i.title}</p>
                    {i.variant && !i.missing && <p className="text-xs text-ink-mute">{i.variant}</p>}
                    <div className="mt-auto flex items-center justify-between pt-2">
                      <div className="flex items-center border border-ivory-line">
                        <button className="p-1.5" aria-label={t("Decrease")} onClick={() => setQty(i.productId, i.variantId, i.qty - 1)}><Minus size={12} /></button>
                        <span className="w-7 text-center text-xs">{i.qty}</span>
                        <button className="p-1.5" aria-label={t("Increase")} onClick={() => setQty(i.productId, i.variantId, i.qty + 1)}><Plus size={12} /></button>
                      </div>
                      <p className="text-sm">{formatINR(i.price * i.qty)}</p>
                    </div>
                  </div>
                  <button className="self-start text-ink-mute" aria-label={t("Remove")} onClick={() => remove(i.productId, i.variantId)}><X size={14} /></button>
                </li>
              ))}
            </ul>
            <div className="border-t border-ivory-line px-6 py-5">
              <div className="flex justify-between text-sm"><span>{t("Subtotal")}</span><span>{formatINR(subtotal)}</span></div>
              <p className="mt-1 text-xs text-ink-mute">{t("Inclusive of GST · Complimentary insured shipping")}</p>
              <p className="mt-1 text-xs text-gold-dark">{t("Or pay just {amount} now, rest on delivery", { amount: formatINR(Math.ceil((subtotal * advancePercent) / 10000) * 100) })}</p>
              <Link href="/checkout" onClick={() => setOpen(false)} className="btn-ink mt-5 w-full">{t("Checkout")}</Link>
              <Link href="/cart" onClick={() => setOpen(false)} className="mt-3 block text-center text-xs underline underline-offset-4">{t("View bag")}</Link>
            </div>
          </>
        )}
      </aside>
    </div>
  );
}
