"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import { useCart } from "./cart";
import { useMoney, usePrefs, useT } from "@/lib/i18n/client";

type V = { id: string; name: string; price: number; stock: number };
type Prod = { id: string; slug: string; title: string; brand: string; price: number; image: string | null; stock: number };

export function AddToBag({ product, variants }: { product: Prod; variants: V[] }) {
  const { add } = useCart();
  const router = useRouter();
  const t = useT();
  const formatINR = useMoney();
  const { locale } = usePrefs();
  const [vid, setVid] = useState<string | null>(variants.find((v) => v.stock > 0)?.id ?? null);
  const v = variants.find((x) => x.id === vid) ?? null;
  const stock = variants.length ? v?.stock ?? 0 : product.stock;
  const price = v?.price ?? product.price;
  const item = () => ({ productId: product.id, variantId: v?.id ?? null, qty: 1, title: product.title, variant: v?.name ?? null, price, image: product.image, slug: product.slug, brand: product.brand, lang: locale });

  return (
    <div>
      {variants.length > 0 && (
        <fieldset className="mb-6">
          <legend className="label">{variants[0].name.toLowerCase().startsWith("size") || variants[0].name.startsWith("साइज़") ? t("Select size") : t("Select option")}</legend>
          <div className="flex flex-wrap gap-2">
            {variants.map((x) => (
              <button key={x.id} type="button" disabled={x.stock <= 0} onClick={() => setVid(x.id)}
                className={`min-w-14 border px-3 py-2.5 text-sm transition disabled:cursor-not-allowed disabled:text-ink-mute/40 disabled:line-through ${vid === x.id ? "border-ink bg-ink text-ivory" : "border-ivory-line hover:border-ink"}`}>
                {x.name.replace(/^(Size|साइज़)\s*/i, "")}
              </button>
            ))}
          </div>
          {v && v.price !== product.price && <p className="mt-2 text-sm">{formatINR(v.price)}</p>}
        </fieldset>
      )}
      {stock > 0 ? (
        <div className="grid gap-3 sm:grid-cols-2">
          <button className="btn-ink w-full" onClick={() => add(item())}>{t("Add to bag")}</button>
          <button className="btn-line w-full" onClick={() => { add(item()); router.push("/checkout"); }}>{t("Buy now")}</button>
          {stock <= 3 && <p className="text-xs text-gold-dark sm:col-span-2">{t("Only {n} left — pieces like this rarely return.", { n: stock })}</p>}
        </div>
      ) : (
        <div>
          <button disabled className="btn-ink w-full">{t("Sold out")}</button>
          <p className="mt-2 text-xs text-ink-mute">{t("Write to us and we’ll tell you the moment it returns.")}</p>
        </div>
      )}
    </div>
  );
}
