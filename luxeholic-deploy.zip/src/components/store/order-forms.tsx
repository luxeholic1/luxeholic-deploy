"use client";
import { useActionState } from "react";
import { requestReturn, submitUtr } from "@/app/(store)/actions";
import { useT } from "@/lib/i18n/client";

export function UtrForm({ number, token }: { number: string; token: string }) {
  const [s, action, pending] = useActionState(submitUtr, null);
  const t = useT();
  if (s?.ok) return <p className="mt-5 text-sm">{t("Thank you — we’re verifying your transfer and will confirm by email.")}</p>;
  return (
    <form action={action} className="mt-5">
      <input type="hidden" name="number" value={number} /><input type="hidden" name="t" value={token} />
      <label className="label" htmlFor="utr">{t("Paid already? Enter the UTR / reference number")}</label>
      <div className="flex gap-2"><input id="utr" name="utr" className="field" placeholder={t("e.g. {example}", { example: "412345678901" })} /><button disabled={pending} className="btn-ink !px-5">{t("Submit")}</button></div>
      {s?.error && <p className="mt-2 text-xs text-red-700">{t(s.error)}</p>}
    </form>
  );
}

export function ReturnForm({ number, token, days }: { number: string; token: string; days: number }) {
  const [s, action, pending] = useActionState(requestReturn, null);
  const t = useT();
  if (s?.ok) return <p className="text-sm">{t("Return requested. Our team will arrange a pickup within 2 working days.")}</p>;
  return (
    <details>
      <summary className="cursor-pointer text-xs underline">{t("Request a return (within {days} days)", { days })}</summary>
      <form action={action} className="mt-3 space-y-2">
        <input type="hidden" name="number" value={number} /><input type="hidden" name="t" value={token} />
        <textarea name="reason" rows={3} className="field" placeholder={t("What went wrong?")} />
        <button disabled={pending} className="btn-line !py-2">{t("Request return")}</button>
        {s?.error && <p className="text-xs text-red-700">{t(s.error)}</p>}
      </form>
    </details>
  );
}
