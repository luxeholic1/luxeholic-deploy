"use client";
import { useActionState } from "react";
import { login, register } from "@/app/(store)/actions";
import { useT } from "@/lib/i18n/client";

export function AuthForm({ mode, next }: { mode: "login" | "register"; next?: string }) {
  const [s, action, pending] = useActionState(mode === "login" ? login : register, null);
  const t = useT();
  return (
    <form action={action} className="mt-10 space-y-4">
      <input type="hidden" name="next" value={next ?? ""} />
      {mode === "register" && <div><label className="label" htmlFor="a-name">{t("Full name")}</label><input id="a-name" name="name" required className="field" autoComplete="name" /></div>}
      <div><label className="label" htmlFor="a-email">{t("Email")}</label><input id="a-email" name="email" type="email" required className="field" autoComplete="email" /></div>
      {mode === "register" && <div><label className="label" htmlFor="a-phone">{t("Mobile")}</label><input id="a-phone" name="phone" required className="field" autoComplete="tel" /></div>}
      <div><label className="label" htmlFor="a-pw">{t("Password")}</label><input id="a-pw" name="password" type="password" required minLength={mode === "register" ? 10 : 1} className="field" autoComplete={mode === "login" ? "current-password" : "new-password"} />
        {mode === "register" && <p className="mt-1 text-xs text-ink-mute">{t("At least 10 characters with a number.")}</p>}</div>
      {mode === "register" && <label className="flex gap-2 text-sm"><input type="checkbox" name="optin" className="accent-ink" /> {t("Send me first looks and private previews")}</label>}
      {s?.error && <p className="text-sm text-red-700" role="alert">{t(s.error)}</p>}
      <button disabled={pending} className="btn-ink w-full">{mode === "login" ? t("Sign in") : t("Create account")}</button>
    </form>
  );
}
