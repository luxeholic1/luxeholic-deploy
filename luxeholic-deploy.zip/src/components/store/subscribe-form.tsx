"use client";
import { useActionState } from "react";
import { subscribe } from "@/app/(store)/actions";
import { useT } from "@/lib/i18n/client";

export function SubscribeForm({ tone = "dark" }: { tone?: "dark" | "light" }) {
  const [state, action, pending] = useActionState(subscribe, null);
  const t = useT();
  if (state?.ok) return <p className={`text-sm ${tone === "dark" ? "text-ivory/85" : "text-ink-soft"}`}>{t("Welcome to the circle. Watch your inbox for first looks.")}</p>;
  return (
    <form action={action} className="flex">
      <label htmlFor={`sub-${tone}`} className="sr-only">{t("Email address")}</label>
      <input id={`sub-${tone}`} name="email" type="email" required placeholder={t("Your email for first looks")}
        className={`min-w-0 flex-1 border-b bg-transparent py-3 text-sm outline-none ${tone === "dark" ? "border-ivory/30 text-ivory placeholder:text-ivory/40 focus:border-ivory" : "border-ink/30 placeholder:text-ink-mute/60 focus:border-ink"}`} />
      <button disabled={pending} className={`border-b px-4 text-[11px] uppercase tracking-[0.22em] ${tone === "dark" ? "border-ivory/30" : "border-ink/30"}`}>{t("Join")}</button>
      {state?.error && <p className="ml-3 self-center text-xs text-red-300">{t(state.error)}</p>}
    </form>
  );
}
