"use client";
import { useActionState, useEffect, useRef } from "react";
import { useT } from "@/lib/i18n/client";

type S = { ok?: string; error?: string } | null;

/** Form bound to a server action that returns { ok } or { error }; shows the message under the button. */
export function ActionForm({ action, submit, children, className, resetOnOk, busy }: {
  action: (s: S, fd: FormData) => Promise<S>; submit: string; children: React.ReactNode; className?: string; resetOnOk?: boolean; busy?: string;
}) {
  const [state, run, pending] = useActionState<S, FormData>(action, null);
  const ref = useRef<HTMLFormElement>(null);
  const t = useT();
  useEffect(() => { if (state?.ok && resetOnOk) ref.current?.reset(); }, [state, resetOnOk]);
  return (
    <form ref={ref} action={run} className={className}>
      {children}
      <div className="mt-5 flex flex-wrap items-center gap-4">
        <button className="btn-ink !py-3" disabled={pending}>{pending ? busy ?? t("Saving…") : submit}</button>
        {state?.error && <p role="alert" className="text-sm text-red-700">{t(state.error)}</p>}
        {state?.ok && <p role="status" className="text-sm text-emerald-800">{t(state.ok)}</p>}
      </div>
    </form>
  );
}
