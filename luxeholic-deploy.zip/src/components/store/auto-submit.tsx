"use client";
import { useEffect, useRef } from "react";
import { useT } from "@/lib/i18n/client";

export function AutoSubmit({ action, fields }: { action: string; fields: Record<string, string> }) {
  const ref = useRef<HTMLFormElement>(null);
  const t = useT();
  useEffect(() => { ref.current?.submit(); }, []);
  return (
    <form ref={ref} action={action} method="post" className="mt-8">
      {Object.entries(fields).map(([k, v]) => <input key={k} type="hidden" name={k} value={v} />)}
      <noscript><button className="btn-ink">{t("Continue to payment")}</button></noscript>
    </form>
  );
}
