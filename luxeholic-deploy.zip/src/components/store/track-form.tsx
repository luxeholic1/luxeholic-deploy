"use client";
import { useActionState } from "react";
import { trackOrder } from "@/app/(store)/actions";
import { useT } from "@/lib/i18n/client";

export function TrackForm() {
  const [s, action, pending] = useActionState(trackOrder, null);
  const t = useT();
  return (
    <form action={action} className="space-y-4">
      <div><label className="label" htmlFor="t-num">{t("Order number")}</label><input id="t-num" name="number" required placeholder="LX261008-ABCDE" className="field uppercase" /></div>
      <div><label className="label" htmlFor="t-email">{t("Email")}</label><input id="t-email" name="email" type="email" required className="field" /></div>
      {s?.error && <p className="text-sm text-red-700">{t(s.error)}</p>}
      <button disabled={pending} className="btn-ink">{t("Find my order")}</button>
    </form>
  );
}
