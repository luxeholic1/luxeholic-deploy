/**
 * Product imagery. Real vendor photos when present; otherwise a calm gallery-style
 * placeholder (plinth + object silhouette) so the catalogue never shows broken images.
 */
const PALETTES = [
  ["#EFE8DC", "#D9CBB3", "#0E0D0B"],
  ["#ECE6DD", "#C9B79A", "#7E6133"],
  ["#E9E4DA", "#BFB4A3", "#2A2723"],
  ["#F1EBE1", "#D5C2A2", "#A8834A"],
  ["#E6E1D8", "#B7AC9B", "#3B3631"],
];
function hash(s: string) { let h = 0; for (let i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) | 0; return Math.abs(h); }

export function ArtPlaceholder({ seed, label, className = "" }: { seed: string; label?: string; className?: string }) {
  const h = hash(seed);
  const [bg, mid, ink] = PALETTES[h % PALETTES.length];
  const shape = h % 5;
  const id = `g${h}`;
  return (
    <svg viewBox="0 0 400 500" className={className} role={label ? "img" : "presentation"} aria-label={label || undefined} aria-hidden={label ? undefined : true} preserveAspectRatio="xMidYMid slice">
      <defs>
        <radialGradient id={id} cx="50%" cy="35%" r="75%">
          <stop offset="0" stopColor="#FFFDF8" />
          <stop offset="1" stopColor={bg} />
        </radialGradient>
      </defs>
      <rect width="400" height="500" fill={`url(#${id})`} />
      <ellipse cx="200" cy="398" rx="120" ry="10" fill={mid} opacity=".45" />
      <rect x="130" y="340" width="140" height="58" fill={mid} opacity=".9" />
      <rect x="130" y="340" width="140" height="4" fill={ink} opacity=".15" />
      {shape === 0 && <path d="M200 140 L262 340 H138 Z" fill={ink} />}
      {shape === 1 && <><circle cx="200" cy="250" r="78" fill="none" stroke={ink} strokeWidth="14" /><circle cx="200" cy="250" r="34" fill={ink} opacity=".85" /></>}
      {shape === 2 && <path d="M168 340 C150 290 160 230 180 210 C165 190 170 160 200 150 C230 160 235 190 220 210 C240 230 250 290 232 340 Z" fill={ink} />}
      {shape === 3 && <path d="M150 340 V230 A50 50 0 0 1 250 230 V340 Z" fill="none" stroke={ink} strokeWidth="12" />}
      {shape === 4 && <><rect x="170" y="170" width="60" height="170" fill={ink} /><rect x="150" y="150" width="100" height="22" fill={ink} opacity=".75" /></>}
    </svg>
  );
}

export function ProductImage({ src, seed, alt, className = "" }: { src?: string | null; seed: string; alt: string; className?: string }) {
  if (!src) return <ArtPlaceholder seed={seed} label={alt} className={`h-full w-full ${className}`} />;
  // eslint-disable-next-line @next/next/no-img-element
  return <img src={src} alt={alt} loading="lazy" decoding="async" className={`h-full w-full object-cover ${className}`} />;
}
