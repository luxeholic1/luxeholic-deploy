"use client";
import { useEffect, useRef, useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { Globe } from "lucide-react";
import { setPrefs } from "@/app/(store)/prefs-actions";
import { usePrefs, useT } from "@/lib/i18n/client";
import { CURRENCIES, LOCALE_INFO, type Currency } from "@/lib/i18n/config";

const SYMBOL: Record<Currency, string> = { INR: "₹", USD: "$", GBP: "£", EUR: "€", AED: "د.إ", AUD: "A$", CAD: "C$", SGD: "S$", NZD: "NZ$" };
function curName(c: Currency, intl: string) {
  try { return new Intl.DisplayNames([intl], { type: "currency" }).of(c) ?? c; } catch { return c; }
}

/** Globe pill: language + currency. Switching re-renders every page in the chosen language — nothing stays in the other one. */
export function PrefsSwitcher({ compact = false, align = "right" }: { compact?: boolean; align?: "left" | "right" }) {
  const { locale, currency, rates, languages } = usePrefs();
  const t = useT();
  const router = useRouter();
  const [open, setOpen] = useState(false);
  const [pending, start] = useTransition();
  const box = useRef<HTMLDivElement>(null);
  useEffect(() => {
    if (!open) return;
    const off = (e: MouseEvent) => { if (!box.current?.contains(e.target as Node)) setOpen(false); };
    const esc = (e: KeyboardEvent) => e.key === "Escape" && setOpen(false);
    document.addEventListener("mousedown", off); document.addEventListener("keydown", esc);
    return () => { document.removeEventListener("mousedown", off); document.removeEventListener("keydown", esc); };
  }, [open]);
  const choose = (k: "lang" | "cur", v: string) => start(async () => {
    const fd = new FormData(); fd.set(k, v); await setPrefs(fd);
    if (k === "lang") { const i = LOCALE_INFO[v as keyof typeof LOCALE_INFO]; const h = document.documentElement; h.lang = i.html; h.dir = i.dir ?? "ltr"; h.classList.toggle("lang-hi", v === "hi"); h.classList.toggle("lang-script", !!i.font && v !== "hi"); }
    setOpen(false); router.refresh();
  });
  const curs = CURRENCIES.filter((c) => c === "INR" || rates[c as Currency]);
  return (
    <div ref={box} className="relative">
      <button type="button" onClick={() => setOpen((o) => !o)} aria-expanded={open} aria-haspopup="dialog" aria-label={t("Language and currency")}
        className={`flex items-center gap-1.5 rounded-full border border-ivory-line px-2.5 py-1.5 text-[11px] font-medium tracking-wide hover:border-ink ${pending ? "opacity-60" : ""}`}>
        <Globe size={14} strokeWidth={1.5} />{!compact && <span>{LOCALE_INFO[locale].label} · {SYMBOL[currency]}</span>}
      </button>
      {open && (
        <div role="dialog" aria-label={t("Language and currency")} className={`absolute ${align === "left" ? "left-0" : "right-0"} top-full z-50 mt-2 w-72 max-w-[calc(100vw-2rem)] border border-ivory-line bg-ivory p-4 shadow-xl`} >
          <p className="label">{t("Language")}</p>
          <div className="grid grid-cols-2 gap-1.5">
            {languages.map((l) => (
              <button key={l} type="button" lang={LOCALE_INFO[l].html} onClick={() => choose("lang", l)} aria-pressed={locale === l}
                className={`border px-3 py-2 text-sm ${locale === l ? "border-ink bg-ink text-ivory" : "border-ivory-line hover:border-ink"}`}>{LOCALE_INFO[l].label}</button>
            ))}
          </div>
          <p className="label mt-4">{t("Currency")}</p>
          <div className="grid grid-cols-2 gap-1.5">
            {curs.map((c) => (
              <button key={c} type="button" onClick={() => choose("cur", c)} aria-pressed={currency === c}
                className={`flex items-baseline gap-1.5 border px-3 py-2 text-left text-sm ${currency === c ? "border-ink bg-ink text-ivory" : "border-ivory-line hover:border-ink"}`}><b className="font-medium">{SYMBOL[c]}</b><span className="text-[12px] leading-tight">{curName(c, LOCALE_INFO[locale].intl)}</span></button>
            ))}
          </div>
          {currency !== "INR" && <p className="mt-3 text-xs leading-relaxed text-ink-mute">{t("Prices are converted for display. You pay in Indian rupees (₹) at checkout.")}</p>}
        </div>
      )}
    </div>
  );
}
