"use client";
import Link from "next/link";
import { useState } from "react";
import { AuthForm } from "./auth-form";
import { TrackForm } from "./track-form";
import { LoginForm as TeamLoginForm } from "@/app/team/login/form";
import { useT } from "@/lib/i18n/client";

type Tab = "customer" | "guest" | "team";
const TABS: { key: Tab; label: string; hint: string }[] = [
  { key: "customer", label: "Customer", hint: "Orders, addresses, faster checkout" },
  { key: "guest", label: "Guest", hint: "Shop without an account" },
  { key: "team", label: "Luxeholic Team", hint: "Staff workspace" },
];

export function LoginTabs({ initial, next, teams }: { initial: Tab; next?: string; teams: { slug: string; name: string }[] }) {
  const [tab, setTab] = useState<Tab>(initial);
  const tr = useT();
  return (
    <div className="mt-8">
      <div role="tablist" aria-label={tr("Sign in as")} className="grid grid-cols-3 border border-ivory-line bg-white/50">
        {TABS.map((t) => (
          <button key={t.key} role="tab" aria-selected={tab === t.key} onClick={() => setTab(t.key)}
            className={`px-3 py-3.5 text-left transition ${tab === t.key ? "bg-ink text-ivory" : "hover:bg-ivory-deep"}`}>
            <span className="block text-[13px] font-medium">{tr(t.label)}</span>
            <span className={`mt-0.5 block text-[11px] leading-snug ${tab === t.key ? "text-ivory/70" : "text-ink-mute"}`}>{tr(t.hint)}</span>
          </button>
        ))}
      </div>

      {tab === "customer" && (
        <div role="tabpanel">
          <AuthForm mode="login" next={next} />
          <p className="mt-6 text-sm text-ink-soft">{tr("New to Luxeholic?")} <Link href={`/account/register${next ? `?next=${encodeURIComponent(next)}` : ""}`} className="underline">{tr("Create an account")}</Link></p>
        </div>
      )}

      {tab === "guest" && (
        <div role="tabpanel" className="mt-10 space-y-10">
          <div>
            <p className="font-display text-2xl">{tr("Shop as a guest")}</p>
            <p className="mt-2 text-sm text-ink-soft">{tr("No account needed. Browse, add to bag and check out with just your email and mobile number. Your order link is emailed to you.")}</p>
            <div className="mt-5 flex flex-wrap gap-3">
              <Link href="/shop" className="btn-ink">{tr("Start shopping")}</Link>
              <Link href="/guest" className="btn-line">{tr("My guest orders")}</Link>
              {next === "/checkout" && <Link href="/checkout" className="btn-line">{tr("Continue to checkout")}</Link>}
            </div>
          </div>
          <div className="border-t border-ivory-line pt-8">
            <p className="font-display text-2xl">{tr("Already ordered as a guest?")}</p>
            <p className="mb-5 mt-2 text-sm text-ink-soft">{tr("Find your order with the order number and email.")}</p>
            <TrackForm />
          </div>
        </div>
      )}

      {tab === "team" && (
        <div role="tabpanel" className="mt-2">
          <TeamLoginForm teams={teams} />
        </div>
      )}
    </div>
  );
}
