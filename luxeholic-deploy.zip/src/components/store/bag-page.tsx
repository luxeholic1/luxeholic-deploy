"use client";
import Link from "next/link";
import { Minus, Plus } from "lucide-react";
import { useCart } from "./cart";
import { ProductImage } from "./art";
import { useMoney, usePrefs, useT } from "@/lib/i18n/client";
import { brandName } from "@/lib/i18n/config";

export function BagPage() {
  const { items, subtotal, setQty, remove, ready } = useCart();
  const t = useT();
  const formatINR = useMoney();
  const { locale } = usePrefs();
  if (!ready) return <div className="h-60" />;
  if (!items.length) return (
    <div className="py-24 text-center"><p className="h-display text-3xl italic">{t("Your bag is waiting.")}</p><Link href="/shop" className="btn-ink mt-8">{t("Discover the collection")}</Link></div>
  );
  return (
    <div className="mt-10 grid gap-12 lg:grid-cols-[1fr_380px]">
      <ul className="divide-y divide-ivory-line border-y border-ivory-line">
        {items.map((i) => (
          <li key={i.productId + (i.variantId ?? "")} className="flex gap-5 py-6">
            <Link href={`/p/${i.slug}`} className="h-36 w-28 shrink-0 overflow-hidden bg-ivory-deep"><ProductImage src={i.image} seed={i.slug} alt={i.missing ? "" : i.title} /></Link>
            <div className="flex flex-1 flex-col">
              {i.brand && <p className="eyebrow !text-[10px]">{brandName(i.brand, locale)}</p>}
              <Link href={`/p/${i.slug}`} className="font-display text-xl">{i.missing ? t("Saved piece") : i.title}</Link>
              {i.variant && !i.missing && <p className="text-sm text-ink-mute">{i.variant}</p>}
              <div className="mt-auto flex items-center justify-between">
                <div className="flex items-center border border-ivory-line">
                  <button className="p-2" aria-label={t("Decrease")} onClick={() => setQty(i.productId, i.variantId, i.qty - 1)}><Minus size={13} /></button>
                  <span className="w-8 text-center text-sm">{i.qty}</span>
                  <button className="p-2" aria-label={t("Increase")} onClick={() => setQty(i.productId, i.variantId, i.qty + 1)}><Plus size={13} /></button>
                </div>
                <button className="text-xs text-ink-mute underline" onClick={() => remove(i.productId, i.variantId)}>{t("Remove")}</button>
                <p>{formatINR(i.price * i.qty)}</p>
              </div>
            </div>
          </li>
        ))}
      </ul>
      <aside className="card-lx h-fit p-7">
        <div className="flex justify-between"><span>{t("Subtotal")}</span><span>{formatINR(subtotal)}</span></div>
        <div className="mt-2 flex justify-between text-sm text-ink-mute"><span>{t("Shipping")}</span><span>{t("Complimentary")}</span></div>
        <p className="mt-4 text-xs text-ink-mute">{t("Prices include GST. Coupons can be applied at checkout.")}</p>
        <Link href="/checkout" className="btn-ink mt-6 w-full">{t("Proceed to checkout")}</Link>
      </aside>
    </div>
  );
}
