"use client";
import Link from "next/link";
import { useActionState, useEffect, useMemo, useState, useTransition } from "react";
import { useCart } from "./cart";
import { ProductImage } from "./art";
import { useMoney, usePrefs, useT } from "@/lib/i18n/client";
import { formatMoney } from "@/lib/i18n/config";
import { placeOrder, quote } from "@/app/(store)/actions";

const STATES = ["Andaman and Nicobar Islands", "Andhra Pradesh", "Arunachal Pradesh", "Assam", "Bihar", "Chandigarh", "Chhattisgarh", "Dadra and Nagar Haveli and Daman and Diu", "Delhi", "Goa", "Gujarat", "Haryana", "Himachal Pradesh", "Jammu and Kashmir", "Jharkhand", "Karnataka", "Kerala", "Ladakh", "Lakshadweep", "Madhya Pradesh", "Maharashtra", "Manipur", "Meghalaya", "Mizoram", "Nagaland", "Odisha", "Puducherry", "Punjab", "Rajasthan", "Sikkim", "Tamil Nadu", "Telangana", "Tripura", "Uttar Pradesh", "Uttarakhand", "West Bengal"];

type Pay = { payu: boolean; phonepe: boolean; bank: boolean; cod: boolean; partialCod: boolean; codMax: number; partialMax: number; advancePercent: number; codFee: number };
type Addr = { name: string; phone: string; line1: string; line2: string | null; city: string; state: string; pincode: string } | null;
type Q = Awaited<ReturnType<typeof quote>>;

export function CheckoutForm({ customer, address, pay, returnsDays }: { customer: { name: string; email: string; phone: string } | null; address: Addr; pay: Pay; returnsDays: number }) {
  const { items, ready, setQty } = useCart();
  const t = useT();
  const { locale, currency } = usePrefs();
  const approx = useMoney();
  // Checkout is charged in rupees; other currencies are shown as an estimate beside the total.
  const formatINR = (p: number) => formatMoney(p, "INR", {}, locale);
  const [state, action, pending] = useActionState(placeOrder, null);
  const [q, setQ] = useState<Q | null>(null);
  const [coupon, setCoupon] = useState("");
  const [applied, setApplied] = useState("");
  const [loading, start] = useTransition();
  const lines = useMemo(() => items.map((i) => ({ productId: i.productId, variantId: i.variantId ?? null, qty: i.qty })), [items]);

  useEffect(() => {
    if (!ready || !lines.length) return;
    start(async () => {
      const r = await quote(lines, applied || undefined);
      setQ(r);
      // reconcile bag with live prices/stock
      for (const i of items) {
        const live = r.items.find((x) => x.productId === i.productId && (x.variantId ?? null) === (i.variantId ?? null));
        if (!live) setQty(i.productId, i.variantId, 0);
        else if (live.qty < i.qty) setQty(i.productId, i.variantId, live.qty);
      }
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [ready, JSON.stringify(lines), applied]);

  const total = q?.total ?? 0;
  const options = [
    pay.payu && { id: "PAYU", title: t("UPI · Cards · Netbanking"), note: t("Secure payment via PayU") },
    pay.phonepe && { id: "PHONEPE", title: t("PhonePe"), note: t("UPI, cards & wallets via PhonePe") },
    pay.partialCod && total <= pay.partialMax && { id: "PARTIAL_COD", title: t("Pay {pct}% now, rest on delivery", { pct: pay.advancePercent }), note: t("{now} today · {later} in cash/UPI at your door", { now: formatINR(Math.ceil((total + pay.codFee) * pay.advancePercent / 10000) * 100), later: formatINR(total + pay.codFee - Math.ceil((total + pay.codFee) * pay.advancePercent / 10000) * 100) }) },
    pay.bank && { id: "BANK_TRANSFER", title: t("Bank transfer (NEFT / RTGS / IMPS)"), note: t("We’ll show our account details after you place the order") },
    pay.cod && total <= pay.codMax && { id: "COD", title: t("Cash on delivery"), note: t("Our team will call to confirm before dispatch") + (pay.codFee ? " · " + t("{fee} COD fee", { fee: formatINR(pay.codFee) }) : "") },
  ].filter(Boolean) as { id: string; title: string; note: string }[];
  const [method, setMethod] = useState<string>("");
  const chosen = options.find((o) => o.id === method) ? method : options[0]?.id ?? "";
  const f = state?.fields ?? {};
  const d = (k: string, fallback = "") => f[k] ?? fallback;

  if (!ready) return <div className="h-80" />;
  if (!items.length) return (
    <div className="py-24 text-center"><p className="h-display text-3xl italic">{t("Your bag is empty.")}</p><Link href="/shop" className="btn-ink mt-8">{t("Discover the collection")}</Link></div>
  );

  return (
    <form action={action} className="mt-10 grid gap-12 lg:grid-cols-[1fr_420px]">
      <input type="hidden" name="lines" value={JSON.stringify(lines)} />
      <input type="hidden" name="coupon" value={applied} />
      <div className="space-y-12">
        {!customer && (
          <p className="text-sm text-ink-soft">{t("Checking out as a guest.")} <Link href="/login?next=/checkout" className="underline">{t("Sign in")}</Link> {t("for faster checkout and order history.")}</p>
        )}
        <section>
          <h2 className="eyebrow !text-ink">{t("1 · Contact")}</h2>
          <div className="mt-5 grid gap-4 sm:grid-cols-2">
            <div><label className="label" htmlFor="email">{t("Email")}</label><input className="field" id="email" name="email" type="email" required defaultValue={d("email", customer?.email)} autoComplete="email" /></div>
            <div><label className="label" htmlFor="phone">{t("Mobile number")}</label><input className="field" id="phone" name="phone" inputMode="tel" required defaultValue={d("phone", address?.phone ?? customer?.phone)} placeholder={t("10-digit mobile")} autoComplete="tel-national" /></div>
          </div>
        </section>
        <section>
          <h2 className="eyebrow !text-ink">{t("2 · Delivery address")}</h2>
          <div className="mt-5 grid gap-4 sm:grid-cols-2">
            <div className="sm:col-span-2"><label className="label" htmlFor="name">{t("Full name")}</label><input className="field" id="name" name="name" required defaultValue={d("name", address?.name ?? customer?.name)} autoComplete="name" /></div>
            <div className="sm:col-span-2"><label className="label" htmlFor="line1">{t("House / flat, street")}</label><input className="field" id="line1" name="line1" required defaultValue={d("line1", address?.line1)} autoComplete="address-line1" /></div>
            <div className="sm:col-span-2"><label className="label" htmlFor="line2">{t("Area, landmark (optional)")}</label><input className="field" id="line2" name="line2" defaultValue={d("line2", address?.line2 ?? "")} autoComplete="address-line2" /></div>
            <div><label className="label" htmlFor="city">{t("City")}</label><input className="field" id="city" name="city" required defaultValue={d("city", address?.city)} autoComplete="address-level2" /></div>
            <div><label className="label" htmlFor="pincode">{t("PIN code")}</label><input className="field" id="pincode" name="pincode" required inputMode="numeric" maxLength={6} defaultValue={d("pincode", address?.pincode)} autoComplete="postal-code" /></div>
            <div className="sm:col-span-2"><label className="label" htmlFor="state">{t("State")}</label>
              <select className="field" id="state" name="state" required defaultValue={d("state", address?.state ?? "")}>
                <option value="" disabled>{t("Select state")}</option>{STATES.map((s) => <option key={s} value={s}>{t(s)}</option>)}
              </select>
            </div>
            <div className="sm:col-span-2"><label className="label" htmlFor="gstin">{t("GSTIN for business invoice (optional)")}</label><input className="field uppercase" id="gstin" name="gstin" maxLength={15} defaultValue={d("gstin")} /></div>
            <div className="sm:col-span-2"><label className="label" htmlFor="notes">{t("Gift message or delivery note (optional)")}</label><textarea className="field" id="notes" name="notes" rows={2} maxLength={500} defaultValue={d("notes")} /></div>
            {customer && <label className="flex items-center gap-2 text-sm sm:col-span-2"><input type="checkbox" name="saveAddress" defaultChecked={!address} /> {t("Save this address to my account")}</label>}
          </div>
        </section>
        <section>
          <h2 className="eyebrow !text-ink">{t("3 · Payment")}</h2>
          <div className="mt-5 space-y-3">
            {options.map((o) => (
              <label key={o.id} className={`flex cursor-pointer gap-4 border p-5 transition ${chosen === o.id ? "border-ink bg-white" : "border-ivory-line bg-white/50"}`}>
                <input type="radio" name="method" value={o.id} checked={chosen === o.id} onChange={() => setMethod(o.id)} className="mt-1 accent-ink" />
                <span><span className="block">{o.title}</span><span className="mt-0.5 block text-sm text-ink-mute">{o.note}</span>
                  {o.id === "PARTIAL_COD" && chosen === "PARTIAL_COD" && (pay.payu || pay.phonepe) && (
                    <span className="mt-3 flex gap-4 text-sm">
                      {pay.payu && <label className="flex items-center gap-1.5"><input type="radio" name="advanceVia" value="PAYU" defaultChecked className="accent-ink" /> {t("UPI/Card (PayU)")}</label>}
                      {pay.phonepe && <label className="flex items-center gap-1.5"><input type="radio" name="advanceVia" value="PHONEPE" defaultChecked={!pay.payu} className="accent-ink" /> {t("PhonePe")}</label>}
                    </span>
                  )}
                </span>
              </label>
            ))}
            {!options.length && <p className="text-sm text-red-700">{t("No payment method is available right now — please contact us.")}</p>}
          </div>
        </section>
      </div>

      <aside className="h-fit lg:sticky lg:top-28">
        <div className="card-lx p-7">
          <p className="eyebrow !text-ink">{t("Order summary")}</p>
          <ul className="mt-5 max-h-72 space-y-4 overflow-y-auto">
            {items.map((i) => (
              <li key={i.productId + (i.variantId ?? "")} className="flex gap-3">
                <div className="relative h-20 w-16 shrink-0 overflow-hidden bg-ivory-deep"><ProductImage src={i.image} seed={i.slug} alt={i.missing ? "" : i.title} />
                  <span className="absolute -right-1 -top-1 flex h-5 w-5 items-center justify-center rounded-full bg-ink text-[10px] text-ivory">{i.qty}</span></div>
                <div className="flex-1 text-sm"><p className="line-clamp-2">{i.missing ? t("Saved piece") : i.title}</p>{i.variant && !i.missing && <p className="text-xs text-ink-mute">{i.variant}</p>}</div>
                <p className="text-sm">{formatINR(i.price * i.qty)}</p>
              </li>
            ))}
          </ul>
          <div className="mt-6 flex gap-2">
            <input value={coupon} onChange={(e) => setCoupon(e.target.value.toUpperCase())} placeholder={t("Coupon code")} className="field !py-2.5" aria-label={t("Coupon code")} />
            <button type="button" className="btn-line !px-4 !py-2.5" onClick={() => setApplied(coupon.trim())}>{t("Apply")}</button>
          </div>
          <dl className="mt-6 space-y-2 border-t border-ivory-line pt-5 text-sm">
            <div className="flex justify-between"><dt>{t("Subtotal")}</dt><dd>{q ? formatINR(q.subtotal) : "…"}</dd></div>
            {q && q.discount > 0 && <div className="flex justify-between text-gold-dark"><dt>{t("Coupon {code}", { code: q.coupon ?? "" })}</dt><dd>−{formatINR(q.discount)}</dd></div>}
            <div className="flex justify-between"><dt>{t("Shipping (insured)")}</dt><dd>{q ? (q.shippingFee ? formatINR(q.shippingFee) : t("Complimentary")) : "…"}</dd></div>
            {(chosen === "COD" || chosen === "PARTIAL_COD") && pay.codFee > 0 && <div className="flex justify-between"><dt>{t("COD fee")}</dt><dd>{formatINR(pay.codFee)}</dd></div>}
            <div className="flex justify-between border-t border-ivory-line pt-3 text-base"><dt>{t("Total")}</dt><dd>{q ? formatINR(q.total + ((chosen === "COD" || chosen === "PARTIAL_COD") ? pay.codFee : 0)) : "…"}</dd></div>
            {q && currency !== "INR" && <p className="text-right text-xs text-ink-mute">{t("About {amount}. You pay in Indian rupees (₹).", { amount: approx(q.total + ((chosen === "COD" || chosen === "PARTIAL_COD") ? pay.codFee : 0)) })}</p>}
            <p className="text-xs text-ink-mute">{t("Inclusive of GST")}{q?.maxDays ? " · " + t("Delivered in about {n} days", { n: q.maxDays }) : ""}</p>
          </dl>
          {q?.problems.map((p) => <p key={p} className="mt-3 text-xs text-red-700">{p}</p>)}
          <label className="mt-6 flex items-start gap-2 text-xs leading-relaxed text-ink-soft">
            <input type="checkbox" name="terms" required className="mt-0.5 accent-ink" />
            <span>{t("I agree to the")} <Link href="/policies/terms" className="underline" target="_blank">{t("terms")}</Link>, <Link href="/policies/returns" className="underline" target="_blank">{t("{n}-day returns policy", { n: returnsDays })}</Link> {t("and")} <Link href="/policies/privacy" className="underline" target="_blank">{t("privacy policy")}</Link>{t(".")}</span>
          </label>
          {state?.error && <p className="mt-4 bg-red-50 p-3 text-sm text-red-800" role="alert">{t(state.error)}</p>}
          <button disabled={pending || loading || !q || !options.length} className="btn-ink mt-6 w-full">
            {pending ? t("Placing order…") : chosen === "COD" || chosen === "BANK_TRANSFER" ? t("Place order") : t("Continue to payment")}
          </button>
          <p className="mt-3 text-center text-[11px] text-ink-mute">{t("Payments are encrypted and processed by RBI-regulated gateways.")}</p>
        </div>
      </aside>
    </form>
  );
}
