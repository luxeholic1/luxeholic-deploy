import Link from "next/link";
import { businessAddress, type Settings } from "@/lib/settings";
import { POLICY_PAGES } from "@/lib/site";
import { SubscribeForm } from "./subscribe-form";
import { MARKETPLACES } from "./marketplaces";
import { CookieSettingsButton } from "./consent";
import { CallbackButton } from "./callback";
import { getI18n } from "@/lib/i18n/server";
import { siteTexts } from "@/lib/i18n/content";
import { brandName } from "@/lib/i18n/config";

export async function Footer({ settings, tree }: { settings: Settings; tree: { slug: string; name: string }[] }) {
  const b = settings.business;
  const { t, money, locale } = await getI18n();
  const tx = await siteTexts({ legalName: b.legalName, address: businessAddress(b), supportHours: b.supportHours }, locale);
  const socials = [[t("Instagram"), b.instagram], [t("Facebook"), b.facebook], [t("Pinterest"), b.pinterest], [t("YouTube"), b.youtube]].filter(([, u]) => u);
  return (
    <footer className="mt-24 bg-ink text-ivory">
      <div className="container-lx grid gap-14 py-16 lg:grid-cols-[1.3fr_1fr_1fr_1fr]">
        <div>
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img src="/brand/mark-light.png" alt="" className="h-14 w-auto" />
          <p className="h-display mt-6 max-w-sm text-3xl italic">{t("New in the city. Here to win your heart, one piece at a time.")}</p>
          <div className="mt-8 max-w-sm"><SubscribeForm /></div>
        </div>
        <div>
          <p className="eyebrow !text-ivory/60">{t("Shop")}</p>
          <ul className="mt-5 space-y-3 text-sm text-ivory/85">
            {tree.map((c) => <li key={c.slug}><Link className="link-u" href={`/c/${c.slug}`}>{c.name}</Link></li>)}
            <li><Link className="link-u" href="/collections/first-luxe">{t("First Luxe · under {price}", { price: money(500000) })}</Link></li>
            <li><Link className="link-u" href="/collections/new-arrivals">{t("New Arrivals")}</Link></li>
          </ul>
        </div>
        <div>
          <p className="eyebrow !text-ivory/60">{t("Client care")}</p>
          <ul className="mt-5 space-y-3 text-sm text-ivory/85">
            <li><Link className="link-u" href="/contact">{t("Contact us")}</Link></li>
            <li><CallbackButton className="link-u text-left">{t("Request a call back")}</CallbackButton></li>
            <li><Link className="link-u" href="/account">{t("My account")}</Link></li>
            <li><Link className="link-u" href="/guest">{t("Guest orders")}</Link></li>
            <li><Link className="link-u" href="/track-order">{t("Track your order")}</Link></li>
            <li><Link className="link-u" href="/faq">{t("FAQ")}</Link></li>
            <li><Link className="link-u" href="/about">{t("Our story")}</Link></li>
            {POLICY_PAGES.map((p) => <li key={p.slug}><Link className="link-u" href={`/policies/${p.slug}`}>{t(p.title)}</Link></li>)}
          </ul>
        </div>
        <div>
          <p className="eyebrow !text-ivory/60">{t("Reach us")}</p>
          <address className="mt-5 space-y-2 text-sm not-italic text-ivory/85">
            {tx.legalName && <p>{tx.legalName}</p>}
            <p>{tx.address}</p>
            {b.phone && <p>{t("Customer care:")} <a href={`tel:${b.phone.replace(/\s/g, "")}`}>{b.phone}</a></p>}
            <p><a href={`mailto:${b.email}`}>{b.email}</a></p>
            <p className="text-ivory/60">{tx.supportHours}</p>
            {b.gstin && <p className="text-ivory/60">{t("GSTIN")} {b.gstin}</p>}
            {b.iec && <p className="text-ivory/60">{t("IEC")} {b.iec}</p>}
          </address>
          <p className="eyebrow mt-6 !text-ivory/60">{t("Also on")}</p>
          <ul className="mt-2 flex flex-wrap gap-x-4 gap-y-1 text-sm text-ivory/85">
            {MARKETPLACES.map((m) => {
              const url = settings.marketplaces[m.key];
              return <li key={m.key}>{url ? <a href={url} target="_blank" rel="noopener noreferrer" className="link-u">{t(m.name)}</a> : t(m.name)}</li>;
            })}
          </ul>
          {socials.length > 0 && (
            <ul className="mt-6 flex flex-wrap gap-4 text-xs uppercase tracking-[0.2em] text-ivory/70">
              {socials.map(([n, u]) => <li key={n}><a href={u} target="_blank" rel="noopener noreferrer" className="link-u">{n}</a></li>)}
            </ul>
          )}
        </div>
      </div>
      <div className="border-t border-ivory/10">
        <div className="container-lx flex flex-col gap-3 py-6 text-[11px] uppercase tracking-[0.18em] text-ivory/50 sm:flex-row sm:items-center sm:justify-between">
          <p>© {new Date().getFullYear()} {brandName("Luxeholic", locale)}{b.trademark}. {t("All prices in INR, inclusive of GST.")}</p>
          <p>{t("UPI · Cards · Netbanking · PhonePe · Bank transfer · Cash on delivery")}</p>
          <span className="flex gap-5"><CookieSettingsButton className="link-u uppercase tracking-[0.18em]" /><Link href="/login?as=team" className="link-u" rel="nofollow">{t("Team login")}</Link></span>
        </div>
      </div>
    </footer>
  );
}
