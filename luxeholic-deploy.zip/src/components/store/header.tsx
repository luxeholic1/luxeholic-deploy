"use client";
import Link from "next/link";
import { useEffect, useRef, useState } from "react";
import { usePathname } from "next/navigation";
import { ChevronDown, ChevronRight, LayoutGrid, Menu, Search, ShoppingBag, User, X } from "lucide-react";
import { useCart } from "./cart";
import { PrefsSwitcher } from "./prefs-switcher";
import { useMoney, useT } from "@/lib/i18n/client";

type Cat = { slug: string; name: string; tagline: string | null; children: { slug: string; name: string }[] };

export function Header({ tree, announcement, signedIn, tm = "™" }: { tree: Cat[]; announcement: string; signedIn: boolean; tm?: string }) {
  const { count, setOpen, ready } = useCart();
  const t = useT();
  const money = useMoney();
  const [mega, setMega] = useState<string | null>(null);
  const [mobile, setMobile] = useState(false);
  const [search, setSearch] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const path = usePathname();
  useEffect(() => { setMobile(false); setMega(null); setSearch(false); }, [path]);
  useEffect(() => {
    const on = () => setScrolled(window.scrollY > 8);
    on(); window.addEventListener("scroll", on, { passive: true });
    return () => window.removeEventListener("scroll", on);
  }, []);
  const active = tree.find((c) => c.slug === mega);
  // small hover-intent delay so the menu doesn't flicker while the pointer travels into it
  const timer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const open = (key: string | null) => { if (timer.current) clearTimeout(timer.current); setMega(key); };
  const closeSoon = () => { if (timer.current) clearTimeout(timer.current); timer.current = setTimeout(() => setMega(null), 180); };
  useEffect(() => {
    const esc = (e: KeyboardEvent) => e.key === "Escape" && setMega(null);
    window.addEventListener("keydown", esc);
    return () => window.removeEventListener("keydown", esc);
  }, []);
  const navItem = (on: boolean) =>
    `flex h-12 items-center gap-1.5 border-b-2 px-3 text-[13.5px] font-medium tracking-[0.04em] transition-colors ${on ? "border-gold text-ink" : "border-transparent text-ink-soft hover:border-ink/30 hover:text-ink"}`;

  return (
    <>
      {announcement && (
        <div className="bg-ink py-2 text-center text-[10.5px] uppercase tracking-[0.22em] text-ivory/90">
          <div className="container-lx truncate">{announcement}</div>
        </div>
      )}
      <header className={`sticky top-0 z-40 border-b transition-colors duration-300 ${scrolled ? "border-ivory-line bg-ivory/95 backdrop-blur" : "border-transparent bg-ivory"}`} onMouseLeave={closeSoon}>
        <div className="container-lx grid h-[64px] grid-cols-[1fr_auto_1fr] items-center lg:h-[72px]">
          <div className="flex items-center gap-1">
            <button className="-ml-2 p-2 lg:hidden" aria-label={t("Open menu")} onClick={() => setMobile(true)}><Menu size={20} strokeWidth={1.4} /></button>
            <button className="p-2 lg:-ml-2" aria-label={t("Search")} onClick={() => setSearch((s) => !s)}><Search size={19} strokeWidth={1.4} /></button>
          </div>
          <Link href="/" aria-label={t("Luxeholic home")} className="flex items-center justify-center">
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img src="/brand/wordmark-dark.png" alt="Luxeholic" width={640} height={94} className="h-[15px] w-auto sm:h-[19px]" />
            {tm && <sup className="ml-0.5 self-start pt-1 text-[9px] leading-none text-ink-soft" aria-label={tm === "®" ? t("registered trademark") : t("trademark")}>{tm}</sup>}
          </Link>
          <div className="flex items-center justify-end gap-1 sm:gap-2">
            <span className="hidden sm:block"><PrefsSwitcher /></span>
            <Link href={signedIn ? "/account" : "/login"} className="p-2" aria-label={t("Account")}><User size={19} strokeWidth={1.4} /></Link>
            <button className="relative -mr-2 p-2" aria-label={t("Shopping bag")} onClick={() => setOpen(true)}>
              <ShoppingBag size={19} strokeWidth={1.4} />
              {ready && count > 0 && <span className="absolute right-0.5 top-0.5 flex h-4 min-w-4 items-center justify-center rounded-full bg-ink px-1 text-[9px] text-ivory">{count}</span>}
            </button>
          </div>
        </div>
        <nav className="hidden border-t border-ivory-line/70 lg:block" aria-label={t("Main")} data-tree={JSON.stringify(tree.map((c) => ({ s: c.slug, n: c.name, t: c.tagline, c: c.children.map((x) => [x.slug, x.name]) })))}>
          <ul className="container-lx flex items-stretch justify-center gap-1 xl:gap-3">
            <li>
              <button type="button" onMouseEnter={() => open("all")} onFocus={() => open("all")} onClick={() => setMega(mega === "all" ? null : "all")}
                aria-expanded={mega === "all"} className={navItem(mega === "all")}>
                <LayoutGrid size={15} strokeWidth={1.6} />{t("All categories")}
              </button>
            </li>
            {tree.map((c) => (
              <li key={c.slug}>
                <Link href={`/c/${c.slug}`} onMouseEnter={() => open(c.slug)} onFocus={() => open(c.slug)} aria-expanded={mega === c.slug}
                  className={navItem(mega === c.slug || path.startsWith(`/c/${c.slug}`) || c.children.some((x) => path === `/c/${x.slug}`))}>
                  {c.name}
                  {c.slug === "lux-tech" && <span className="rounded-full bg-gold px-1.5 py-px text-[9px] font-semibold uppercase tracking-wider text-white">{t("New")}</span>}
                  <ChevronDown size={14} strokeWidth={1.8} className={`transition ${mega === c.slug ? "rotate-180" : ""}`} />
                </Link>
              </li>
            ))}
            <li><Link href="/collections/first-luxe" onMouseEnter={() => open(null)} className={navItem(false) + " !text-gold-dark"}>{t("Under {price}", { price: money(500000) })}</Link></li>
          </ul>
        </nav>

        {/* Mega menu — every category, with its sub-categories, on hover */}
        {mega && (
          <div className="absolute inset-x-0 top-full hidden border-y border-ivory-line bg-ivory shadow-[0_30px_60px_-30px_rgba(14,13,11,.3)] lg:block" onMouseEnter={() => open(mega)}>
            {mega === "all" ? (
              <div className="container-lx grid grid-cols-5 gap-8 py-9">
                {tree.map((c) => (
                  <div key={c.slug}>
                    <Link href={`/c/${c.slug}`} className="block border-b border-ivory-line pb-3 text-[15px] font-semibold text-ink hover:text-gold-dark">{c.name}</Link>
                    <ul className="mt-3 space-y-2">
                      {c.children.map((s) => <li key={s.slug}><Link href={`/c/${s.slug}`} className="block py-0.5 text-[14px] text-ink-soft hover:text-ink hover:underline hover:underline-offset-4">{s.name}</Link></li>)}
                    </ul>
                  </div>
                ))}
              </div>
            ) : active && (
              <div className="container-lx grid grid-cols-[230px_1fr_300px] gap-10 py-8">
                <ul className="space-y-0.5 border-r border-ivory-line pr-6" aria-label={t("Categories")}>
                  {tree.map((c) => (
                    <li key={c.slug}>
                      <Link href={`/c/${c.slug}`} onMouseEnter={() => setMega(c.slug)}
                        className={`flex items-center justify-between rounded px-3 py-2.5 text-[15px] transition ${c.slug === active.slug ? "bg-ink font-medium text-ivory" : "text-ink hover:bg-ivory-deep"}`}>
                        {c.name}<ChevronRight size={15} strokeWidth={1.6} />
                      </Link>
                    </li>
                  ))}
                </ul>
                <div>
                  <p className="text-[12px] font-semibold uppercase tracking-[0.14em] text-ink-mute">{t("{name} · {n} sub-categories", { name: active.name, n: active.children.length })}</p>
                  <ul className="mt-4 grid grid-cols-2 gap-x-8 gap-y-1">
                    {active.children.map((s) => (
                      <li key={s.slug}>
                        <Link href={`/c/${s.slug}`} className="group flex items-center justify-between border-b border-ivory-line/70 py-2.5 text-[15px] text-ink hover:text-gold-dark">
                          {s.name}<ChevronRight size={14} className="opacity-0 transition group-hover:translate-x-0.5 group-hover:opacity-100" />
                        </Link>
                      </li>
                    ))}
                  </ul>
                  <Link href={`/c/${active.slug}`} className="mt-5 inline-flex items-center gap-1.5 text-[13px] font-semibold uppercase tracking-[0.12em] text-ink underline underline-offset-4 hover:text-gold-dark">{t("Shop all {name}", { name: active.name })}<ChevronRight size={14} /></Link>
                </div>
                <div className="bg-ivory-deep p-6">
                  <p className="h-display text-3xl italic">{active.tagline}</p>
                  <p className="mt-5 text-[12px] font-semibold uppercase tracking-[0.14em] text-ink-mute">{t("Shop by budget")}</p>
                  <ul className="mt-2 space-y-1.5 text-[14px]">
                    <li><Link href={`/c/${active.slug}?tier=first-luxe`} className="hover:underline">{t("Under {price}", { price: money(500000) })}</Link></li>
                    <li><Link href={`/c/${active.slug}?tier=signature`} className="hover:underline">{money(500000)} – {money(2500000)}</Link></li>
                    <li><Link href={`/c/${active.slug}?tier=haute`} className="hover:underline">{t("{price} and above", { price: money(2500000) })}</Link></li>
                  </ul>
                </div>
              </div>
            )}
          </div>
        )}

        {search && (
          <form action="/search" className="absolute inset-x-0 top-full border-b border-ivory-line bg-ivory">
            <div className="container-lx flex items-center gap-4 py-5">
              <Search size={18} strokeWidth={1.4} />
              <input name="q" autoFocus placeholder={t("Search sculptures, brands, gifts…")} className="h-display w-full bg-transparent text-2xl italic outline-none placeholder:text-ink-mute/50" />
              <button type="button" onClick={() => setSearch(false)} aria-label={t("Close search")}><X size={18} strokeWidth={1.4} /></button>
            </div>
          </form>
        )}
      </header>

      {/* Mobile drawer */}
      {mobile && (
        <div className="fixed inset-0 z-50 lg:hidden">
          <div className="absolute inset-0 bg-ink/40" onClick={() => setMobile(false)} />
          <div className="absolute inset-y-0 left-0 w-[86%] max-w-sm overflow-y-auto bg-ivory p-6 animate-fadeUp">
            <div className="mb-8 flex items-center justify-between">
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img src="/brand/wordmark-dark.png" alt="Luxeholic" className="h-3.5 w-auto" />
              <button onClick={() => setMobile(false)} aria-label={t("Close menu")}><X size={20} strokeWidth={1.4} /></button>
            </div>
            {tree.map((c) => (
              <details key={c.slug} className="border-b border-ivory-line py-4">
                <summary className="flex cursor-pointer list-none items-center justify-between font-display text-2xl">{c.name}<span className="text-sm text-ink-mute">+</span></summary>
                <ul className="mt-3 space-y-2.5 pl-1">
                  <li><Link href={`/c/${c.slug}`} className="text-sm underline underline-offset-4">{t("All {name}", { name: c.name })}</Link></li>
                  {c.children.map((s) => <li key={s.slug}><Link href={`/c/${s.slug}`} className="text-sm text-ink-soft">{s.name}</Link></li>)}
                </ul>
              </details>
            ))}
            <div className="mt-8 space-y-3 text-sm">
              <PrefsSwitcher align="left" />
              <Link href="/collections/first-luxe" className="block">{t("First Luxe — under {price}", { price: money(500000) })}</Link>
              <Link href="/collections/new-arrivals" className="block">{t("New Arrivals")}</Link>
              <Link href={signedIn ? "/account" : "/login"} className="block">{signedIn ? t("My account") : t("Sign in · Guest · Team")}</Link>
              {!signedIn && <Link href="/guest" className="block">{t("Guest orders")}</Link>}
              <Link href="/track-order" className="block">{t("Track your order")}</Link>
              <Link href="/contact" className="block">{t("Contact us")}</Link>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
