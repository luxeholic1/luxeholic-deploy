"use client";
import { useState } from "react";
import { ProductImage } from "./art";
import { useT } from "@/lib/i18n/client";

export function Gallery({ images, seed, alt }: { images: string[]; seed: string; alt: string }) {
  const [i, setI] = useState(0);
  const t = useT();
  const list = images.length ? images : [null];
  return (
    <div className="grid gap-3 lg:grid-cols-[76px_1fr]">
      {list.length > 1 && (
        <div className="no-scrollbar order-2 flex gap-2 overflow-x-auto lg:order-1 lg:flex-col">
          {list.map((src, n) => (
            <button key={n} onClick={() => setI(n)} aria-label={t("Image {n}", { n: n + 1 })} className={`aspect-[4/5] w-[68px] shrink-0 overflow-hidden bg-ivory-deep ${n === i ? "ring-1 ring-ink" : "opacity-70"}`}>
              <ProductImage src={src} seed={seed} alt="" />
            </button>
          ))}
        </div>
      )}
      <div className={`order-1 aspect-[4/5] overflow-hidden bg-ivory-deep lg:order-2 ${list.length === 1 ? "lg:col-span-2" : ""}`}>
        <ProductImage src={list[i]} seed={seed} alt={alt} />
      </div>
    </div>
  );
}
