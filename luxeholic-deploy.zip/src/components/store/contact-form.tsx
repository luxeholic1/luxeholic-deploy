"use client";
import { useActionState } from "react";
import { contact } from "@/app/(store)/actions";
import { useT } from "@/lib/i18n/client";

export function ContactForm({ order }: { order?: string }) {
  const [s, action, pending] = useActionState(contact, null);
  const t = useT();
  if (s?.ok) return <div className="card-lx p-10"><p className="h-display text-3xl italic">{t("Thank you.")}</p><p className="mt-3 text-ink-soft">{t("We’ve emailed you a reference number and will reply within one working day.")}</p></div>;
  return (
    <form action={action} className="grid gap-4 sm:grid-cols-2">
      <div><label className="label" htmlFor="c-name">{t("Name")}</label><input id="c-name" name="name" required className="field" /></div>
      <div><label className="label" htmlFor="c-email">{t("Email")}</label><input id="c-email" name="email" type="email" required className="field" /></div>
      <div><label className="label" htmlFor="c-phone">{t("Phone (optional)")}</label><input id="c-phone" name="phone" className="field" /></div>
      <div><label className="label" htmlFor="c-order">{t("Order number (optional)")}</label><input id="c-order" name="orderNumber" defaultValue={order} className="field" /></div>
      <div className="sm:col-span-2"><label className="label" htmlFor="c-subject">{t("Subject")}</label><input id="c-subject" name="subject" required className="field" /></div>
      <div className="sm:col-span-2"><label className="label" htmlFor="c-msg">{t("Message")}</label><textarea id="c-msg" name="message" rows={6} required className="field" /></div>
      <input name="website" tabIndex={-1} autoComplete="off" className="hidden" aria-hidden />
      {s?.error && <p className="text-sm text-red-700 sm:col-span-2">{t(s.error)}</p>}
      <div className="sm:col-span-2"><button disabled={pending} className="btn-ink">{pending ? t("Sending…") : t("Send message")}</button></div>
    </form>
  );
}
