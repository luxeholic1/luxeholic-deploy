"use client";
import { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState } from "react";
import { usePrefs } from "@/lib/i18n/client";
import { bagLabels } from "@/app/(store)/bag-actions";

export type BagItem = {
  productId: string; variantId?: string | null; qty: number;
  title: string; variant?: string | null; price: number;
  /** Language the title/variant are written in; relabelled when the visitor switches language. */
  lang?: string; missing?: boolean; image?: string | null; slug: string; brand?: string;
};
type Ctx = {
  items: BagItem[]; count: number; subtotal: number; open: boolean; ready: boolean;
  add: (i: BagItem) => void; setQty: (productId: string, variantId: string | null | undefined, qty: number) => void;
  remove: (productId: string, variantId?: string | null) => void; clear: () => void; setOpen: (o: boolean) => void;
};
const CartCtx = createContext<Ctx | null>(null);
const KEY = "lx_bag_v1";
const same = (a: BagItem, p: string, v?: string | null) => a.productId === p && (a.variantId ?? null) === (v ?? null);

export function CartProvider({ children }: { children: React.ReactNode }) {
  const [items, setItems] = useState<BagItem[]>([]);
  const [open, setOpen] = useState(false);
  const [ready, setReady] = useState(false);

  useEffect(() => {
    try { const raw = localStorage.getItem(KEY); if (raw) setItems(JSON.parse(raw)); } catch { /* storage unavailable */ }
    setReady(true);
  }, []);
  useEffect(() => {
    if (!ready) return;
    try { localStorage.setItem(KEY, JSON.stringify(items)); } catch { /* ignore */ }
  }, [items, ready]);
  // Keep bag titles in the page language (a piece added in English shows in Hindi after switching, and back).
  const { locale } = usePrefs();
  const busy = useRef(false);
  useEffect(() => {
    if (!ready || busy.current || !items.some((i) => (i.lang ?? "en") !== locale)) return;
    busy.current = true;
    bagLabels(items.map((i) => ({ productId: i.productId, variantId: i.variantId ?? null })))
      .then((m) => setItems((cur) => cur.map((i) => {
        const l = m[`${i.productId}:${i.variantId ?? ""}`];
        if (!l) return { ...i, lang: locale };
        return { ...i, lang: locale, title: l.title ?? i.title, variant: i.variantId ? l.variant ?? i.variant : i.variant, missing: !l.title || (!!i.variantId && !l.variant) };
      })))
      .catch(() => { /* offline: keep labels */ })
      .finally(() => { busy.current = false; });
  }, [ready, locale, items]);

  const add = useCallback((i: BagItem) => {
    setItems((cur) => {
      const ex = cur.find((x) => same(x, i.productId, i.variantId));
      return ex ? cur.map((x) => (x === ex ? { ...x, qty: Math.min(10, x.qty + i.qty) } : x)) : [...cur, i];
    });
    setOpen(true);
  }, []);
  const setQty = useCallback((p: string, v: string | null | undefined, qty: number) =>
    setItems((cur) => (qty <= 0 ? cur.filter((x) => !same(x, p, v)) : cur.map((x) => (same(x, p, v) ? { ...x, qty: Math.min(10, qty) } : x)))), []);
  const remove = useCallback((p: string, v?: string | null) => setItems((cur) => cur.filter((x) => !same(x, p, v))), []);
  const clear = useCallback(() => setItems([]), []);

  const value = useMemo(() => ({
    items, open, ready, setOpen, add, setQty, remove, clear,
    count: items.reduce((s, i) => s + i.qty, 0),
    subtotal: items.reduce((s, i) => s + i.qty * i.price, 0),
  }), [items, open, ready, add, setQty, remove, clear]);
  return <CartCtx.Provider value={value}>{children}</CartCtx.Provider>;
}

export function useCart() {
  const c = useContext(CartCtx);
  if (!c) throw new Error("useCart outside CartProvider");
  return c;
}
