"use client";
import Link from "next/link";
import { useEffect, useRef, useState } from "react";
import type { HeroContent } from "@/lib/hero-shared";
import { useT } from "@/lib/i18n/client";

const src = (v: string, ext: string) => (/\.(mp4|webm)$/i.test(v) ? (ext === "mp4" ? v : "") : ext === "webm" && v.startsWith("/u/") ? "" : `${v}.${ext}`);
const poster = (v: string) => (/\.(mp4|webm)$/i.test(v) ? undefined : `${v}.jpg`);

/**
 * Pinned, scroll-scrubbed video chapters that cross-fade into each other.
 * A button is always visible; reduced-motion visitors get a chapter switcher instead of scrubbing.
 */
export function ScrollHero({ hero }: { hero: HeroContent }) {
  const t = useT();
  const chs = hero.chapters.filter((c) => c.show);
  const N = chs.length;
  const track = useRef<HTMLDivElement>(null);
  const layers = useRef<(HTMLDivElement | null)[]>([]);
  const vids = useRef<(HTMLVideoElement | null)[]>([]);
  const bar = useRef<HTMLElement | null>(null);
  const [active, setActive] = useState(0);
  const [phone, setPhone] = useState(false);
  const [reduce, setReduce] = useState(false);
  const [hdr, setHdr] = useState(0);

  useEffect(() => {
    setPhone(window.innerWidth <= 820);
    setReduce(window.matchMedia("(prefers-reduced-motion: reduce)").matches);
    const h = () => setHdr(document.querySelector("header")?.offsetHeight ?? 0);
    h(); window.addEventListener("resize", h);
    return () => window.removeEventListener("resize", h);
  }, []);

  useEffect(() => {
    if (reduce || !N) return;
    let target = 0, shown = 0, raf = 0, last = -1;
    const cur = chs.map(() => 0);
    const smooth = (x: number) => { x = Math.max(0, Math.min(1, x)); return x * x * (3 - 2 * x); };
    const FADE = 0.22;
    const measure = () => {
      const el = track.current; if (!el) return;
      const total = el.offsetHeight - (window.innerHeight - hdr);
      target = total > 0 ? Math.max(0, Math.min(1, (-el.getBoundingClientRect().top + hdr) / total)) : 0;
    };
    const frame = () => {
      shown += (target - shown) * 0.18;
      if (Math.abs(target - shown) < 0.0004) shown = target;
      let f = shown * N; if (f >= N) f = N - 1e-4;
      const idx = Math.floor(f), local = f - idx;
      if (bar.current) bar.current.style.transform = `scaleX(${shown.toFixed(4)})`;
      layers.current.forEach((l, k) => {
        if (!l) return;
        let op = 0, sc = 1;
        if (k === idx) { op = 1; sc = 1.03 - 0.03 * local; } else if (k === idx + 1) { op = smooth((local - (1 - FADE)) / FADE); sc = 1.04; }
        l.style.opacity = op.toFixed(3); l.style.transform = `scale(${sc.toFixed(4)})`; l.style.visibility = op > 0 ? "visible" : "hidden";
      });
      [idx, idx + 1].forEach((k) => {
        const v = vids.current[k]; if (!v || !v.duration || Number.isNaN(v.duration)) return;
        const want = Math.min(v.duration - 0.05, (k === idx ? local : 0) * v.duration);
        if (Math.abs(cur[k] - want) > 1 / 30) { cur[k] = want; try { v.currentTime = want; } catch { /* not seekable yet */ } }
      });
      const a = local > 1 - FADE / 2 && idx + 1 < N ? idx + 1 : idx;
      if (a !== last) { last = a; setActive(a); const n = vids.current[a + 1]; if (n && n.preload !== "auto") { n.preload = "auto"; } }
      raf = shown !== target ? requestAnimationFrame(frame) : 0;
    };
    const onScroll = () => { measure(); if (!raf) raf = requestAnimationFrame(frame); };
    window.addEventListener("scroll", onScroll, { passive: true }); window.addEventListener("resize", onScroll);
    vids.current.forEach((v) => { v?.pause(); v?.addEventListener("loadedmetadata", onScroll); });
    onScroll();
    return () => { window.removeEventListener("scroll", onScroll); window.removeEventListener("resize", onScroll); if (raf) cancelAnimationFrame(raf); };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [reduce, N, hdr]);

  useEffect(() => {
    if (!reduce) return;
    layers.current.forEach((l, k) => { if (l) { l.style.opacity = k === active ? "1" : "0"; l.style.visibility = k === active ? "visible" : "hidden"; } });
    vids.current.forEach((v, k) => { if (!v) return; if (k === active) v.play().catch(() => {}); else v.pause(); });
  }, [reduce, active]);

  if (!N) return null;
  const go = (i: number) => {
    if (reduce) return setActive(i);
    const el = track.current; if (!el) return;
    const total = el.offsetHeight - (window.innerHeight - hdr);
    window.scrollTo({ top: el.getBoundingClientRect().top + window.scrollY - hdr + total * ((i + 0.05) / N), behavior: "smooth" });
  };
  const light = chs[active]?.theme === "light";
  const stageH = `calc(100svh - ${hdr}px)`;
  return (
    <section aria-label={t("Featured collections")} className={`lxh ${light ? "lxh-light" : ""}`}>
      <div ref={track} style={{ height: reduce ? stageH : `calc(${N * 115 + 30}svh)` }} className="relative">
        <div className="sticky overflow-hidden bg-[#0b0b0a]" style={{ top: hdr, height: stageH }}>
          {chs.map((c, i) => {
            const v = phone && c.mobile ? c.mobile : c.video;
            return (
              <div key={c.id} ref={(el) => { layers.current[i] = el; }} className="lxh-layer absolute inset-0" style={{ opacity: i ? 0 : 1, ["--fx" as string]: `${c.focus}%` }}>
                <video ref={(el) => { vids.current[i] = el; }} muted playsInline loop={reduce} preload={i < 2 ? "auto" : "metadata"} poster={poster(v)} aria-label={c.alt} className="h-full w-full object-cover">
                  {src(v, "webm") && <source src={src(v, "webm")} type="video/webm" />}
                  <source src={src(v, "mp4")} type="video/mp4" />
                </video>
              </div>
            );
          })}
          <div className="lxh-scrim pointer-events-none absolute inset-0" />
          <div className="lxh-copy absolute inset-y-0 z-[2] grid items-center">
            {chs.map((c, i) => {
              const H = i === 0 ? "h1" : "h2";
              const on = i === active;
              return (
                <div key={c.id} className={`lxh-ch ${c.theme === "light" ? "text-ink" : "text-ivory"} ${on ? "on" : ""}`} aria-hidden={!on}>
                  <p className="lxh-eye"><span className="opacity-75">0{i + 1} / 0{N}</span>{c.eyebrow}</p>
                  <H className="h-display mt-4 text-[38px] sm:text-[52px] xl:text-[68px]">{c.headline}</H>
                  <p className="mt-5 max-w-md text-[15px] leading-relaxed opacity-85">{c.text}</p>
                  <div className="mt-8 flex flex-wrap items-center gap-x-6 gap-y-4">
                    {c.cta1.label && <Link href={c.cta1.href} tabIndex={on ? 0 : -1} className={c.theme === "light" ? "btn-ink" : "btn bg-ivory text-ink hover:bg-gold"}>{c.cta1.label} <span aria-hidden="true">→</span></Link>}
                    {c.cta2.label && <Link href={c.cta2.href} tabIndex={on ? 0 : -1} className="text-[11px] uppercase tracking-[0.22em] underline underline-offset-8">{c.cta2.label}</Link>}
                  </div>
                </div>
              );
            })}
          </div>
          <ol className="lxh-dots absolute right-3 top-1/2 z-[3] hidden -translate-y-1/2 flex-col gap-1 sm:flex" aria-label={t("Hero chapters")}>
            {chs.map((c, i) => (
              <li key={c.id}><button type="button" onClick={() => go(i)} aria-label={`${t("Chapter {n}", { n: i + 1 })}: ${c.eyebrow}`} aria-current={i === active} className="grid h-7 w-7 place-items-center"><span className={`block w-1.5 rounded-full transition-all ${light ? "bg-ink" : "bg-ivory"} ${i === active ? "h-5 opacity-100" : "h-1.5 opacity-50"}`} /></button></li>
            ))}
          </ol>
          <div className={`absolute inset-x-0 bottom-0 z-[3] px-4 pb-4 sm:px-10 ${light ? "text-ink" : "text-ivory"}`}>
            <div className={`mb-3 h-px overflow-hidden ${light ? "bg-ink/20" : "bg-ivory/25"}`}><i ref={bar} className="block h-full origin-left scale-x-0 bg-gold" /></div>
            <nav aria-label={t("Shopping promises")} className="flex flex-wrap gap-x-3 gap-y-1 pl-28 text-[11px] tracking-wide opacity-85 sm:pl-56">
              {hero.trust.map((x, i) => <span key={i} className={i > 1 ? "hidden sm:inline" : ""}>{i > 0 && <span aria-hidden="true" className="mr-3">·</span>}<Link href={x.href} className="hover:underline">{x.label}</Link></span>)}
            </nav>
          </div>
        </div>
      </div>
    </section>
  );
}
