import Link from "next/link";
import { ProductImage } from "./art";
import type { Product } from "@/lib/catalog";
import { getI18n } from "@/lib/i18n/server";
import { brandName } from "@/lib/i18n/config";

export async function ProductCard({ p, priority = false }: { p: Product; priority?: boolean }) {
  const { t, money, locale } = await getI18n();
  const off = p.compareAtPrice && p.compareAtPrice > p.price ? Math.round(100 - (p.price / p.compareAtPrice) * 100) : 0;
  return (
    <Link href={`/p/${p.slug}`} className="group block" prefetch={priority}>
      <div className="relative aspect-[4/5] overflow-hidden bg-ivory-deep">
        <ProductImage src={p.images[0]} seed={p.slug} alt={p.title} className="transition duration-[1.2s] ease-out group-hover:scale-[1.04]" />
        {p.images[1] && (
          // eslint-disable-next-line @next/next/no-img-element
          <img src={p.images[1]} alt="" loading="lazy" className="absolute inset-0 h-full w-full object-cover opacity-0 transition duration-700 group-hover:opacity-100" />
        )}
        <div className="absolute left-3 top-3 flex flex-col gap-1.5">
          {p.isNewArrival && <span className="bg-ivory/90 px-2 py-1 text-[9.5px] uppercase tracking-[0.2em]">{t("New")}</span>}
          {off >= 5 && <span className="bg-ink px-2 py-1 text-[9.5px] uppercase tracking-[0.2em] text-ivory">−{off}%</span>}
        </div>
        {p.stock > 0 && p.stock <= 2 && <span className="absolute bottom-3 left-3 bg-ivory/90 px-2 py-1 text-[9.5px] uppercase tracking-[0.2em] text-gold-dark">{t("Last {n}", { n: p.stock })}</span>}
      </div>
      <div className="pt-4">
        <p className="eyebrow !text-[10px]">{brandName(p.brand, locale)}</p>
        <h3 className="mt-1 line-clamp-2 font-display text-[19px] leading-snug">{p.title}</h3>
        <p className="mt-1.5 text-sm">
          {money(p.price)}
          {off >= 5 && <span className="ml-2 text-ink-mute line-through">{money(p.compareAtPrice!)}</span>}
        </p>
      </div>
    </Link>
  );
}

export function ProductGrid({ products }: { products: Product[] }) {
  return (
    <div className="grid grid-cols-2 gap-x-4 gap-y-10 sm:gap-x-6 md:grid-cols-3 lg:grid-cols-4">
      {products.map((p, i) => <ProductCard key={p.id} p={p} priority={i < 4} />)}
    </div>
  );
}
