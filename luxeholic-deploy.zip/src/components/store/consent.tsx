"use client";
import { useEffect, useState } from "react";
import Link from "next/link";
import { useT } from "@/lib/i18n/client";

declare global { interface Window { gtag?: (...a: unknown[]) => void } }
type Choice = { analytics: boolean; marketing: boolean; at: string };
const KEY = "lx_consent_v2";

function read(): Choice | null {
  try {
    const v = localStorage.getItem(KEY); if (v) return JSON.parse(v);
    const old = localStorage.getItem("lx_consent"); // earlier one-switch banner
    if (old) return { analytics: old === "granted", marketing: old === "granted", at: "" };
  } catch { /* storage blocked */ }
  return null;
}
function apply(c: Choice) {
  const a = c.analytics ? "granted" : "denied", m = c.marketing ? "granted" : "denied";
  window.gtag?.("consent", "update", { analytics_storage: a, ad_storage: m, ad_user_data: m, ad_personalization: m });
}

/** Opens the cookie settings panel from anywhere (footer button uses data-cookie-settings). */
export function CookieSettingsButton({ className }: { className?: string }) {
  const t = useT();
  return <button type="button" className={className} onClick={() => window.dispatchEvent(new Event("lx:cookies"))}>{t("Cookie settings")}</button>;
}

/**
 * Google Consent Mode v2: a first-visit banner (only when tags are configured) and a settings
 * panel with separate Analytics and Marketing switches. Necessary cookies are always on.
 */
export function ConsentManager({ tagsOn }: { tagsOn: boolean }) {
  const t = useT();
  const [banner, setBanner] = useState(false);
  const [panel, setPanel] = useState(false);
  const [c, setC] = useState<Choice>({ analytics: false, marketing: false, at: "" });
  useEffect(() => {
    const saved = read();
    if (saved) { setC(saved); apply(saved); } else if (tagsOn) setBanner(true);
    const open = () => { setPanel(true); setBanner(false); };
    window.addEventListener("lx:cookies", open);
    return () => window.removeEventListener("lx:cookies", open);
  }, [tagsOn]);
  useEffect(() => {
    if (!panel) return;
    const k = (e: KeyboardEvent) => { if (e.key === "Escape") setPanel(false); };
    document.addEventListener("keydown", k); return () => document.removeEventListener("keydown", k);
  }, [panel]);
  const save = (next: Choice) => {
    const v = { ...next, at: new Date().toISOString() };
    try { localStorage.setItem(KEY, JSON.stringify(v)); } catch { /* ignore */ }
    apply(v); setC(v); setBanner(false); setPanel(false);
  };
  return (
    <>
      {banner && (
        <div className="fixed inset-x-3 bottom-3 z-50 mx-auto max-w-xl border border-ivory-line bg-ivory p-5 shadow-xl sm:inset-x-auto sm:right-6">
          <p className="text-sm leading-relaxed">{t("We use cookies to understand what you love and to measure our ads.")} <Link href="/policies/privacy" className="underline">{t("Privacy policy")}</Link></p>
          <div className="mt-4 flex flex-wrap gap-3">
            <button className="btn-ink !py-2.5" onClick={() => save({ analytics: true, marketing: true, at: "" })}>{t("Accept all")}</button>
            <button className="btn-line !py-2.5" onClick={() => save({ analytics: false, marketing: false, at: "" })}>{t("Only essential")}</button>
            <button className="text-[11px] uppercase tracking-[0.18em] underline underline-offset-4" onClick={() => { setPanel(true); setBanner(false); }}>{t("Choose")}</button>
          </div>
        </div>
      )}
      {panel && (
        <div className="fixed inset-0 z-[80] grid place-items-center bg-ink/55 p-4" onMouseDown={(e) => { if (e.target === e.currentTarget) setPanel(false); }}>
          <div role="dialog" aria-modal="true" aria-labelledby="ck-title" className="w-full max-w-md bg-ivory p-6 shadow-2xl sm:p-8">
            <h2 id="ck-title" className="h-display text-3xl">{t("Cookie settings")}</h2>
            <p className="mt-2 text-sm text-ink-soft">{t("Choose which cookies LUXEHOLIC may use. You can change this any time from the footer.")}</p>
            <div className="mt-5 divide-y divide-ivory-line border-y border-ivory-line text-sm">
              <div className="flex items-center justify-between gap-4 py-3.5"><span><b className="font-medium">{t("Necessary")}</b><span className="block text-ink-mute">{t("Bag, sign-in, security, checkout.")}</span></span><span className="text-[11px] uppercase tracking-[0.16em] text-emerald-700">{t("Always on")}</span></div>
              <label className="flex cursor-pointer items-center justify-between gap-4 py-3.5"><span><b className="font-medium">{t("Analytics")}</b><span className="block text-ink-mute">{t("Anonymous visit counts (Google Analytics).")}</span></span><input type="checkbox" className="h-5 w-5 accent-ink" checked={c.analytics} onChange={(e) => setC({ ...c, analytics: e.target.checked })} /></label>
              <label className="flex cursor-pointer items-center justify-between gap-4 py-3.5"><span><b className="font-medium">{t("Marketing")}</b><span className="block text-ink-mute">{t("Measure ads on Google, Meta and Pinterest.")}</span></span><input type="checkbox" className="h-5 w-5 accent-ink" checked={c.marketing} onChange={(e) => setC({ ...c, marketing: e.target.checked })} /></label>
            </div>
            <div className="mt-6 flex flex-wrap gap-3">
              <button className="btn-ink !py-2.5" onClick={() => save(c)}>{t("Save choices")}</button>
              <button className="btn-line !py-2.5" onClick={() => save({ analytics: true, marketing: true, at: "" })}>{t("Accept all")}</button>
              <button className="btn-line !py-2.5" onClick={() => setPanel(false)}>{t("Cancel")}</button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
