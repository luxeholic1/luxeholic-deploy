import Link from "next/link";
import { brandsIn, listProducts, type ProductFilter } from "@/lib/catalog";
import { PRICE_TIERS } from "@/lib/money";
import { ProductGrid } from "./product-card";
import { getI18n } from "@/lib/i18n/server";
import { brandName } from "@/lib/i18n/config";

type SP = Record<string, string | undefined>;
const SORTS = [["featured", "Curated"], ["new", "Newest"], ["price-asc", "Price: low to high"], ["price-desc", "Price: high to low"]] as const;

/** Shared listing with sort / price tier / brand filters driven by the URL (crawlable, shareable). */
export async function Listing({ base, sp, filter, showTiers = true }: { base: string; sp: SP; filter: ProductFilter; showTiers?: boolean }) {
  const { t, locale } = await getI18n();
  const tier = PRICE_TIERS.find((x) => x.slug === sp.tier);
  const f: ProductFilter = {
    ...filter,
    locale,
    sort: (SORTS.find(([k]) => k === sp.sort)?.[0] ?? filter.sort ?? "featured") as ProductFilter["sort"],
    page: Number(sp.page) || 1,
    brand: sp.brand || filter.brand,
    ...(tier ? { minPrice: tier.min, maxPrice: tier.max } : {}),
  };
  const [{ products, total, page, pages }, brands] = await Promise.all([listProducts(f), brandsIn(filter.categoryIds)]);
  const href = (patch: SP) => {
    const merged: SP = { ...sp, page: undefined, ...patch };
    const q = new URLSearchParams(Object.entries(merged).filter((e): e is [string, string] => Boolean(e[1])));
    const s = q.toString();
    return s ? `${base}?${s}` : base;
  };
  const chip = (on: boolean) => `whitespace-nowrap border px-3.5 py-1.5 text-[11px] uppercase tracking-[0.16em] transition ${on ? "border-ink bg-ink text-ivory" : "border-ivory-line hover:border-ink"}`;
  return (
    <div>
      <div className="flex flex-col gap-4 border-y border-ivory-line py-4 md:flex-row md:items-center md:justify-between">
        <div className="no-scrollbar -mx-4 flex gap-2 overflow-x-auto px-4 md:mx-0 md:px-0">
          {showTiers && <Link href={href({ tier: undefined })} className={chip(!tier)}>{t("All prices")}</Link>}
          {showTiers && PRICE_TIERS.map((x) => <Link key={x.slug} href={href({ tier: x.slug })} className={chip(tier?.slug === x.slug)}>{t(x.name)}</Link>)}
          {brands.length > 1 && (
            <details className="relative">
              <summary className={`${chip(!!sp.brand)} cursor-pointer list-none`}>{sp.brand ? brandName(sp.brand, locale) : t("Brand")}</summary>
              <div className="absolute left-0 z-20 mt-2 max-h-72 w-56 overflow-y-auto border border-ivory-line bg-ivory p-2 shadow-lg">
                <Link href={href({ brand: undefined })} className="block px-2 py-1.5 text-sm hover:bg-ivory-deep">{t("All brands")}</Link>
                {brands.map((b) => <Link key={b} href={href({ brand: b })} className="block px-2 py-1.5 text-sm hover:bg-ivory-deep">{brandName(b, locale)}</Link>)}
              </div>
            </details>
          )}
        </div>
        <div className="flex items-center gap-4 text-xs text-ink-mute">
          <span>{total === 1 ? t("1 piece") : t("{n} pieces", { n: total })}</span>
          <div className="flex gap-3">
            {SORTS.map(([k, label]) => <Link key={k} href={href({ sort: k === "featured" ? undefined : k })} className={f.sort === k ? "text-ink underline underline-offset-4" : "hover:text-ink"}>{t(label)}</Link>)}
          </div>
        </div>
      </div>
      <div className="mt-10">
        {products.length ? <ProductGrid products={products} /> : (
          <div className="py-24 text-center">
            <p className="h-display text-3xl italic">{t("Nothing here — yet.")}</p>
            <p className="mt-3 text-sm text-ink-mute">{t("New pieces arrive every week. Try another price range, or explore the full collection.")}</p>
            <Link href="/shop" className="btn-line mt-8">{t("Shop everything")}</Link>
          </div>
        )}
      </div>
      {pages > 1 && (
        <nav className="mt-14 flex justify-center gap-2" aria-label={t("Pagination")}>
          {Array.from({ length: pages }, (_, i) => i + 1).slice(Math.max(0, page - 4), page + 3).map((n) => (
            <Link key={n} href={href({ page: n === 1 ? undefined : String(n) })} className={`flex h-10 w-10 items-center justify-center border text-sm ${n === page ? "border-ink bg-ink text-ivory" : "border-ivory-line"}`}>{n}</Link>
          ))}
        </nav>
      )}
    </div>
  );
}

export async function PageHead({ eyebrow, title, intro, crumbs }: { eyebrow?: string; title: string; intro?: string | null; crumbs?: { href: string; label: string }[] }) {
  const { t } = await getI18n();
  return (
    <header className="pb-10 pt-12 lg:pt-16">
      {crumbs && (
        <nav aria-label={t("Breadcrumb")} className="mb-6 text-xs text-ink-mute">
          {crumbs.map((c, i) => <span key={c.href}>{i > 0 && " / "}<Link href={c.href} className="hover:text-ink">{c.label}</Link></span>)}
        </nav>
      )}
      {eyebrow && <p className="eyebrow">{eyebrow}</p>}
      <h1 className="h-display mt-3 text-5xl sm:text-7xl">{title}</h1>
      {intro && <p className="mt-5 max-w-2xl text-ink-soft">{intro}</p>}
    </header>
  );
}
