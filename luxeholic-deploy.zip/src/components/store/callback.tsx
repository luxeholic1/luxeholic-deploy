"use client";
import { useActionState, useEffect, useRef, useState } from "react";
import { usePathname } from "next/navigation";
import { requestCallback, type CallbackState } from "@/app/(store)/actions";
import { useT } from "@/lib/i18n/client";

const INTERESTS = ["Lux-Tech device", "Designer fashion", "Art & décor", "Corporate / bulk gifting", "Help with an order", "Something else"];
const TIMES = ["Morning · 10–1", "Afternoon · 1–4", "Evening · 4–7"];

/** Any element with data-callback opens the "Request a call back" form. */
export function openCallback() { window.dispatchEvent(new Event("lx:callback")); }

export function CallbackButton({ className, children }: { className?: string; children: React.ReactNode }) {
  return <button type="button" className={className} onClick={openCallback}>{children}</button>;
}

export function CallbackDialog({ phone, whatsapp }: { phone: string; whatsapp: string }) {
  const [open, setOpen] = useState(false);
  const [key, setKey] = useState(0); // fresh form each time it opens after a success
  const last = useRef<HTMLElement | null>(null);
  useEffect(() => {
    const on = () => { last.current = document.activeElement as HTMLElement; setOpen(true); };
    const click = (e: MouseEvent) => { const t = (e.target as HTMLElement).closest?.("[data-callback]"); if (t) { e.preventDefault(); on(); } };
    window.addEventListener("lx:callback", on); document.addEventListener("click", click);
    return () => { window.removeEventListener("lx:callback", on); document.removeEventListener("click", click); };
  }, []);
  const close = () => { setOpen(false); setTimeout(() => last.current?.focus?.(), 0); };
  if (!open) return null;
  return <Dialog key={key} onClose={close} onDone={() => setKey((k) => k + 1)} phone={phone} whatsapp={whatsapp} />;
}

function Dialog({ onClose, onDone, phone, whatsapp }: { onClose: () => void; onDone: () => void; phone: string; whatsapp: string }) {
  const [state, action, pending] = useActionState<CallbackState, FormData>(requestCallback, null);
  const box = useRef<HTMLDivElement>(null);
  const path = usePathname();
  const t = useT();
  useEffect(() => {
    document.documentElement.style.overflow = "hidden";
    box.current?.querySelector<HTMLElement>("input,button.lx-primary")?.focus();
    const key = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
      if (e.key === "Tab" && box.current) {
        const f = [...box.current.querySelectorAll<HTMLElement>("a[href],button,input,select,textarea")].filter((x) => !x.hasAttribute("disabled"));
        const a = f[0], z = f[f.length - 1];
        if (e.shiftKey && document.activeElement === a) { e.preventDefault(); z.focus(); }
        else if (!e.shiftKey && document.activeElement === z) { e.preventDefault(); a.focus(); }
      }
    };
    document.addEventListener("keydown", key);
    return () => { document.documentElement.style.overflow = ""; document.removeEventListener("keydown", key); };
  }, [onClose]);
  useEffect(() => { if (state?.field) box.current?.querySelector<HTMLElement>(`[name="${state.field}"]`)?.focus(); }, [state]);
  const wa = whatsapp.replace(/[^\d]/g, "");
  return (
    <div className="fixed inset-0 z-[80] grid place-items-center bg-ink/55 p-4" onMouseDown={(e) => { if (e.target === e.currentTarget) onClose(); }}>
      <div ref={box} role="dialog" aria-modal="true" aria-labelledby="cb-title" className="relative max-h-[calc(100svh-2rem)] w-full max-w-lg overflow-auto bg-ivory p-6 shadow-2xl sm:p-8">
        <button type="button" onClick={onClose} aria-label={t("Close")} className="absolute right-4 top-4 grid h-9 w-9 place-items-center border border-ivory-line hover:bg-ivory-deep">✕</button>
        {state?.ok ? (
          <div>
            <h2 id="cb-title" className="h-display pr-10 text-3xl">{t("Thank you — we’ll call you.")}</h2>
            <p className="mt-3 text-sm leading-relaxed text-ink-soft">{t("Our concierge will call {phone} in the {when}, Monday to Saturday.", { phone: state.phone ?? "", when: t(state.when ?? "") })} {t("Reference")} <b>{state.number}</b>.</p>
            <div className="mt-6 flex flex-wrap gap-3">
              <a className="btn-ink" href={`https://wa.me/${wa}?text=${encodeURIComponent(`Hello LUXEHOLIC, I requested a call back (${state.number}).`)}`} target="_blank" rel="noopener noreferrer">{t("Also message on WhatsApp")}</a>
              <button type="button" className="btn-line" onClick={() => { onDone(); onClose(); }}>{t("Close")}</button>
            </div>
          </div>
        ) : (
          <form action={action} noValidate>
            <h2 id="cb-title" className="h-display pr-10 text-3xl">{t("Request a call back")}</h2>
            <p className="mt-2 text-sm text-ink-soft">{t("Our concierge calls back Monday to Saturday, 10 am – 7 pm IST.")} {t("Prefer to call?")} <a className="underline" href={`tel:${phone.replace(/\s/g, "")}`}>{phone}</a></p>
            <input type="hidden" name="source" value={path === "/" ? "home" : path.slice(0, 30)} />
            <input type="text" name="website" tabIndex={-1} autoComplete="off" className="hidden" aria-hidden="true" />
            <div className="mt-5 grid gap-4">
              <L label={t("Your name")}><input name="name" required maxLength={80} autoComplete="name" className="field" aria-invalid={state?.field === "name" || undefined} /></L>
              <L label={t("Mobile number")} hint={t("10-digit Indian number, or with country code (+44…)")}><input name="phone" type="tel" inputMode="tel" required maxLength={20} autoComplete="tel" className="field" aria-invalid={state?.field === "phone" || undefined} /></L>
              <div className="grid gap-4 sm:grid-cols-2">
                <L label={t("About")}><select name="interest" className="field">{INTERESTS.map((i) => <option key={i} value={i}>{t(i)}</option>)}</select></L>
                <L label={t("Best time")}><select name="time" className="field">{TIMES.map((i) => <option key={i} value={i}>{t(i)}</option>)}</select></L>
              </div>
              <div className="grid gap-4 sm:grid-cols-2">
                <L label={t("City (optional)")}><input name="city" maxLength={60} autoComplete="address-level2" className="field" /></L>
                <L label={t("Email (optional)")}><input name="email" type="email" maxLength={120} autoComplete="email" className="field" aria-invalid={state?.field === "email" || undefined} /></L>
              </div>
              <L label={t("Anything we should know? (optional)")}><textarea name="message" rows={3} maxLength={500} className="field" /></L>
              <label className="flex items-start gap-3 text-sm text-ink-soft"><input type="checkbox" name="consent" className="mt-1 h-4 w-4 accent-ink" aria-invalid={state?.field === "consent" || undefined} /><span>{t("LUXEHOLIC may call or WhatsApp me about this request.")} <a href="/policies/privacy" className="underline">{t("Privacy policy")}</a></span></label>
              {state?.error && <p role="alert" className="text-sm text-red-700">{t(state.error)}</p>}
              <button className="btn-ink lx-primary w-full" disabled={pending}>{pending ? t("Sending…") : t("Request my call back")}</button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
}

function L({ label, hint, children }: { label: string; hint?: string; children: React.ReactNode }) {
  return <label className="block text-[11px] font-medium uppercase tracking-[0.16em] text-ink-mute">{label}<span className="mt-1.5 block normal-case tracking-normal">{children}</span>{hint && <span className="mt-1 block text-[11px] normal-case tracking-normal text-ink-mute">{hint}</span>}</label>;
}
