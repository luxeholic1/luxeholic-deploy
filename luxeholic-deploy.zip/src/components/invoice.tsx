import { businessAddress, type Settings } from "@/lib/settings";
import { formatINR, gstPortion } from "@/lib/money";
import { prettyDateTime } from "@/lib/dates";
import type { schema } from "@/db";

type Order = typeof schema.orders.$inferSelect & { items: (typeof schema.orderItems.$inferSelect)[] };

/** GST tax invoice — shared by Team → Orders and the customer's order page. Intra-state: CGST + SGST; otherwise IGST. */
export function TaxInvoice({ o, b }: { o: Order; b: Settings["business"] }) {
  const a = o.shippingAddress;
  const intra = (a.state || "").toLowerCase() === (b.state || "").toLowerCase();
  return (
    <>
      <div className="flex items-start justify-between border-b pb-6">
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img src="/brand/logo-full-dark.png" alt="Luxeholic" className="h-16 w-auto" />
        <div className="text-right"><p className="text-lg font-semibold">Tax Invoice</p><p>No. {o.number}</p><p>{prettyDateTime(o.createdAt)}</p></div>
      </div>
      <div className="grid grid-cols-2 gap-6 border-b py-6">
        <div><p className="text-xs uppercase text-stone-500">Sold by</p><p className="font-medium">{b.legalName || b.brand}</p><p>{businessAddress(b)}</p>{b.gstin && <p>GSTIN: {b.gstin}</p>}<p>{b.email}</p></div>
        <div><p className="text-xs uppercase text-stone-500">Bill / ship to</p><p className="font-medium">{a.name}</p><p>{a.line1}{a.line2 ? `, ${a.line2}` : ""}, {a.city}, {a.state} {a.pincode}</p><p>{o.phone}</p>{o.gstin && <p>GSTIN: {o.gstin}</p>}<p>Place of supply: {a.state}</p></div>
      </div>
      <table className="mt-6 w-full"><thead><tr className="border-b text-left text-xs uppercase text-stone-500"><th className="py-2">Item</th><th>Qty</th><th>GST %</th><th className="text-right">Taxable</th>{intra ? <><th className="text-right">CGST</th><th className="text-right">SGST</th></> : <th className="text-right">IGST</th>}<th className="text-right">Total</th></tr></thead>
        <tbody>{o.items.map((i) => { const line = i.unitPrice * i.quantity; const tax = gstPortion(line, i.gstPercent); return (
          <tr key={i.id} className="border-b"><td className="py-2">{i.title}{i.variant ? ` (${i.variant})` : ""}<br /><span className="text-xs text-stone-500">{i.sku}</span></td><td>{i.quantity}</td><td>{i.gstPercent}%</td><td className="text-right">{formatINR(line - tax, true)}</td>{intra ? <><td className="text-right">{formatINR(Math.floor(tax / 2), true)}</td><td className="text-right">{formatINR(tax - Math.floor(tax / 2), true)}</td></> : <td className="text-right">{formatINR(tax, true)}</td>}<td className="text-right">{formatINR(line, true)}</td></tr>
        ); })}</tbody></table>
      <dl className="ml-auto mt-6 w-72 space-y-1">
        {o.discount > 0 && <div className="flex justify-between"><dt>Discount</dt><dd>−{formatINR(o.discount, true)}</dd></div>}
        <div className="flex justify-between"><dt>Shipping</dt><dd>{formatINR(o.shippingFee, true)}</dd></div>
        {o.codFee > 0 && <div className="flex justify-between"><dt>COD fee</dt><dd>{formatINR(o.codFee, true)}</dd></div>}
        <div className="flex justify-between border-t pt-1 text-base font-semibold"><dt>Grand total</dt><dd>{formatINR(o.total, true)}</dd></div>
        <div className="flex justify-between text-xs text-stone-500"><dt>of which GST</dt><dd>{formatINR(o.taxIncluded, true)}</dd></div>
        <div className="flex justify-between text-xs text-stone-500"><dt>Paid</dt><dd>{formatINR(o.amountPaid, true)} ({o.paymentMethod.replace("_", " ")})</dd></div>
      </dl>
      <p className="mt-10 text-xs text-stone-500">This is a computer-generated invoice. Prices are inclusive of GST. Subject to {b.city} jurisdiction.</p>
    </>
  );
}
