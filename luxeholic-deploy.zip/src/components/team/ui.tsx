import Link from "next/link";

export function PageHeader({ title, sub, actions }: { title: string; sub?: React.ReactNode; actions?: React.ReactNode }) {
  return (
    <div className="mb-6 flex flex-wrap items-end justify-between gap-4">
      <div>
        <h1 className="text-2xl font-semibold tracking-tight text-stone-900">{title}</h1>
        {sub && <p className="mt-1 text-sm text-stone-500">{sub}</p>}
      </div>
      {actions && <div className="flex flex-wrap gap-2">{actions}</div>}
    </div>
  );
}

const TONES: Record<string, string> = {
  gray: "bg-stone-100 text-stone-700", green: "bg-emerald-50 text-emerald-700", amber: "bg-amber-50 text-amber-800",
  red: "bg-red-50 text-red-700", blue: "bg-sky-50 text-sky-700", violet: "bg-violet-50 text-violet-700", ink: "bg-stone-900 text-white",
};
const STATUS_TONE: Record<string, keyof typeof TONES> = {
  PENDING: "amber", CONFIRMED: "blue", PROCESSING: "violet", SHIPPED: "blue", DELIVERED: "green", CANCELLED: "gray",
  RETURN_REQUESTED: "red", RETURNED: "gray", PAID: "green", PARTIALLY_PAID: "blue", FAILED: "red", REFUNDED: "gray",
  AWAITING_VERIFICATION: "amber", DRAFT: "gray", ACTIVE: "green", ARCHIVED: "gray", SENT: "blue", RECEIVED: "green",
  TODO: "gray", IN_PROGRESS: "blue", BLOCKED: "red", DONE: "green", OPEN: "amber", WAITING_CUSTOMER: "violet", RESOLVED: "green",
  LOW: "gray", MEDIUM: "blue", HIGH: "amber", URGENT: "red",
};
export function Badge({ children, tone }: { children: React.ReactNode; tone?: keyof typeof TONES }) {
  const t = tone ?? STATUS_TONE[String(children)] ?? "gray";
  return <span className={`t-badge ${TONES[t]}`}>{String(children).replace(/_/g, " ").toLowerCase()}</span>;
}

export function Stat({ label, value, href, hint, tone }: { label: string; value: React.ReactNode; href?: string; hint?: string; tone?: "warn" | "ok" }) {
  const body = (
    <div className={`t-card h-full p-4 transition ${href ? "hover:border-stone-400" : ""}`}>
      <p className="text-xs font-medium uppercase tracking-wide text-stone-500">{label}</p>
      <p className={`mt-2 text-2xl font-semibold ${tone === "warn" ? "text-amber-700" : tone === "ok" ? "text-emerald-700" : "text-stone-900"}`}>{value}</p>
      {hint && <p className="mt-1 text-xs text-stone-400">{hint}</p>}
    </div>
  );
  return href ? <Link href={href}>{body}</Link> : body;
}

export function Empty({ children }: { children: React.ReactNode }) {
  return <div className="rounded-lg border border-dashed border-stone-300 p-10 text-center text-sm text-stone-500">{children}</div>;
}

export function Tabs({ items, active }: { items: { href: string; label: string; key: string; count?: number }[]; active: string }) {
  return (
    <div className="no-scrollbar mb-5 flex gap-1 overflow-x-auto border-b border-stone-200">
      {items.map((i) => (
        <Link key={i.key} href={i.href} className={`-mb-px whitespace-nowrap border-b-2 px-3 py-2 text-sm ${active === i.key ? "border-stone-900 font-medium text-stone-900" : "border-transparent text-stone-500 hover:text-stone-800"}`}>
          {i.label}{i.count !== undefined && <span className="ml-1.5 rounded-full bg-stone-100 px-1.5 text-[11px] text-stone-600">{i.count}</span>}
        </Link>
      ))}
    </div>
  );
}

export function Section({ title, children, actions, className = "" }: { title: string; children: React.ReactNode; actions?: React.ReactNode; className?: string }) {
  return (
    <section className={`t-card ${className}`}>
      <div className="flex items-center justify-between border-b border-stone-100 px-4 py-3">
        <h2 className="text-sm font-semibold text-stone-800">{title}</h2>{actions}
      </div>
      <div className="p-4">{children}</div>
    </section>
  );
}

export function Field({ label, children, hint, className = "" }: { label: string; children: React.ReactNode; hint?: string; className?: string }) {
  return <label className={`block ${className}`}><span className="t-label">{label}</span>{children}{hint && <span className="mt-1 block text-xs text-stone-400">{hint}</span>}</label>;
}

export function TeamDot({ color }: { color?: string | null }) {
  return <span className="inline-block h-2 w-2 shrink-0 rounded-full" style={{ background: color ?? "#a8a29e" }} />;
}
