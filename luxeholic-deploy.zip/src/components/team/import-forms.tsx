"use client";
import { startTransition, useActionState, useRef, useState } from "react";
import { importCsv, importFromWoo, type ImportState } from "@/app/team/actions/import";

function Btn({ intent, children, primary, pending }: { intent: string; children: React.ReactNode; primary?: boolean; pending: boolean }) {
  return <button name="intent" value={intent} disabled={pending} className={primary ? "t-btn" : "t-btn-ghost"}>{pending ? "Working…" : children}</button>;
}

/** Submit without React's automatic form reset, so the chosen file stays selected between "Check" and "Import". */
function keepForm(action: (fd: FormData) => void) {
  return (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const fd = new FormData(e.currentTarget, (e.nativeEvent as SubmitEvent).submitter);
    startTransition(() => action(fd));
  };
}

const fmt = (p?: number) => (p ? `₹${(p / 100).toLocaleString("en-IN")}` : "—");

function Results({ s }: { s: ImportState }) {
  if (!s) return null;
  return (
    <div className="mt-5">
      <p className={`rounded-md px-3 py-2 text-sm ${s.ok ? (s.dryRun ? "bg-amber-50 text-amber-900" : "bg-emerald-50 text-emerald-900") : "bg-red-50 text-red-800"}`}>{s.message}</p>
      {!!s.results?.length && (
        <div className="mt-3 max-h-[480px] overflow-auto rounded-md border border-stone-200">
          <table className="w-full text-left text-xs">
            <thead className="sticky top-0 bg-stone-50 text-stone-500"><tr><th className="p-2">Row</th><th className="p-2">Photo</th><th className="p-2">SKU</th><th className="p-2">Title</th><th className="p-2">Category</th><th className="p-2">Price</th><th className="p-2">Result</th><th className="p-2">Notes</th></tr></thead>
            <tbody>
              {s.results.map((r) => (
                <tr key={r.row} className="border-t border-stone-100 align-top">
                  <td className="p-2 text-stone-400">{r.row}</td>
                  {/* eslint-disable-next-line @next/next/no-img-element */}
                  <td className="p-2">{r.image ? <img src={r.image} alt="" className="h-10 w-10 rounded object-cover" loading="lazy" /> : <span className="text-red-600">none</span>}</td>
                  <td className="p-2 font-mono">{r.sku || "—"}</td>
                  <td className="max-w-[260px] p-2">{r.title}</td>
                  <td className="p-2">{r.category ?? "—"}</td>
                  <td className="p-2 whitespace-nowrap">{fmt(r.price)}</td>
                  <td className="p-2"><span className={`rounded px-1.5 py-0.5 ${r.action === "error" ? "bg-red-100 text-red-700" : r.action === "skip" ? "bg-stone-100" : r.action === "create" ? "bg-emerald-100 text-emerald-800" : "bg-sky-100 text-sky-800"}`}>{r.action === "create" ? "new" : r.action}{r.status ? ` · ${r.status.toLowerCase()}` : ""}</span></td>
                  <td className="p-2 text-stone-500">{r.notes.join("; ")}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}

export function CsvImportForm() {
  const [state, action, pending] = useActionState(importCsv, null);
  const [name, setName] = useState("");
  const fileRef = useRef<HTMLInputElement>(null);
  return (
    <form onSubmit={keepForm(action)}>
      <label className="flex cursor-pointer flex-col items-center justify-center gap-1 rounded-lg border-2 border-dashed border-stone-300 bg-stone-50 px-4 py-8 text-center text-sm hover:border-stone-500">
        <input ref={fileRef} type="file" name="file" accept=".csv,text/csv" className="sr-only" onChange={(e) => setName(e.target.files?.[0]?.name ?? "")} />
        <span className="font-medium">{name || "Choose your CSV file"}</span>
        <span className="text-xs text-stone-500">From Excel / Google Sheets: File → Download → CSV · up to 2,000 rows</span>
      </label>
      <div className="mt-4 grid gap-3 sm:grid-cols-2">
        <label className="text-sm"><span className="mb-1 block text-xs text-stone-500">If a SKU already exists</span>
          <select name="mode" className="t-input"><option value="upsert">Update it, and add new SKUs</option><option value="create">Only add new SKUs</option><option value="update">Only update existing SKUs (prices / stock)</option></select>
        </label>
        <label className="text-sm"><span className="mb-1 block text-xs text-stone-500">Rows with a blank status</span>
          <select name="defaultStatus" className="t-input"><option value="DRAFT">Save as draft (review first)</option><option value="ACTIVE">Publish straight away</option></select>
        </label>
      </div>
      <div className="mt-4 flex flex-wrap gap-2">
        <Btn pending={pending} intent="check">1 · Check file</Btn>
        <Btn pending={pending} intent="import" primary>2 · Import products</Btn>
      </div>
      <p className="mt-2 text-xs text-stone-500">Check first: you&apos;ll see every row, what will happen and any problems — nothing is saved until you press Import.</p>
      <Results s={state} />
    </form>
  );
}

export function WooImportForm() {
  const [state, action, pending] = useActionState(importFromWoo, null);
  return (
    <form onSubmit={keepForm(action)}>
      <div className="grid gap-3 sm:grid-cols-[1fr_auto] sm:items-end">
        <label className="text-sm"><span className="mb-1 block text-xs text-stone-500">Old WooCommerce store address</span>
          <input name="url" defaultValue="https://luxeholic.in" className="t-input" />
        </label>
        <label className="flex items-center gap-2 pb-2 text-sm"><input type="checkbox" name="archiveDemo" defaultChecked /> Hide demo products</label>
      </div>
      <div className="mt-4 flex flex-wrap gap-2">
        <Btn pending={pending} intent="check">Preview</Btn>
        <Btn pending={pending} intent="import" primary>Import all products</Btn>
      </div>
      <Results s={state} />
    </form>
  );
}

/** Drag-and-drop photo uploader for the product form: uploads, then appends URLs to the images textarea. */
export function PhotoUploader({ target = "images" }: { target?: string }) {
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState("");
  const [over, setOver] = useState(false);
  async function send(files: FileList | null) {
    if (!files?.length) return;
    setBusy(true); setMsg("");
    const fd = new FormData();
    for (const f of Array.from(files)) fd.append("files", f);
    try {
      const res = await fetch("/api/team/upload", { method: "POST", body: fd });
      const j = (await res.json()) as { urls?: string[]; errors?: string[]; error?: string };
      if (!res.ok) throw new Error(j.error ?? "Upload failed");
      const ta = document.querySelector<HTMLTextAreaElement>(`textarea[name="${target}"]`);
      if (ta && j.urls?.length) ta.value = [ta.value.trim(), ...j.urls].filter(Boolean).join("\n");
      setMsg(`${j.urls?.length ?? 0} photo(s) added below${j.errors?.length ? ` · ${j.errors.join("; ")}` : ""}. Save the product to keep them.`);
    } catch (e) { setMsg((e as Error).message); }
    setBusy(false);
  }
  return (
    <div className="mb-3">
      <label onDragOver={(e) => { e.preventDefault(); setOver(true); }} onDragLeave={() => setOver(false)} onDrop={(e) => { e.preventDefault(); setOver(false); send(e.dataTransfer.files); }}
        className={`flex cursor-pointer flex-col items-center rounded-lg border-2 border-dashed px-4 py-5 text-center text-sm ${over ? "border-stone-700 bg-stone-100" : "border-stone-300 bg-stone-50"}`}>
        <input type="file" accept="image/jpeg,image/png,image/webp" multiple className="sr-only" onChange={(e) => send(e.target.files)} />
        <span className="font-medium">{busy ? "Uploading…" : "Upload photos from your computer"}</span>
        <span className="text-xs text-stone-500">Drag & drop or click · JPG / PNG / WebP · up to 5 MB each · square, plain background works best</span>
      </label>
      {msg && <p className="mt-1 text-xs text-stone-600">{msg}</p>}
    </div>
  );
}
