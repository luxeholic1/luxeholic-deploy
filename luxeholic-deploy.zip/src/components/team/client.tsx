"use client";
import { useEffect, useState } from "react";
import { useFormStatus } from "react-dom";
import { usePathname, useRouter, useSearchParams } from "next/navigation";
import Link from "next/link";
import { Menu, X } from "lucide-react";

/** Toast for ?ok= / ?err= flashes set by server actions. */
export function Flash() {
  const sp = useSearchParams();
  const router = useRouter();
  const path = usePathname();
  const ok = sp.get("ok"), err = sp.get("err");
  const [show, setShow] = useState(false);
  useEffect(() => {
    if (!ok && !err) return;
    setShow(true);
    const t = setTimeout(() => {
      setShow(false);
      const q = new URLSearchParams(sp.toString()); q.delete("ok"); q.delete("err");
      router.replace(q.size ? `${path}?${q}` : path, { scroll: false });
    }, ok ? 2600 : 6000);
    return () => clearTimeout(t);
  }, [ok, err, path, router, sp]);
  if (!show || (!ok && !err)) return null;
  return (
    <div role="status" className={`fixed bottom-5 right-5 z-50 max-w-sm rounded-lg px-4 py-3 text-sm shadow-lg ${err ? "bg-red-600 text-white" : "bg-stone-900 text-white"}`}>
      {err ?? ok}
    </div>
  );
}

export function Submit({ children, className = "t-btn", confirm, name, value }: { children: React.ReactNode; className?: string; confirm?: string; name?: string; value?: string }) {
  const { pending } = useFormStatus();
  return (
    <button name={name} value={value} disabled={pending} className={className}
      onClick={(e) => { if (confirm && !window.confirm(confirm)) e.preventDefault(); }}>
      {pending ? "Working…" : children}
    </button>
  );
}

export function MobileNav({ children }: { children: React.ReactNode }) {
  const [open, setOpen] = useState(false);
  const path = usePathname();
  useEffect(() => setOpen(false), [path]);
  return (
    <>
      <button className="rounded-md p-2 lg:hidden" onClick={() => setOpen(true)} aria-label="Open navigation"><Menu size={20} /></button>
      {open && (
        <div className="fixed inset-0 z-50 lg:hidden">
          <div className="absolute inset-0 bg-black/40" onClick={() => setOpen(false)} />
          <div className="absolute inset-y-0 left-0 w-72 overflow-y-auto bg-white p-4">
            <button className="mb-2 rounded-md p-2" onClick={() => setOpen(false)} aria-label="Close"><X size={18} /></button>
            {children}
          </div>
        </div>
      )}
    </>
  );
}

export function NavLink({ href, children }: { href: string; children: React.ReactNode }) {
  const path = usePathname();
  const active = href === "/team" ? path === "/team" : path.startsWith(href);
  return (
    <Link href={href} className={`flex items-center gap-2.5 rounded-md px-2.5 py-1.5 text-sm ${active ? "bg-stone-900 text-white" : "text-stone-600 hover:bg-stone-100 hover:text-stone-900"}`}>
      {children}
    </Link>
  );
}

/** Assignee dropdown that narrows to the chosen team. */
export function TeamAssignee({ teams, staff, defaultTeam, lockTeam }: {
  teams: { id: string; name: string }[]; staff: { id: string; name: string; teamId: string | null }[]; defaultTeam?: string; lockTeam?: boolean;
}) {
  const [team, setTeam] = useState(defaultTeam ?? "");
  const people = staff.filter((s) => !team || team === "ALL" || s.teamId === team);
  return (
    <>
      <label className="block"><span className="t-label">Team</span>
        <select name="teamId" className="t-input" value={team} onChange={(e) => setTeam(e.target.value)} disabled={lockTeam}>
          {!lockTeam && <option value="ALL">Everyone (company-wide)</option>}
          {teams.map((t) => <option key={t.id} value={t.id}>{t.name}</option>)}
        </select>
        {lockTeam && <input type="hidden" name="teamId" value={team} />}
      </label>
      <label className="block"><span className="t-label">Assign to</span>
        <select name="assigneeId" className="t-input" defaultValue="">
          <option value="">Whole team (anyone can complete)</option>
          <option value="EACH">Each member — their own copy</option>
          {people.map((p) => <option key={p.id} value={p.id}>{p.name}</option>)}
        </select>
      </label>
    </>
  );
}

export function CopyText({ text }: { text: string }) {
  const [done, setDone] = useState(false);
  return (
    <button type="button" className="t-btn-ghost !py-1 !text-xs" onClick={() => { navigator.clipboard?.writeText(text); setDone(true); setTimeout(() => setDone(false), 1500); }}>
      {done ? "Copied" : "Copy"}
    </button>
  );
}

export function SelectAll({ form }: { form: string }) {
  return <input type="checkbox" aria-label="Select all" onChange={(e) => document.querySelectorAll<HTMLInputElement>(`form#${form} input[name=ids]`).forEach((c) => (c.checked = e.target.checked))} />;
}
