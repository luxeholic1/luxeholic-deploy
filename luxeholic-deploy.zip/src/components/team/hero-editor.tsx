"use client";
import { useMemo, useState, useTransition } from "react";
import { checkChapter, DEFAULT_HERO, type HeroChapter, type HeroContent } from "@/lib/hero-shared";
import { saveHero } from "@/app/team/actions/hero";

const vsrc = (v: string) => (/\.(mp4|webm)$/i.test(v) ? v : `${v}.mp4`);
const poster = (v: string) => (/\.(mp4|webm)$/i.test(v) ? undefined : `${v}.jpg`);

export function HeroEditor({ initial }: { initial: HeroContent }) {
  const [hero, setHero] = useState<HeroContent>(initial);
  const [msg, setMsg] = useState<{ ok?: string; error?: string } | null>(null);
  const [busy, setBusy] = useState<string | null>(null);
  const [pending, start] = useTransition();
  const checks = useMemo(() => hero.chapters.map((c, i) => checkChapter(c, i === hero.chapters.findIndex((x) => x.show))), [hero]);
  const blocking = hero.chapters.reduce((n, c, i) => n + (c.show ? checks[i].filter((x) => x.level === "bad").length : 0), 0);
  const warn = hero.chapters.reduce((n, c, i) => n + (c.show ? checks[i].filter((x) => x.level === "warn").length : 0), 0);

  const set = (i: number, patch: Partial<HeroChapter>) => setHero((h) => ({ ...h, chapters: h.chapters.map((c, k) => (k === i ? { ...c, ...patch } : c)) }));
  const move = (i: number, d: number) => setHero((h) => { const a = [...h.chapters]; const j = i + d; if (j < 0 || j >= a.length) return h; [a[i], a[j]] = [a[j], a[i]]; return { ...h, chapters: a }; });
  const remove = (i: number) => { if (hero.chapters.length < 2) return; if (confirmDel !== i) { setConfirmDel(i); return; } setConfirmDel(null); setHero((h) => ({ ...h, chapters: h.chapters.filter((_, k) => k !== i) })); };
  const [confirmDel, setConfirmDel] = useState<number | null>(null);
  const add = () => setHero((h) => ({ ...h, chapters: [...h.chapters, { id: `ch-${Date.now().toString(36)}`, show: false, video: "/media/hero/04-shop", theme: "dark", focus: 50, alt: "", eyebrow: "New chapter", headline: "", text: "", cta1: { label: "", href: "/shop" }, cta2: { label: "", href: "" } }] }));

  async function upload(i: number, f: File | undefined) {
    if (!f) return;
    setBusy(`Uploading video for chapter ${i + 1}…`); setMsg(null);
    const fd = new FormData(); fd.append("file", f);
    try {
      const r = await fetch("/api/team/hero-video", { method: "POST", body: fd });
      const j = (await r.json()) as { video?: string; encoded?: boolean; error?: string };
      if (!r.ok || !j.video) throw new Error(j.error ?? "Upload failed");
      set(i, { video: j.video, mobile: undefined });
      setMsg({ ok: j.encoded ? `Video added to chapter ${i + 1} and optimised for smooth scrolling. Save to publish.` : `Video added to chapter ${i + 1}. This server can't optimise videos (no ffmpeg) — it plays, but export with short keyframes for the smoothest scroll. Save to publish.` });
    } catch (e) { setMsg({ error: (e as Error).message }); }
    setBusy(null);
  }
  const save = () => start(async () => { setMsg(null); setMsg(await saveHero(hero)); });

  return (
    <div>
      <div className="sticky top-0 z-10 -mx-4 mb-4 flex flex-wrap items-center gap-2 border-b border-stone-200 bg-stone-50/95 px-4 py-3 backdrop-blur">
        <button className="t-btn" onClick={save} disabled={pending || !!busy}>{pending ? "Saving…" : "Save & publish"}</button>
        <button className="t-btn-ghost" onClick={add}>+ Add chapter</button>
        <button className="t-btn-ghost" onClick={() => setHero(DEFAULT_HERO)}>Reset to default</button>
        <a className="t-btn-ghost" href="/" target="_blank" rel="noopener">View homepage ↗</a>
        <span className="ml-auto flex gap-2 text-xs">
          <span className="rounded-full border border-stone-200 bg-white px-2.5 py-1">{hero.chapters.filter((c) => c.show).length} of {hero.chapters.length} shown</span>
          {blocking ? <span className="rounded-full border border-red-200 bg-white px-2.5 py-1 text-red-700">{blocking} blocking</span> : <span className="rounded-full border border-emerald-200 bg-white px-2.5 py-1 text-emerald-700">No blocking issues</span>}
          {warn > 0 && <span className="rounded-full border border-amber-200 bg-white px-2.5 py-1 text-amber-700">{warn} to review</span>}
        </span>
        {(busy || msg) && <p role="status" className={`w-full text-sm ${msg?.error ? "text-red-700" : "text-emerald-700"}`}>{busy ?? msg?.error ?? msg?.ok}</p>}
      </div>

      <div className="space-y-4">
        {hero.chapters.map((c, i) => (
          <article key={c.id} className={`t-card grid gap-5 p-4 lg:grid-cols-[320px_1fr] ${c.show ? "" : "opacity-60"}`}>
            <div>
              <div className="relative aspect-video overflow-hidden rounded-md bg-black">
                <video key={c.video} src={vsrc(c.video)} poster={poster(c.video)} muted loop playsInline preload="metadata" className="h-full w-full object-cover" onMouseEnter={(e) => e.currentTarget.play().catch(() => {})} onMouseLeave={(e) => e.currentTarget.pause()} />
                <span className="absolute left-2 top-2 rounded bg-black/60 px-1.5 py-0.5 text-[10px] uppercase tracking-wider text-white">Chapter {i + 1}{c.show ? "" : " · hidden"}</span>
              </div>
              <label className="mt-2 inline-block cursor-pointer text-sm underline">Replace video<input type="file" accept="video/mp4,video/quicktime,video/webm" className="sr-only" onChange={(e) => upload(i, e.target.files?.[0])} /></label>
              <p className="text-xs text-stone-500">6–15 s · at least 1280×720 · no sound needed · up to 80 MB</p>
              <label className="mt-3 block text-xs text-stone-600">Phone framing ({c.focus}%) — keep the subject in view<input type="range" min={0} max={100} step={5} value={c.focus} onChange={(e) => set(i, { focus: +e.target.value })} className="mt-1 w-full accent-stone-800" /></label>
            </div>
            <div>
              <div className="mb-3 flex flex-wrap items-center gap-2">
                <p className="font-medium">{c.eyebrow || `Chapter ${i + 1}`}</p>
                <label className="ml-2 flex items-center gap-1.5 text-sm"><input type="checkbox" checked={c.show} onChange={(e) => set(i, { show: e.target.checked })} /> Show</label>
                <span className="ml-auto flex gap-1">
                  <button className="t-btn-ghost !px-2 !py-1" aria-label="Move up" disabled={i === 0} onClick={() => move(i, -1)}>↑</button>
                  <button className="t-btn-ghost !px-2 !py-1" aria-label="Move down" disabled={i === hero.chapters.length - 1} onClick={() => move(i, 1)}>↓</button>
                  <button className="t-btn-danger !px-2 !py-1" onClick={() => remove(i)}>{confirmDel === i ? "Click again to delete" : "Delete"}</button>
                </span>
              </div>
              <div className="grid gap-3 sm:grid-cols-2">
                <F label="Small label"><input className="t-input" maxLength={48} value={c.eyebrow} onChange={(e) => set(i, { eyebrow: e.target.value })} /></F>
                <F label="Text colour"><select className="t-input" value={c.theme} onChange={(e) => set(i, { theme: e.target.value as "dark" | "light" })}><option value="dark">Light text (dark footage)</option><option value="light">Dark text (bright footage)</option></select></F>
                <F label={i === hero.chapters.findIndex((x) => x.show) ? "Headline (the page’s main heading)" : "Headline"} wide count={`${c.headline.length}/70`}><input className="t-input" maxLength={90} value={c.headline} onChange={(e) => set(i, { headline: e.target.value })} /></F>
                <F label="Text" wide count={`${c.text.length}/220`}><textarea className="t-input" rows={3} maxLength={260} value={c.text} onChange={(e) => set(i, { text: e.target.value })} /></F>
                <F label="Main button"><input className="t-input" maxLength={40} value={c.cta1.label} onChange={(e) => set(i, { cta1: { ...c.cta1, label: e.target.value } })} /></F>
                <F label="Main button link"><input className="t-input" maxLength={200} placeholder="/c/rugged-phones" value={c.cta1.href} onChange={(e) => set(i, { cta1: { ...c.cta1, href: e.target.value } })} /></F>
                <F label="Second link (optional)"><input className="t-input" maxLength={40} value={c.cta2.label} onChange={(e) => set(i, { cta2: { ...c.cta2, label: e.target.value } })} /></F>
                <F label="Second link goes to"><input className="t-input" maxLength={200} value={c.cta2.href} onChange={(e) => set(i, { cta2: { ...c.cta2, href: e.target.value } })} /></F>
                <F label="Video description (screen readers)" wide><input className="t-input" maxLength={160} value={c.alt} onChange={(e) => set(i, { alt: e.target.value })} /></F>
              </div>
              <ul className="mt-3 space-y-0.5 rounded-md border border-dashed border-stone-200 bg-stone-50 p-3 text-sm">
                <li className="text-[11px] font-semibold uppercase tracking-wider text-stone-500">Merchant Center checks</li>
                {checks[i].map((x, k) => <li key={k} className={x.level === "bad" ? "text-red-700" : x.level === "warn" ? "text-amber-700" : "text-emerald-700"}>{x.level === "bad" ? "✕" : x.level === "warn" ? "◐" : "✓"} {x.msg}</li>)}
              </ul>
            </div>
          </article>
        ))}
      </div>

      <section className="t-card mt-6 p-4">
        <p className="font-medium">Promise bar (bottom of the hero)</p>
        <p className="mb-3 text-sm text-stone-500">Keep these factual and matching your policy pages.</p>
        {hero.trust.map((t, i) => (
          <div key={i} className="mb-2 grid grid-cols-[1fr_1fr_auto] gap-2">
            <input className="t-input" aria-label={`Promise ${i + 1}`} maxLength={60} value={t.label} onChange={(e) => setHero((h) => ({ ...h, trust: h.trust.map((x, k) => (k === i ? { ...x, label: e.target.value } : x)) }))} />
            <input className="t-input" aria-label={`Promise ${i + 1} link`} maxLength={200} value={t.href} onChange={(e) => setHero((h) => ({ ...h, trust: h.trust.map((x, k) => (k === i ? { ...x, href: e.target.value } : x)) }))} />
            <button className="t-btn-ghost" aria-label="Remove promise" onClick={() => setHero((h) => ({ ...h, trust: h.trust.filter((_, k) => k !== i) }))}>✕</button>
          </div>
        ))}
        {hero.trust.length < 6 && <button className="t-btn-ghost mt-1" onClick={() => setHero((h) => ({ ...h, trust: [...h.trust, { label: "", href: "/" }] }))}>+ Add promise</button>}
      </section>
    </div>
  );
}

function F({ label, wide, count, children }: { label: string; wide?: boolean; count?: string; children: React.ReactNode }) {
  return <label className={`block ${wide ? "sm:col-span-2" : ""}`}><span className="t-label flex justify-between">{label}{count && <span className="font-normal text-stone-400">{count}</span>}</span>{children}</label>;
}
