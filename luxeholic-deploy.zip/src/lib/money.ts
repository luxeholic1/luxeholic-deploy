/** Money helpers. All amounts are integer paise (₹1 = 100 paise). */

const inr0 = new Intl.NumberFormat("en-IN", { style: "currency", currency: "INR", maximumFractionDigits: 0 });
const inr2 = new Intl.NumberFormat("en-IN", { style: "currency", currency: "INR", minimumFractionDigits: 2 });

export function formatINR(paise: number, exact = false) {
  const r = paise / 100;
  return exact || !Number.isInteger(r) ? inr2.format(r) : inr0.format(r);
}

export const toPaise = (rupees: number) => Math.round(rupees * 100);
export const toRupeeString = (paise: number) => (paise / 100).toFixed(2); // "1234.00" for gateways

/** Price tiers — "from middle class to the very rich": every visitor finds a door in. */
export const PRICE_TIERS = [
  { slug: "first-luxe", name: "First Luxe", line: "Luxury, under ₹5,000", min: 0, max: 500000 },
  { slug: "signature", name: "Signature", line: "₹5,000 – ₹25,000", min: 500000, max: 2500000 },
  { slug: "haute", name: "Haute", line: "₹25,000 and above", min: 2500000, max: null as number | null },
] as const;

export function tierOf(paise: number) {
  return PRICE_TIERS.find((t) => paise >= t.min && (t.max === null || paise < t.max))!;
}

/** Round UP to a clean luxury price point (no ".99" bargain look). */
export function luxuryRound(paise: number) {
  const r = paise / 100;
  const step = r < 2000 ? 50 : r < 10000 ? 100 : r < 50000 ? 500 : 1000;
  return Math.ceil(r / step) * step * 100;
}

export type PricingInput = {
  costMinor: number;      // vendor cost in minor units of vendor currency (cents)
  currency: string;       // USD | EUR | INR ...
  fx: Record<string, number>; // INR per 1 unit of currency
  markupPercent: number;
  dutyPercent: number;
  gstPercent: number;
  shippingFlat: number;   // paise per unit
};

/**
 * landed = cost × fx × (1 + duty) + shipping
 * price  = landed × (1 + markup) × (1 + GST)  → rounded up to a luxury price point
 * Prices are shown GST-inclusive (required for Google Merchant Center in India).
 */
export function priceFromCost(p: PricingInput) {
  const rate = p.currency === "INR" ? 1 : p.fx[p.currency];
  if (!rate) throw new Error(`No FX rate for ${p.currency}. Add it in Settings → FX rates.`);
  const costInr = (p.costMinor / 100) * rate * 100; // paise
  const landed = costInr * (1 + p.dutyPercent / 100) + p.shippingFlat;
  const price = landed * (1 + p.markupPercent / 100) * (1 + p.gstPercent / 100);
  return { landedCost: Math.round(landed), price: luxuryRound(price) };
}

/** GST portion contained in a GST-inclusive amount. */
export const gstPortion = (inclusive: number, gstPercent: number) =>
  Math.round((inclusive * gstPercent) / (100 + gstPercent));

/** Product condition for Google / schema.org, from tags ("used", "refurbished"); default new. */
export const productCondition = (tags: string[]): "new" | "used" | "refurbished" =>
  tags.includes("refurbished") ? "refurbished" : tags.includes("used") ? "used" : "new";

type Tr = (s: string, v?: Record<string, string | number>) => string;
/** A tier's price line in the visitor's language and currency. */
export function tierLine(tier: (typeof PRICE_TIERS)[number], t: Tr, money: (p: number) => string) {
  if (tier.min === 0) return t("Luxury, under {price}", { price: money(tier.max!) });
  if (tier.max === null) return t("{price} and above", { price: money(tier.min) });
  return `${money(tier.min)} – ${money(tier.max)}`;
}
