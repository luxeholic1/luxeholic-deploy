/**
 * PhonePe Payment Gateway — Standard Checkout v2 (OAuth client credentials).
 * Docs: https://developer.phonepe.com/payment-gateway  (Business dashboard → Developer Settings)
 * Env: PHONEPE_CLIENT_ID, PHONEPE_CLIENT_SECRET, PHONEPE_CLIENT_VERSION (default 1),
 *      PHONEPE_MODE=sandbox|live, PHONEPE_WEBHOOK_USER, PHONEPE_WEBHOOK_PASS
 * Endpoints below match PhonePe's published v2 spec — re-check them when you receive production keys.
 */
import { sha256, safeEqual } from "../crypto";
import { SITE_URL } from "../site";

export const phonepeConfigured = () => Boolean(process.env.PHONEPE_CLIENT_ID && process.env.PHONEPE_CLIENT_SECRET);

const live = () => process.env.PHONEPE_MODE === "live";
const authBase = () => (live() ? "https://api.phonepe.com/apis/identity-manager" : "https://api-preprod.phonepe.com/apis/pg-sandbox");
const pgBase = () => (live() ? "https://api.phonepe.com/apis/pg" : "https://api-preprod.phonepe.com/apis/pg-sandbox");

let cached: { token: string; exp: number } | null = null;

async function token() {
  if (cached && cached.exp - 60 > Date.now() / 1000) return cached.token;
  const res = await fetch(`${authBase()}/v1/oauth/token`, {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: new URLSearchParams({
      client_id: process.env.PHONEPE_CLIENT_ID!,
      client_version: process.env.PHONEPE_CLIENT_VERSION || "1",
      client_secret: process.env.PHONEPE_CLIENT_SECRET!,
      grant_type: "client_credentials",
    }),
  });
  const j = await res.json();
  if (!res.ok || !j.access_token) throw new Error(`PhonePe auth failed: ${JSON.stringify(j).slice(0, 200)}`);
  cached = { token: j.access_token, exp: j.expires_at ?? Date.now() / 1000 + 3000 };
  return cached.token;
}

/** Creates a checkout and returns PhonePe's hosted payment page URL. */
export async function createPhonepePayment(p: { txnId: string; amount: number; orderNumber: string }) {
  const res = await fetch(`${pgBase()}/checkout/v2/pay`, {
    method: "POST",
    headers: { "Content-Type": "application/json", Authorization: `O-Bearer ${await token()}` },
    body: JSON.stringify({
      merchantOrderId: p.txnId,
      amount: p.amount, // paise
      expireAfter: 1200,
      metaInfo: { udf1: p.orderNumber },
      paymentFlow: {
        type: "PG_CHECKOUT",
        message: `Luxeholic order ${p.orderNumber}`,
        merchantUrls: { redirectUrl: `${SITE_URL}/api/payments/phonepe/return?txn=${encodeURIComponent(p.txnId)}` },
      },
    }),
  });
  const j = await res.json();
  if (!res.ok || !j.redirectUrl) throw new Error(`PhonePe pay failed: ${JSON.stringify(j).slice(0, 300)}`);
  return { redirectUrl: j.redirectUrl as string, providerRef: j.orderId as string };
}

/** Server-to-server status check — the source of truth (never trust the redirect alone). */
export async function phonepeStatus(txnId: string) {
  const res = await fetch(`${pgBase()}/checkout/v2/order/${encodeURIComponent(txnId)}/status`, {
    headers: { "Content-Type": "application/json", Authorization: `O-Bearer ${await token()}` },
    cache: "no-store",
  });
  const j = await res.json();
  return {
    state: (j.state as "COMPLETED" | "FAILED" | "PENDING") ?? "PENDING",
    amount: Number(j.amount ?? 0),
    providerRef: j.paymentDetails?.[0]?.transactionId ?? j.orderId ?? null,
    raw: j,
  };
}

/** Webhook auth: Authorization header = SHA256("username:password") configured in PhonePe dashboard. */
export function verifyPhonepeWebhook(authHeader: string | null) {
  const u = process.env.PHONEPE_WEBHOOK_USER, p = process.env.PHONEPE_WEBHOOK_PASS;
  if (!u || !p || !authHeader) return false;
  return safeEqual(sha256(`${u}:${p}`), authHeader.replace(/^SHA256\s*/i, "").trim().toLowerCase());
}
