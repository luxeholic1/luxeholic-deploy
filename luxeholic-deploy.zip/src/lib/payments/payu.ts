/**
 * PayU India — hosted checkout (form POST to PayU, PayU POSTs back to surl/furl).
 * Docs: https://docs.payu.in  (Merchant dashboard → Developers → Key & Salt)
 * Env: PAYU_KEY, PAYU_SALT, PAYU_MODE=test|live
 */
import { sha512, safeEqual } from "../crypto";
import { toRupeeString } from "../money";
import { SITE_URL } from "../site";

export const payuConfigured = () => Boolean(process.env.PAYU_KEY && process.env.PAYU_SALT);
const endpoint = () => (process.env.PAYU_MODE === "live" ? "https://secure.payu.in/_payment" : "https://test.payu.in/_payment");

export function buildPayuForm(p: {
  txnid: string; amount: number; productinfo: string; firstname: string; email: string; phone: string; orderNumber: string;
}) {
  const key = process.env.PAYU_KEY!;
  const salt = process.env.PAYU_SALT!;
  const amount = toRupeeString(p.amount);
  const firstname = p.firstname.replace(/[^\w .-]/g, "").slice(0, 60) || "Customer";
  const productinfo = p.productinfo.replace(/[|]/g, " ").slice(0, 100);
  const udf1 = p.orderNumber;
  // key|txnid|amount|productinfo|firstname|email|udf1|udf2|udf3|udf4|udf5||||||SALT
  const hash = sha512([key, p.txnid, amount, productinfo, firstname, p.email, udf1, "", "", "", "", "", "", "", "", "", "", salt].join("|"));
  const cb = `${SITE_URL}/api/payments/payu/callback`;
  return {
    action: endpoint(),
    fields: { key, txnid: p.txnid, amount, productinfo, firstname, email: p.email, phone: p.phone, udf1, surl: cb, furl: cb, hash, service_provider: "payu_paisa" },
  };
}

/** Verify PayU's response hash (reverse order). Returns null when tampered. */
export function verifyPayuResponse(f: Record<string, string>) {
  const salt = process.env.PAYU_SALT!;
  const key = process.env.PAYU_KEY!;
  const seq = [salt, f.status, "", "", "", "", "", f.udf5 ?? "", f.udf4 ?? "", f.udf3 ?? "", f.udf2 ?? "", f.udf1 ?? "", f.email, f.firstname, f.productinfo, f.amount, f.txnid, key];
  if (f.additionalCharges) seq.unshift(f.additionalCharges);
  const expected = sha512(seq.join("|"));
  if (!f.hash || !safeEqual(expected, f.hash.toLowerCase())) return null;
  return {
    txnid: f.txnid,
    success: f.status === "success",
    amountPaise: Math.round(parseFloat(f.amount) * 100),
    providerRef: f.mihpayid,
    message: f.error_Message || f.field9 || f.status,
  };
}
