import { cache } from "react";
import { cookies, headers } from "next/headers";
import { redirect } from "next/navigation";
import { SignJWT, jwtVerify } from "jose";
import bcrypt from "bcryptjs";
import { and, eq, gte, sql } from "drizzle-orm";
import { db, schema } from "@/db";
import { accessLevel, type Level, type ModuleKey } from "./rbac";

const STAFF_COOKIE = "lx_staff";
const CUSTOMER_COOKIE = "lx_cust";
const STAFF_TTL = 60 * 60 * 12; // 12h working session
const CUSTOMER_TTL = 60 * 60 * 24 * 30;

function secret() {
  const s = process.env.AUTH_SECRET;
  if (!s || s.length < 32) throw new Error("AUTH_SECRET must be set (32+ random characters)");
  return new TextEncoder().encode(s);
}

export const hashPassword = (p: string) => bcrypt.hash(p, 11);
export const verifyPassword = (p: string, h: string) => bcrypt.compare(p, h);

export function passwordProblem(p: string) {
  if (p.length < 10) return "Use at least 10 characters.";
  if (!/[A-Za-z]/.test(p) || !/[0-9]/.test(p)) return "Use letters and at least one number.";
  return null;
}

async function sign(payload: Record<string, unknown>, ttl: number) {
  return new SignJWT(payload).setProtectedHeader({ alg: "HS256" }).setIssuedAt().setExpirationTime(`${ttl}s`).sign(secret());
}
async function read<T>(name: string): Promise<T | null> {
  const token = (await cookies()).get(name)?.value;
  if (!token) return null;
  try {
    return (await jwtVerify(token, secret())).payload as T;
  } catch {
    return null;
  }
}
async function setCookie(name: string, value: string, maxAge: number) {
  (await cookies()).set(name, value, {
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    sameSite: "lax",
    path: "/",
    maxAge,
  });
}

export async function clientIp() {
  const h = await headers();
  return (h.get("x-forwarded-for")?.split(",")[0] || h.get("x-real-ip") || "").trim() || null;
}

// ─────────── Brute-force protection ───────────
export async function tooManyAttempts(key: string) {
  const since = new Date(Date.now() - 15 * 60 * 1000);
  const [r] = await db
    .select({ n: sql<number>`count(*)::int` })
    .from(schema.loginAttempts)
    .where(and(eq(schema.loginAttempts.key, key), eq(schema.loginAttempts.ok, false), gte(schema.loginAttempts.createdAt, since)));
  return (r?.n ?? 0) >= 8;
}
export const recordAttempt = (key: string, ok: boolean) => db.insert(schema.loginAttempts).values({ key, ok });

// ─────────── Staff ───────────
export async function startStaffSession(staffId: string, version: number) {
  await setCookie(STAFF_COOKIE, await sign({ sid: staffId, v: version }, STAFF_TTL), STAFF_TTL);
}
export async function endStaffSession() {
  (await cookies()).delete(STAFF_COOKIE);
}

export type CurrentStaff = NonNullable<Awaited<ReturnType<typeof getStaff>>>;

export const getStaff = cache(async () => {
  const p = await read<{ sid: string; v: number }>(STAFF_COOKIE);
  if (!p?.sid) return null;
  const s = await db.query.staff.findFirst({ where: eq(schema.staff.id, p.sid), with: { team: true } });
  if (!s || !s.active || s.sessionVersion !== p.v) return null;
  const { passwordHash: _ph, ...safe } = s;
  return safe;
});

/** Guard for team pages. Pass a module to enforce panel access. */
export async function requireStaff(module?: ModuleKey, level: Level = "read") {
  const s = await getStaff();
  if (!s) redirect("/team/login");
  if (s.mustChangePassword) redirect("/team/change-password");
  if (module) {
    const a = accessLevel(s, module);
    if (!a || (level === "write" && a !== "write")) redirect("/team?denied=" + module);
  }
  return s;
}
export async function requireSuper() {
  const s = await requireStaff();
  if (s.role !== "SUPER_ADMIN") redirect("/team?denied=admin");
  return s;
}

// ─────────── Customers ───────────
export async function startCustomerSession(customerId: string) {
  await setCookie(CUSTOMER_COOKIE, await sign({ cid: customerId }, CUSTOMER_TTL), CUSTOMER_TTL);
}
export async function endCustomerSession() {
  (await cookies()).delete(CUSTOMER_COOKIE);
}
export const getCustomer = cache(async () => {
  const p = await read<{ cid: string }>(CUSTOMER_COOKIE);
  if (!p?.cid) return null;
  const c = await db.query.customers.findFirst({ where: eq(schema.customers.id, p.cid) });
  if (!c) return null;
  const { passwordHash: _ph, ...safe } = c;
  return safe;
});
export async function requireCustomer(next = "/account") {
  const c = await getCustomer();
  if (!c) redirect(`/login?next=${encodeURIComponent(next)}`);
  return c;
}

// ─────────── Guests ───────────
// Orders placed without an account are remembered on this device (signed cookie, 90 days)
// so the guest panel can list them without a password.
const GUEST_COOKIE = "lx_guest";
const GUEST_TTL = 60 * 60 * 24 * 90;
export type GuestOrderRef = { n: string; t: string };
export async function getGuestOrders(): Promise<GuestOrderRef[]> {
  const p = await read<{ o?: GuestOrderRef[] }>(GUEST_COOKIE);
  return Array.isArray(p?.o) ? p!.o.filter((x) => typeof x?.n === "string" && typeof x?.t === "string").slice(0, 20) : [];
}
export async function rememberGuestOrder(number: string, token: string) {
  const list = (await getGuestOrders()).filter((x) => x.n !== number);
  list.unshift({ n: number, t: token });
  await setCookie(GUEST_COOKIE, await sign({ o: list.slice(0, 20) }, GUEST_TTL), GUEST_TTL);
}
export async function forgetGuestOrders() { (await cookies()).delete(GUEST_COOKIE); }
