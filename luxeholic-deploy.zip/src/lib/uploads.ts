import path from "node:path";

/** Where product photos uploaded from the team panel are stored (outside the build, survives deploys). */
export const UPLOAD_DIR = path.resolve(process.env.UPLOAD_DIR || "./uploads");
export const IMAGE_TYPES: Record<string, string> = { "image/jpeg": "jpg", "image/png": "png", "image/webp": "webp" };
export const MAX_IMAGE_BYTES = 5 * 1024 * 1024;
