import { and, eq, inArray, lt } from "drizzle-orm";
import { db, schema } from "@/db";
import { dailyTaskJob } from "./tasks";
import { syncAllVendors } from "./vendors/sync";
import { restock } from "./orders";
import { refreshDisplayRates } from "./fx-display";

/** Unpaid online orders older than 2 hours are cancelled and their stock released. */
export async function cleanupAbandoned() {
  const cutoff = new Date(Date.now() - 2 * 60 * 60 * 1000);
  const stale = await db.select({ id: schema.orders.id }).from(schema.orders).where(and(
    eq(schema.orders.status, "PENDING"), lt(schema.orders.createdAt, cutoff),
    inArray(schema.orders.paymentMethod, ["PAYU", "PHONEPE", "PARTIAL_COD"]),
    inArray(schema.orders.paymentStatus, ["PENDING", "FAILED"]),
  ));
  for (const o of stale) {
    await db.update(schema.orders).set({ status: "CANCELLED", internalNotes: "Auto-cancelled: payment not completed within 2 hours" }).where(eq(schema.orders.id, o.id));
    await restock(o.id);
  }
  return { cancelled: stale.length };
}

export async function runJob(job: string) {
  switch (job) {
    case "daily": return { tasks: await dailyTaskJob(), cleanup: await cleanupAbandoned(), rates: await refreshDisplayRates().catch((e: Error) => ({ error: e.message })) };
    case "rates": return refreshDisplayRates(true);
    case "sync": return syncAllVendors();
    case "cleanup": return cleanupAbandoned();
    default: throw new Error(`Unknown job ${job}`);
  }
}
