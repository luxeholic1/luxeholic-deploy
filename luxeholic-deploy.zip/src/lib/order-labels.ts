export const ORDER_LABEL: Record<string, string> = {
  PENDING: "Awaiting payment", CONFIRMED: "Confirmed", PROCESSING: "Being prepared", SHIPPED: "On its way", DELIVERED: "Delivered",
  CANCELLED: "Cancelled", RETURN_REQUESTED: "Return requested", RETURNED: "Returned",
};
export const PAY_LABEL: Record<string, string> = {
  PENDING: "Payment pending", AWAITING_VERIFICATION: "Verifying transfer", PARTIALLY_PAID: "Advance paid", PAID: "Paid", FAILED: "Payment failed", REFUNDED: "Refunded",
};
export const ACTIVE_ORDER = ["PENDING", "CONFIRMED", "PROCESSING", "SHIPPED", "RETURN_REQUESTED"];
