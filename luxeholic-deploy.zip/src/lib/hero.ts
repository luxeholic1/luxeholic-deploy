import { eq } from "drizzle-orm";
import { db, schema } from "@/db";
import { DEFAULT_HERO, type HeroContent } from "./hero-shared";
export * from "./hero-shared";
import { localize, siteTexts } from "./i18n/content";
import type { Locale } from "./i18n/config";

export async function getHero(): Promise<HeroContent> {
  try {
    const [row] = await db.select().from(schema.settings).where(eq(schema.settings.key, "hero"));
    const v = row?.value as HeroContent | undefined;
    if (v?.chapters?.length) return { chapters: v.chapters, trust: v.trust ?? DEFAULT_HERO.trust };
  } catch { /* fall back to defaults */ }
  return DEFAULT_HERO;
}


/** The hero in the visitor's language. Non-English: chapters (and promises) without a current translation are left out. */
export async function getLocalizedHero(locale: Locale): Promise<HeroContent> {
  const hero = await getHero();
  if (locale === "en") return hero;
  const flat = hero.chapters.map((c) => ({ id: c.id, eyebrow: c.eyebrow, headline: c.headline, text: c.text, cta1: c.cta1.label, cta2: c.cta2.label, alt: c.alt }));
  const { items } = await localize("hero", flat, locale);
  const m = new Map(items.map((x) => [x.id, x]));
  const chapters = hero.chapters.filter((c) => m.has(c.id)).map((c) => {
    const x = m.get(c.id)!;
    return { ...c, eyebrow: x.eyebrow, headline: x.headline, text: x.text, alt: x.alt, cta1: { ...c.cta1, label: x.cta1 }, cta2: { ...c.cta2, label: x.cta2 } };
  });
  const tr = await siteTexts(Object.fromEntries(hero.trust.map((t, i) => [`hero-trust-${i}`, t.label])), locale, "hide");
  const trust = hero.trust.map((t, i) => ({ ...t, label: tr[`hero-trust-${i}`] })).filter((t) => t.label);
  return { chapters, trust };
}
