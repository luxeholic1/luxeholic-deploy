import { sql, type SQL } from "drizzle-orm";
import { schema } from "@/db";
import { SITE_NAME } from "@/lib/site";

/**
 * Per-product Google Merchant Center quality checks — the same rules the feed (/feed/google.xml) relies on.
 * Each check has a weight; the score is out of 100. Computed in SQL so 30k+ products can be sorted and summarised.
 */
const p = schema.products, c = schema.categories;
const plain = sql`regexp_replace(coalesce(${p.description}, ''), '<[^>]*>', '', 'g')`;
export const GMC_CHECKS: { key: string; weight: number; label: string; fix: string; pass: SQL }[] = [
  { key: "image", weight: 20, label: "Main image", fix: "Add at least one clear photo (no watermark or text on it)", pass: sql`jsonb_array_length(${p.images}) > 0` },
  { key: "desc", weight: 15, label: "Description ≥ 80 characters", fix: "Write a fuller description (what it is, key specs, what’s in the box)", pass: sql`length(${plain}) >= 80` },
  { key: "ids", weight: 15, label: "GTIN or MPN", fix: "Add the barcode (GTIN/EAN) or the maker’s part number (MPN)", pass: sql`(${p.gtin} is not null and ${p.gtin} <> '') or ${p.brand} = ${SITE_NAME} or (${p.mpn} is not null and ${p.mpn} <> '')` },
  { key: "title", weight: 10, label: "Title 15–150 characters", fix: "Use brand + product + key attribute, at most 150 characters", pass: sql`length(${p.title}) between 15 and 150` },
  { key: "promo", weight: 10, label: "No promo text or ALL CAPS in title", fix: "Remove words like “sale”, “free shipping”, “best” and shouting capitals", pass: sql`not (${p.title} ~* '(free ship|\\msale\\M|discount|best price|cheapest|offer|!!)' or (length(${p.title}) > 12 and ${p.title} = upper(${p.title}) and ${p.title} ~ '[A-Z]{6}'))` },
  { key: "price", weight: 10, label: "Price set", fix: "Set a selling price", pass: sql`${p.price} > 0` },
  { key: "gcat", weight: 10, label: "Google product category", fix: "Set the Google category on this product’s category (Team → Categories)", pass: sql`${c.googleCategory} is not null and ${c.googleCategory} <> ''` },
  { key: "brand", weight: 5, label: "Brand", fix: "Set the brand", pass: sql`${p.brand} is not null and ${p.brand} <> ''` },
  { key: "gallery", weight: 5, label: "2+ images", fix: "Add a second angle or a detail shot", pass: sql`jsonb_array_length(${p.images}) > 1` },
];
export const gmcScoreSql = sql.join(GMC_CHECKS.map((k) => sql`(case when ${k.pass} then ${k.weight} else 0 end)`), sql` + `);
export const gmcFlagsSql = sql.join(GMC_CHECKS.map((k) => sql`(case when ${k.pass} then '' else ${k.key + ","} end)`), sql` || `);
export function gmcBand(score: number) {
  return score >= 90 ? { label: "Ready", tone: "green" as const } : score >= 70 ? { label: "Needs a fix", tone: "amber" as const } : { label: "Likely disapproved", tone: "red" as const };
}
