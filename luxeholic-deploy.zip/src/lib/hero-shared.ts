/** Shared by the browser editor and the server — no database imports here. */

/** Homepage scroll-video hero: chapters edited in Team → Marketing → Homepage hero. */
export type HeroLink = { label: string; href: string };
export type HeroChapter = {
  id: string; show: boolean;
  video: string;          // base path without extension (".mp4"/".webm"/".jpg" are added), or a full .mp4 URL
  mobile?: string;        // optional portrait version for phones
  theme: "dark" | "light"; focus: number; alt: string;
  eyebrow: string; headline: string; text: string; cta1: HeroLink; cta2: HeroLink;
};
export type HeroContent = { chapters: HeroChapter[]; trust: HeroLink[] };

export const DEFAULT_HERO: HeroContent = {
  trust: [
    { label: "GST invoice on every order", href: "/policies/payments" },
    { label: "Easy returns on unused items", href: "/policies/returns" },
    { label: "Insured delivery across India", href: "/policies/shipping" },
    { label: "Secure checkout · UPI, cards, net banking", href: "/policies/payments" },
  ],
  chapters: [
    { id: "rugged", show: true, video: "/media/hero/01-rugged", theme: "dark", focus: 50,
      alt: "A rugged smartphone with a rear camera module, shown against a night sky",
      eyebrow: "Lux-Tech · Rugged phones", headline: "Rugged 5G phones, built for every terrain.",
      text: "Ulefone, Unihertz, Oukitel, Blackview and Doogee devices with up to IP68/IP69K protection and long-life batteries — checked, sealed and shipped insured with a GST invoice.",
      cta1: { label: "Shop rugged phones", href: "/c/rugged-phones" }, cta2: { label: "All Lux-Tech", href: "/c/lux-tech" } },
    { id: "unbox", show: true, video: "/media/hero/02-unbox", theme: "light", focus: 50,
      alt: "Hands unboxing a rugged phone with its charger and cable",
      eyebrow: "What’s in the box", headline: "Factory-sealed. GST-invoiced.",
      text: "Every device arrives in its original sealed box with the maker’s accessories, a tax invoice in your name and easy returns on unused items.",
      cta1: { label: "How we ship", href: "/policies/shipping" }, cta2: { label: "Return policy", href: "/policies/returns" } },
    { id: "glasses", show: true, video: "/media/hero/03-glasses", mobile: "/media/hero/03-glasses-m", theme: "dark", focus: 50,
      alt: "AI smart glasses: voice assistant, translation, object recognition, camera and battery",
      eyebrow: "Lux-Tech · Smart glasses", headline: "AI smart glasses, hands-free.",
      text: "Open-ear audio, an 8MP camera, live translation and a voice assistant in the frame you wear every day. Features vary by model — each listing has the full specifications.",
      cta1: { label: "Explore smart glasses", href: "/c/ai-smart-glasses" }, cta2: { label: "Contact the concierge", href: "/contact" } },
    { id: "shop", show: true, video: "/media/hero/04-shop", theme: "dark", focus: 50,
      alt: "Hands browsing a shop on a tablet in a dark room",
      eyebrow: "LUXEHOLIC · Noida, India", headline: "Art, décor, fashion & Lux-Tech, delivered across India.",
      text: "Prices in INR including GST. Pay securely by UPI, cards, net banking — or cash on delivery.",
      cta1: { label: "Shop everything", href: "/shop" }, cta2: { label: "Luxury under ₹5,000", href: "/collections/first-luxe" } },
  ],
};

// ─────────── Google Merchant Center checks (shared by the editor and the server) ───────────
const PROMO = /(?<![\w-])(free|best|#1|no\.?\s?1|cheapest|lowest price|guarantee[ds]?|sale|% ?off|limited time|hurry|offer|deal|buy now|click here|discount)\b/i;
const CAPS_OK = /^(LUXEHOLIC|GST|INR|UPI|AI|5G|4G|IP68|IP69K|8MP|USB|NFC|OTG|LED|EMI|DJI|TV)$/;
export const SAFE_LINK = /^(\/(?!\/)[^\s]*|https:\/\/(www\.)?luxeholic\.in(\/[^\s]*)?)$/i;
export type Check = { level: "ok" | "warn" | "bad"; msg: string };

export function checkChapter(c: HeroChapter, first: boolean): Check[] {
  const out: Check[] = [];
  const add = (level: Check["level"], msg: string) => out.push({ level, msg });
  const h = c.headline.trim(), t = c.text.trim();
  if (!h) add("bad", "Headline is empty.");
  else if (h.length > 70) add("warn", `Headline is ${h.length} characters — keep it under 70 so it fits on phones.`);
  if (t.length > 220) add("warn", `Text is ${t.length} characters — keep it under 220.`);
  for (const [where, v] of [["headline", h], ["text", t], ["label", c.eyebrow], ["button", c.cta1.label], ["second link", c.cta2.label]] as const) {
    const m = v.match(PROMO);
    if (m) add("bad", `Promotional word “${m[0]}” in the ${where}. Merchant Center flags promo and urgency wording unless the offer is real and shown at checkout.`);
    if (/!{2,}|\?{2,}/.test(v)) add("warn", `Repeated punctuation in the ${where}.`);
    const caps = (v.match(/\b[A-Z0-9]{4,}\b/g) ?? []).filter((w) => !CAPS_OK.test(w) && /[A-Z]/.test(w));
    if (caps.length) add("warn", `ALL-CAPS word in the ${where}: ${caps.join(", ")}.`);
  }
  if (!c.cta1.label.trim()) add("bad", "Add a main button so the chapter leads somewhere.");
  for (const [k, b] of [["Main button", c.cta1], ["Second link", c.cta2]] as const) {
    if (b.label.trim() && !SAFE_LINK.test(b.href.trim())) add("bad", `${k} must go to a page on luxeholic.in (e.g. /shop or /c/rugged-phones).`);
  }
  if (!c.alt.trim()) add("warn", "Describe the video for screen readers.");
  if (first && h && !/(phone|fashion|glasses|art|décor|decor|sculpture|tech|gift|jewel|watch|bag)/i.test(h)) add("warn", "The first headline is the page’s main heading — say what you sell.");
  if (/₹\s?\d|\d\s?(rs|inr)\b/i.test(`${h} ${t}`)) add("warn", "Prices in the hero must match the product pages exactly — or leave them out.");
  if (!out.length) add("ok", "Ready for Merchant Center.");
  return out;
}
