import { businessAddress, type Settings } from "./settings";
import { formatINR } from "./money";

/**
 * Policy pages written for Google Merchant Center review: clear return window & conditions,
 * refund timelines, shipping costs + handling/transit times, payment methods, contact details.
 * Values come from Store Settings, so the pages always match the checkout and the feed.
 */
export function policyHtml(slug: string, s: Settings): string | null {
  const b = s.business;
  const who = b.legalName ? `${b.legalName} (“Luxeholic”, “we”, “us”)` : "Luxeholic (“we”, “us”)";
  const contact = `<p>Email <a href="mailto:${b.email}">${b.email}</a>${b.phone ? ` · Phone/WhatsApp ${b.phone}` : ""} · ${b.supportHours}<br/>Address: ${businessAddress(b)}</p>`;
  const r = s.returns.windowDays;
  const p = s.payments;
  const ship = s.shipping.freeAbove === 0 ? "Shipping is <b>free on every order</b> across India, and every parcel is insured in transit."
    : `Shipping is free on orders of ${formatINR(s.shipping.freeAbove)} or more; a flat ${formatINR(s.shipping.flatFee)} applies below that. Every parcel is insured in transit.`;

  const pages: Record<string, string> = {
    shipping: `
<p>${ship} We currently deliver to all serviceable PIN codes in India.</p>
<h2>When will my order arrive?</h2>
<table><thead><tr><th>Collection</th><th>Dispatch (handling)</th><th>Delivery after dispatch</th></tr></thead><tbody>
<tr><td>Art & Sculpture, Home Décor</td><td>1–3 business days</td><td>7–15 business days</td></tr>
<tr><td>Designer Fashion, Gifting & Accessories</td><td>1–3 business days</td><td>7–12 business days</td></tr>
<tr><td>Lux-Tech</td><td>1–3 business days</td><td>7–15 business days</td></tr>
</tbody></table>
<p>Each product page shows an estimated delivery window for that piece. Orders placed on Sundays or public holidays are processed the next business day. Some pieces travel to us from our international design partners before final inspection, which is why delivery can take up to 15 business days; all import duties are already included in the price — you will never be asked to pay anything extra at the door (other than the balance on a Cash-on-Delivery order).</p>
<h2>Tracking</h2>
<p>As soon as your order ships, we email you the courier name and tracking number. You can also check status any time on <a href="/track-order">Track your order</a>.</p>
<h2>Damaged or missing parcels</h2>
<p>Please record a short unboxing video. If a parcel arrives damaged or tampered with, write to us within 48 hours of delivery with photos; we will replace the piece or refund you in full.</p>
<h2>Contact</h2>${contact}`,

    returns: `
<p>We want you to love every piece. If something isn't right, you may return it within <b>${r} days of delivery</b>.</p>
<h2>Conditions</h2>
<ul><li>The item must be unused, in its original condition and packaging, with all tags, certificates and accessories.</li>
<li>Earrings, fragrances, personalised or made-to-order items cannot be returned unless they arrive damaged or defective.</li>
<li>Designer fashion must be unworn, with brand tags attached.</li></ul>
<h2>How to return</h2>
<ol><li>Open your order from the confirmation email (or <a href="/track-order">Track your order</a>) and choose <b>Request a return</b>, or email us with your order number.</li>
<li>We arrange a <b>free reverse pickup</b> from your address within 2–4 business days. Return shipping is free.</li>
<li>Once the item reaches us and passes inspection (1–2 business days), we issue your refund.</li></ol>
<h2>Refunds</h2>
<ul><li>Online payments (UPI, cards, netbanking, PhonePe) are refunded to the original payment method within <b>5–7 business days</b> of approval.</li>
<li>Cash-on-delivery and bank-transfer payments are refunded by bank transfer (NEFT/IMPS) to an account you share with us, within 5–7 business days.</li>
<li>The advance paid on a “Pay ${p.advancePercent}% now” order is refunded the same way if the order is cancelled before dispatch.</li></ul>
<h2>Exchanges</h2><p>Need a different size or colour? Request a return and place a new order — or write to us and we'll reserve the replacement for you.</p>
<h2>Cancellations</h2><p>You can cancel free of charge any time before dispatch by contacting us. After dispatch, please use the returns process.</p>
<h2>Contact</h2>${contact}`,

    payments: `
<p>All prices are in Indian Rupees (INR) and include GST. We accept:</p>
<ul>
<li><b>UPI, debit/credit cards, netbanking and wallets</b> through PayU and PhonePe — RBI-regulated payment gateways. We never see or store your card details.</li>
<li><b>Bank transfer</b> (NEFT/RTGS/IMPS). Account details appear on your order page; share the UTR number and we confirm within a few working hours.</li>
<li><b>Pay ${p.advancePercent}% now, rest on delivery</b> — pay a ${p.advancePercent}% advance online to confirm the order and the balance in cash or UPI when it arrives (orders up to ${formatINR(p.partialCodMaxOrder)}).</li>
<li><b>Cash on delivery</b> for orders up to ${formatINR(p.codMaxOrder)}. We call to confirm COD orders before dispatch.${p.codFee ? ` A ${formatINR(p.codFee)} COD fee applies.` : ""}</li>
</ul>
<p>A GST invoice is emailed with every order. Add your GSTIN at checkout for a business invoice.</p>
<h2>Contact</h2>${contact}`,

    authenticity: `
<p>Every designer piece on Luxeholic is <b>100% authentic</b>. Our designer fashion and accessories are sourced through established European luxury distribution partners who buy directly from brands and authorised wholesalers.</p>
<ul><li>Items ship with original brand tags and, where the brand provides them, dust bags, boxes and authenticity cards.</li>
<li>Our team inspects pieces before dispatch.</li>
<li>If any item is ever proven not to be genuine, we will refund the full amount you paid, including shipping.</li></ul>
<p>Our own Luxeholic-label sculpture, décor and Lux-Tech pieces are selected and quality-checked by our curators; product pages state materials and finishes honestly.</p>
<h2>Contact</h2>${contact}`,

    privacy: `
<p>${who} respects your privacy. This policy explains what we collect and why, in line with India's Digital Personal Data Protection Act, 2023.</p>
<h2>What we collect</h2>
<ul><li>Details you give us: name, email, phone, delivery address, GSTIN (optional), messages to client care.</li>
<li>Order and payment status (payments are processed by PayU / PhonePe — we never receive full card details).</li>
<li>With your consent: cookies and analytics/advertising tags (Google Analytics, Google Ads) to understand what you like and show relevant ads. You can decline in the cookie banner.</li></ul>
<h2>How we use it</h2>
<ul><li>To process, deliver and support your orders, and to prevent fraud.</li><li>To send order updates. Marketing emails only if you opt in — unsubscribe any time.</li></ul>
<h2>Who we share it with</h2>
<p>Only service providers needed to fulfil your order: payment gateways, courier partners, our supply partners (name, address and phone for delivery), email delivery and hosting providers. We never sell your data.</p>
<h2>Your rights</h2>
<p>You may access, correct or delete your personal data, or withdraw consent, by emailing <a href="mailto:${b.email}">${b.email}</a>. We respond within 30 days. Order records are kept for 8 years as required by Indian tax law.</p>
<h2>Security</h2><p>All traffic is encrypted (HTTPS). Passwords are stored hashed. Access to customer data is restricted to authorised staff and logged.</p>
<h2>Grievance officer</h2>${contact}`,

    terms: `
<p>These terms govern your use of luxeholic.in, operated by ${who}. By placing an order you agree to them.</p>
<h2>Products & pricing</h2><p>We describe pieces as accurately as possible; handcrafted and resin items may vary slightly in finish, which is part of their character. Prices are in INR including GST and may change without notice, but you always pay the price shown at checkout. If a pricing error occurs, we will contact you before dispatch and you may cancel for a full refund.</p>
<h2>Orders</h2><p>An order is confirmed once payment (or the COD advance) is received, or once we verify a COD order by phone. We may decline or cancel orders in case of stock unavailability, suspected fraud or an unserviceable address — any amount paid is refunded in full.</p>
<h2>Delivery, returns & payments</h2><p>See our <a href="/policies/shipping">Shipping</a>, <a href="/policies/returns">Returns & Refunds</a> and <a href="/policies/payments">Payments</a> policies, which form part of these terms.</p>
<h2>Intellectual property</h2><p>Content and the Luxeholic name and marks belong to us. Brand names of designer products belong to their respective owners.</p>
<h2>Liability</h2><p>Our liability for any order is limited to the amount you paid for it. Nothing limits rights you have under the Consumer Protection Act, 2019.</p>
<h2>Governing law</h2><p>These terms are governed by the laws of India; courts at ${b.city}, ${b.state} have jurisdiction.</p>
<h2>Contact</h2>${contact}`,
  };
  return pages[slug] ?? null;
}
