import { eq, inArray } from "drizzle-orm";
import { db, schema } from "@/db";
import { col } from "./vendors/csv";
import { uniqueSlug } from "./vendors/sync";
import { slugify } from "./site";

/**
 * Retail listings — products the team lists directly (CSV upload, manual form, or an import
 * from the old WooCommerce store). Prices here are final selling prices (₹, GST inclusive),
 * so imported products are price-locked and never re-priced by vendor syncs.
 */
export type ListingInput = {
  sku: string;
  title: string;
  description: string;
  shortDescription?: string | null;
  brand?: string | null;
  price: number;                 // paise, GST inclusive
  compareAtPrice?: number | null;
  stock: number;
  images: string[];
  category: string;              // category slug or name
  status?: "ACTIVE" | "DRAFT" | "ARCHIVED" | null; // null = use the import default
  condition?: "new" | "used" | "refurbished" | null;
  material?: string | null; color?: string | null; size?: string | null;
  gtin?: string | null; mpn?: string | null; weightGrams?: number | null;
  tags?: string[];
  dispatchDays?: number | null; deliveryDays?: number | null;
  seoTitle?: string | null; seoDescription?: string | null;
  marketplaceLinks?: Record<string, string>;
  slug?: string | null;
};

export type RowResult = {
  row: number; sku: string; title: string;
  action: "create" | "update" | "skip" | "error";
  status?: string; category?: string; price?: number; image?: string | null;
  notes: string[];
};

export type ImportOptions = {
  mode: "upsert" | "create" | "update";
  defaultStatus: "ACTIVE" | "DRAFT";
  dryRun: boolean;
  source: string;                // e.g. "csv", "woocommerce"
};

export const CSV_COLUMNS = [
  ["sku", "Your unique product code. Same SKU again = update that product.", "LX-RESIN-0042"],
  ["title", "Product name shown to customers.", "Gold Leaf Resin Thinker Sculpture"],
  ["category", "Category name or slug (see list below).", "resin-sculptures"],
  ["price", "Selling price in ₹, GST inclusive.", "4999"],
  ["compare_at_price", "Optional MRP / was-price in ₹ (must be higher).", "6499"],
  ["stock", "Units available.", "12"],
  ["status", "active or draft (blank = the option you pick on upload).", "active"],
  ["brand", "Defaults to Luxeholic.", "Luxeholic"],
  ["short_description", "1–2 lines under the price.", "Hand-finished resin with 24k gold leaf."],
  ["description", "Full description (40+ characters to publish).", "A modern take on Rodin's Thinker, cast in resin and hand-gilded…"],
  ["images", "Image URLs separated by | (first = main image).", "https://luxeholic.in/u/2026/10/thinker-1.jpg|https://luxeholic.in/u/2026/10/thinker-2.jpg"],
  ["condition", "new, used or refurbished (Google requires this for pre-owned).", "new"],
  ["material", "", "Resin, gold leaf"],
  ["color", "", "Gold"],
  ["size", "", "32 cm"],
  ["gtin", "Barcode / EAN if the product has one.", ""],
  ["mpn", "Manufacturer part number.", ""],
  ["weight_grams", "", "1200"],
  ["tags", "Comma separated.", "gift, bestseller"],
  ["dispatch_days", "Days to dispatch (default 3).", "2"],
  ["delivery_days", "Days to deliver after dispatch (default 7).", "6"],
  ["amazon_url", "This product on Amazon (optional).", ""],
  ["flipkart_url", "", ""],
  ["blinkit_url", "", ""],
  ["walmart_url", "", ""],
  ["seo_title", "", ""],
  ["seo_description", "", ""],
] as const;

export function templateCsv() {
  const esc = (v: string) => (/[",\n|]/.test(v) ? `"${v.replace(/"/g, '""')}"` : v);
  return "﻿" + [CSV_COLUMNS.map((c) => c[0]).join(","), CSV_COLUMNS.map((c) => esc(c[2])).join(",")].join("\r\n") + "\r\n";
}

const money = (v: string) => {
  const s = v.replace(/[₹,\s]|INR|Rs\.?/gi, "");
  if (!s) return null;
  const n = parseFloat(s);
  return Number.isFinite(n) ? Math.round(n * 100) : NaN;
};
const toInt = (v: string) => { const n = parseInt(v.replace(/[,\s]/g, ""), 10); return Number.isFinite(n) ? n : null; };
const cleanHtml = (s: string) =>
  s.replace(/<\s*br\s*\/?>/gi, "\n").replace(/<\/(p|li|h\d|div)>/gi, "\n\n").replace(/<li[^>]*>/gi, "• ").replace(/<[^>]+>/g, "")
    .replace(/&nbsp;/g, " ").replace(/&amp;/g, "&").replace(/&#8243;/g, "″").replace(/&#8211;/g, "–").replace(/&#8217;/g, "’").replace(/&#8220;|&#8221;/g, '"')
    .replace(/&quot;/g, '"').replace(/&#0?39;/g, "'").replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&#(\d+);/g, (_, d) => String.fromCharCode(+d))
    .replace(/\*\*(.+?)\*\*/g, "$1").replace(/^\s*Markdown\s+/i, "")
    .replace(/[ \t]+\n/g, "\n").replace(/\n{3,}/g, "\n\n").trim();
export { cleanHtml };

/** Accepts our template and WooCommerce/Shopify-style exports. */
export function rowToListing(r: Record<string, string>): ListingInput & { _errors: string[] } {
  const errors: string[] = [];
  const price = money(col(r, "price", "sale_price", "selling price", "Sale price", "Regular price", "Variant Price", "mrp"));
  const regular = money(col(r, "compare_at_price", "Regular price", "mrp", "Variant Compare At Price"));
  const salePrice = money(col(r, "Sale price"));
  const finalPrice = salePrice && !Number.isNaN(salePrice) ? salePrice : price;
  if (finalPrice === null) errors.push("price is missing");
  else if (Number.isNaN(finalPrice) || finalPrice < 100) errors.push("price must be a number in ₹ (e.g. 4999)");
  const stockRaw = col(r, "stock", "quantity", "qty", "Stock", "Variant Inventory Qty");
  const inStock = col(r, "In stock?", "in_stock");
  let stock = toInt(stockRaw);
  if (stock === null) stock = inStock === "0" ? 0 : inStock ? 10 : 0;
  const images = col(r, "images", "image", "Images", "image_urls", "Image Src")
    .split(/\s*[|\n]\s*|\s*,\s*(?=https?:\/\/)/).map((u) => u.trim()).filter((u) => /^https?:\/\/\S+$/.test(u) || /^\/\S+$/.test(u));
  const cond = col(r, "condition").toLowerCase();
  const status = col(r, "status", "Published").toLowerCase();
  const mk: Record<string, string> = {};
  for (const k of ["amazon", "flipkart", "blinkit", "walmart"]) {
    const u = col(r, `${k}_url`, k, `${k} link`);
    if (u) { if (/^https:\/\//.test(u)) mk[k] = u; else errors.push(`${k}_url must start with https://`); }
  }
  const title = cleanHtml(col(r, "title", "name", "product name", "Name", "Title")).slice(0, 150);
  if (title.length < 3) errors.push("title is missing");
  const category = col(r, "category", "category_slug", "Categories", "Product Type").split(/\s*[,>]\s*/).filter(Boolean).pop() ?? "";
  return {
    sku: col(r, "sku", "SKU", "Variant SKU", "product code", "code").replace(/\s+/g, "-").slice(0, 60),
    title,
    description: cleanHtml(col(r, "description", "Description", "Body (HTML)", "long_description")),
    shortDescription: cleanHtml(col(r, "short_description", "Short description")) || null,
    brand: col(r, "brand", "Brands", "Vendor") || null,
    price: finalPrice ?? 0,
    compareAtPrice: regular && finalPrice && regular > finalPrice ? regular : null,
    stock, images, category,
    status: status === "active" || status === "1" || status === "published" ? "ACTIVE" : status === "draft" || status === "0" ? "DRAFT" : status === "archived" ? "ARCHIVED" : null,
    condition: cond === "used" || cond === "refurbished" || cond === "new" ? cond : null,
    material: col(r, "material") || null, color: col(r, "color", "colour") || null, size: col(r, "size") || null,
    gtin: col(r, "gtin", "ean", "barcode", "upc", "Variant Barcode") || null, mpn: col(r, "mpn") || null,
    weightGrams: toInt(col(r, "weight_grams", "weight (g)")),
    tags: col(r, "tags", "Tags").split(",").map((t) => t.trim()).filter(Boolean),
    dispatchDays: toInt(col(r, "dispatch_days")), deliveryDays: toInt(col(r, "delivery_days")),
    seoTitle: col(r, "seo_title", "SEO Title") || null, seoDescription: col(r, "seo_description", "SEO Description") || null,
    marketplaceLinks: mk,
    _errors: errors,
  };
}

type Cat = { id: string; slug: string; name: string; parentId: string | null };

function findCategory(cats: Cat[], q: string) {
  const n = q.trim().toLowerCase().replace(/&amp;/g, "&");
  if (!n) return null;
  return cats.find((c) => c.slug === n) ?? cats.find((c) => c.name.toLowerCase() === n) ?? cats.find((c) => c.slug === slugify(n)) ?? null;
}

/** Validate and (unless dryRun) create/update products by SKU. */
export async function importListings(rows: (ListingInput & { _errors?: string[] })[], opt: ImportOptions): Promise<{ results: RowResult[]; created: number; updated: number; failed: number }> {
  const cats: Cat[] = await db.select({ id: schema.categories.id, slug: schema.categories.slug, name: schema.categories.name, parentId: schema.categories.parentId }).from(schema.categories);
  const review = cats.find((c) => c.slug === "needs-review");
  const skus = [...new Set(rows.map((r) => r.sku).filter(Boolean))];
  const existing = skus.length
    ? await db.select({ id: schema.products.id, sku: schema.products.sku, images: schema.products.images, status: schema.products.status }).from(schema.products).where(inArray(schema.products.sku, skus))
    : [];
  const bySku = new Map(existing.map((e) => [e.sku, e]));
  const seen = new Set<string>();
  const results: RowResult[] = [];
  let created = 0, updated = 0, failed = 0;

  for (const [i, r] of rows.entries()) {
    const notes = [...(r._errors ?? [])];
    const res: RowResult = { row: i + 2, sku: r.sku, title: r.title, action: "error", notes, price: r.price, image: r.images[0] ?? null };
    results.push(res);
    if (!r.sku) notes.push("sku is missing");
    else if (seen.has(r.sku)) notes.push("duplicate sku in this file (row ignored)");
    seen.add(r.sku);
    const ex = r.sku ? bySku.get(r.sku) : undefined;
    if (!res.image && ex?.images[0]) res.image = ex.images[0];
    if (ex && opt.mode === "create") { res.action = "skip"; notes.push("already exists — skipped (mode: new only)"); continue; }
    if (!ex && opt.mode === "update") { res.action = "skip"; notes.push("not found — skipped (mode: update only)"); continue; }
    let cat = findCategory(cats, r.category);
    if (!cat) {
      if (r.category) notes.push(`category “${r.category}” not found → Needs review`);
      else if (!ex) notes.push("no category → Needs review");
      cat = ex ? null : review ?? null;
    }
    if (notes.some((n) => /missing|must|duplicate/.test(n))) { failed++; continue; }

    // Publishing rules (Merchant Center): image, real category, description.
    let status = r.status ?? (ex ? null : opt.defaultStatus);
    const images = r.images.length ? r.images : ex?.images ?? [];
    const description = r.description || r.shortDescription || "";
    if (status === "ACTIVE") {
      const why = [!images.length && "no image", (cat?.slug === "needs-review" || (!cat && !ex)) && "needs a category", description.length < 40 && "description under 40 characters", r.stock <= 0 && null].filter(Boolean);
      if (why.length) { status = "DRAFT"; notes.push(`saved as draft: ${why.join(", ")}`); }
    }
    if (r.compareAtPrice && r.compareAtPrice <= r.price) notes.push("compare-at price ignored (not higher than price)");
    const tags = [...new Set([...(r.tags ?? []), ...(r.condition && r.condition !== "new" ? [r.condition] : []), `src:${opt.source}`])];
    res.action = ex ? "update" : "create";
    res.status = status ?? ex?.status;
    res.category = cat?.slug ?? "(unchanged)";
    if (opt.dryRun) { ex ? updated++ : created++; continue; }

    const values = {
      title: r.title, description: description || r.title, shortDescription: r.shortDescription ?? null,
      brand: r.brand || "Luxeholic", price: r.price, compareAtPrice: r.compareAtPrice && r.compareAtPrice > r.price ? r.compareAtPrice : null,
      priceLocked: true, stock: Math.max(0, r.stock), images,
      material: r.material ?? null, color: r.color ?? null, size: r.size ?? null, gtin: r.gtin ?? null, mpn: r.mpn ?? null,
      weightGrams: r.weightGrams ?? null, tags, seoTitle: r.seoTitle ?? null, seoDescription: r.seoDescription ?? null,
      ...(r.dispatchDays ? { dispatchDays: r.dispatchDays } : {}), ...(r.deliveryDays ? { deliveryDays: r.deliveryDays } : {}),
      ...(r.marketplaceLinks && Object.keys(r.marketplaceLinks).length ? { marketplaceLinks: r.marketplaceLinks } : {}),
      ...(cat ? { categoryId: cat.id } : {}), ...(status ? { status } : {}),
    };
    try {
      if (ex) {
        await db.update(schema.products).set(values).where(eq(schema.products.id, ex.id));
        updated++;
      } else {
        await db.insert(schema.products).values({ ...values, categoryId: cat!.id, sku: r.sku, slug: r.slug ? await uniqueSlug(r.slug) : await uniqueSlug(r.title), status: status ?? "DRAFT" });
        created++;
      }
    } catch (e) {
      res.action = "error"; failed++;
      notes.push((e as Error).message.slice(0, 160));
    }
  }
  return { results, created, updated, failed };
}
