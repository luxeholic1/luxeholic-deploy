import { getSetting, saveSetting } from "./settings";
import { CURRENCIES } from "./i18n/config";

/**
 * Display currencies (INR per 1 unit), refreshed daily from open.er-api.com when "auto" is on.
 * Display only: checkout always charges INR, so a stale rate can never change what a customer pays.
 */
export async function refreshDisplayRates(force = false) {
  const d = await getSetting("display");
  if (!d.auto && !force) return { skipped: "auto off" };
  const r = await fetch("https://open.er-api.com/v6/latest/INR", { cache: "no-store", signal: AbortSignal.timeout(15000) })
    .catch(() => { throw new Error("Couldn’t reach the exchange-rate service — the current rates are kept. Try again later."); });
  if (!r.ok) throw new Error(`Rate service answered ${r.status}`);
  const j = (await r.json()) as { result?: string; rates?: Record<string, number> };
  if (j.result !== "success" || !j.rates) throw new Error("Rate service returned no rates");
  const rates: Record<string, number> = { ...d.rates };
  for (const c of CURRENCIES) {
    if (c === "INR" || d.off?.includes(c)) continue;
    const perInr = j.rates[c];
    if (perInr && perInr > 0) rates[c] = Math.round((1 / perInr) * 100) / 100;
  }
  await saveSetting("display", { ...d, rates, updatedAt: new Date().toISOString() });
  return { updated: Object.keys(rates).length };
}
