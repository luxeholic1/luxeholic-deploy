import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { and, eq, isNull, or, type SQL } from "drizzle-orm";
import { schema } from "@/db";
import { getStaff, type CurrentStaff } from "./auth";
import { accessLevel, type ModuleKey } from "./rbac";

export class Denied extends Error {}

/** Permission check inside server actions (UI hiding is never enough). */
export async function guard(module?: ModuleKey | "super" | "assign", level: "read" | "write" = "write"): Promise<CurrentStaff> {
  const s = await getStaff();
  if (!s || s.mustChangePassword) throw new Denied("Please sign in again.");
  if (!module) return s;
  if (module === "super") { if (s.role !== "SUPER_ADMIN") throw new Denied("Only the super admin can do that."); return s; }
  if (module === "assign") { if (s.role === "MEMBER") throw new Denied("Only team leads and the super admin can assign tasks."); return s; }
  const a = accessLevel(s, module);
  if (!a || (level === "write" && a !== "write")) throw new Denied("Your team doesn't have permission for that.");
  return s;
}

/**
 * Wraps a form action: runs it, revalidates, and redirects back with a flash message
 * (`?ok=` / `?err=`) that the panel shows as a toast. fn may return a different path to go to.
 */
export async function run(back: string, fn: () => Promise<string | { to?: string; msg?: string } | void>) {
  let ok = true, msg = "Saved", to = back;
  try {
    const r = await fn();
    if (typeof r === "string") msg = r;
    else if (r) { msg = r.msg ?? msg; to = r.to ?? back; }
  } catch (e) {
    ok = false;
    msg = e instanceof Error ? e.message : "Something went wrong";
    console.error("[team action]", e);
  }
  revalidatePath("/team", "layout");
  const sep = to.includes("?") ? "&" : "?";
  redirect(`${to}${sep}${ok ? "ok" : "err"}=${encodeURIComponent(msg.slice(0, 200))}`);
}

/** Which tasks a staff member can see. */
export function taskScope(s: CurrentStaff): SQL | undefined {
  if (s.role === "SUPER_ADMIN") return undefined;
  const mine = eq(schema.tasks.assigneeId, s.id);
  const companyWide = and(isNull(schema.tasks.teamId), isNull(schema.tasks.assigneeId));
  if (!s.teamId) return or(mine, companyWide);
  const teamWide = s.role === "TEAM_LEAD" ? eq(schema.tasks.teamId, s.teamId) : and(eq(schema.tasks.teamId, s.teamId), isNull(schema.tasks.assigneeId));
  return or(mine, companyWide, teamWide);
}

export const str = (fd: FormData, k: string) => String(fd.get(k) ?? "").trim();
export const optStr = (fd: FormData, k: string) => str(fd, k) || null;
export const int = (fd: FormData, k: string, d = 0) => { const n = parseInt(str(fd, k), 10); return Number.isFinite(n) ? n : d; };
export const num = (fd: FormData, k: string, d = 0) => { const n = parseFloat(str(fd, k)); return Number.isFinite(n) ? n : d; };
/** "₹1,299.50" → 129950 paise */
export const rupees = (fd: FormData, k: string) => { const v = str(fd, k).replace(/[₹,\s]/g, ""); return v ? Math.round(parseFloat(v) * 100) : null; };
export const bool = (fd: FormData, k: string) => fd.get(k) === "on" || fd.get(k) === "true";
