import { isStrict } from "@/lib/i18n/config";
import { cache } from "react";
import { and, asc, desc, eq, gt, gte, ilike, inArray, lt, or, sql, type SQL } from "drizzle-orm";
import { db, schema } from "@/db";
import { localize } from "@/lib/i18n/content";
import type { Locale } from "@/lib/i18n/config";

export type CategoryNode = typeof schema.categories.$inferSelect & { children: (typeof schema.categories.$inferSelect)[] };

export const getCategoryTree = cache(async (): Promise<CategoryNode[]> => {
  const all = await db.select().from(schema.categories).where(eq(schema.categories.active, true)).orderBy(asc(schema.categories.sortOrder));
  return all.filter((c) => !c.parentId).map((p) => ({ ...p, children: all.filter((c) => c.parentId === p.id) }));
});

export const getCategory = cache(async (slug: string) => {
  const tree = await getCategoryTree();
  for (const p of tree) {
    if (p.slug === slug) return { category: p, parent: null, children: p.children };
    const c = p.children.find((x) => x.slug === slug);
    if (c) return { category: c, parent: p, children: [] as CategoryNode["children"] };
  }
  return null;
});

export type ProductFilter = {
  categoryIds?: string[]; minPrice?: number; maxPrice?: number | null; q?: string; brand?: string;
  sort?: "featured" | "new" | "price-asc" | "price-desc"; featured?: boolean; newArrivals?: boolean;
  page?: number; perPage?: number; includeSoldOut?: boolean;
  /** Non-English: only products translated into this language are listed, with their translated text. */
  locale?: Locale;
};

/** Storefront query — only ACTIVE products; sold-out pieces are hidden from listings (no ghost inventory). */
export async function listProducts(f: ProductFilter = {}) {
  const where: SQL[] = [eq(schema.products.status, "ACTIVE")];
  if (!f.includeSoldOut) where.push(gt(schema.products.stock, 0));
  if (f.categoryIds?.length) where.push(inArray(schema.products.categoryId, f.categoryIds));
  if (f.minPrice) where.push(gte(schema.products.price, f.minPrice));
  if (f.maxPrice) where.push(lt(schema.products.price, f.maxPrice));
  if (f.brand) where.push(eq(schema.products.brand, f.brand));
  if (f.featured) where.push(eq(schema.products.isFeatured, true));
  if (f.newArrivals) where.push(eq(schema.products.isNewArrival, true));
  const loc = f.locale && f.locale !== "en" ? f.locale : null;
  if (loc && isStrict(loc)) where.push(sql`exists (select 1 from ${schema.translations} tr where tr.entity = 'product' and tr.entity_id = ${schema.products.id}::text and tr.field = 'title' and tr.locale = ${loc})`);
  if (f.q) {
    const terms = f.q.trim().split(/\s+/).slice(0, 6);
    for (const t of terms) {
      const inTr = loc ? sql`exists (select 1 from ${schema.translations} tr where tr.entity = 'product' and tr.entity_id = ${schema.products.id}::text and tr.locale = ${loc} and tr.text ilike ${`%${t}%`})` : sql`false`;
      where.push(or(ilike(schema.products.title, `%${t}%`), ilike(schema.products.brand, `%${t}%`), ilike(schema.products.description, `%${t}%`), inTr)!);
    }
  }
  const order = {
    featured: [desc(schema.products.isFeatured), desc(schema.products.createdAt)],
    new: [desc(schema.products.createdAt)],
    "price-asc": [asc(schema.products.price)],
    "price-desc": [desc(schema.products.price)],
  }[f.sort ?? "featured"];
  const perPage = f.perPage ?? 24;
  const page = Math.max(1, f.page ?? 1);
  const [rows, [{ n }]] = await Promise.all([
    db.select().from(schema.products).where(and(...where)).orderBy(...order).limit(perPage).offset((page - 1) * perPage),
    db.select({ n: sql<number>`count(*)::int` }).from(schema.products).where(and(...where)),
  ]);
  const products = loc ? (await localize("product", rows, loc)).items : rows;
  return { products, total: n - (rows.length - products.length), page, pages: Math.max(1, Math.ceil(n / perPage)) };
}

export const getProduct = cache(async (slug: string) =>
  db.query.products.findFirst({
    where: eq(schema.products.slug, slug),
    with: { variants: true, category: true, vendor: { columns: { name: true, type: true } } },
  }),
);

export async function brandsIn(categoryIds?: string[]) {
  const where: SQL[] = [eq(schema.products.status, "ACTIVE"), gt(schema.products.stock, 0)];
  if (categoryIds?.length) where.push(inArray(schema.products.categoryId, categoryIds));
  const rows = await db.selectDistinct({ brand: schema.products.brand }).from(schema.products).where(and(...where)).orderBy(asc(schema.products.brand)).limit(60);
  return rows.map((r) => r.brand);
}

export type Product = typeof schema.products.$inferSelect;

/** Category tree in the visitor's language. Non-English: untranslated categories are left out. */
export const getLocalizedTree = cache(async (locale: Locale): Promise<CategoryNode[]> => {
  const tree = await getCategoryTree();
  if (locale === "en") return tree;
  const all = tree.flatMap((c) => [c, ...c.children]);
  const { items } = await localize("category", all, locale);
  const m = new Map(items.map((x) => [x.id, x]));
  return tree.filter((c) => m.has(c.id)).map((c) => ({ ...m.get(c.id)!, children: c.children.filter((s) => m.has(s.id)).map((s) => m.get(s.id)!) }));
});

export const getLocalizedCategory = cache(async (slug: string, locale: Locale) => {
  const tree = await getLocalizedTree(locale);
  for (const p of tree) {
    if (p.slug === slug) return { category: p, parent: null, children: p.children };
    const c = p.children.find((x) => x.slug === slug);
    if (c) return { category: c, parent: p, children: [] as CategoryNode["children"] };
  }
  return null;
});

/** A product page in the visitor's language: null when the product (or any of its options) has no current translation. */
export async function localizeProduct<T extends NonNullable<Awaited<ReturnType<typeof getProduct>>>>(p: T, locale: Locale): Promise<T | null> {
  if (locale === "en") return p;
  const [prod, vars, cats] = await Promise.all([
    localize("product", [p], locale),
    localize("variant", p.variants, locale),
    localize("category", [p.category], locale),
  ]);
  if (!prod.items.length || vars.missing.length || !cats.items.length) return null;
  return { ...prod.items[0], variants: vars.items, category: cats.items[0] } as T;
}
