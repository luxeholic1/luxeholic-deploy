import nodemailer from "nodemailer";
import { and, eq, inArray } from "drizzle-orm";
import { db, schema } from "@/db";
import { SITE_NAME, SITE_URL } from "./site";
import { clientIp } from "./auth";

let transporter: nodemailer.Transporter | null = null;
function mailer() {
  if (!process.env.SMTP_HOST) return null;
  transporter ??= nodemailer.createTransport({
    host: process.env.SMTP_HOST,
    port: Number(process.env.SMTP_PORT || 465),
    secure: Number(process.env.SMTP_PORT || 465) === 465,
    auth: { user: process.env.SMTP_USER, pass: process.env.SMTP_PASS },
  });
  return transporter;
}

const shell = (title: string, body: string, cta?: { label: string; url: string }) => `
<div style="background:#F7F3EC;padding:32px 0;font-family:Georgia,serif;color:#0E0D0B">
  <div style="max-width:560px;margin:0 auto;background:#fff;border:1px solid #E2D9C9">
    <div style="padding:28px 32px;border-bottom:1px solid #E2D9C9;text-align:center;letter-spacing:.3em;font-size:14px">LUXEHOLIC</div>
    <div style="padding:32px">
      <h1 style="font-weight:400;font-size:26px;margin:0 0 16px">${title}</h1>
      <div style="font-family:Arial,sans-serif;font-size:14px;line-height:1.7;color:#2A2723">${body}</div>
      ${cta ? `<p style="margin-top:28px"><a href="${cta.url}" style="background:#0E0D0B;color:#F7F3EC;padding:12px 24px;text-decoration:none;font-family:Arial;font-size:12px;letter-spacing:.2em">${cta.label.toUpperCase()}</a></p>` : ""}
    </div>
    <div style="padding:18px 32px;border-top:1px solid #E2D9C9;font-family:Arial;font-size:11px;color:#6B655C;text-align:center">${SITE_NAME} · ${SITE_URL.replace(/^https?:\/\//, "")}</div>
  </div>
</div>`;

export async function sendMail(to: string, subject: string, title: string, body: string, cta?: { label: string; url: string }) {
  const m = mailer();
  if (!m) {
    console.info(`[mail:dev] to=${to} subject="${subject}"`);
    return;
  }
  try {
    await m.sendMail({ from: process.env.MAIL_FROM || `${SITE_NAME} <no-reply@luxeholic.in>`, to, subject, html: shell(title, body, cta) });
  } catch (e) {
    console.error("[mail] failed", e);
  }
}

/** In-app notification (bell) + optional email for each staff member. */
export async function notifyStaff(staffIds: string[], title: string, body?: string, link?: string, email = false) {
  const ids = [...new Set(staffIds.filter(Boolean))];
  if (!ids.length) return;
  await db.insert(schema.notifications).values(ids.map((staffId) => ({ staffId, title, body, link })));
  if (email) {
    const people = await db.select({ email: schema.staff.email }).from(schema.staff).where(inArray(schema.staff.id, ids));
    await Promise.all(people.map((p) => sendMail(p.email, title, title, body ?? "", link ? { label: "Open", url: SITE_URL + link } : undefined)));
  }
}

/** Notify every active member of the given team slugs (+ super admins). */
export async function notifyTeams(slugs: string[], title: string, body?: string, link?: string) {
  const rows = await db
    .select({ id: schema.staff.id, role: schema.staff.role, slug: schema.teams.slug })
    .from(schema.staff)
    .leftJoin(schema.teams, eq(schema.staff.teamId, schema.teams.id))
    .where(eq(schema.staff.active, true));
  const ids = rows.filter((r) => r.role === "SUPER_ADMIN" || (r.slug && slugs.includes(r.slug))).map((r) => r.id);
  await notifyStaff(ids, title, body, link);
}

export async function audit(staffId: string | null, action: string, entity: string, entityId?: string | null, meta?: unknown) {
  let ip: string | null = null;
  try {
    ip = await clientIp();
  } catch {
    /* called outside a request (cron) */
  }
  await db.insert(schema.activityLogs).values({ staffId, action, entity, entityId: entityId ?? null, meta: meta as never, ip });
}

export async function unreadCount(staffId: string) {
  const rows = await db
    .select({ id: schema.notifications.id })
    .from(schema.notifications)
    .where(and(eq(schema.notifications.staffId, staffId), eq(schema.notifications.read, false)))
    .limit(100);
  return rows.length;
}
