/**
 * Optional machine translation for the Translations page (set ANTHROPIC_API_KEY).
 * Drafts are saved as "auto" so the team can see what still needs a human read-through.
 */
export const autoTranslateEnabled = () => Boolean(process.env.ANTHROPIC_API_KEY);

import { LOCALE_INFO, type Locale } from "./config";

const STYLE: Partial<Record<Locale, string>> = {
  hi: "natural, polished Hindi (Devanagari) — warm and clear, never stiff or overly Sanskritised. Transliterate brand names into Devanagari",
  mr: "natural, polished Marathi (Devanagari)",
  pa: "natural Punjabi in Gurmukhi script",
  ar: "Modern Standard Arabic suited to Gulf shoppers",
};

/** Translate a set of English strings into one language with Claude. Keys come back unchanged. */
export async function translateFields(fields: Record<string, string>, locale: Locale, context: string, maxTokens = 4000): Promise<Record<string, string>> {
  const key = process.env.ANTHROPIC_API_KEY;
  if (!key) throw new Error("Automatic translation is off. Add ANTHROPIC_API_KEY to the server settings to turn it on.");
  const lang = STYLE[locale] ?? `natural, polished ${LOCALE_INFO[locale].english}`;
  const body = {
    model: process.env.ANTHROPIC_MODEL || "claude-sonnet-5-5",
    max_tokens: maxTokens,
    system:
      `You translate e-commerce content for LUXEHOLIC, an Indian luxury store (designer fashion, décor and rugged "Lux-Tech" electronics), from English into ${lang}. ` +
      "Write the way a premium brand speaks to customers. " +
      "Keep model numbers, sizes, units, prices, e-mail addresses, phone numbers, {placeholders} and codes as written (e.g. 12GB, 5G, IP68, USB, YD204, GST, UPI, IFSC). " +
      (locale === "hi" ? "" : "Keep brand and designer names in Latin letters. ") +
      "Never add claims, prices or promotional words that are not in the English. Keep interface labels as short as the English. " +
      "Answer with only a JSON object that has exactly the same keys as the input.",
    messages: [{ role: "user", content: `${context}\n\n${JSON.stringify(fields)}` }],
  };
  const r = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: { "content-type": "application/json", "x-api-key": key, "anthropic-version": "2023-06-01" },
    body: JSON.stringify(body),
    signal: AbortSignal.timeout(120000),
  });
  if (!r.ok) throw new Error(`Translation service error ${r.status}`);
  const j = (await r.json()) as { content?: { type: string; text?: string }[] };
  const text = j.content?.find((c) => c.type === "text")?.text ?? "";
  const m = text.match(/\{[\s\S]*\}/);
  if (!m) throw new Error("The translation came back in an unexpected format. Please try again.");
  const out = JSON.parse(m[0]) as Record<string, unknown>;
  const clean: Record<string, string> = {};
  for (const k of Object.keys(fields)) if (typeof out[k] === "string" && (out[k] as string).trim()) clean[k] = (out[k] as string).trim();
  return clean;
}

export const translateToHindi = (fields: Record<string, string>, context: string) => translateFields(fields, "hi", context);
