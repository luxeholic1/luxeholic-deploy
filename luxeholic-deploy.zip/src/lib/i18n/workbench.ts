import { and, asc, eq, inArray } from "drizzle-orm";
import { db, schema } from "@/db";
import { getHero } from "@/lib/hero";
import { businessAddress, getSettings } from "@/lib/settings";
import { FIELDS, hashText, type Entity } from "./content";
import type { Locale } from "./config";

export type FieldState = "ok" | "stale" | "missing";
export type WorkItem = { entity: Entity; id: string; label: string; href?: string; fields: { field: string; label: string; en: string; tr: string; state: FieldState; auto: boolean }[] };

const FIELD_LABEL: Record<string, string> = {
  title: "Title", shortDescription: "Short description", description: "Description", material: "Material", color: "Colour",
  name: "Name", tagline: "Tagline", eyebrow: "Small label", headline: "Headline", text: "Text", cta1: "Main button", cta2: "Second link", alt: "Video description",
};
export const SITE_LABEL: Record<string, string> = {
  announcement: "Announcement bar", legalName: "Legal name", address: "Business address", supportHours: "Support hours", city: "City", state: "State",
};

/** English source texts for one kind of content, keyed by record id. */
export async function sources(entity: Entity): Promise<{ id: string; label: string; href?: string; values: Record<string, string> }[]> {
  if (entity === "product") {
    const rows = await db.select().from(schema.products).where(eq(schema.products.status, "ACTIVE")).orderBy(asc(schema.products.title));
    return rows.map((p) => ({ id: p.id, label: p.title, href: `/p/${p.slug}`, values: pick(p, FIELDS.product) }));
  }
  if (entity === "variant") {
    const rows = await db.select({ v: schema.productVariants, title: schema.products.title, slug: schema.products.slug }).from(schema.productVariants)
      .innerJoin(schema.products, eq(schema.products.id, schema.productVariants.productId)).where(eq(schema.products.status, "ACTIVE"));
    return rows.map(({ v, title, slug }) => ({ id: v.id, label: `${title} — ${v.name}`, href: `/p/${slug}`, values: { name: v.name } }));
  }
  if (entity === "category") {
    const rows = await db.select().from(schema.categories).where(eq(schema.categories.active, true)).orderBy(asc(schema.categories.sortOrder));
    return rows.map((c) => ({ id: c.id, label: c.name, href: `/c/${c.slug}`, values: pick(c, FIELDS.category) }));
  }
  if (entity === "hero") {
    const h = await getHero();
    return h.chapters.map((c, i) => ({ id: c.id, label: `Chapter ${i + 1} · ${c.eyebrow}`, href: "/", values: { eyebrow: c.eyebrow, headline: c.headline, text: c.text, cta1: c.cta1.label, cta2: c.cta2.label, alt: c.alt } }));
  }
  const s = await getSettings();
  const b = s.business;
  const hero = await getHero();
  const site: [string, string, string][] = [
    ["announcement", SITE_LABEL.announcement, s.announcement], ["legalName", SITE_LABEL.legalName, b.legalName], ["address", SITE_LABEL.address, businessAddress(b)],
    ["supportHours", SITE_LABEL.supportHours, b.supportHours], ["city", SITE_LABEL.city, b.city], ["state", SITE_LABEL.state, b.state],
    ...hero.trust.map((t, i): [string, string, string] => [`hero-trust-${i}`, `Hero promise ${i + 1}`, t.label]),
  ];
  return site.filter(([, , en]) => en).map(([id, label, en]) => ({ id, label, values: { text: en } }));
}

function pick(row: Record<string, unknown>, fields: readonly string[]) {
  const out: Record<string, string> = {};
  for (const f of fields) { const v = row[f]; if (typeof v === "string" && v.trim()) out[f] = v; }
  return out;
}

export async function workItems(entity: Entity, locale: Locale): Promise<WorkItem[]> {
  const src = await sources(entity);
  const ids = src.map((s) => s.id);
  const rows = ids.length ? await db.select().from(schema.translations)
    .where(and(eq(schema.translations.entity, entity), eq(schema.translations.locale, locale), inArray(schema.translations.entityId, ids))) : [];
  const m = new Map(rows.map((r) => [`${r.entityId}:${r.field}`, r]));
  return src.map((s) => ({
    entity, id: s.id, label: s.label, href: s.href,
    fields: Object.entries(s.values).map(([field, en]) => {
      const r = m.get(`${s.id}:${field}`);
      const state: FieldState = !r ? "missing" : r.sourceHash !== hashText(en) ? "stale" : "ok";
      return { field, label: FIELD_LABEL[field] ?? field, en, tr: r?.text ?? "", state, auto: r?.source === "auto" };
    }),
  }));
}

export const itemState = (w: WorkItem): FieldState =>
  w.fields.some((f) => f.state === "missing") ? "missing" : w.fields.some((f) => f.state === "stale") ? "stale" : "ok";
