import { cache } from "react";
import { cookies, headers } from "next/headers";
import { getSettings } from "@/lib/settings";
import { CUR_COOKIE, LANG_COOKIE, fill, formatMoney, isCurrency, isLocale, marketFor, type Currency, type Locale } from "./config";
import { HI } from "./hi";
import { uiDict } from "./ui-dict";

/** Interface dictionary for a language: Hindi ships with the code; the others live in the database (drafted with Claude from Team → Languages). */
export async function getDict(locale: Locale): Promise<Record<string, string> | null> {
  if (locale === "en") return null;
  if (locale === "hi") return HI;
  return uiDict(locale).catch(() => ({}));
}

/** The visitor's language and currency: their saved choice, else the domain's market. */
export const getPrefs = cache(async () => {
  const [c, h, s] = await Promise.all([cookies(), headers(), getSettings()]);
  const market = marketFor(h.get("x-forwarded-host") ?? h.get("host"));
  const enabled = (s.display.languages ?? ["en"]).filter(isLocale);
  let locale: Locale = isLocale(c.get(LANG_COOKIE)?.value) ? (c.get(LANG_COOKIE)!.value as Locale) : market.locale;
  if (!enabled.includes(locale)) locale = "en";
  const cv = c.get(CUR_COOKIE)?.value;
  const currency: Currency = isCurrency(cv) && (cv === "INR" || s.display.rates[cv]) ? cv : market.currency;
  return { locale, currency, market, rates: s.display.rates as Partial<Record<Currency, number>>, languages: enabled };
});

export function translator(locale: Locale, d: Record<string, string> | null) {
  return (s: string, vars?: Record<string, string | number>) => {
    if (!d) return fill(s, vars);
    const v = d[s];
    if (v === undefined && locale === "hi" && process.env.NODE_ENV !== "production") console.warn(`[i18n] missing ${locale}: ${JSON.stringify(s)}`);
    return fill(v ?? s, vars);
  };
}

/** Server components: `const { t, money } = await getI18n();` */
export const getI18n = cache(async () => {
  const p = await getPrefs();
  const dict = await getDict(p.locale);
  return { ...p, dict, t: translator(p.locale, dict), money: (paise: number) => formatMoney(paise, p.currency, p.rates, p.locale) };
});
