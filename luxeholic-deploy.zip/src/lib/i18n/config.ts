/** Languages, currencies and the market each domain opens in. Shared by server, client and middleware. */
export const LOCALES = ["en", "hi", "mr", "te", "ta", "kn", "ml", "bn", "gu", "pa", "or", "fr", "es", "de", "ar"] as const;
export type Locale = (typeof LOCALES)[number];
type Info = { label: string; english: string; html: string; intl: string; og: string; dir?: "rtl"; font?: string };
export const LOCALE_INFO: Record<Locale, Info> = {
  en: { label: "English", english: "English", html: "en-IN", intl: "en-IN", og: "en_IN" },
  hi: { label: "हिन्दी", english: "Hindi", html: "hi-IN", intl: "hi-IN", og: "hi_IN", font: "Noto Sans Devanagari" },
  mr: { label: "मराठी", english: "Marathi", html: "mr-IN", intl: "mr-IN", og: "mr_IN", font: "Noto Sans Devanagari" },
  te: { label: "తెలుగు", english: "Telugu", html: "te-IN", intl: "te-IN", og: "te_IN", font: "Noto Sans Telugu" },
  ta: { label: "தமிழ்", english: "Tamil", html: "ta-IN", intl: "ta-IN", og: "ta_IN", font: "Noto Sans Tamil" },
  kn: { label: "ಕನ್ನಡ", english: "Kannada", html: "kn-IN", intl: "kn-IN", og: "kn_IN", font: "Noto Sans Kannada" },
  ml: { label: "മലയാളം", english: "Malayalam", html: "ml-IN", intl: "ml-IN", og: "ml_IN", font: "Noto Sans Malayalam" },
  bn: { label: "বাংলা", english: "Bengali", html: "bn-IN", intl: "bn-IN", og: "bn_IN", font: "Noto Sans Bengali" },
  gu: { label: "ગુજરાતી", english: "Gujarati", html: "gu-IN", intl: "gu-IN", og: "gu_IN", font: "Noto Sans Gujarati" },
  pa: { label: "ਪੰਜਾਬੀ", english: "Punjabi", html: "pa-IN", intl: "pa-IN", og: "pa_IN", font: "Noto Sans Gurmukhi" },
  or: { label: "ଓଡ଼ିଆ", english: "Odia", html: "or-IN", intl: "or-IN", og: "or_IN", font: "Noto Sans Oriya" },
  fr: { label: "Français", english: "French", html: "fr", intl: "fr-FR", og: "fr_FR" },
  es: { label: "Español", english: "Spanish", html: "es", intl: "es-ES", og: "es_ES" },
  de: { label: "Deutsch", english: "German", html: "de", intl: "de-DE", og: "de_DE" },
  ar: { label: "العربية", english: "Arabic", html: "ar", intl: "ar-AE", og: "ar_AE", dir: "rtl", font: "Noto Sans Arabic" },
};
/** Hindi is fully curated: anything untranslated is hidden. Other languages show English for catalogue text not yet translated. */
export const STRICT_LOCALES: Locale[] = ["hi"];
export const isStrict = (l: Locale) => STRICT_LOCALES.includes(l);
/** Google Fonts stylesheet for a language's script (null for Latin). */
export function fontHref(l: Locale) {
  const f = LOCALE_INFO[l].font;
  return f ? `https://fonts.googleapis.com/css2?family=${f.replace(/ /g, "+")}:wght@300;400;500;600&display=swap` : null;
}

export const CURRENCIES = ["INR", "USD", "GBP", "EUR", "AED", "AUD", "CAD", "SGD", "NZD"] as const;
export type Currency = (typeof CURRENCIES)[number];
export const CURRENCY_LABEL: Record<Currency, string> = {
  INR: "₹ INR", USD: "$ USD", GBP: "£ GBP", EUR: "€ EUR", AED: "AED", AUD: "A$ AUD", CAD: "C$ CAD", SGD: "S$ SGD", NZD: "NZ$ NZD",
};

export type Market = { hosts: string[]; country: string; currency: Currency; locale: Locale };
/** Which currency and language a visitor starts with, by the domain they arrive on.
 *  Override with MARKETS_JSON (same shape) without a code change. */
const DEFAULT_MARKETS: Market[] = [
  { hosts: ["luxeholic.in", "www.luxeholic.in"], country: "IN", currency: "INR", locale: "en" },
  { hosts: ["hi.luxeholic.in"], country: "IN", currency: "INR", locale: "hi" },
  { hosts: ["luxeholic.com", "www.luxeholic.com"], country: "US", currency: "USD", locale: "en" },
  { hosts: ["luxeholic.co.uk", "www.luxeholic.co.uk"], country: "GB", currency: "GBP", locale: "en" },
  { hosts: ["luxeholic.ae", "www.luxeholic.ae"], country: "AE", currency: "AED", locale: "en" },
  { hosts: ["luxeholic.com.au", "www.luxeholic.com.au"], country: "AU", currency: "AUD", locale: "en" },
  { hosts: ["luxeholic.co.nz", "www.luxeholic.co.nz"], country: "NZ", currency: "NZD", locale: "en" },
];
export const FALLBACK_MARKET: Market = { hosts: [], country: "IN", currency: "INR", locale: "en" };

export function markets(): Market[] {
  try { const m = process.env.MARKETS_JSON ? (JSON.parse(process.env.MARKETS_JSON) as Market[]) : null; if (Array.isArray(m) && m.length) return m; } catch { /* use defaults */ }
  return DEFAULT_MARKETS;
}
export function marketFor(host: string | null | undefined): Market {
  const h = (host ?? "").toLowerCase().split(":")[0];
  return markets().find((m) => m.hosts.includes(h)) ?? FALLBACK_MARKET;
}
export const isLocale = (v: unknown): v is Locale => LOCALES.includes(v as Locale);
export const isCurrency = (v: unknown): v is Currency => CURRENCIES.includes(v as Currency);
export const LANG_COOKIE = "lx_lang";
export const CUR_COOKIE = "lx_cur";

/** Interpolate {name} placeholders. */
export function fill(s: string, vars?: Record<string, string | number>) {
  return vars ? s.replace(/\{(\w+)\}/g, (_, k) => (k in vars ? String(vars[k]) : `{${k}}`)) : s;
}

/** Format paise in the visitor's currency. INR is exact; other currencies are converted for display only. */
export function formatMoney(paise: number, currency: Currency, ratesInrPer: Partial<Record<Currency, number>>, locale: Locale = "en") {
  const intl = LOCALE_INFO[locale].intl;
  if (currency === "INR" || !ratesInrPer[currency]) {
    return new Intl.NumberFormat(intl, { style: "currency", currency: "INR", maximumFractionDigits: paise % 100 ? 2 : 0 }).format(paise / 100);
  }
  const v = paise / 100 / ratesInrPer[currency]!;
  return new Intl.NumberFormat(intl, { style: "currency", currency, maximumFractionDigits: v >= 100 ? 0 : 2 }).format(v);
}

/** Our own label is written in the page's script; designer and maker brands are trademarks and stay as the brand writes them. */
export const brandName = (brand: string, locale: Locale) => (locale === "hi" && /^luxeholic$/i.test(brand.trim()) ? "लक्ज़हॉलिक" : brand);
