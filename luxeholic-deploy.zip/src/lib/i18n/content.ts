import { isStrict } from "./config";
import { createHash } from "node:crypto";
import { and, eq, inArray } from "drizzle-orm";
import { db, schema } from "@/db";
import type { Locale } from "./config";

export const hashText = (s: string | null | undefined) => createHash("sha1").update(s ?? "").digest("hex").slice(0, 16);

/** Which fields of each kind of content get translated. */
export const FIELDS = {
  product: ["title", "shortDescription", "description", "material", "color"],
  category: ["name", "tagline", "description"],
  variant: ["name"],
  hero: ["eyebrow", "headline", "text", "cta1", "cta2", "alt"],
  site: ["text"],
} as const;
export type Entity = keyof typeof FIELDS;

type Row = typeof schema.translations.$inferSelect;
export async function loadTranslations(entity: Entity, ids: string[], locale: Locale) {
  if (locale === "en" || !ids.length) return new Map<string, Row>();
  const rows = await db.select().from(schema.translations)
    .where(and(eq(schema.translations.entity, entity), eq(schema.translations.locale, locale), inArray(schema.translations.entityId, ids)));
  return new Map(rows.map((r) => [`${r.entityId}:${r.field}`, r]));
}

/**
 * Overlay translations on records. A record is "complete" only when every non-empty English field
 * has a translation made from the current English text — incomplete records are dropped, so a
 * Hindi page never shows English catalogue text.
 */
export async function localize<T extends { id: string }>(entity: Entity, list: T[], locale: Locale): Promise<{ items: T[]; missing: T[] }> {
  if (locale === "en" || !list.length) return { items: list, missing: [] };
  const map = await loadTranslations(entity, list.map((x) => x.id), locale);
  const items: T[] = [], missing: T[] = [];
  for (const x of list) {
    const out = { ...x } as Record<string, unknown>;
    let ok = true;
    for (const f of FIELDS[entity]) {
      const en = (x as Record<string, unknown>)[f];
      if (typeof en !== "string" || !en.trim()) continue;
      const tr = map.get(`${x.id}:${f}`);
      if (!tr || tr.sourceHash !== hashText(en)) { ok = false; break; }
      out[f] = tr.text;
    }
    if (ok) items.push(out as T);
    else { missing.push(x); if (!isStrict(locale)) items.push(x); }   // other languages fall back to English until translated
  }
  return { items, missing };
}

export async function localizeOne<T extends { id: string }>(entity: Entity, x: T, locale: Locale): Promise<T | null> {
  const r = await localize(entity, [x], locale);
  return r.items[0] ?? null;
}

/** Translated product titles for order lines (by product id); falls back to null when missing. */
export async function productTitles(ids: string[], locale: Locale) {
  const out = new Map<string, string>();
  if (locale === "en") return out;
  const map = await loadTranslations("product", ids, locale);
  for (const [k, r] of map) if (k.endsWith(":title")) out.set(r.entityId, r.text);
  return out;
}

export async function saveTranslation(entity: Entity, entityId: string, field: string, locale: Locale, text: string, english: string, source: "manual" | "auto" = "manual") {
  const v = { entity, entityId, field, locale, text: text.trim(), sourceHash: hashText(english), source };
  await db.insert(schema.translations).values(v).onConflictDoUpdate({
    target: [schema.translations.entity, schema.translations.entityId, schema.translations.field, schema.translations.locale],
    set: { text: v.text, sourceHash: v.sourceHash, source, updatedAt: new Date() },
  });
}

/** Site-wide free text kept in Settings (announcement, address, support hours…), keyed by a stable id.
 *  Returns the translation when it matches the current English text; otherwise `fallback`
 *  ("" hides the text, which is what the announcement bar wants). */
export async function siteTexts<K extends string>(texts: Record<K, string>, locale: Locale, fallback: "hide" | "english" = "english"): Promise<Record<K, string>> {
  const out = { ...texts };
  if (locale === "en") return out;
  const keys = Object.keys(texts) as K[];
  const map = await loadTranslations("site", keys, locale);
  for (const k of keys) {
    const en = texts[k];
    if (!en) continue;
    const tr = map.get(`${k}:text`);
    out[k] = tr && tr.sourceHash === hashText(en) ? tr.text : fallback === "hide" ? "" : en;
  }
  return out;
}

/** Business details from Store Settings, in the visitor's language (falls back to English until translated). */
export async function businessTexts(b: { legalName: string; addressLine1: string; addressLine2?: string; city: string; state: string; pincode: string; supportHours: string }, address: string, locale: Locale) {
  return siteTexts({ legalName: b.legalName, address, supportHours: b.supportHours, city: b.city, state: b.state }, locale);
}

/** Order lines keep an English snapshot of the title; show the translated title/option when one exists. */
export async function orderLineLabels(items: { id: string; productId: string | null; variantId: string | null; title: string; variant: string | null }[], locale: Locale) {
  const out = new Map<string, { title: string; variant: string | null }>();
  if (locale === "en") { for (const i of items) out.set(i.id, { title: i.title, variant: i.variant }); return out; }
  const pids = [...new Set(items.map((i) => i.productId).filter((x): x is string => !!x))];
  const vids = [...new Set(items.map((i) => i.variantId).filter((x): x is string => !!x))];
  const [titles, vmap] = await Promise.all([productTitles(pids, locale), loadTranslations("variant", vids, locale)]);
  for (const i of items) {
    out.set(i.id, {
      title: (i.productId && titles.get(i.productId)) || i.title,
      variant: i.variant ? (i.variantId && vmap.get(`${i.variantId}:name`)?.text) || i.variant : null,
    });
  }
  return out;
}
