"use client";
import { createContext, useCallback, useContext } from "react";
import { fill, formatMoney, type Currency, type Locale } from "./config";

type Ctx = { locale: Locale; currency: Currency; rates: Partial<Record<Currency, number>>; dict: Record<string, string> | null; languages: Locale[] };
const C = createContext<Ctx>({ locale: "en", currency: "INR", rates: {}, dict: null, languages: ["en"] });

export function I18nProvider({ value, children }: { value: Ctx; children: React.ReactNode }) {
  return <C.Provider value={value}>{children}</C.Provider>;
}
export function usePrefs() { return useContext(C); }
export function useT() {
  const { dict } = useContext(C);
  return useCallback((s: string, vars?: Record<string, string | number>) => fill(dict?.[s] ?? s, vars), [dict]);
}
export function useMoney() {
  const { currency, rates, locale } = useContext(C);
  return useCallback((paise: number) => formatMoney(paise, currency, rates, locale), [currency, rates, locale]);
}
