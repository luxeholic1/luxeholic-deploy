/**
 * Hindi translations for the live catalogue, hero and site texts. Safe to re-run:
 * it only writes a translation when the English text still matches (so edited products are left for the team to re-translate).
 *   npm run seed:hindi  ·  also runs on first start and after each WooCommerce import
 */
import { db, schema } from "@/db";
import { saveTranslation } from "./content";
import { getSettings, businessAddress } from "@/lib/settings";
import { getHero } from "@/lib/hero";

const CATEGORIES: Record<string, { name: string; tagline?: string; description?: string }> = {
  "art-sculpture": { name: "कला और मूर्तिकला", tagline: "ऐसी वस्तुएँ जो बातचीत का केंद्र बन जाएँ" },
  "resin-sculptures": { name: "रेज़िन मूर्तियाँ" },
  "abstract-figurines": { name: "एब्स्ट्रैक्ट और मॉडर्न मूर्तियाँ" },
  "animal-sculptures": { name: "पशु मूर्तियाँ" },
  "spiritual-art": { name: "आध्यात्मिक और बुद्ध कला" },
  "wall-art": { name: "दीवार कला और फ़्रेम" },
  "tabletop-accents": { name: "बुकएंड और टेबल सज्जा" },
  "home-decor": { name: "गृह सज्जा", tagline: "हर कमरे के लिए शांत लग्ज़री" },
  "vases-planters": { name: "फूलदान और प्लांटर" },
  "candles-holders": { name: "मोमबत्तियाँ और स्टैंड" },
  "lamps-lighting": { name: "लैंप और लाइटिंग" },
  "clocks": { name: "घड़ियाँ (दीवार और टेबल)" },
  "mirrors": { name: "आईने" },
  "trays-bowls-boxes": { name: "ट्रे, कटोरे और डिब्बे" },
  "tableware-barware": { name: "टेबलवेयर और बारवेयर" },
  "designer-fashion": { name: "डिज़ाइनर फ़ैशन", tagline: "असली यूरोपीय फ़ैशन हाउस" },
  "womens-clothing": { name: "महिलाओं के कपड़े" },
  "mens-clothing": { name: "पुरुषों के कपड़े" },
  "handbags": { name: "डिज़ाइनर हैंडबैग" },
  "designer-shoes": { name: "डिज़ाइनर जूते" },
  "gifting-accessories": { name: "उपहार और एक्सेसरीज़", tagline: "ऐसे उपहार जो उम्र भर साथ रहें" },
  "watches": { name: "कलाई घड़ियाँ" },
  "sunglasses": { name: "धूप के चश्मे और आईवियर" },
  "wallets-leather": { name: "वॉलेट और छोटे लेदर उत्पाद" },
  "belts": { name: "बेल्ट" },
  "scarves-stoles": { name: "स्कार्फ़ और स्टोल" },
  "jewellery": { name: "आभूषण" },
  "fragrance": { name: "सुगंध" },
  "bags-travel": { name: "बैग और यात्रा" },
  "gift-sets": { name: "चुनिंदा गिफ़्ट सेट" },
  "lux-tech": { name: "लक्स-टेक", tagline: "सुंदर तकनीक, सोच-समझकर चुनी गई" },
  "ai-smart-glasses": { name: "AI स्मार्ट चश्मे" },
  "rugged-phones": { name: "रग्ड फ़ोन" },
  "mobile-phones": { name: "मोबाइल फ़ोन" },
  "smart-wearables": { name: "स्मार्ट वियरेबल्स" },
  "premium-audio": { name: "प्रीमियम ऑडियो" },
  "smart-home": { name: "स्मार्ट होम" },
  "desk-travel-tech": { name: "डेस्क और ट्रैवल टेक" },
};

/** Keyed by the product's current English title. */
const PRODUCTS: Record<string, Partial<Record<"title" | "shortDescription" | "description" | "material" | "color", string>>> = {
  "OnePlus 7T Pro 12GB RAM 256GB ROM Unlocked 5G": {
    title: "वनप्लस 7T प्रो, 12GB RAM, 256GB स्टोरेज, अनलॉक्ड 5G",
    description: "यह इस्तेमाल किया हुआ वनप्लस 7T प्रो स्मार्टफ़ोन है। यह अनलॉक्ड, सेकंड-हैंड डिवाइस है और ग्रेड A+ स्थिति में उपलब्ध है।",
  },
  "Portable Handheld Digital Microscope for Kids with 2″ Screen – Brown": {
    title: "बच्चों के लिए पोर्टेबल हैंडहेल्ड डिजिटल माइक्रोस्कोप, 2″ स्क्रीन के साथ – भूरा",
    description: "यह पोर्टेबल हैंडहेल्ड डिजिटल माइक्रोस्कोप बच्चों को सूक्ष्म दुनिया को पूरी स्पष्टता से देखने देता है।",
    color: "भूरा",
  },
  "Digital Wall Clock with Wireless Outdoor Sensor & Indoor Temperature Humidity Monitor (YD204 White)": {
    title: "वायरलेस आउटडोर सेंसर और इनडोर तापमान-नमी मॉनिटर वाली डिजिटल दीवार घड़ी (YD204, सफ़ेद)",
    description: "वायरलेस आउटडोर सेंसर वाली इस डिजिटल दीवार घड़ी में बड़ी, साफ़ LCD स्क्रीन और घर के अंदर-बाहर के मौसम का मॉनिटर है।",
    color: "सफ़ेद",
  },
  "Portable USB Electric Mosquito Repellent – Mini Heated Insect Killer for Outdoor Camping, Travel, and Home (Green)": {
    title: "पोर्टेबल USB इलेक्ट्रिक मच्छर भगाने वाला उपकरण – कैंपिंग, यात्रा और घर के लिए मिनी हीटेड कीट नाशक (हरा)",
    description: "USB इलेक्ट्रिक मच्छर भगाने वाला यह उपकरण कैंपिंग, यात्रा और घर के लिए भरोसेमंद, रसायन-मुक्त सुरक्षा देता है।",
    color: "हरा",
  },
  "REMOID M006 Water-Resistant Travel Laptop Backpack Beige Rucksack": {
    title: "रेमॉइड M006 वॉटर-रेज़िस्टेंट ट्रैवल लैपटॉप बैकपैक, बेज रकसैक",
    description: "इस वॉटर-रेज़िस्टेंट ट्रैवल लैपटॉप बैकपैक के साथ अपनी रोज़ की यात्रा या वीकेंड की सैर को बेहतर बनाएँ।",
    color: "बेज",
  },
  "Kids Foldable Mesh Beach Bag & Toy Organizer – Lightweight Single-Shoulder Sand-Away Storage Pouch with Adjustable Strap & Zipper": {
    title: "बच्चों का फ़ोल्डेबल मेश बीच बैग और खिलौना ऑर्गनाइज़र – एडजस्टेबल स्ट्रैप और ज़िप वाला हल्का, एक कंधे वाला रेत-मुक्त स्टोरेज पाउच",
    description: "बीच पर बिखराव और कार की डिक्की में रेत को अलविदा कहें। बच्चों के लिए एक कंधे वाला, फ़ोल्ड होने वाला मेश पाउच।",
  },
  "3-Piece Decorative Guitar Wall Hooks – Vintage Resin Headstock Key & Coat Hangers for Music Lovers, Unique Wall Decor & Organizer Set": {
    title: "3 पीस सजावटी गिटार वॉल हुक – संगीत प्रेमियों के लिए विंटेज रेज़िन हेडस्टॉक चाबी और कोट हैंगर, अनोखा दीवार सज्जा और ऑर्गनाइज़र सेट",
    description: "संगीतकारों के लिए अनोखा डिज़ाइन: ट्यूनिंग पेग और तारों की बारीकियों के साथ असली जैसा गिटार हेडस्टॉक आकार।",
  },
  "Gold Iron Coffee Capsule Storage Basket & Open Display Stand": {
    title: "सुनहरी आयरन कॉफ़ी कैप्सूल स्टोरेज बास्केट और ओपन डिस्प्ले स्टैंड",
    description: "सुनहरी आयरन कॉफ़ी कैप्सूल स्टोरेज बास्केट के साथ अपने कॉफ़ी कॉर्नर को स्टाइल से व्यवस्थित करें।",
    color: "सुनहरा",
  },
  "Gothic Resin Skull Ashtray & Spooky Halloween Home Decor": {
    title: "गॉथिक रेज़िन स्कल ऐशट्रे और डरावनी हैलोवीन गृह सज्जा",
    description: "गॉथिक रेज़िन स्कल ऐशट्रे के साथ अपनी जगह को एक रहस्यमय, कूल अंदाज़ दें।",
  },
};

const HERO: Record<string, { eyebrow: string; headline: string; text: string; cta1: string; cta2: string; alt: string }> = {
  rugged: {
    eyebrow: "लक्स-टेक · रग्ड फ़ोन",
    headline: "हर इलाक़े के लिए बने मज़बूत 5G फ़ोन।",
    text: "यूलेफ़ोन, यूनिहर्ट्ज़, ओकिटेल, ब्लैकव्यू और डूजी के डिवाइस — IP68/IP69K तक की सुरक्षा और लंबी चलने वाली बैटरी के साथ; जाँचे, सील किए और GST इनवॉइस के साथ बीमित भेजे जाते हैं।",
    cta1: "रग्ड फ़ोन देखें",
    cta2: "सभी लक्स-टेक",
    alt: "रात के आसमान की पृष्ठभूमि में पीछे कैमरा मॉड्यूल वाला मज़बूत स्मार्टफ़ोन",
  },
  unbox: {
    eyebrow: "बॉक्स में क्या है",
    headline: "फ़ैक्टरी-सील्ड। GST इनवॉइस के साथ।",
    text: "हर डिवाइस अपने मूल सील बंद बॉक्स में, कंपनी की एक्सेसरीज़ के साथ आता है — आपके नाम का टैक्स इनवॉइस और अप्रयुक्त वस्तुओं पर आसान वापसी के साथ।",
    cta1: "हम कैसे भेजते हैं",
    cta2: "वापसी नीति",
    alt: "चार्जर और केबल के साथ रग्ड फ़ोन का बॉक्स खोलते हाथ",
  },
  glasses: {
    eyebrow: "लक्स-टेक · स्मार्ट चश्मे",
    headline: "AI स्मार्ट चश्मे, बिना हाथ लगाए।",
    text: "ओपन-ईयर ऑडियो, 8MP कैमरा, लाइव अनुवाद और वॉइस असिस्टेंट — उसी फ़्रेम में जो आप रोज़ पहनते हैं। फ़ीचर मॉडल के अनुसार अलग हो सकते हैं — हर लिस्टिंग में पूरी जानकारी दी गई है।",
    cta1: "स्मार्ट चश्मे देखें",
    cta2: "कंसीयर्ज से संपर्क करें",
    alt: "AI स्मार्ट चश्मे: वॉइस असिस्टेंट, अनुवाद, वस्तु पहचान, कैमरा और बैटरी",
  },
  shop: {
    eyebrow: "लक्ज़हॉलिक · नोएडा, भारत",
    headline: "कला, सज्जा, फ़ैशन और लक्स-टेक, पूरे भारत में डिलीवरी।",
    text: "कीमतें GST सहित भारतीय रुपये में। UPI, कार्ड, नेटबैंकिंग से सुरक्षित भुगतान करें — या कैश ऑन डिलीवरी चुनें।",
    cta1: "सब कुछ देखें",
    cta2: "₹5,000 से कम में लग्ज़री",
    alt: "अँधेरे कमरे में टैबलेट पर ख़रीदारी करते हाथ",
  },
};

/** Promise bar under the hero, keyed by the English label. */
const TRUST: Record<string, string> = {
  "GST invoice on every order": "हर ऑर्डर पर GST इनवॉइस",
  "Easy returns on unused items": "अप्रयुक्त वस्तुओं पर आसान वापसी",
  "Insured delivery across India": "पूरे भारत में बीमित डिलीवरी",
  "Secure checkout · UPI, cards, net banking": "सुरक्षित चेकआउट · UPI, कार्ड, नेटबैंकिंग",
};

/** Site texts from Store Settings, keyed by the English text. */
const SITE: Record<string, string> = {
  "Complimentary insured shipping across India · Easy 7-day returns · Pay 10% now, rest on delivery":
    "पूरे भारत में मुफ़्त बीमित शिपिंग · 7 दिन की आसान वापसी · अभी 10% चुकाएँ, बाकी डिलीवरी पर",
  "Madhu Chopra (Proprietor), trading as LUXEHOLIC": "मधु चोपड़ा (प्रोप्राइटर), व्यापारिक नाम लक्ज़हॉलिक",
  "T16-2601, Tower 16, Plot No. GH-03, Lotus Boulevard, Phase 2, Sector 100, Noida 201301, Uttar Pradesh, India":
    "T16-2601, टावर 16, प्लॉट नं. GH-03, लोटस बुलेवार्ड, फ़ेज़ 2, सेक्टर 100, नोएडा 201301, उत्तर प्रदेश, भारत",
  "Mon–Sat, 10:00 AM – 7:00 PM IST": "सोम–शनि, सुबह 10:00 – शाम 7:00 (IST)",
  "Noida": "नोएडा",
  "Uttar Pradesh": "उत्तर प्रदेश",
};

/** Returns how many translations were written. */
export async function seedHindi(log: (m: string) => void = console.log) {
  let n = 0, skipped = 0;
  const cats = await db.select().from(schema.categories);
  for (const c of cats) {
    const h = CATEGORIES[c.slug]; if (!h) continue;
    await saveTranslation("category", c.id, "name", "hi", h.name, c.name, "manual"); n++;
    if (c.tagline && h.tagline) { await saveTranslation("category", c.id, "tagline", "hi", h.tagline, c.tagline, "manual"); n++; }
    if (c.description && h.description) { await saveTranslation("category", c.id, "description", "hi", h.description, c.description, "manual"); n++; }
  }
  const prods = await db.select().from(schema.products);
  for (const p of prods) {
    const h = PRODUCTS[p.title]; if (!h) continue;
    for (const f of ["title", "shortDescription", "description", "material", "color"] as const) {
      const en = p[f]; if (!en) continue;
      if (!h[f]) { skipped++; log(`  no Hindi for ${p.title.slice(0, 40)} · ${f}`); continue; }
      await saveTranslation("product", p.id, f, "hi", h[f]!, en, "manual"); n++;
    }
  }
  const hero = await getHero();
  for (const ch of hero.chapters) {
    const h = HERO[ch.id]; if (!h) continue;
    const en = { eyebrow: ch.eyebrow, headline: ch.headline, text: ch.text, cta1: ch.cta1.label, cta2: ch.cta2.label, alt: ch.alt };
    for (const f of Object.keys(en) as (keyof typeof en)[]) if (en[f]) { await saveTranslation("hero", ch.id, f, "hi", h[f], en[f], "manual"); n++; }
  }
  for (const [i, t] of hero.trust.entries()) if (TRUST[t.label]) { await saveTranslation("site", `hero-trust-${i}`, "text", "hi", TRUST[t.label], t.label, "manual"); n++; }
  const s = await getSettings();
  const b = s.business;
  const site: Record<string, string> = { announcement: s.announcement, legalName: b.legalName, address: businessAddress(b), supportHours: b.supportHours, city: b.city, state: b.state };
  for (const [id, en] of Object.entries(site)) {
    if (!en) continue;
    if (SITE[en]) { await saveTranslation("site", id, "text", "hi", SITE[en], en, "manual"); n++; }
    else log(`  no Hindi for site text "${id}": ${en}`);
  }
  log(`Hindi translations saved: ${n}${skipped ? ` (${skipped} fields still need Hindi)` : ""}`);
  return n;
}
