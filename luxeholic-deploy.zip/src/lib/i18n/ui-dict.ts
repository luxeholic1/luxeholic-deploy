import { unstable_cache, revalidateTag } from "next/cache";
import { and, eq } from "drizzle-orm";
import { db, schema } from "@/db";
import { HI } from "./hi";
import { hashText } from "./content";
import type { Locale } from "./config";

/** The site's interface text (buttons, menus, checkout, emails…) — the same English keys as the Hindi dictionary. */
export const UI_KEYS = Object.keys(HI);
const tag = (l: Locale) => `ui-dict:${l}`;

/** Interface translations for a language other than English/Hindi, kept in the translations table (entity "ui"). */
export function uiDict(locale: Locale): Promise<Record<string, string>> {
  return unstable_cache(async () => {
    const rows = await db.select({ id: schema.translations.entityId, text: schema.translations.text }).from(schema.translations)
      .where(and(eq(schema.translations.entity, "ui"), eq(schema.translations.locale, locale)));
    const byHash = new Map(rows.map((r) => [r.id, r.text]));
    const out: Record<string, string> = {};
    for (const k of UI_KEYS) { const v = byHash.get(hashText(k)); if (v) out[k] = v; }
    return out;
  }, ["ui-dict", locale], { tags: [tag(locale)], revalidate: 3600 })();
}

export async function saveUiStrings(locale: Locale, map: Record<string, string>, source: "auto" | "manual") {
  for (const [en, text] of Object.entries(map)) {
    if (!text.trim()) continue;
    const v = { entity: "ui", entityId: hashText(en), field: "text", locale, text: text.trim(), sourceHash: hashText(en), source };
    await db.insert(schema.translations).values(v).onConflictDoUpdate({
      target: [schema.translations.entity, schema.translations.entityId, schema.translations.field, schema.translations.locale],
      set: { text: v.text, source, updatedAt: new Date() },
    });
  }
  revalidateTag(tag(locale));
}
