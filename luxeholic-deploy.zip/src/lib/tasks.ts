import { and, eq, isNull, lte, or, gte, ne, lt, inArray } from "drizzle-orm";
import { db, schema } from "@/db";
import { addDays, dayOfMonth, eachDay, todayIST, weekday } from "./dates";
import { notifyStaff, sendMail } from "./notify";
import { SITE_URL } from "./site";

type Template = typeof schema.tasks.$inferSelect;

export function occursOn(t: Pick<Template, "dueDate" | "recurUntil" | "recurrence">, day: string) {
  if (day < t.dueDate) return false;
  if (t.recurUntil && day > t.recurUntil) return false;
  switch (t.recurrence) {
    case "DAILY": return true;
    case "WEEKDAYS": return weekday(day) !== 0; // working days: Mon–Sat
    case "WEEKLY": return weekday(day) === weekday(t.dueDate);
    case "MONTHLY": return dayOfMonth(day) === dayOfMonth(t.dueDate);
    default: return false;
  }
}

/**
 * Recurring to-dos are stored as templates; each occurrence becomes a real, dated task
 * (so it can be ticked off, commented on and reported on). Idempotent — safe to call often.
 * We never generate past today + horizon, so future days stay light.
 */
export async function materializeRecurring(from: string, to: string) {
  const limit = addDays(todayIST(), 14);
  if (to > limit) to = limit;
  if (from > to) return 0;
  const templates = await db
    .select()
    .from(schema.tasks)
    .where(and(eq(schema.tasks.isTemplate, true), lte(schema.tasks.dueDate, to), or(isNull(schema.tasks.recurUntil), gte(schema.tasks.recurUntil, from))));
  const rows: (typeof schema.tasks.$inferInsert)[] = [];
  for (const t of templates) {
    for (const day of eachDay(from, to)) {
      if (!occursOn(t, day)) continue;
      rows.push({
        title: t.title, description: t.description, kind: t.kind, teamId: t.teamId, assigneeId: t.assigneeId,
        createdById: t.createdById, priority: t.priority, dueDate: day, dueTime: t.dueTime, templateId: t.id,
        recurrence: "NONE", isTemplate: false,
      });
    }
  }
  if (!rows.length) return 0;
  const inserted = await db.insert(schema.tasks).values(rows).onConflictDoNothing().returning({ id: schema.tasks.id });
  return inserted.length;
}

/** Morning job: create today's to-dos and remind people of anything overdue. */
export async function dailyTaskJob() {
  const today = todayIST();
  const created = await materializeRecurring(addDays(today, -1), addDays(today, 7));
  const overdue = await db
    .select({ id: schema.tasks.id, title: schema.tasks.title, assigneeId: schema.tasks.assigneeId, teamId: schema.tasks.teamId })
    .from(schema.tasks)
    .where(and(eq(schema.tasks.isTemplate, false), ne(schema.tasks.status, "DONE"), lt(schema.tasks.dueDate, today)));
  // Group overdue counts per person (team-wide tasks go to the whole team)
  const teamIds = [...new Set(overdue.filter((o) => !o.assigneeId && o.teamId).map((o) => o.teamId!))];
  const members = teamIds.length
    ? await db.select({ id: schema.staff.id, teamId: schema.staff.teamId }).from(schema.staff).where(and(inArray(schema.staff.teamId, teamIds), eq(schema.staff.active, true)))
    : [];
  const counts = new Map<string, number>();
  for (const o of overdue) {
    const targets = o.assigneeId ? [o.assigneeId] : members.filter((m) => m.teamId === o.teamId).map((m) => m.id);
    for (const t of targets) counts.set(t, (counts.get(t) ?? 0) + 1);
  }
  for (const [staffId, n] of counts) {
    await notifyStaff([staffId], `You have ${n} overdue task${n > 1 ? "s" : ""}`, "Open your task list to catch up.", "/team/tasks?view=overdue");
  }
  const digests = await sendDailyDigests(today);
  return { created, overdue: overdue.length, digests };
}

/** "Your to-dos for today" — bell notification for everyone, email too when SMTP is configured. */
export async function sendDailyDigests(day: string) {
  const people = await db.select({ id: schema.staff.id, name: schema.staff.name, email: schema.staff.email, teamId: schema.staff.teamId })
    .from(schema.staff).where(eq(schema.staff.active, true));
  const todays = await db.select({ title: schema.tasks.title, teamId: schema.tasks.teamId, assigneeId: schema.tasks.assigneeId, dueTime: schema.tasks.dueTime, priority: schema.tasks.priority })
    .from(schema.tasks).where(and(eq(schema.tasks.isTemplate, false), eq(schema.tasks.dueDate, day), ne(schema.tasks.status, "DONE")));
  let sent = 0;
  for (const p of people) {
    const mine = todays.filter((t) => t.assigneeId === p.id || (!t.assigneeId && (t.teamId === p.teamId || !t.teamId)));
    if (!mine.length) continue;
    await notifyStaff([p.id], `Today: ${mine.length} to-do${mine.length > 1 ? "s" : ""}`, mine.slice(0, 3).map((t) => t.title).join(" · "), "/team/tasks");
    if (process.env.SMTP_HOST) {
      const list = mine.map((t) => `• ${t.dueTime ? `<b>${t.dueTime}</b> ` : ""}${t.title}${t.priority === "URGENT" || t.priority === "HIGH" ? ` <span style="color:#7E6133">(${t.priority.toLowerCase()})</span>` : ""}`).join("<br>");
      await sendMail(p.email, `Your Luxeholic to-dos for today (${mine.length})`, `Good morning, ${p.name.split(" ")[0]}.`, list, { label: "Open my tasks", url: `${SITE_URL}/team/tasks` });
    }
    sent++;
  }
  return sent;
}
