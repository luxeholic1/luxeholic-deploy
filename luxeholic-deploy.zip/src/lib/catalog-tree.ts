/**
 * The Luxeholic category tree. Seeded into the database (editable later in Team → Categories).
 * `google` = Google product taxonomy path sent in the Merchant Center feed.
 * `keywords` = how synced vendor products are auto-sorted into sub-categories.
 */
export type TreeNode = {
  slug: string; name: string; tagline?: string; google: string; vendor?: "sunsky" | "brandsgateway";
  apparel?: boolean; keywords?: string[]; children?: TreeNode[];
};

export const CATALOG_TREE: TreeNode[] = [
  {
    slug: "art-sculpture", name: "Art & Sculpture", tagline: "Pieces that become the conversation", vendor: "sunsky",
    google: "Home & Garden > Decor > Artwork > Sculptures & Statues",
    children: [
      { slug: "resin-sculptures", name: "Resin Sculptures", google: "Home & Garden > Decor > Artwork > Sculptures & Statues", keywords: ["resin", "sculpture", "statue", "statuette"] },
      { slug: "abstract-figurines", name: "Abstract & Modern Figurines", google: "Home & Garden > Decor > Figurines", keywords: ["abstract", "figurine", "thinker", "modern art", "geometric"] },
      { slug: "animal-sculptures", name: "Animal Sculptures", google: "Home & Garden > Decor > Figurines", keywords: ["animal", "horse", "elephant", "lion", "deer", "bear", "dog", "cat", "bird", "panther", "gorilla"] },
      { slug: "spiritual-art", name: "Spiritual & Buddha Art", google: "Home & Garden > Decor > Artwork > Sculptures & Statues", keywords: ["buddha", "ganesha", "spiritual", "zen", "meditation", "religious"] },
      { slug: "wall-art", name: "Wall Art & Frames", google: "Home & Garden > Decor > Artwork > Posters, Prints, & Visual Artwork", keywords: ["wall art", "canvas", "painting", "frame", "wall decor", "poster", "print"] },
      { slug: "tabletop-accents", name: "Bookends & Tabletop Accents", google: "Home & Garden > Decor > Bookends", keywords: ["bookend", "ornament", "desktop ornament", "tabletop", "paperweight"] },
    ],
  },
  {
    slug: "home-decor", name: "Home Décor", tagline: "Quiet luxury for every room", vendor: "sunsky",
    google: "Home & Garden > Decor",
    children: [
      { slug: "vases-planters", name: "Vases & Planters", google: "Home & Garden > Decor > Vases", keywords: ["vase", "planter", "flower pot", "pot"] },
      { slug: "candles-holders", name: "Candles & Holders", google: "Home & Garden > Decor > Candle Holders", keywords: ["candle", "candlestick", "lantern", "tealight", "diffuser"] },
      { slug: "lamps-lighting", name: "Lamps & Lighting", google: "Home & Garden > Lighting > Lamps", keywords: ["lamp", "light", "chandelier", "night light", "led"] },
      { slug: "clocks", name: "Clocks", google: "Home & Garden > Decor > Clocks", keywords: ["clock"] },
      { slug: "mirrors", name: "Mirrors", google: "Home & Garden > Decor > Mirrors", keywords: ["mirror"] },
      { slug: "trays-bowls-boxes", name: "Trays, Bowls & Boxes", google: "Home & Garden > Decor > Decorative Trays", keywords: ["tray", "bowl", "jewelry box", "storage box", "trinket"] },
      { slug: "tableware-barware", name: "Tableware & Barware", google: "Home & Garden > Kitchen & Dining > Tableware", keywords: ["glass", "wine", "decanter", "cup", "mug", "plate", "coaster", "tableware", "barware", "whisky"] },
    ],
  },
  {
    slug: "designer-fashion", name: "Designer Fashion", tagline: "Authentic European houses", vendor: "brandsgateway", apparel: true,
    google: "Apparel & Accessories",
    children: [
      { slug: "womens-clothing", name: "Women's Clothing", apparel: true, google: "Apparel & Accessories > Clothing", keywords: ["women > clothing", "dress", "skirt", "blouse", "women's", "womens"] },
      { slug: "mens-clothing", name: "Men's Clothing", apparel: true, google: "Apparel & Accessories > Clothing", keywords: ["men > clothing", "shirt", "t-shirt", "polo", "jacket", "trousers", "jeans", "sweater", "hoodie", "blazer", "coat"] },
      { slug: "handbags", name: "Designer Handbags", apparel: true, google: "Apparel & Accessories > Handbags, Wallets & Cases > Handbags", keywords: ["bag", "handbag", "tote", "clutch", "backpack", "crossbody", "shoulder bag"] },
      { slug: "designer-shoes", name: "Designer Shoes", apparel: true, google: "Apparel & Accessories > Shoes", keywords: ["shoe", "sneaker", "loafer", "boot", "heel", "sandal", "pump", "slipper", "moccasin"] },
    ],
  },
  {
    slug: "gifting-accessories", name: "Gifting & Accessories", tagline: "Gifts they will keep for life", vendor: "brandsgateway", apparel: true,
    google: "Apparel & Accessories > Clothing Accessories",
    children: [
      { slug: "watches", name: "Watches", apparel: true, google: "Apparel & Accessories > Jewelry > Watches", keywords: ["watch"] },
      { slug: "sunglasses", name: "Sunglasses & Eyewear", apparel: true, google: "Apparel & Accessories > Clothing Accessories > Sunglasses", keywords: ["sunglasses", "eyewear", "glasses frame", "optical"] },
      { slug: "wallets-leather", name: "Wallets & Small Leather Goods", apparel: true, google: "Apparel & Accessories > Handbags, Wallets & Cases > Wallets & Money Clips", keywords: ["wallet", "card holder", "cardholder", "key holder", "keyring", "pouch"] },
      { slug: "belts", name: "Belts", apparel: true, google: "Apparel & Accessories > Clothing Accessories > Belts", keywords: ["belt"] },
      { slug: "scarves-stoles", name: "Scarves & Stoles", apparel: true, google: "Apparel & Accessories > Clothing Accessories > Scarves & Shawls", keywords: ["scarf", "stole", "shawl", "foulard"] },
      { slug: "jewellery", name: "Jewellery", apparel: true, google: "Apparel & Accessories > Jewelry", keywords: ["jewel", "necklace", "bracelet", "earring", "ring", "pendant", "cufflink"] },
      { slug: "fragrance", name: "Fragrance", google: "Health & Beauty > Personal Care > Cosmetics > Perfume & Cologne", keywords: ["perfume", "fragrance", "eau de", "cologne", "parfum"] },
      { slug: "bags-travel", name: "Bags & Travel", google: "Luggage & Bags", keywords: ["backpack", "rucksack", "travel bag", "duffel", "luggage", "beach bag"] },
      { slug: "gift-sets", name: "Curated Gift Sets", google: "Arts & Entertainment > Party & Celebration > Gift Giving", keywords: ["gift set", "gift box", "hamper"] },
    ],
  },
  {
    slug: "lux-tech", name: "Lux-Tech", tagline: "Beautiful technology, carefully chosen", vendor: "sunsky",
    google: "Electronics",
    children: [
      { slug: "ai-smart-glasses", name: "AI Smart Glasses", google: "Electronics", keywords: ["smart glasses", "ai glasses", "bluetooth glasses", "audio glasses"] },
      { slug: "rugged-phones", name: "Rugged Phones", google: "Electronics > Communications > Telephony > Mobile Phones", keywords: ["rugged", "phone", "smartphone", "doogee", "ulefone", "blackview", "oukitel"] },
      { slug: "mobile-phones", name: "Mobile Phones", google: "Electronics > Communications > Telephony > Mobile Phones", keywords: ["oneplus", "iphone", "galaxy", "pixel", "mobile phone"] },
      { slug: "smart-wearables", name: "Smart Wearables", google: "Electronics", keywords: ["smart watch", "smartwatch", "smart band", "smart ring", "fitness tracker"] },
      { slug: "premium-audio", name: "Premium Audio", google: "Electronics > Audio > Audio Components > Headphones & Headsets", keywords: ["earphone", "earbuds", "headphone", "headset", "speaker", "tws"] },
      { slug: "smart-home", name: "Smart Home", google: "Electronics", keywords: ["smart home", "camera", "smart plug", "projector", "air purifier", "robot"] },
      { slug: "desk-travel-tech", name: "Desk & Travel Tech", google: "Electronics", keywords: ["charger", "power bank", "wireless charger", "keyboard", "mouse", "stand", "hub", "adapter"] },
    ],
  },
];

export const ALL_LEAVES = CATALOG_TREE.flatMap((p) => (p.children ?? []).map((c) => ({ ...c, parent: p })));

/** Pick our sub-category for a synced vendor product. Returns null when unsure (product stays DRAFT for review). */
export function mapCategory(vendorSlug: string, vendorCategory: string, title: string, overrides?: Record<string, string>) {
  const cat = vendorCategory.toLowerCase();
  const text = `${cat} ${title.toLowerCase()}`;
  if (overrides) {
    for (const [k, slug] of Object.entries(overrides)) if (cat.includes(k.toLowerCase()) || text.includes(k.toLowerCase())) return slug;
  }
  const candidates = ALL_LEAVES.filter((l) => !l.parent.vendor || l.parent.vendor === vendorSlug || vendorSlug.startsWith(l.parent.vendor!));
  const pool = candidates.length ? candidates : ALL_LEAVES;
  // category path first (more reliable), then title
  for (const source of [cat, text]) {
    for (const leaf of pool) if (leaf.keywords?.some((k) => new RegExp(`\\b${k.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")}`).test(source))) return leaf.slug;
  }
  return null;
}
