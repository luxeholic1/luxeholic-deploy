/**
 * Panel access. Every team gets the workspace (dashboard, tasks, calendar, notifications).
 * Business modules are granted per team by the super admin (Team → Teams), stored on teams.modules.
 * The super admin always has full write access everywhere.
 */
export type Level = "read" | "write";

export const MODULES = {
  orders: { label: "Orders", href: "/team/orders", hint: "Customer orders, payments, COD & bank-transfer verification" },
  leads: { label: "Call-back requests", href: "/team/leads", hint: "\"Request a call back\" from the website — call, note, close" },
  customers: { label: "Customers", href: "/team/customers", hint: "Customer accounts and order history" },
  products: { label: "Products", href: "/team/products", hint: "Catalogue, stock, pricing, publishing" },
  categories: { label: "Categories", href: "/team/categories", hint: "Category & sub-category tree" },
  purchaseOrders: { label: "Purchase Orders", href: "/team/purchase-orders", hint: "Orders to vendors (dropship + stock)" },
  vendors: { label: "Vendors & OEMs", href: "/team/vendors", hint: "SunSky, BrandsGateway and new vendors; sync" },
  tickets: { label: "Support Tickets", href: "/team/tickets", hint: "Customer queries from the contact form" },
  marketing: { label: "Marketing", href: "/team/marketing", hint: "Coupons, subscribers, Merchant Center feed" },
} as const;
export type ModuleKey = keyof typeof MODULES;

/** Super-admin-only areas */
export const ADMIN_AREAS = {
  staff: { label: "Staff & Logins", href: "/team/staff" },
  teams: { label: "Teams & Access", href: "/team/teams" },
  settings: { label: "Store Settings", href: "/team/settings" },
  activity: { label: "Audit Log", href: "/team/activity" },
} as const;

/** Sensible defaults, seeded once and editable afterwards. */
export const DEFAULT_TEAM_MODULES: Record<string, Partial<Record<ModuleKey, Level>>> = {
  sales: { orders: "write", leads: "write", customers: "write", products: "read", tickets: "read" },
  marketing: { marketing: "write", products: "write", categories: "write", customers: "read", leads: "read" },
  procurement: { purchaseOrders: "write", vendors: "read", orders: "read", products: "read" },
  inventory: { products: "write", categories: "write", purchaseOrders: "read", orders: "read" },
  "tech-support": { tickets: "write", leads: "write", orders: "read", customers: "read", products: "read" },
  alliances: { vendors: "write", purchaseOrders: "read", products: "read" },
};

export type StaffLike = {
  role: "SUPER_ADMIN" | "TEAM_LEAD" | "MEMBER";
  team: { modules: Record<string, Level> } | null;
};

export function accessLevel(s: StaffLike, m: ModuleKey): Level | null {
  if (s.role === "SUPER_ADMIN") return "write";
  return (s.team?.modules?.[m] as Level | undefined) ?? null;
}
export const canRead = (s: StaffLike, m: ModuleKey) => accessLevel(s, m) !== null;
export const canWrite = (s: StaffLike, m: ModuleKey) => accessLevel(s, m) === "write";
export const isSuper = (s: { role: string }) => s.role === "SUPER_ADMIN";
/** Who may assign tasks: super admin (any team) and team leads (own team). */
export const canAssign = (s: { role: string }) => s.role === "SUPER_ADMIN" || s.role === "TEAM_LEAD";
