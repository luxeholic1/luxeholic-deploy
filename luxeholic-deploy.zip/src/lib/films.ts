import type { ScrollFilm } from "@/components/store/scroll-video";

/**
 * Scroll-scrubbed films per category slug. To add one: drop an MP4 in /public/media/<folder>/
 * (encode with: ffmpeg -i in.mp4 -an -vf scale=1280:-2,fps=24 -c:v libx264 -crf 30 -g 6 -keyint_min 6 -movflags +faststart out.mp4)
 * and list it here. Category pages show every film listed for their slug.
 */
const RUGKING_5: ScrollFilm = {
  id: "rugking-5-pro",
  src: "/media/lux-tech/rugking-5-pro.mp4",
  poster: "/media/lux-tech/rugking-5-pro.jpg",
  eyebrow: "Lux-Tech · Rugged Phones",
  heading: "Ulefone RugKing 5 Pro",
  screens: 7,
  beats: [
    { at: 0, eyebrow: "Scroll to explore", title: "Built for the wild.", text: "Ulefone RugKing 5 Pro — a phone that goes where you go." },
    { at: 0.05, eyebrow: "20MP Night Vision", title: "See in the dark.", text: "Infrared night-vision camera for trails, camps and late returns." },
    { at: 0.12, eyebrow: "Reverse charging", title: "Charge the others.", text: "Top up earbuds or a friend's phone straight from the RugKing." },
    { at: 0.3, eyebrow: "IP68 · IP69K", title: "Rain, river, rockface.", text: "Water- and dust-proof to the highest ratings." },
    { at: 0.6, eyebrow: "Water-Lock mode", title: "Wet screen, steady touch.", text: "Navigate maps even with water on the display." },
    { at: 0.78, eyebrow: "Unisoc T7250", title: "Quietly powerful.", text: "Efficient octa-core performance and a built-in camping light." },
    { at: 0.92, eyebrow: "Lux-Tech", title: "Toughness, beautifully done." },
  ],
  cta: { href: "/c/rugged-phones", label: "Shop rugged phones" },
};

const RUGKING_2_ACC: ScrollFilm = {
  id: "rugking-2-pro-accessories",
  src: "/media/lux-tech/rugking-2-pro-accessories.mp4",
  poster: "/media/lux-tech/rugking-2-pro-accessories.jpg",
  eyebrow: "Lux-Tech · Accessory ecosystem",
  heading: "Ulefone RugKing 2 Pro accessories",
  screens: 4,
  beats: [
    { at: 0, eyebrow: "RugKing 2 Pro", title: "One phone. A whole kit.", text: "Clip-on accessories that change what your phone can do." },
    { at: 0.08, eyebrow: "Armor case", title: "Wear it on your strap.", text: "A clip-on armour case for hands-free adventures." },
    { at: 0.42, eyebrow: "Desk charging dock", title: "Home base.", text: "Drop it in the dock and it's charging, upright and ready." },
    { at: 0.72, eyebrow: "Floating tray", title: "Poolside, sorted.", text: "A floating tray that keeps your phone — and snacks — above water." },
  ],
  cta: { href: "/c/rugged-phones", label: "Shop rugged phones" },
};

const A2_GLASSES: ScrollFilm = {
  id: "a2-smart-glasses",
  src: "/media/smart-glasses/a2-smart-glasses.mp4",
  poster: "/media/smart-glasses/a2-smart-glasses.jpg",
  eyebrow: "Lux-Tech · AI Smart Glasses",
  heading: "A2 8MP HD smart camera glasses",
  screens: 6,
  beats: [
    { at: 0, eyebrow: "Scroll to explore", title: "Glasses that think.", text: "A2 smart camera glasses — classic frames with an AI assistant built in." },
    { at: 0.08, eyebrow: "Classic design", title: "Looks like eyewear. Because it is.", text: "Lightweight, flexible temples for all-day comfort." },
    { at: 0.22, eyebrow: "8MP camera", title: "Capture what you see.", text: "Hands-free photos and video from eye level." },
    { at: 0.38, eyebrow: "Open-air audio", title: "Music without earbuds.", text: "Dual speakers aimed at your ears, with minimal sound leakage." },
    { at: 0.46, eyebrow: "Bluetooth calling", title: "Take the call, keep walking.", text: "Dual microphones with noise cancellation." },
    { at: 0.54, eyebrow: "AI object recognition", title: "Ask what you're looking at.", text: "Identify plants, landmarks and objects on the go." },
    { at: 0.68, eyebrow: "AI translation", title: "Every conversation, understood.", text: "Real-time dialogue translation through the companion app." },
    { at: 0.84, eyebrow: "Long-lasting battery", title: "All day, every day." },
  ],
  cta: { href: "/c/ai-smart-glasses", label: "Shop AI smart glasses" },
};

const M02_GLASSES: ScrollFilm = {
  id: "m02-ultra-smart-glasses",
  src: "/media/smart-glasses/m02-ultra-smart-glasses.mp4",
  poster: "/media/smart-glasses/m02-ultra-smart-glasses.jpg",
  eyebrow: "Lux-Tech · AI Smart Glasses",
  heading: "M02 Ultra 8MP AI smart glasses",
  screens: 6,
  beats: [
    { at: 0, eyebrow: "M02 Ultra", title: "AI glasses, with a case that charges them.", text: "8MP camera, AI assistant, music and calls — in everyday frames." },
    { at: 0.07, eyebrow: "Flexible temples", title: "A fit that never pinches." },
    { at: 0.19, eyebrow: "Sony 8MP camera", title: "Shoot from your point of view.", text: "Photos and video, hands-free." },
    { at: 0.32, eyebrow: "360° surround sound", title: "Your soundtrack, wherever you are.", text: "Touch-slide on the temple to change volume." },
    { at: 0.45, eyebrow: "AI photo recognition", title: "Point. Ask. Know." },
    { at: 0.58, eyebrow: "Magnetic fast charging", title: "Snap on, power up." },
    { at: 0.65, eyebrow: "Calls · Wi-Fi + Bluetooth", title: "Answer calls. Share instantly.", text: "Wi-Fi transfer sends photos and videos to your phone in seconds." },
    { at: 0.78, eyebrow: "3600mAh charging case", title: "A case that keeps going." },
    { at: 0.9, eyebrow: "Colour options", title: "Pick your frame." },
  ],
  cta: { href: "/c/ai-smart-glasses", label: "Shop AI smart glasses" },
};

/** Films appear only on the category slugs listed here. */
export const CATEGORY_FILMS: Record<string, ScrollFilm[]> = {
  "rugged-phones": [RUGKING_5, RUGKING_2_ACC],
  "ai-smart-glasses": [A2_GLASSES, M02_GLASSES],
};
