export const SITE_URL = (process.env.NEXT_PUBLIC_SITE_URL || "http://localhost:3000").replace(/\/$/, "");
export const SITE_NAME = "Luxeholic";
export const SITE_TAGLINE = "Art you can live with.";
export const SITE_DESCRIPTION =
  "Luxeholic — curated resin sculpture, home décor, designer fashion, gifting and Lux-Tech. Luxury for every home, delivered across India with complimentary insured shipping.";

export const SUPER_ADMIN_EMAIL = (process.env.SUPER_ADMIN_EMAIL || "karykalita1012@gmail.com").toLowerCase();

export const abs = (path: string) => (path.startsWith("http") ? path : `${SITE_URL}${path.startsWith("/") ? "" : "/"}${path}`);

export function slugify(s: string) {
  return s
    .toLowerCase()
    .normalize("NFKD")
    .replace(/[̀-ͯ]/g, "")
    .replace(/&/g, " and ")
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "")
    .slice(0, 90);
}

export const POLICY_PAGES = [
  { slug: "shipping", title: "Shipping Policy" },
  { slug: "returns", title: "Returns & Refunds" },
  { slug: "payments", title: "Payments & COD" },
  { slug: "authenticity", title: "Authenticity Promise" },
  { slug: "privacy", title: "Privacy Policy" },
  { slug: "terms", title: "Terms of Service" },
] as const;
