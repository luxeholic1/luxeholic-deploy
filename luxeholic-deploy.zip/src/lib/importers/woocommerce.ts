import { mapCategory } from "../catalog-tree";
import { cleanHtml, type ListingInput } from "../listings";

/**
 * Pulls the live catalogue from a WooCommerce store's public Store API
 * (/wp-json/wc/store/v1/products — no keys needed) and converts it to listings.
 * Used once to move luxeholic.in's products onto the new site, and safe to re-run:
 * products are matched by SKU, so a second run only updates price/stock/images.
 */
export type WooStoreProduct = {
  id: number; name: string; slug: string; sku: string; permalink?: string;
  description?: string; short_description?: string;
  prices: { price: string; regular_price: string; sale_price: string; currency_minor_unit: number };
  is_in_stock: boolean; low_stock_remaining?: number | null;
  add_to_cart?: { maximum?: number };
  categories: { name: string; slug?: string }[] | string[];
  images: { src: string }[] | string[];
  attributes?: { name: string; terms: { name: string }[] }[];
};

/** Our category for typical luxeholic.in categories / titles (checked in order, before the generic keyword map). */
export const WOO_CATEGORY_MAP: Record<string, string> = {
  "mobile phones": "mobile-phones",
  oneplus: "mobile-phones",
  iphone: "mobile-phones",
  "smart glasses": "ai-smart-glasses",
  charger: "desk-travel-tech",
  microscope: "desk-travel-tech",
  mosquito: "desk-travel-tech",
  "wall clock": "clocks",
  clock: "clocks",
  backpack: "bags-travel",
  "single-shoulder bags": "bags-travel",
  "beach bag": "bags-travel",
  bags: "bags-travel",
  ashtray: "tabletop-accents",
  "coffee capsule": "tableware-barware",
  "wall hooks": "wall-art",
};

const minorToPaise = (v: string, unit: number) => Math.round((parseInt(v || "0", 10) / 10 ** unit) * 100);

export function wooToListing(p: WooStoreProduct, opts: { defaultStock?: number } = {}): ListingInput {
  const cats = (p.categories as (string | { name: string })[]).map((c) => cleanHtml(typeof c === "string" ? c : c.name));
  const name = cleanHtml(p.name);
  const short = cleanHtml(p.short_description ?? "");
  const desc = cleanHtml(p.description ?? "") || short;
  const unit = p.prices.currency_minor_unit ?? 2;
  const price = minorToPaise(p.prices.sale_price || p.prices.price, unit);
  const regular = minorToPaise(p.prices.regular_price, unit);
  const blob = `${name} ${short}`.toLowerCase();
  const condition = /\brefurbished\b/.test(blob) ? "refurbished" : /\b(used|second[- ]hand|pre[- ]owned)\b/.test(blob) ? "used" : "new";
  const max = p.add_to_cart?.maximum;
  const stock = !p.is_in_stock ? 0 : p.low_stock_remaining ?? (max && max < 9999 ? max : opts.defaultStock ?? 5);
  const attr = (n: string) => p.attributes?.find((a) => a.name.toLowerCase() === n)?.terms.map((t) => t.name).join(", ") || null;
  const color = attr("color") ?? attr("colour") ?? (name.match(/\b(white|black|green|beige|brown|gold|silver|blue|red|pink|grey|gray)\b/i)?.[1] ?? null);
  return {
    sku: (p.sku || `WC-${p.id}`).replace(/\s+/g, "-").slice(0, 60),
    slug: p.slug,
    title: name.replace(/\s{2,}/g, " ").slice(0, 150),
    description: desc,
    shortDescription: short && short !== desc ? short.slice(0, 300) : null,
    brand: name.match(/^(OnePlus|REMOID|Apple|Samsung|Xiaomi|Ulefone)\b/i)?.[1] ?? "Luxeholic",
    price,
    compareAtPrice: regular > price ? regular : null,
    stock,
    images: (p.images as (string | { src: string })[]).map((i) => (typeof i === "string" ? i : i.src)).filter(Boolean),
    category: mapCategory("", cats.join(" > "), name, WOO_CATEGORY_MAP) ?? "",
    condition,
    color: color ? color[0].toUpperCase() + color.slice(1).toLowerCase() : null,
    tags: [...cats.map((c) => c.toLowerCase()), "luxeholic.in"],
    status: p.images.length ? "ACTIVE" : "DRAFT",
  };
}

/** One page of the public Store API (100 products). */
export async function fetchWooPage(baseUrl: string, page: number): Promise<{ items: WooStoreProduct[]; totalPages: number }> {
  const base = baseUrl.replace(/\/+$/, "");
  const res = await fetch(`${base}/wp-json/wc/store/v1/products?per_page=100&page=${page}`, {
    headers: { Accept: "application/json", "User-Agent": "LuxeholicImporter/1.0" }, cache: "no-store", signal: AbortSignal.timeout(60000),
  });
  if (res.status === 400 && page > 1) return { items: [], totalPages: page - 1 };
  if (!res.ok) throw new Error(`${base} answered ${res.status} on page ${page}`);
  return { items: (await res.json()) as WooStoreProduct[], totalPages: parseInt(res.headers.get("x-wp-totalpages") ?? "0", 10) };
}

export async function fetchWooStore(baseUrl: string, maxPages = 50): Promise<WooStoreProduct[]> {
  const base = baseUrl.replace(/\/+$/, "");
  const out: WooStoreProduct[] = [];
  for (let page = 1; page <= maxPages; page++) {
    const res = await fetch(`${base}/wp-json/wc/store/v1/products?per_page=100&page=${page}`, {
      headers: { Accept: "application/json", "User-Agent": "LuxeholicImporter/1.0" },
      cache: "no-store",
      signal: AbortSignal.timeout(30000),
    });
    if (res.status === 400 && page > 1) break; // past the last page
    if (!res.ok) throw new Error(`${base} answered ${res.status} on page ${page}. Is the WooCommerce Store API enabled?`);
    const batch = (await res.json()) as WooStoreProduct[];
    out.push(...batch);
    const totalPages = parseInt(res.headers.get("x-wp-totalpages") ?? "0", 10);
    if (batch.length < 100 || (totalPages && page >= totalPages)) break;
  }
  return out;
}
