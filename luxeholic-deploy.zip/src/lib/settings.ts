import { cache } from "react";
import { eq } from "drizzle-orm";
import { db, schema } from "@/db";

/**
 * Store-wide settings, editable by the super admin in Team → Settings.
 * Business details here feed the footer, contact page, policies, invoices and the
 * Merchant Center feed — Google cross-checks them, so keep them accurate.
 */
export const DEFAULT_SETTINGS = {
  business: {
    brand: "Luxeholic",
    legalName: "Madhu Chopra (Proprietor), trading as LUXEHOLIC", // must match GST certificate (shown on policies + invoices)
    gstin: "09AFIPC0413J1ZT",
    iec: "AFIPC0413J", // Importer-Exporter Code (DGFT)
    trademark: "™", // switch to "®" only once the registration certificate is issued
    email: "sales@luxeholic.com.au",
    phone: "+91 92664 33722",
    whatsapp: "+91 92664 33722",
    addressLine1: "T16-2601, Tower 16, Plot No. GH-03, Lotus Boulevard",
    addressLine2: "Phase 2, Sector 100",
    city: "Noida",
    state: "Uttar Pradesh",
    pincode: "201301",
    country: "India",
    supportHours: "Mon–Sat, 10:00 AM – 7:00 PM IST",
    instagram: "",
    facebook: "",
    pinterest: "",
    youtube: "",
  },
  announcement: "Complimentary insured shipping across India · Easy 7-day returns · Pay 10% now, rest on delivery",
  payments: {
    payu: true,
    phonepe: true,
    bankTransfer: true,
    cod: true,
    partialCod: true,
    advancePercent: 10,
    codMaxOrder: 1000000,       // ₹10,000 — above this, plain COD is hidden (advance COD still available)
    partialCodMaxOrder: 20000000, // ₹2,00,000
    codFee: 0,
  },
  bank: {
    accountName: "LUXEHOLIC",
    accountNumber: "008527000000840",
    ifsc: "YESB0000085",
    bankName: "YES Bank Ltd",
    branch: "Atta, Noida, Uttar Pradesh",
    upiId: "",
    qrImage: "/brand/phonepe-qr.jpg", // UPI / PhonePe scan-to-pay QR shown on bank-transfer orders
  },
  shipping: {
    freeAbove: 0,        // paise; 0 = always free
    flatFee: 0,          // paise charged below freeAbove
    domesticOnly: true,
  },
  returns: { windowDays: 7, finalSaleCategories: [] as string[] },
  // INR per 1 unit of foreign currency. Update weekly (or before big sync runs).
  fx: { USD: 88, EUR: 103, GBP: 118, CNY: 12.3, HKD: 11.3 } as Record<string, number>,
  // Prices shown in a visitor's currency (display only — checkout always charges INR). INR per 1 unit.
  // With auto on, a daily job refreshes them from open.er-api.com.
  display: { auto: true, rates: { USD: 88.5, GBP: 117, EUR: 102, AED: 24.1, AUD: 57.5, CAD: 63, SGD: 68, NZD: 51 } as Record<string, number>, updatedAt: "", languages: ["en", "hi"] as string[], off: [] as string[] },
  tracking: { ga4Id: "", googleAdsId: "", metaPixelId: "", gmcVerification: "" },
  // Your store pages on marketplaces — shown in the "Also on" section and footer. Leave a link empty to show the name without a link.
  marketplaces: { amazon: "", flipkart: "", blinkit: "", walmart: "" },
};
export type Settings = typeof DEFAULT_SETTINGS;
export type SettingKey = keyof Settings;

export const getSettings = cache(async (): Promise<Settings> => {
  const rows = await db.select().from(schema.settings);
  const out = structuredClone(DEFAULT_SETTINGS) as Settings;
  for (const r of rows) {
    const k = r.key as SettingKey;
    if (!(k in out)) continue;
    const v = r.value as never;
    (out as Record<string, unknown>)[k] =
      typeof out[k] === "object" && out[k] !== null ? { ...(out[k] as object), ...(v as object) } : v;
  }
  // New currencies get their default rate until the next rate refresh.
  const off = new Set(out.display.off ?? []);
  out.display.rates = Object.fromEntries(Object.entries({ ...DEFAULT_SETTINGS.display.rates, ...out.display.rates }).filter(([c]) => !off.has(c)));
  return out;
});

export async function saveSetting<K extends SettingKey>(key: K, value: Settings[K]) {
  await db
    .insert(schema.settings)
    .values({ key, value: value as never })
    .onConflictDoUpdate({ target: schema.settings.key, set: { value: value as never } });
}

export async function getSetting<K extends SettingKey>(key: K): Promise<Settings[K]> {
  const [row] = await db.select().from(schema.settings).where(eq(schema.settings.key, key));
  const d = DEFAULT_SETTINGS[key];
  if (!row) return structuredClone(d) as Settings[K];
  return (typeof d === "object" ? { ...(d as object), ...(row.value as object) } : row.value) as Settings[K];
}

export function businessAddress(b: Settings["business"]) {
  return [b.addressLine1, b.addressLine2, `${b.city}${b.pincode ? " " + b.pincode : ""}`, b.state, b.country]
    .filter(Boolean)
    .join(", ");
}
