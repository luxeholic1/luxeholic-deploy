import { and, eq, gte, inArray, sql } from "drizzle-orm";
import { db, schema } from "@/db";
import { getSettings } from "./settings";
import { gstPortion, formatINR } from "./money";
import { randomToken } from "./crypto";
import { notifyTeams, sendMail } from "./notify";
import { SITE_URL } from "./site";
import { productTitles } from "./i18n/content";
import { fill } from "./i18n/config";

/** Messages shown to shoppers in their language (outside a request — scripts, webhooks — English). */
async function shopperLang() {
  try {
    const { getI18n } = await import("./i18n/server");
    const i = await getI18n();
    return { t: i.t, locale: i.locale };
  } catch { return { t: fill, locale: "en" as const }; }
}

export type CartLine = { productId: string; variantId?: string | null; qty: number };
export type PayChoice = "PAYU" | "PHONEPE" | "BANK_TRANSFER" | "COD" | "PARTIAL_COD";

const code = (n: number) => Array.from({ length: n }, () => "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"[Math.floor(Math.random() * 32)]).join("");
export const newOrderNumber = () => `LX${new Date().toISOString().slice(2, 10).replace(/-/g, "")}-${code(5)}`;
export const newTxnId = (prefix: string) => `${prefix}${Date.now().toString(36).toUpperCase()}${code(4)}`;
export const newPoNumber = () => `PO-${new Date().toISOString().slice(2, 7).replace("-", "")}-${code(5)}`;

/** Re-prices a cart from the database (never trust client prices). */
export async function priceCart(lines: CartLine[], couponCode?: string | null) {
  const clean = lines.filter((l) => l.productId && l.qty > 0).slice(0, 50);
  const ids = [...new Set(clean.map((l) => l.productId))];
  const prods = ids.length
    ? await db.query.products.findMany({ where: inArray(schema.products.id, ids), with: { variants: true, vendor: true } })
    : [];
  const settings = await getSettings();
  const { t, locale } = await shopperLang();
  const names = await productTitles(ids, locale);
  const nm = (p: { id: string; title: string }) => names.get(p.id) ?? p.title;
  const problems: string[] = [];
  const items = clean.flatMap((l) => {
    const p = prods.find((x) => x.id === l.productId);
    if (!p || p.status !== "ACTIVE") { problems.push(t("An item in your bag is no longer available.")); return []; }
    const v = l.variantId ? p.variants.find((x) => x.id === l.variantId) : null;
    if (l.variantId && !v) { problems.push(t("{title}: selected option is unavailable.", { title: nm(p) })); return []; }
    const stock = v ? v.stock : p.stock;
    const qty = Math.min(l.qty, 10);
    if (stock < qty) { problems.push(stock > 0 ? t("Only {n} left of {title}.", { n: stock, title: nm(p) }) : t("{title} just sold out.", { title: nm(p) })); if (stock <= 0) return []; }
    const unit = v?.price ?? p.price;
    return [{
      productId: p.id, variantId: v?.id ?? null, title: p.title, variant: v?.name ?? null, sku: v?.sku ?? p.sku,
      image: p.images[0] ?? null, unitPrice: unit, quantity: Math.min(qty, stock), slug: p.slug,
      gstPercent: p.vendor?.gstPercent ?? 18, vendorId: p.vendorId, vendorSku: v?.vendorSku ?? p.vendorSku, costAmount: p.costAmount,
      deliveryDays: p.dispatchDays + p.deliveryDays,
    }];
  });
  const subtotal = items.reduce((s, i) => s + i.unitPrice * i.quantity, 0);

  let discount = 0;
  let coupon: typeof schema.coupons.$inferSelect | undefined;
  if (couponCode) {
    [coupon] = await db.select().from(schema.coupons).where(eq(schema.coupons.code, couponCode.trim().toUpperCase()));
    const now = new Date();
    const valid = coupon && coupon.active && (!coupon.startsAt || coupon.startsAt <= now) && (!coupon.endsAt || coupon.endsAt >= now)
      && (coupon.maxUses == null || coupon.usedCount < coupon.maxUses) && subtotal >= coupon.minSubtotal;
    if (!valid) { problems.push(t("That coupon isn't valid for this bag.")); coupon = undefined; }
    else discount = Math.min(subtotal, coupon!.percentOff ? Math.round((subtotal * coupon!.percentOff) / 100) : coupon!.amountOff ?? 0);
  }
  const ship = settings.shipping;
  const shippingFee = subtotal === 0 || ship.freeAbove === 0 || subtotal - discount >= ship.freeAbove ? 0 : ship.flatFee;
  const total = subtotal - discount + shippingFee;
  const taxIncluded = items.reduce((s, i) => s + gstPortion(Math.round(i.unitPrice * i.quantity * (subtotal ? (subtotal - discount) / subtotal : 1)), i.gstPercent), 0);
  const maxDays = items.reduce((m, i) => Math.max(m, i.deliveryDays), 0);
  return { items, subtotal, discount, coupon: coupon?.code ?? null, shippingFee, total, taxIncluded, problems, maxDays };
}

export function paymentOptions(total: number, s: Awaited<ReturnType<typeof getSettings>>["payments"]) {
  return {
    PAYU: s.payu && Boolean(process.env.PAYU_KEY),
    PHONEPE: s.phonepe && Boolean(process.env.PHONEPE_CLIENT_ID),
    BANK_TRANSFER: s.bankTransfer,
    COD: s.cod && total <= s.codMaxOrder,
    PARTIAL_COD: s.partialCod && total <= s.partialCodMaxOrder && Boolean(process.env.PAYU_KEY || process.env.PHONEPE_CLIENT_ID),
  } satisfies Record<PayChoice, boolean>;
}

/** Atomically reserve stock; throws if anything sold out in the meantime. */
async function reserve(tx: Parameters<Parameters<typeof db.transaction>[0]>[0], items: Awaited<ReturnType<typeof priceCart>>["items"]) {
  for (const i of items) {
    const t = i.variantId ? schema.productVariants : schema.products;
    const r = await tx.update(t).set({ stock: sql`${t.stock} - ${i.quantity}` })
      .where(and(eq(t.id, (i.variantId ?? i.productId)!), gte(t.stock, i.quantity))).returning({ id: t.id });
    if (!r.length) { const { t, locale } = await shopperLang(); const n = (await productTitles([i.productId], locale)).get(i.productId); throw new Error(t("{title} just sold out.", { title: n ?? i.title })); }
    if (i.variantId) await tx.update(schema.products).set({ stock: sql`greatest(${schema.products.stock} - ${i.quantity}, 0)` }).where(eq(schema.products.id, i.productId));
  }
}

export async function restock(orderId: string) {
  const items = await db.select().from(schema.orderItems).where(eq(schema.orderItems.orderId, orderId));
  for (const i of items) {
    if (i.variantId) await db.update(schema.productVariants).set({ stock: sql`${schema.productVariants.stock} + ${i.quantity}` }).where(eq(schema.productVariants.id, i.variantId));
    if (i.productId) await db.update(schema.products).set({ stock: sql`${schema.products.stock} + ${i.quantity}` }).where(eq(schema.products.id, i.productId));
  }
}

export async function createOrder(input: {
  lines: CartLine[]; coupon?: string | null; method: PayChoice; customerId: string | null;
  email: string; phone: string; shipping: schema.AddressJson; billing?: schema.AddressJson | null; gstin?: string | null; notes?: string | null;
}) {
  const priced = await priceCart(input.lines, input.coupon);
  const { t } = await shopperLang();
  if (!priced.items.length) throw new Error(priced.problems[0] ?? t("Your bag is empty."));
  const settings = await getSettings();
  const opts = paymentOptions(priced.total, settings.payments);
  if (!opts[input.method]) throw new Error(t("That payment method isn't available for this order."));
  const codFee = input.method === "COD" || input.method === "PARTIAL_COD" ? settings.payments.codFee : 0;
  const total = priced.total + codFee;
  const advanceDue = input.method === "PARTIAL_COD" ? Math.ceil((total * settings.payments.advancePercent) / 100 / 100) * 100 : 0;

  const order = await db.transaction(async (tx) => {
    await reserve(tx, priced.items);
    const [o] = await tx.insert(schema.orders).values({
      number: newOrderNumber(), customerId: input.customerId, isGuest: !input.customerId, accessToken: randomToken(18),
      email: input.email.toLowerCase(), phone: input.phone, shippingAddress: input.shipping, billingAddress: input.billing ?? null,
      gstin: input.gstin || null, subtotal: priced.subtotal, shippingFee: priced.shippingFee, codFee, discount: priced.discount,
      couponCode: priced.coupon, taxIncluded: priced.taxIncluded, total, paymentMethod: input.method, advanceDue, notes: input.notes || null,
      paymentStatus: "PENDING", status: "PENDING",
    }).returning();
    await tx.insert(schema.orderItems).values(priced.items.map((i) => ({
      orderId: o.id, productId: i.productId, variantId: i.variantId, title: i.title, variant: i.variant, sku: i.sku,
      image: i.image, unitPrice: i.unitPrice, quantity: i.quantity, gstPercent: i.gstPercent,
    })));
    if (priced.coupon) await tx.update(schema.coupons).set({ usedCount: sql`${schema.coupons.usedCount} + 1` }).where(eq(schema.coupons.code, priced.coupon));
    return o;
  });

  if (input.method === "COD" || input.method === "BANK_TRANSFER") await onOrderPlaced(order.id);
  return order;
}

/** Creates the pending payment row an online gateway will settle. */
export async function startPayment(orderId: string, provider: "PAYU" | "PHONEPE") {
  const [o] = await db.select().from(schema.orders).where(eq(schema.orders.id, orderId));
  if (!o) throw new Error("Order not found");
  const purpose = o.paymentMethod === "PARTIAL_COD" ? "ADVANCE" : "FULL";
  const amount = purpose === "ADVANCE" ? o.advanceDue : o.total - o.amountPaid;
  const txnId = newTxnId(provider === "PAYU" ? "PU" : "PP");
  await db.insert(schema.payments).values({ orderId, provider, txnId, amount, purpose, status: "PENDING" });
  return { order: o, txnId, amount };
}

/** Gateway confirmed money received. Idempotent. */
export async function settlePayment(txnId: string, ok: boolean, amountPaise: number | null, providerRef: string | null, raw: unknown) {
  const [p] = await db.select().from(schema.payments).where(eq(schema.payments.txnId, txnId));
  if (!p) return null;
  const [order] = await db.select().from(schema.orders).where(eq(schema.orders.id, p.orderId));
  if (p.status === "PAID" || p.status === "FAILED") return order;
  if (ok && amountPaise !== null && amountPaise < p.amount) ok = false; // underpaid / tampered
  await db.update(schema.payments).set({ status: ok ? "PAID" : "FAILED", providerRef, raw: raw as never }).where(eq(schema.payments.id, p.id));
  if (!ok) {
    await db.update(schema.orders).set({ paymentStatus: "FAILED" }).where(eq(schema.orders.id, order.id));
    return { ...order, paymentStatus: "FAILED" as const };
  }
  const amountPaid = order.amountPaid + p.amount;
  const paymentStatus = amountPaid >= order.total ? "PAID" : "PARTIALLY_PAID";
  const [updated] = await db.update(schema.orders)
    .set({ amountPaid, paymentStatus, status: order.status === "PENDING" ? "CONFIRMED" : order.status })
    .where(eq(schema.orders.id, order.id)).returning();
  await onOrderPlaced(order.id);
  return updated;
}

/** Side effects once an order is real: emails, team alerts, vendor routing. */
export async function onOrderPlaced(orderId: string) {
  const o = await db.query.orders.findFirst({ where: eq(schema.orders.id, orderId), with: { items: true } });
  if (!o) return;
  const url = `${SITE_URL}/order/${o.number}?t=${o.accessToken}`;
  const lines = o.items.map((i) => `${i.title}${i.variant ? ` (${i.variant})` : ""} × ${i.quantity} — ${formatINR(i.unitPrice * i.quantity)}`).join("<br>");
  const payLine = {
    PAYU: "Paid online", PHONEPE: "Paid via PhonePe", COD: "Cash on delivery — our team will call to confirm.",
    BANK_TRANSFER: "Awaiting bank transfer — details are on your order page.",
    PARTIAL_COD: `Advance ${formatINR(o.amountPaid)} received · ${formatINR(o.total - o.amountPaid)} payable on delivery`,
  }[o.paymentMethod];
  await sendMail(o.email, `Your Luxeholic order ${o.number}`, "Thank you — your piece is on its way to you.",
    `Order <b>${o.number}</b><br><br>${lines}<br><br>Total: <b>${formatINR(o.total)}</b><br>${payLine}`, { label: "View order", url });
  await notifyTeams(["sales"], `New order ${o.number} · ${formatINR(o.total)}`, `${o.paymentMethod.replace("_", " ")} · ${o.email}`, `/team/orders/${o.id}`);
  if (o.paymentStatus === "PAID" || o.paymentStatus === "PARTIALLY_PAID") await routeToVendors(o.id);
}

/**
 * Dropship routing: group the order's items by vendor and open a DRAFT purchase order for each
 * vendor that has auto-routing on. Procurement reviews and places it (one click for SunSky API).
 */
export async function routeToVendors(orderId: string) {
  const existing = await db.select({ id: schema.purchaseOrders.id }).from(schema.purchaseOrders).where(eq(schema.purchaseOrders.orderId, orderId));
  if (existing.length) return;
  const items = await db.query.orderItems.findMany({ where: eq(schema.orderItems.orderId, orderId), with: { product: { with: { vendor: true, variants: true } } } });
  const [order] = await db.select().from(schema.orders).where(eq(schema.orders.id, orderId));
  const settings = await getSettings();
  const byVendor = new Map<string, typeof items>();
  for (const i of items) {
    const v = i.product?.vendor;
    if (!v || !v.autoRouteOrders || !v.active) continue;
    byVendor.set(v.id, [...(byVendor.get(v.id) ?? []), i]);
  }
  for (const [vendorId, list] of byVendor) {
    const vendor = list[0].product!.vendor!;
    const rate = vendor.currency === "INR" ? 1 : settings.fx[vendor.currency] ?? 0;
    const poItems = list.map((i) => ({
      productId: i.productId, title: `${i.title}${i.variant ? ` (${i.variant})` : ""}`,
      vendorSku: i.product?.variants.find((v) => v.id === i.variantId)?.vendorSku ?? i.product?.vendorSku ?? i.sku,
      quantity: i.quantity, unitCost: Math.round((i.product?.costAmount ?? 0) * rate),
    }));
    const [po] = await db.insert(schema.purchaseOrders).values({
      number: newPoNumber(), vendorId, orderId, status: "DRAFT",
      totalCost: poItems.reduce((s, x) => s + x.unitCost * x.quantity, 0),
      notes: `Dropship for customer order ${order.number}. Ship to customer address.`,
    }).returning();
    await db.insert(schema.purchaseOrderItems).values(poItems.map((x) => ({ ...x, poId: po.id })));
    await notifyTeams(["procurement"], `Place ${vendor.name} order for ${order.number}`, `${poItems.length} item(s) · PO ${po.number}`, `/team/purchase-orders/${po.id}`);
  }
}
