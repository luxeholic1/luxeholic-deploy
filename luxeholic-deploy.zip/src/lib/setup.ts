/**
 * First-run setup, safe to run on every start:
 *  1. applies database migrations (drizzle/), under a lock so several server processes can't race;
 *  2. creates the essentials once — teams, super admin, category tree, vendors;
 *  3. adds Hindi for the catalogue, hero and site texts.
 * Runs automatically when the server starts (src/instrumentation.ts) — nothing to run by hand on cPanel.
 * Turn off with AUTO_SETUP=0.
 */
import path from "node:path";
import { writeFileSync } from "node:fs";
import { eq, sql } from "drizzle-orm";
import { db, schema } from "@/db";
import { CATALOG_TREE } from "@/lib/catalog-tree";
import { DEFAULT_TEAM_MODULES } from "@/lib/rbac";
import { hashPassword } from "@/lib/auth";
import { tempPassword } from "@/lib/crypto";
import { SUPER_ADMIN_EMAIL } from "@/lib/site";

export const TEAMS = [
  { slug: "sales", name: "Sales", color: "#A8834A", description: "Orders, COD confirmation, customer relationships" },
  { slug: "marketing", name: "Marketing", color: "#8C5A6E", description: "Campaigns, coupons, Merchant Center & ads" },
  { slug: "procurement", name: "Procurement", color: "#4F6B5A", description: "Purchase orders and vendor ordering" },
  { slug: "inventory", name: "Inventory", color: "#5B6A86", description: "Catalogue, stock, pricing & publishing" },
  { slug: "tech-support", name: "Tech Support", color: "#7A6A55", description: "Customer tickets, site & sync health" },
  { slug: "alliances", name: "Alliances", color: "#3E5C6B", description: "OEMs & vendors — SunSky, BrandsGateway, new partners" },
];

export async function migrateDb() {
  const url = process.env.DATABASE_URL ?? "";
  const migrationsFolder = path.join(process.cwd(), "drizzle");
  if (url.startsWith("pglite:")) {
    const { migrate } = await import("drizzle-orm/pglite/migrator");
    await migrate(db as never, { migrationsFolder });
    return;
  }
  const { migrate } = await import("drizzle-orm/node-postgres/migrator");
  await db.execute(sql`select pg_advisory_lock(7531902)`);
  try { await migrate(db, { migrationsFolder }); }
  finally { await db.execute(sql`select pg_advisory_unlock(7531902)`); }
}

export async function seedEssentials() {
  const console = { log: (m: string) => log(m) };

  // Teams
  for (const [i, t] of TEAMS.entries()) {
    await db.insert(schema.teams).values({ ...t, sortOrder: i, modules: DEFAULT_TEAM_MODULES[t.slug] as never })
      .onConflictDoNothing({ target: schema.teams.slug });
  }
  console.log("✓ teams");

  // Super admin
  const [existing] = await db.select().from(schema.staff).where(eq(schema.staff.email, SUPER_ADMIN_EMAIL));
  if (!existing) {
    const pw = process.env.SUPER_ADMIN_PASSWORD || tempPassword();
    await db.insert(schema.staff).values({ name: "Super Admin", email: SUPER_ADMIN_EMAIL, passwordHash: await hashPassword(pw), role: "SUPER_ADMIN", mustChangePassword: process.env.LOCAL_PREVIEW !== "1" });
    console.log(`✓ super admin ${SUPER_ADMIN_EMAIL}  temporary password: ${pw}${process.env.LOCAL_PREVIEW === "1" ? "" : "  (you'll be asked to change it)"}`);
    if (!process.env.SUPER_ADMIN_PASSWORD) {
      // cPanel: the owner can read this in File Manager (it's outside public_html), then delete it.
      try { writeFileSync(path.join(process.cwd(), "FIRST-LOGIN.txt"), `Team login: /team/login\nEmail: ${SUPER_ADMIN_EMAIL}\nTemporary password: ${pw}\nYou'll be asked to set your own password. Delete this file afterwards.\n`, { mode: 0o600 }); } catch { /* read-only disk */ }
    }
  } else console.log("✓ super admin exists");

  // Categories
  let order = 0;
  for (const p of CATALOG_TREE) {
    const [parent] = await db.insert(schema.categories).values({
      name: p.name, slug: p.slug, tagline: p.tagline, googleCategory: p.google, isApparel: !!p.apparel, defaultVendorSlug: p.vendor, sortOrder: order++,
    }).onConflictDoUpdate({ target: schema.categories.slug, set: { googleCategory: p.google } }).returning();
    for (const [j, c] of (p.children ?? []).entries()) {
      await db.insert(schema.categories).values({
        name: c.name, slug: c.slug, parentId: parent.id, googleCategory: c.google, isApparel: !!c.apparel, defaultVendorSlug: p.vendor, sortOrder: j,
      }).onConflictDoUpdate({ target: schema.categories.slug, set: { googleCategory: c.google, parentId: parent.id } });
    }
  }
  await db.insert(schema.categories).values({ name: "Needs review", slug: "needs-review", active: false, sortOrder: 999, description: "Synced products the auto-sorter couldn't place. Move them to a real category." })
    .onConflictDoNothing({ target: schema.categories.slug });
  console.log("✓ categories");

  // Vendors
  await db.insert(schema.vendors).values([
    {
      name: "SunSky", slug: "sunsky", type: "SUNSKY", website: "https://www.sunsky-online.com/", apiBaseUrl: "https://open.sunsky-online.com/openapi",
      currency: "USD", markupPercent: 120, dutyPercent: 20, gstPercent: 18, shippingFlat: 45000, dispatchDays: 3, deliveryDays: 15,
      notes: "Art & Sculpture, Home Décor, Lux-Tech. API key/secret from your SunSky sales manager.",
      config: { autoPublish: false, maxItems: 1500 },
    },
    {
      name: "BrandsGateway", slug: "brandsgateway", type: "BRANDSGATEWAY", website: "https://app.brandsgateway.com/",
      currency: "EUR", markupPercent: 45, dutyPercent: 25, gstPercent: 12, shippingFlat: 150000, dispatchDays: 3, deliveryDays: 12,
      notes: "Designer Fashion and Gifting & Accessories. Paste the custom-store product feed URL from the BrandsGateway app.",
      config: { autoPublish: false, maxItems: 3000 },
    },
  ]).onConflictDoNothing({ target: schema.vendors.slug });
  console.log("✓ vendors");

}

function log(m: string) { console.log(`[setup] ${m}`); }

let started: Promise<void> | null = null;
export function firstRun() {
  started ??= (async () => {
    if (!process.env.DATABASE_URL) { log("DATABASE_URL is not set — skipping setup"); return; }
    await migrateDb(); log("✓ database up to date");
    const [any] = await db.select({ id: schema.staff.id }).from(schema.staff).limit(1);
    if (!any) await seedEssentials();
    const { seedHindi } = await import("@/lib/i18n/seed-hi");
    await seedHindi(log);
  })();
  return started;
}
