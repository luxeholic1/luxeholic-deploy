/** Calendar helpers. The business runs on IST, so "today" is the Indian calendar day. */
export const TZ = "Asia/Kolkata";

export function ymd(d: Date = new Date()) {
  return new Intl.DateTimeFormat("en-CA", { timeZone: TZ, year: "numeric", month: "2-digit", day: "2-digit" }).format(d);
}
export const todayIST = () => ymd(new Date());

/** Pure date arithmetic on "YYYY-MM-DD" strings (UTC noon avoids DST edge cases). */
export function addDays(day: string, n: number) {
  const d = new Date(`${day}T12:00:00Z`);
  d.setUTCDate(d.getUTCDate() + n);
  return d.toISOString().slice(0, 10);
}
export const weekday = (day: string) => new Date(`${day}T12:00:00Z`).getUTCDay(); // 0 = Sun
export const dayOfMonth = (day: string) => Number(day.slice(8, 10));

export function eachDay(from: string, to: string) {
  const out: string[] = [];
  for (let d = from; d <= to; d = addDays(d, 1)) out.push(d);
  return out;
}

/** 6-week grid (Mon-first) for a month "YYYY-MM". */
export function monthGrid(month: string) {
  const first = `${month}-01`;
  const offset = (weekday(first) + 6) % 7;
  const start = addDays(first, -offset);
  return Array.from({ length: 42 }, (_, i) => addDays(start, i));
}
export function shiftMonth(month: string, n: number) {
  const [y, m] = month.split("-").map(Number);
  const d = new Date(Date.UTC(y, m - 1 + n, 1));
  return d.toISOString().slice(0, 7);
}

export function prettyDay(day: string, opts: Intl.DateTimeFormatOptions = { day: "numeric", month: "short", weekday: "short" }, intl = "en-IN") {
  return new Date(`${day}T12:00:00Z`).toLocaleDateString(intl, { ...opts, timeZone: "UTC" });
}
export function prettyDateTime(d: Date | string, intl = "en-IN") {
  return new Date(d).toLocaleString(intl, { timeZone: TZ, day: "numeric", month: "short", year: "numeric", hour: "numeric", minute: "2-digit" });
}
export function monthLabel(month: string) {
  return new Date(`${month}-01T12:00:00Z`).toLocaleDateString("en-IN", { month: "long", year: "numeric", timeZone: "UTC" });
}
