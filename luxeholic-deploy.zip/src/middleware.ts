import { NextResponse, type NextRequest } from "next/server";
import { CUR_COOKIE, LANG_COOKIE, isCurrency, isLocale, marketFor } from "@/lib/i18n/config";

/**
 * First visit: language and currency come from the domain (luxeholic.in → English/INR, hi.luxeholic.in → Hindi,
 * luxeholic.com → USD…). After that the visitor's own choice (cookies) wins on every page.
 * Links like /?lang=hi&cur=USD set the choice and redirect to the clean URL (used in emails and ads).
 */
export function middleware(req: NextRequest) {
  const year = { path: "/", maxAge: 60 * 60 * 24 * 365, sameSite: "lax" as const };
  const qLang = req.nextUrl.searchParams.get("lang"), qCur = req.nextUrl.searchParams.get("cur");
  if (qLang !== null || qCur !== null) {
    const url = req.nextUrl.clone(); url.searchParams.delete("lang"); url.searchParams.delete("cur");
    const res = NextResponse.redirect(url);
    if (isLocale(qLang)) res.cookies.set(LANG_COOKIE, qLang, year);
    if (isCurrency(qCur?.toUpperCase())) res.cookies.set(CUR_COOKIE, qCur!.toUpperCase(), year);
    return res;
  }
  const m = marketFor(req.headers.get("x-forwarded-host") ?? req.headers.get("host"));
  const set: [string, string][] = [];
  if (!isLocale(req.cookies.get(LANG_COOKIE)?.value)) set.push([LANG_COOKIE, m.locale]);
  if (!isCurrency(req.cookies.get(CUR_COOKIE)?.value)) set.push([CUR_COOKIE, m.currency]);
  if (!set.length) return NextResponse.next();
  // Make the very first render use the domain's language too (the request carries the new cookies).
  for (const [k, v] of set) req.cookies.set(k, v);
  const res = NextResponse.next({ request: { headers: req.headers } });
  for (const [k, v] of set) res.cookies.set(k, v, year);
  return res;
}
export const config = { matcher: ["/((?!api|_next|team|feed|u/|media|brand|favicon|icon|apple-icon|manifest|robots|sitemap).*)"] };
