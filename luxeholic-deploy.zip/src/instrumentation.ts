/** Runs once when the server starts: migrations + first-run setup (see src/lib/setup.ts). */
export async function register() {
  if (process.env.NEXT_RUNTIME === "nodejs") {
    if (process.env.AUTO_SETUP === "0" || process.env.NEXT_PHASE === "phase-production-build") return;
    const { firstRun } = await import("./lib/setup");
    await firstRun().catch((e: unknown) => console.error("[setup] failed:", e));
  }
}
