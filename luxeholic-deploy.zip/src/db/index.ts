import { drizzle as drizzlePg, type NodePgDatabase } from "drizzle-orm/node-postgres";
import { Pool } from "pg";
import * as schema from "./schema";

/**
 * DATABASE_URL="postgresql://…"      → real PostgreSQL (production)
 * DATABASE_URL="pglite:./.localdb"   → embedded Postgres in a local folder (zero-install local preview)
 */
type DB = NodePgDatabase<typeof schema>;
const g = globalThis as unknown as { __db?: DB };
const url = process.env.DATABASE_URL ?? "";

function create(): DB {
  if (url.startsWith("pglite:")) {
    // eslint-disable-next-line @typescript-eslint/no-require-imports
    const { PGlite } = require("@electric-sql/pglite");
    // eslint-disable-next-line @typescript-eslint/no-require-imports
    const { drizzle } = require("drizzle-orm/pglite");
    return drizzle(new PGlite(url.slice("pglite:".length) || "./.localdb"), { schema }) as DB;
  }
  const pool = new Pool({ connectionString: url, max: Number(process.env.DB_POOL_MAX ?? 10) });
  return drizzlePg(pool, { schema });
}

/** Opened on first use, so `next build` (which imports pages but never queries during static analysis) doesn't open the database. */
function get(): DB { return (g.__db ??= create()); }
export const db: DB = new Proxy({} as DB, {
  get(_t, k) { const d = get() as unknown as Record<PropertyKey, unknown>; const v = d[k]; return typeof v === "function" ? (v as (...a: unknown[]) => unknown).bind(d) : v; },
});
export { schema };
