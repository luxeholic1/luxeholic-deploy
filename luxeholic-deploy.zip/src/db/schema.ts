/**
 * Luxeholic data model (Drizzle ORM / PostgreSQL)
 * Storefront: customers, catalog, orders, payments, coupons
 * Operations: vendors (SunSky, BrandsGateway, any new vendor), purchase orders, sync logs
 * Workspace: teams, staff, tasks + calendar + daily recurring to-dos, notifications, audit log
 *
 * Money is stored as integer paise (₹1 = 100) to avoid floating point errors.
 */
import {
  pgTable, pgEnum, text, integer, boolean, timestamp, jsonb, real, primaryKey,
  uniqueIndex, index, date,
} from "drizzle-orm/pg-core";
import { relations } from "drizzle-orm";
import { randomBytes } from "crypto";

export const newId = () => randomBytes(12).toString("base64url");
const id = () => text("id").primaryKey().$defaultFn(newId);
const createdAt = () => timestamp("created_at", { withTimezone: true }).notNull().defaultNow();
const updatedAt = () =>
  timestamp("updated_at", { withTimezone: true }).notNull().defaultNow().$onUpdate(() => new Date());

// ─────────────── Enums ───────────────
export const staffRole = pgEnum("staff_role", ["SUPER_ADMIN", "TEAM_LEAD", "MEMBER"]);
export const productStatus = pgEnum("product_status", ["DRAFT", "ACTIVE", "ARCHIVED"]);
export const vendorType = pgEnum("vendor_type", ["SUNSKY", "BRANDSGATEWAY", "CSV_FEED", "MANUAL"]);
export const poStatus = pgEnum("po_status", ["DRAFT", "SENT", "CONFIRMED", "SHIPPED", "RECEIVED", "CANCELLED"]);
export const orderStatus = pgEnum("order_status", [
  "PENDING", "CONFIRMED", "PROCESSING", "SHIPPED", "DELIVERED", "CANCELLED", "RETURN_REQUESTED", "RETURNED",
]);
export const paymentMethod = pgEnum("payment_method", ["PAYU", "PHONEPE", "BANK_TRANSFER", "COD", "PARTIAL_COD"]);
export const paymentStatus = pgEnum("payment_status", [
  "PENDING", "AWAITING_VERIFICATION", "PARTIALLY_PAID", "PAID", "FAILED", "REFUNDED",
]);
export const ticketStatus = pgEnum("ticket_status", ["OPEN", "IN_PROGRESS", "WAITING_CUSTOMER", "RESOLVED"]);
export const taskStatus = pgEnum("task_status", ["TODO", "IN_PROGRESS", "BLOCKED", "DONE"]);
export const callbackStatus = pgEnum("callback_status", ["NEW", "CALLED", "CLOSED"]);
export const taskPriority = pgEnum("task_priority", ["LOW", "MEDIUM", "HIGH", "URGENT"]);
export const recurrence = pgEnum("recurrence", ["NONE", "DAILY", "WEEKDAYS", "WEEKLY", "MONTHLY"]);

// ─────────────── People ───────────────
export const teams = pgTable("teams", {
  id: id(),
  slug: text("slug").notNull().unique(),
  name: text("name").notNull(),
  description: text("description"),
  color: text("color").notNull().default("#B8955A"),
  sortOrder: integer("sort_order").notNull().default(0),
  // Panel access for this team, editable by the super admin: { orders: "write", products: "read", ... }
  modules: jsonb("modules").$type<Record<string, "read" | "write">>().notNull().default({}),
  createdAt: createdAt(),
});

export const staff = pgTable("staff", {
  id: id(),
  name: text("name").notNull(),
  email: text("email").notNull().unique(),
  phone: text("phone"),
  passwordHash: text("password_hash").notNull(),
  role: staffRole("role").notNull().default("MEMBER"),
  teamId: text("team_id").references(() => teams.id),
  active: boolean("active").notNull().default(true),
  mustChangePassword: boolean("must_change_password").notNull().default(true),
  sessionVersion: integer("session_version").notNull().default(1), // bump to force logout
  lastLoginAt: timestamp("last_login_at", { withTimezone: true }),
  createdAt: createdAt(),
  updatedAt: updatedAt(),
});

export const customers = pgTable("customers", {
  id: id(),
  name: text("name").notNull(),
  email: text("email").notNull().unique(),
  phone: text("phone"),
  passwordHash: text("password_hash").notNull(),
  marketingOptIn: boolean("marketing_opt_in").notNull().default(false),
  createdAt: createdAt(),
  updatedAt: updatedAt(),
});

export const addresses = pgTable("addresses", {
  id: id(),
  customerId: text("customer_id").notNull().references(() => customers.id, { onDelete: "cascade" }),
  name: text("name").notNull(),
  phone: text("phone").notNull(),
  line1: text("line1").notNull(),
  line2: text("line2"),
  city: text("city").notNull(),
  state: text("state").notNull(),
  pincode: text("pincode").notNull(),
  country: text("country").notNull().default("IN"),
  isDefault: boolean("is_default").notNull().default(false),
  createdAt: createdAt(),
});

// ─────────────── Catalog ───────────────
export type VendorConfig = {
  autoPublish?: boolean;          // publish new synced products immediately (needs category + image + stock)
  maxItems?: number;              // cap per sync run
  categoryMap?: Record<string, string>; // vendor category / keyword (lowercase) -> our category slug
  sunskyCategoryIds?: string[];   // which SunSky categories to import
  methods?: Record<string, string>; // API method path overrides
  minCost?: number; maxCost?: number; // import only items within cost range (vendor currency, major units)
  brandsAllow?: string[];         // only these brands (BrandsGateway and SunSky)
  keywords?: string[];            // SunSky: only items whose title/category matches one of these words
  searchParams?: { keyword?: string; brand?: string }; // SunSky search parameter names, if SunSky renames them
};
export const categories = pgTable("categories", {
  id: id(),
  name: text("name").notNull(),
  slug: text("slug").notNull().unique(),
  tagline: text("tagline"),
  description: text("description"),
  image: text("image"),
  parentId: text("parent_id"),
  sortOrder: integer("sort_order").notNull().default(0),
  googleCategory: text("google_category"), // Google product taxonomy path for the Merchant feed
  isApparel: boolean("is_apparel").notNull().default(false),
  defaultVendorSlug: text("default_vendor_slug"),
  active: boolean("active").notNull().default(true),
  createdAt: createdAt(),
}, (t) => [index("categories_parent_idx").on(t.parentId)]);

export const vendors = pgTable("vendors", {
  id: id(),
  name: text("name").notNull(),
  slug: text("slug").notNull().unique(),
  type: vendorType("type").notNull(),
  website: text("website"),
  apiBaseUrl: text("api_base_url"),
  feedUrl: text("feed_url"),
  credentialsEnc: text("credentials_enc"), // AES-256-GCM encrypted JSON (API keys / passwords)
  // Non-secret options: category mapping, auto-publish, max items, SunSky category ids, API method overrides
  config: jsonb("config").$type<VendorConfig>().notNull().default({}),
  currency: text("currency").notNull().default("USD"),
  markupPercent: real("markup_percent").notNull().default(60),
  dutyPercent: real("duty_percent").notNull().default(0),
  gstPercent: real("gst_percent").notNull().default(18),
  shippingFlat: integer("shipping_flat").notNull().default(0), // paise per unit
  dispatchDays: integer("dispatch_days").notNull().default(3),
  deliveryDays: integer("delivery_days").notNull().default(12),
  contactName: text("contact_name"),
  contactEmail: text("contact_email"),
  contactPhone: text("contact_phone"),
  notes: text("notes"),
  active: boolean("active").notNull().default(true),
  autoRouteOrders: boolean("auto_route_orders").notNull().default(true),
  lastSyncAt: timestamp("last_sync_at", { withTimezone: true }),
  createdAt: createdAt(),
  updatedAt: updatedAt(),
});

export const products = pgTable("products", {
  id: id(),
  slug: text("slug").notNull().unique(),
  title: text("title").notNull(),
  shortDescription: text("short_description"),
  description: text("description").notNull(),
  brand: text("brand").notNull().default("Luxeholic"),
  gtin: text("gtin"),
  mpn: text("mpn"),
  sku: text("sku").notNull().unique(),
  vendorId: text("vendor_id").references(() => vendors.id),
  vendorSku: text("vendor_sku"),
  categoryId: text("category_id").notNull().references(() => categories.id),
  costAmount: integer("cost_amount").notNull().default(0), // vendor currency minor units
  costCurrency: text("cost_currency").notNull().default("INR"),
  price: integer("price").notNull(), // INR paise, GST inclusive
  compareAtPrice: integer("compare_at_price"),
  priceLocked: boolean("price_locked").notNull().default(false),
  stock: integer("stock").notNull().default(0),
  status: productStatus("status").notNull().default("DRAFT"),
  images: jsonb("images").$type<string[]>().notNull().default([]),
  material: text("material"),
  color: text("color"),
  size: text("size"),
  gender: text("gender"), // male | female | unisex
  ageGroup: text("age_group"), // adult
  weightGrams: integer("weight_grams"),
  dispatchDays: integer("dispatch_days").notNull().default(3),
  deliveryDays: integer("delivery_days").notNull().default(7),
  isFeatured: boolean("is_featured").notNull().default(false),
  isNewArrival: boolean("is_new_arrival").notNull().default(true),
  tags: jsonb("tags").$type<string[]>().notNull().default([]),
  seoTitle: text("seo_title"),
  seoDescription: text("seo_description"),
  // This product's own listings on marketplaces: { amazon, flipkart, blinkit, walmart }
  marketplaceLinks: jsonb("marketplace_links").$type<Record<string, string>>().notNull().default({}),
  lastSyncedAt: timestamp("last_synced_at", { withTimezone: true }),
  createdAt: createdAt(),
  updatedAt: updatedAt(),
}, (t) => [
  uniqueIndex("products_vendor_sku_uq").on(t.vendorId, t.vendorSku),
  index("products_cat_status_idx").on(t.categoryId, t.status),
  index("products_status_price_idx").on(t.status, t.price),
]);

export const productVariants = pgTable("product_variants", {
  id: id(),
  productId: text("product_id").notNull().references(() => products.id, { onDelete: "cascade" }),
  sku: text("sku").notNull().unique(),
  vendorSku: text("vendor_sku"),
  name: text("name").notNull(),
  size: text("size"),
  color: text("color"),
  price: integer("price"),
  stock: integer("stock").notNull().default(0),
  gtin: text("gtin"),
});

export const wishlist = pgTable("wishlist", {
  customerId: text("customer_id").notNull().references(() => customers.id, { onDelete: "cascade" }),
  productId: text("product_id").notNull().references(() => products.id, { onDelete: "cascade" }),
  createdAt: createdAt(),
}, (t) => [primaryKey({ columns: [t.customerId, t.productId] })]);

export const syncLogs = pgTable("sync_logs", {
  id: id(),
  vendorId: text("vendor_id").notNull().references(() => vendors.id, { onDelete: "cascade" }),
  kind: text("kind").notNull(),
  ok: boolean("ok").notNull(),
  created: integer("created").notNull().default(0),
  updated: integer("updated").notNull().default(0),
  deactivated: integer("deactivated").notNull().default(0),
  message: text("message"),
  startedAt: timestamp("started_at", { withTimezone: true }).notNull().defaultNow(),
  finishedAt: timestamp("finished_at", { withTimezone: true }),
});

// ─────────────── Orders & payments ───────────────
export type AddressJson = {
  name: string; phone: string; line1: string; line2?: string | null;
  city: string; state: string; pincode: string; country: string;
};

export const orders = pgTable("orders", {
  id: id(),
  number: text("number").notNull().unique(),
  customerId: text("customer_id").references(() => customers.id),
  isGuest: boolean("is_guest").notNull().default(false),
  accessToken: text("access_token").notNull().unique(),
  email: text("email").notNull(),
  phone: text("phone").notNull(),
  shippingAddress: jsonb("shipping_address").$type<AddressJson>().notNull(),
  billingAddress: jsonb("billing_address").$type<AddressJson>(),
  gstin: text("gstin"),
  subtotal: integer("subtotal").notNull(),
  shippingFee: integer("shipping_fee").notNull().default(0),
  codFee: integer("cod_fee").notNull().default(0),
  discount: integer("discount").notNull().default(0),
  couponCode: text("coupon_code"),
  taxIncluded: integer("tax_included").notNull().default(0),
  total: integer("total").notNull(),
  paymentMethod: paymentMethod("payment_method").notNull(),
  paymentStatus: paymentStatus("payment_status").notNull().default("PENDING"),
  advanceDue: integer("advance_due").notNull().default(0),
  amountPaid: integer("amount_paid").notNull().default(0),
  bankUtr: text("bank_utr"),
  status: orderStatus("status").notNull().default("PENDING"),
  courier: text("courier"),
  trackingNumber: text("tracking_number"),
  notes: text("notes"),
  internalNotes: text("internal_notes"),
  createdAt: createdAt(),
  updatedAt: updatedAt(),
}, (t) => [index("orders_status_idx").on(t.status, t.createdAt), index("orders_email_idx").on(t.email)]);

export const orderItems = pgTable("order_items", {
  id: id(),
  orderId: text("order_id").notNull().references(() => orders.id, { onDelete: "cascade" }),
  productId: text("product_id").references(() => products.id),
  variantId: text("variant_id"),
  title: text("title").notNull(),
  variant: text("variant"),
  sku: text("sku").notNull(),
  image: text("image"),
  unitPrice: integer("unit_price").notNull(),
  quantity: integer("quantity").notNull(),
  gstPercent: real("gst_percent").notNull().default(18),
});

export const payments = pgTable("payments", {
  id: id(),
  orderId: text("order_id").notNull().references(() => orders.id, { onDelete: "cascade" }),
  provider: paymentMethod("provider").notNull(),
  txnId: text("txn_id").notNull().unique(),
  amount: integer("amount").notNull(),
  purpose: text("purpose").notNull().default("FULL"), // FULL | ADVANCE | BALANCE
  status: paymentStatus("status").notNull().default("PENDING"),
  providerRef: text("provider_ref"),
  raw: jsonb("raw"),
  createdAt: createdAt(),
  updatedAt: updatedAt(),
});

export const purchaseOrders = pgTable("purchase_orders", {
  id: id(),
  number: text("number").notNull().unique(),
  vendorId: text("vendor_id").notNull().references(() => vendors.id),
  orderId: text("order_id").references(() => orders.id),
  status: poStatus("status").notNull().default("DRAFT"),
  vendorRef: text("vendor_ref"),
  trackingNumber: text("tracking_number"),
  notes: text("notes"),
  expectedDate: date("expected_date"),
  totalCost: integer("total_cost").notNull().default(0),
  createdById: text("created_by_id").references(() => staff.id),
  createdAt: createdAt(),
  updatedAt: updatedAt(),
});

export const purchaseOrderItems = pgTable("purchase_order_items", {
  id: id(),
  poId: text("po_id").notNull().references(() => purchaseOrders.id, { onDelete: "cascade" }),
  productId: text("product_id").references(() => products.id),
  title: text("title").notNull(),
  vendorSku: text("vendor_sku"),
  quantity: integer("quantity").notNull(),
  unitCost: integer("unit_cost").notNull(),
});

export const coupons = pgTable("coupons", {
  id: id(),
  code: text("code").notNull().unique(),
  description: text("description"),
  percentOff: integer("percent_off"),
  amountOff: integer("amount_off"),
  minSubtotal: integer("min_subtotal").notNull().default(0),
  maxUses: integer("max_uses"),
  usedCount: integer("used_count").notNull().default(0),
  startsAt: timestamp("starts_at", { withTimezone: true }),
  endsAt: timestamp("ends_at", { withTimezone: true }),
  active: boolean("active").notNull().default(true),
  createdAt: createdAt(),
});

export const subscribers = pgTable("subscribers", {
  id: id(),
  email: text("email").notNull().unique(),
  source: text("source").notNull().default("footer"),
  createdAt: createdAt(),
});

export type TicketReply = { by: string; staff: boolean; body: string; at: string; internal?: boolean };
export const supportTickets = pgTable("support_tickets", {
  id: id(),
  number: text("number").notNull().unique(),
  name: text("name").notNull(),
  email: text("email").notNull(),
  phone: text("phone"),
  subject: text("subject").notNull(),
  message: text("message").notNull(),
  orderNumber: text("order_number"),
  status: ticketStatus("status").notNull().default("OPEN"),
  assigneeId: text("assignee_id").references(() => staff.id),
  replies: jsonb("replies").$type<TicketReply[]>().notNull().default([]),
  createdAt: createdAt(),
  updatedAt: updatedAt(),
});

/** Translations of catalogue & site content (product titles, categories, hero…). `sourceHash` = hash of the
 *  English text it was made from, so a changed product shows as "needs update" instead of going out stale. */
export const translations = pgTable("translations", {
  entity: text("entity").notNull(),        // product | category | hero | site
  entityId: text("entity_id").notNull(),
  field: text("field").notNull(),
  locale: text("locale").notNull(),
  text: text("text").notNull(),
  sourceHash: text("source_hash").notNull(),
  source: text("source").notNull().default("manual"), // manual | auto
  updatedAt: updatedAt(),
}, (t) => [primaryKey({ columns: [t.entity, t.entityId, t.field, t.locale] })]);

export type CallbackNote = { by: string; body: string; at: string };
/** "Request a call back" from the storefront — worked by Sales. */
export const callbacks = pgTable("callbacks", {
  id: id(),
  number: text("number").notNull().unique(),
  name: text("name").notNull(),
  phone: text("phone").notNull(),
  email: text("email"),
  interest: text("interest").notNull(),
  bestTime: text("best_time").notNull(),
  city: text("city"),
  message: text("message"),
  source: text("source").notNull().default("home"),
  customerId: text("customer_id").references(() => customers.id, { onDelete: "set null" }),
  status: callbackStatus("status").notNull().default("NEW"),
  assigneeId: text("assignee_id").references(() => staff.id),
  notes: jsonb("notes").$type<CallbackNote[]>().notNull().default([]),
  createdAt: createdAt(),
  updatedAt: updatedAt(),
}, (t) => [index("callbacks_status_idx").on(t.status, t.createdAt)]);

// ─────────────── Workspace ───────────────
export const tasks = pgTable("tasks", {
  id: id(),
  title: text("title").notNull(),
  description: text("description"),
  kind: text("kind").notNull().default("TASK"), // TASK | MEETING | REMINDER
  teamId: text("team_id").references(() => teams.id),
  assigneeId: text("assignee_id").references(() => staff.id), // null = whole team
  createdById: text("created_by_id").notNull().references(() => staff.id),
  status: taskStatus("status").notNull().default("TODO"),
  priority: taskPriority("priority").notNull().default("MEDIUM"),
  dueDate: date("due_date").notNull(), // YYYY-MM-DD (IST calendar day)
  dueTime: text("due_time"),
  recurrence: recurrence("recurrence").notNull().default("NONE"),
  recurUntil: date("recur_until"),
  isTemplate: boolean("is_template").notNull().default(false),
  templateId: text("template_id"),
  completedAt: timestamp("completed_at", { withTimezone: true }),
  createdAt: createdAt(),
  updatedAt: updatedAt(),
}, (t) => [
  uniqueIndex("tasks_template_day_uq").on(t.templateId, t.dueDate),
  index("tasks_team_day_idx").on(t.teamId, t.dueDate),
  index("tasks_assignee_day_idx").on(t.assigneeId, t.dueDate),
]);

export const taskComments = pgTable("task_comments", {
  id: id(),
  taskId: text("task_id").notNull().references(() => tasks.id, { onDelete: "cascade" }),
  authorId: text("author_id").notNull().references(() => staff.id),
  body: text("body").notNull(),
  createdAt: createdAt(),
});

export const notifications = pgTable("notifications", {
  id: id(),
  staffId: text("staff_id").notNull().references(() => staff.id, { onDelete: "cascade" }),
  title: text("title").notNull(),
  body: text("body"),
  link: text("link"),
  read: boolean("read").notNull().default(false),
  createdAt: createdAt(),
}, (t) => [index("notifications_staff_idx").on(t.staffId, t.read)]);

export const activityLogs = pgTable("activity_logs", {
  id: id(),
  staffId: text("staff_id").references(() => staff.id),
  action: text("action").notNull(),
  entity: text("entity").notNull(),
  entityId: text("entity_id"),
  meta: jsonb("meta"),
  ip: text("ip"),
  createdAt: createdAt(),
}, (t) => [index("activity_created_idx").on(t.createdAt)]);

export const settings = pgTable("settings", {
  key: text("key").primaryKey(),
  value: jsonb("value").notNull(),
  updatedAt: updatedAt(),
});

export const loginAttempts = pgTable("login_attempts", {
  id: id(),
  key: text("key").notNull(),
  ok: boolean("ok").notNull(),
  createdAt: createdAt(),
}, (t) => [index("login_attempts_key_idx").on(t.key, t.createdAt)]);

// ─────────────── Relations (for db.query.*) ───────────────
export const teamsRelations = relations(teams, ({ many }) => ({ members: many(staff), tasks: many(tasks) }));
export const staffRelations = relations(staff, ({ one }) => ({ team: one(teams, { fields: [staff.teamId], references: [teams.id] }) }));
export const customersRelations = relations(customers, ({ many }) => ({ addresses: many(addresses), orders: many(orders) }));
export const addressesRelations = relations(addresses, ({ one }) => ({ customer: one(customers, { fields: [addresses.customerId], references: [customers.id] }) }));
export const categoriesRelations = relations(categories, ({ one, many }) => ({
  parent: one(categories, { fields: [categories.parentId], references: [categories.id], relationName: "tree" }),
  children: many(categories, { relationName: "tree" }),
  products: many(products),
}));
export const vendorsRelations = relations(vendors, ({ many }) => ({ products: many(products), purchaseOrders: many(purchaseOrders), syncLogs: many(syncLogs) }));
export const productsRelations = relations(products, ({ one, many }) => ({
  category: one(categories, { fields: [products.categoryId], references: [categories.id] }),
  vendor: one(vendors, { fields: [products.vendorId], references: [vendors.id] }),
  variants: many(productVariants),
}));
export const productVariantsRelations = relations(productVariants, ({ one }) => ({ product: one(products, { fields: [productVariants.productId], references: [products.id] }) }));
export const syncLogsRelations = relations(syncLogs, ({ one }) => ({ vendor: one(vendors, { fields: [syncLogs.vendorId], references: [vendors.id] }) }));
export const ordersRelations = relations(orders, ({ one, many }) => ({
  customer: one(customers, { fields: [orders.customerId], references: [customers.id] }),
  items: many(orderItems),
  payments: many(payments),
  purchaseOrders: many(purchaseOrders),
}));
export const orderItemsRelations = relations(orderItems, ({ one }) => ({
  order: one(orders, { fields: [orderItems.orderId], references: [orders.id] }),
  product: one(products, { fields: [orderItems.productId], references: [products.id] }),
}));
export const paymentsRelations = relations(payments, ({ one }) => ({ order: one(orders, { fields: [payments.orderId], references: [orders.id] }) }));
export const purchaseOrdersRelations = relations(purchaseOrders, ({ one, many }) => ({
  vendor: one(vendors, { fields: [purchaseOrders.vendorId], references: [vendors.id] }),
  order: one(orders, { fields: [purchaseOrders.orderId], references: [orders.id] }),
  createdBy: one(staff, { fields: [purchaseOrders.createdById], references: [staff.id] }),
  items: many(purchaseOrderItems),
}));
export const purchaseOrderItemsRelations = relations(purchaseOrderItems, ({ one }) => ({ po: one(purchaseOrders, { fields: [purchaseOrderItems.poId], references: [purchaseOrders.id] }) }));
export const callbacksRelations = relations(callbacks, ({ one }) => ({ assignee: one(staff, { fields: [callbacks.assigneeId], references: [staff.id] }) }));
export const supportTicketsRelations = relations(supportTickets, ({ one }) => ({ assignee: one(staff, { fields: [supportTickets.assigneeId], references: [staff.id] }) }));
export const tasksRelations = relations(tasks, ({ one, many }) => ({
  team: one(teams, { fields: [tasks.teamId], references: [teams.id] }),
  assignee: one(staff, { fields: [tasks.assigneeId], references: [staff.id], relationName: "assignee" }),
  createdBy: one(staff, { fields: [tasks.createdById], references: [staff.id], relationName: "creator" }),
  comments: many(taskComments),
}));
export const taskCommentsRelations = relations(taskComments, ({ one }) => ({
  task: one(tasks, { fields: [taskComments.taskId], references: [tasks.id] }),
  author: one(staff, { fields: [taskComments.authorId], references: [staff.id] }),
}));
export const activityLogsRelations = relations(activityLogs, ({ one }) => ({ staff: one(staff, { fields: [activityLogs.staffId], references: [staff.id] }) }));
