import type { Metadata } from "next";
import { eq, desc } from "drizzle-orm";
import { db, schema } from "@/db";
import { getCustomer } from "@/lib/auth";
import { getSettings } from "@/lib/settings";
import { payuConfigured } from "@/lib/payments/payu";
import { phonepeConfigured } from "@/lib/payments/phonepe";
import { CheckoutForm } from "@/components/store/checkout-form";
import { getI18n } from "@/lib/i18n/server";

export async function generateMetadata(): Promise<Metadata> {
  return { title: (await getI18n()).t("Checkout"), robots: { index: false } };
}

export default async function Checkout() {
  const [customer, settings, { t }] = await Promise.all([getCustomer(), getSettings(), getI18n()]);
  const addresses = customer ? await db.select().from(schema.addresses).where(eq(schema.addresses.customerId, customer.id)).orderBy(desc(schema.addresses.isDefault)) : [];
  const p = settings.payments;
  const online = payuConfigured() || phonepeConfigured();
  return (
    <div className="container-lx py-12">
      <h1 className="h-display text-5xl">{t("Checkout")}</h1>
      <CheckoutForm
        customer={customer ? { name: customer.name, email: customer.email, phone: customer.phone ?? "" } : null}
        address={addresses[0] ?? null}
        pay={{
          payu: p.payu && payuConfigured(), phonepe: p.phonepe && phonepeConfigured(), bank: p.bankTransfer, cod: p.cod,
          partialCod: p.partialCod && online, codMax: p.codMaxOrder, partialMax: p.partialCodMaxOrder, advancePercent: p.advancePercent, codFee: p.codFee,
        }}
        returnsDays={settings.returns.windowDays}
      />
    </div>
  );
}
