import { notFound, redirect } from "next/navigation";
import { and, eq } from "drizzle-orm";
import { db, schema } from "@/db";
import { startPayment } from "@/lib/orders";
import { buildPayuForm, payuConfigured } from "@/lib/payments/payu";
import { createPhonepePayment, phonepeConfigured } from "@/lib/payments/phonepe";
import { AutoSubmit } from "@/components/store/auto-submit";
import { ClearBag } from "@/components/store/clear-bag";
import { getI18n } from "@/lib/i18n/server";

export const metadata = { robots: { index: false } };

export default async function Pay({ params, searchParams }: { params: Promise<{ number: string }>; searchParams: Promise<{ t?: string; via?: string }> }) {
  const [{ number }, sp] = await Promise.all([params, searchParams]);
  const [o] = await db.select().from(schema.orders).where(and(eq(schema.orders.number, number), eq(schema.orders.accessToken, sp.t ?? "")));
  if (!o) notFound();
  const back = `/order/${o.number}?t=${o.accessToken}`;
  const settled = o.paymentStatus === "PAID" || (o.paymentMethod === "PARTIAL_COD" && o.paymentStatus === "PARTIALLY_PAID");
  if (settled || o.status === "CANCELLED") redirect(back);
  const via = sp.via === "phonepe" || (o.paymentMethod === "PHONEPE" && sp.via !== "payu") ? "phonepe" : "payu";

  if (via === "phonepe" && phonepeConfigured()) {
    const { txnId, amount } = await startPayment(o.id, "PHONEPE");
    let url: string;
    try {
      url = (await createPhonepePayment({ txnId, amount, orderNumber: o.number })).redirectUrl;
    } catch (e) {
      console.error(e);
      redirect(`${back}&payerr=1`);
    }
    redirect(url);
  }
  if (!payuConfigured()) redirect(`${back}&payerr=1`);
  const { txnId, amount } = await startPayment(o.id, "PAYU");
  const { t } = await getI18n();
  const form = buildPayuForm({ txnid: txnId, amount, productinfo: `Luxeholic order ${o.number}`, firstname: o.shippingAddress.name.split(" ")[0], email: o.email, phone: o.phone, orderNumber: o.number });
  return (
    <div className="container-lx py-28 text-center">
      <ClearBag />
      <p className="eyebrow">{t("Order {number}", { number: o.number })}</p>
      <h1 className="h-display mt-4 text-4xl italic">{t("Taking you to secure payment…")}</h1>
      <AutoSubmit action={form.action} fields={form.fields} />
    </div>
  );
}
