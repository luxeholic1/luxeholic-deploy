"use server";
import { redirect } from "next/navigation";
import { and, eq, inArray } from "drizzle-orm";
import { z } from "zod";
import { db, schema } from "@/db";
import {
  getCustomer, hashPassword, verifyPassword, startCustomerSession, endCustomerSession, passwordProblem,
  tooManyAttempts, recordAttempt, clientIp, rememberGuestOrder, getGuestOrders,
} from "@/lib/auth";
import { createOrder, priceCart, type CartLine } from "@/lib/orders";
import { notifyTeams, sendMail } from "@/lib/notify";

type State = { ok?: boolean; error?: string; fields?: Record<string, string> } | null;

export async function subscribe(_: State, fd: FormData): Promise<State> {
  const email = z.string().email().safeParse(String(fd.get("email") ?? "").trim().toLowerCase());
  if (!email.success) return { error: "Enter a valid email." };
  await db.insert(schema.subscribers).values({ email: email.data }).onConflictDoNothing();
  return { ok: true };
}

export async function contact(_: State, fd: FormData): Promise<State> {
  const s = z.object({
    name: z.string().min(2).max(80), email: z.string().email(), phone: z.string().max(20).optional(),
    subject: z.string().min(3).max(120), message: z.string().min(10).max(4000), orderNumber: z.string().max(30).optional(),
    website: z.string().max(0).optional(), // honeypot
  }).safeParse(Object.fromEntries(fd));
  if (!s.success) return { error: "Please complete every field (message of at least 10 characters)." };
  const number = `T${Date.now().toString(36).toUpperCase()}`;
  const { website: _hp, ...data } = s.data;
  await db.insert(schema.supportTickets).values({ ...data, email: data.email.toLowerCase(), number });
  await notifyTeams(["tech-support"], `New ticket ${number}: ${data.subject}`, `${data.name} · ${data.email}`, "/team/tickets");
  await sendMail(data.email, `We've received your message (${number})`, "Thank you for writing to us.", `Our client-care team replies within one working day. Your reference is <b>${number}</b>.`);
  return { ok: true };
}

// ─────────── Customer accounts ───────────
export async function register(_: State, fd: FormData): Promise<State> {
  const s = z.object({ name: z.string().min(2).max(80), email: z.string().email(), phone: z.string().min(10).max(15), password: z.string(), optin: z.string().optional() })
    .safeParse(Object.fromEntries(fd));
  if (!s.success) return { error: "Please fill in your name, email, mobile number and a password." };
  const pwErr = passwordProblem(s.data.password);
  if (pwErr) return { error: pwErr };
  const email = s.data.email.toLowerCase();
  const [exists] = await db.select({ id: schema.customers.id }).from(schema.customers).where(eq(schema.customers.email, email));
  if (exists) return { error: "An account with this email already exists. Please sign in." };
  const [c] = await db.insert(schema.customers).values({ name: s.data.name, email, phone: s.data.phone, passwordHash: await hashPassword(s.data.password), marketingOptIn: !!s.data.optin }).returning();
  // Move guest orders into the new account only when this device proves them (saved order link) and the email matches —
  // never by email alone, or anyone could claim someone else's orders by registering with their address.
  const saved = await getGuestOrders();
  if (saved.length) {
    const rows = await db.select({ id: schema.orders.id, number: schema.orders.number, token: schema.orders.accessToken }).from(schema.orders)
      .where(and(eq(schema.orders.email, email), eq(schema.orders.isGuest, true), inArray(schema.orders.number, saved.map((g) => g.n))));
    for (const r of rows) if (saved.some((g) => g.n === r.number && g.t === r.token)) await db.update(schema.orders).set({ customerId: c.id }).where(eq(schema.orders.id, r.id));
  }
  await startCustomerSession(c.id);
  redirect(String(fd.get("next") || "/account"));
}

export async function login(_: State, fd: FormData): Promise<State> {
  const email = String(fd.get("email") ?? "").trim().toLowerCase();
  const password = String(fd.get("password") ?? "");
  const key = `c:${email}`;
  if (await tooManyAttempts(key)) return { error: "Too many attempts. Please wait 15 minutes." };
  const [c] = await db.select().from(schema.customers).where(eq(schema.customers.email, email));
  const ok = !!c && (await verifyPassword(password, c.passwordHash));
  await recordAttempt(key, ok);
  if (!ok) return { error: "Email or password is incorrect." };
  await startCustomerSession(c.id);
  const next = String(fd.get("next") || "/account");
  redirect(next.startsWith("/") ? next : "/account");
}

export async function logout() {
  await endCustomerSession();
  redirect("/");
}

// ─────────── Checkout ───────────
const addr = z.object({
  name: z.string().min(2).max(80), phone: z.string().regex(/^[6-9]\d{9}$/, "Enter a 10-digit Indian mobile number"),
  line1: z.string().min(4).max(160), line2: z.string().max(160).optional().nullable(), city: z.string().min(2).max(60),
  state: z.string().min(2).max(60), pincode: z.string().regex(/^\d{6}$/, "Enter a 6-digit PIN code"), country: z.literal("India"),
});

export async function quote(lines: CartLine[], coupon?: string) {
  const p = await priceCart(lines, coupon);
  return { subtotal: p.subtotal, discount: p.discount, shippingFee: p.shippingFee, total: p.total, coupon: p.coupon, problems: p.problems, maxDays: p.maxDays,
    items: p.items.map((i) => ({ productId: i.productId, variantId: i.variantId, price: i.unitPrice, qty: i.quantity })) };
}

export async function placeOrder(_: State, fd: FormData): Promise<State> {
  let lines: CartLine[] = [];
  try { lines = JSON.parse(String(fd.get("lines") ?? "[]")); } catch { /* invalid */ }
  const raw = Object.fromEntries(fd) as Record<string, string>;
  const ship = addr.safeParse({ name: raw.name, phone: raw.phone?.replace(/\D/g, "").slice(-10), line1: raw.line1, line2: raw.line2 || null, city: raw.city, state: raw.state, pincode: raw.pincode, country: "India" });
  if (!ship.success) return { error: ship.error.issues[0]?.message ?? "Please check your address.", fields: raw };
  const email = z.string().email().safeParse(raw.email?.trim().toLowerCase());
  if (!email.success) return { error: "Enter a valid email for your order confirmation.", fields: raw };
  const method = raw.method as "PAYU" | "PHONEPE" | "BANK_TRANSFER" | "COD" | "PARTIAL_COD";
  if (!["PAYU", "PHONEPE", "BANK_TRANSFER", "COD", "PARTIAL_COD"].includes(method)) return { error: "Choose how you'd like to pay.", fields: raw };
  if (raw.terms !== "on") return { error: "Please accept the terms and returns policy.", fields: raw };
  const customer = await getCustomer();
  let order;
  try {
    order = await createOrder({
      lines, coupon: raw.coupon || null, method, customerId: customer?.id ?? null, email: email.data, phone: ship.data.phone,
      shipping: ship.data, gstin: raw.gstin?.trim().toUpperCase() || null, notes: raw.notes?.slice(0, 500) || null,
    });
  } catch (e) {
    return { error: (e as Error).message, fields: raw };
  }
  if (!customer) await rememberGuestOrder(order.number, order.accessToken);
  if (customer && raw.saveAddress === "on") {
    await db.insert(schema.addresses).values({ customerId: customer.id, ...ship.data, line2: ship.data.line2 ?? null, isDefault: true });
  }
  const online = method === "PAYU" || method === "PHONEPE" || method === "PARTIAL_COD";
  const gw = method === "PARTIAL_COD" ? (raw.advanceVia === "PHONEPE" ? "phonepe" : "payu") : method.toLowerCase();
  redirect(online ? `/checkout/pay/${order.number}?t=${order.accessToken}&via=${gw}` : `/order/${order.number}?t=${order.accessToken}&placed=1`);
}

export async function submitUtr(_: State, fd: FormData): Promise<State> {
  const number = String(fd.get("number")), token = String(fd.get("t")), utr = String(fd.get("utr") ?? "").trim().toUpperCase();
  if (!/^[A-Z0-9]{8,22}$/.test(utr)) return { error: "Enter the 12-digit UTR / reference number from your bank." };
  const [o] = await db.select().from(schema.orders).where(and(eq(schema.orders.number, number), eq(schema.orders.accessToken, token)));
  if (!o || o.paymentMethod !== "BANK_TRANSFER") return { error: "Order not found." };
  await db.update(schema.orders).set({ bankUtr: utr, paymentStatus: "AWAITING_VERIFICATION" }).where(eq(schema.orders.id, o.id));
  await notifyTeams(["sales"], `Verify bank transfer for ${o.number}`, `UTR ${utr}`, `/team/orders/${o.id}`);
  return { ok: true };
}

export async function trackOrder(_: State, fd: FormData): Promise<State> {
  const number = String(fd.get("number") ?? "").trim().toUpperCase();
  const email = String(fd.get("email") ?? "").trim().toLowerCase();
  const ip = (await clientIp()) ?? "x";
  if (await tooManyAttempts(`track:${ip}`)) return { error: "Too many lookups. Try again shortly." };
  const [o] = await db.select().from(schema.orders).where(and(eq(schema.orders.number, number), eq(schema.orders.email, email)));
  await recordAttempt(`track:${ip}`, !!o);
  if (!o) return { error: "We couldn't find that order. Check the order number and email." };
  if (!(await getCustomer())) await rememberGuestOrder(o.number, o.accessToken);
  redirect(`/order/${o.number}?t=${o.accessToken}`);
}

export async function requestReturn(_: State, fd: FormData): Promise<State> {
  const number = String(fd.get("number")), token = String(fd.get("t")), reason = String(fd.get("reason") ?? "").slice(0, 1000);
  const [o] = await db.select().from(schema.orders).where(and(eq(schema.orders.number, number), eq(schema.orders.accessToken, token)));
  if (!o || o.status !== "DELIVERED") return { error: "Returns can be requested once your order is delivered." };
  if (reason.length < 10) return { error: "Tell us briefly what went wrong." };
  await db.update(schema.orders).set({ status: "RETURN_REQUESTED", internalNotes: `${o.internalNotes ?? ""}\nReturn reason: ${reason}`.trim() }).where(eq(schema.orders.id, o.id));
  await notifyTeams(["sales", "tech-support"], `Return requested: ${o.number}`, reason.slice(0, 140), `/team/orders/${o.id}`);
  return { ok: true };
}

// ─────────── Request a call back ───────────
export type CallbackState = { ok?: boolean; error?: string; field?: string; number?: string; phone?: string; when?: string } | null;
const INTERESTS = ["Lux-Tech device", "Designer fashion", "Art & décor", "Corporate / bulk gifting", "Help with an order", "Something else"];
const TIMES = ["Morning · 10–1", "Afternoon · 1–4", "Evening · 4–7"];

export async function requestCallback(_: CallbackState, fd: FormData): Promise<CallbackState> {
  if (String(fd.get("website") ?? "")) return { ok: true, number: "—" }; // honeypot: bots get a quiet success
  const name = String(fd.get("name") ?? "").trim().slice(0, 80);
  if (name.length < 2) return { error: "Please enter your name.", field: "name" };
  const raw = String(fd.get("phone") ?? "").replace(/[^\d+]/g, "");
  const phone = /^\+\d{8,15}$/.test(raw) ? raw : /^(?:\+?91|0)?([6-9]\d{9})$/.test(raw) ? "+91" + raw.replace(/^(?:\+?91|0)/, "") : null;
  if (!phone) return { error: "Enter a 10-digit Indian mobile number, or include your country code.", field: "phone" };
  const emailRaw = String(fd.get("email") ?? "").trim().toLowerCase();
  const email = emailRaw ? z.string().email().safeParse(emailRaw) : null;
  if (email && !email.success) return { error: "That email doesn’t look right — or leave it empty.", field: "email" };
  if (fd.get("consent") !== "on") return { error: "Please tick the box so we may call you.", field: "consent" };
  const interest = INTERESTS.includes(String(fd.get("interest"))) ? String(fd.get("interest")) : "Something else";
  const bestTime = TIMES.includes(String(fd.get("time"))) ? String(fd.get("time")) : TIMES[0];
  const ip = (await clientIp()) ?? "x";
  if (await tooManyAttempts(`cb:${ip}`)) return { error: "We’ve received several requests from you already — our team will call shortly." };
  await recordAttempt(`cb:${ip}`, false); // counts towards the 8-per-15-minutes limit
  const customer = await getCustomer();
  const number = `CB${Date.now().toString(36).toUpperCase()}`;
  await db.insert(schema.callbacks).values({
    number, name, phone, email: email?.success ? email.data : null, interest, bestTime,
    city: String(fd.get("city") ?? "").trim().slice(0, 60) || null,
    message: String(fd.get("message") ?? "").trim().slice(0, 500) || null,
    source: String(fd.get("source") ?? "home").slice(0, 30), customerId: customer?.id ?? null,
  });
  await notifyTeams(["sales"], `Call back ${name} (${bestTime.split(" · ")[0]})`, `${phone} · ${interest}`, "/team/leads");
  if (email?.success) await sendMail(email.data, `We’ll call you back (${number})`, `Thank you, ${name.split(" ")[0]}.`, `Our concierge will call <b>${phone}</b> in the ${bestTime.split(" · ")[0].toLowerCase()}, Monday to Saturday. Your reference is <b>${number}</b>.`);
  return { ok: true, number, phone, when: bestTime.split(" · ")[0].toLowerCase() };
}
