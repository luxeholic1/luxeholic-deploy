import { redirect } from "next/navigation";

export default async function OldLogin({ searchParams }: { searchParams: Promise<{ next?: string }> }) {
  const { next } = await searchParams;
  redirect(`/login${next ? `?next=${encodeURIComponent(next)}` : ""}`);
}
