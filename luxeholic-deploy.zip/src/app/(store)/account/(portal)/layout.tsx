import Link from "next/link";
import { requireCustomer } from "@/lib/auth";
import { logout } from "../../actions";
import { AccountNav } from "./nav";
import { getI18n } from "@/lib/i18n/server";

export default async function AccountLayout({ children }: { children: React.ReactNode }) {
  const c = await requireCustomer();
  const { t } = await getI18n();
  return (
    <div className="container-lx py-12">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div><p className="eyebrow">{t("My account")}</p><h1 className="h-display mt-3 text-4xl sm:text-5xl">{t("Hello, {name}.", { name: c.name.split(" ")[0] })}</h1></div>
        <div className="flex gap-3">
          <Link href="/shop" className="btn-line !py-2.5">{t("Continue shopping")}</Link>
          <form action={logout}><button className="btn-line !py-2.5">{t("Sign out")}</button></form>
        </div>
      </div>
      <div className="mt-10 grid gap-10 lg:grid-cols-[220px_1fr]">
        <AccountNav />
        <div className="min-w-0">{children}</div>
      </div>
    </div>
  );
}
