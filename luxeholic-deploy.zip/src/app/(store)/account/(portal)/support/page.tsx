import type { Metadata } from "next";
import { desc, eq } from "drizzle-orm";
import { db, schema } from "@/db";
import { requireCustomer } from "@/lib/auth";
import { prettyDateTime } from "@/lib/dates";
import { ActionForm } from "@/components/store/action-form";
import { CallbackButton } from "@/components/store/callback";
import { getI18n } from "@/lib/i18n/server";
import { LOCALE_INFO } from "@/lib/i18n/config";
import { newTicket, replyTicket } from "../../actions";

export async function generateMetadata(): Promise<Metadata> {
  return { title: (await getI18n()).t("Help & requests"), robots: { index: false } };
}
const T: Record<string, string> = { OPEN: "Open", IN_PROGRESS: "We’re on it", WAITING_CUSTOMER: "Waiting for you", RESOLVED: "Resolved" };
const C: Record<string, string> = { NEW: "Requested", CALLED: "Called", CLOSED: "Done" };

export default async function Support({ searchParams }: { searchParams: Promise<{ order?: string }> }) {
  const c = await requireCustomer();
  const sp = await searchParams;
  const { t: tr, locale } = await getI18n();
  const intl = LOCALE_INFO[locale].intl;
  const when = (d: Date) => prettyDateTime(d, intl);
  const [tickets, calls, orders] = await Promise.all([
    db.select().from(schema.supportTickets).where(eq(schema.supportTickets.email, c.email)).orderBy(desc(schema.supportTickets.updatedAt)).limit(50),
    db.select().from(schema.callbacks).where(eq(schema.callbacks.customerId, c.id)).orderBy(desc(schema.callbacks.createdAt)).limit(20),
    db.select({ number: schema.orders.number }).from(schema.orders).where(eq(schema.orders.customerId, c.id)).orderBy(desc(schema.orders.createdAt)).limit(30),
  ]);
  return (
    <div className="space-y-10">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div><h2 className="font-display text-3xl">{tr("Help & requests")}</h2><p className="mt-1 text-sm text-ink-soft">{tr("Write to client care, follow replies and see your call-back requests.")}</p></div>
        <CallbackButton className="btn-line !py-2.5">{tr("Request a call back")}</CallbackButton>
      </div>
      <section className="card-lx p-6">
        <h3 className="font-display text-2xl">{tr("New message")}</h3>
        <ActionForm action={newTicket} submit={tr("Send message")} resetOnOk busy={tr("Sending…")} className="mt-4">
          <div className="grid gap-4 sm:grid-cols-2">
            <label><span className="label">{tr("Subject")}</span><input name="subject" required maxLength={120} className="field" placeholder={tr("e.g. Delivery date for my order")} /></label>
            <label><span className="label">{tr("Order (optional)")}</span><select name="orderNumber" defaultValue={sp.order ?? ""} className="field"><option value="">{tr("Not about an order")}</option>{orders.map((o) => <option key={o.number}>{o.number}</option>)}</select></label>
            <label className="sm:col-span-2"><span className="label">{tr("Message")}</span><textarea name="message" required rows={4} maxLength={4000} className="field" /></label>
          </div>
        </ActionForm>
      </section>
      <section>
        <h3 className="eyebrow !text-ink">{tr("Your messages")}</h3>
        {tickets.length === 0 ? <p className="mt-3 text-sm text-ink-soft">{tr("No messages yet.")}</p> : (
          <div className="mt-4 space-y-4">
            {tickets.map((t) => (
              <details key={t.id} className="card-lx p-5" open={t.status === "WAITING_CUSTOMER"}>
                <summary className="flex cursor-pointer list-none flex-wrap items-center justify-between gap-3">
                  <span><span className="font-medium">{t.subject}</span><span className="ml-2 text-xs text-ink-mute">{t.number}{t.orderNumber ? ` · ${t.orderNumber}` : ""}</span></span>
                  <span className="text-xs uppercase tracking-[0.14em]">{tr(T[t.status])} · {when(t.updatedAt)}</span>
                </summary>
                <ol className="mt-4 space-y-3 text-sm">
                  <li className="bg-white/70 p-3"><p className="text-xs text-ink-mute">{tr("You")} · {when(t.createdAt)}</p><p className="mt-1 whitespace-pre-line">{t.message}</p></li>
                  {t.replies.filter((r) => !r.internal).map((r, i) => (
                    <li key={i} className={r.staff ? "border-l-2 border-gold bg-ivory-deep p-3" : "bg-white/70 p-3"}><p className="text-xs text-ink-mute">{r.staff ? tr("LUXEHOLIC client care") : tr("You")} · {when(new Date(r.at))}</p><p className="mt-1 whitespace-pre-line">{r.body}</p></li>
                  ))}
                </ol>
                {t.status !== "RESOLVED" && (
                  <ActionForm action={replyTicket} submit={tr("Send reply")} resetOnOk busy={tr("Sending…")} className="mt-4">
                    <input type="hidden" name="id" value={t.id} />
                    <label><span className="label">{tr("Reply")}</span><textarea name="body" rows={3} maxLength={4000} className="field" /></label>
                  </ActionForm>
                )}
              </details>
            ))}
          </div>
        )}
      </section>
      {calls.length > 0 && (
        <section>
          <h3 className="eyebrow !text-ink">{tr("Call-back requests")}</h3>
          <ul className="mt-3 divide-y divide-ivory-line border-y border-ivory-line text-sm">
            {calls.map((k) => <li key={k.id} className="flex flex-wrap justify-between gap-2 py-3"><span>{tr(k.interest)} · {tr(k.bestTime)}</span><span className="text-ink-mute">{tr(C[k.status])} · {when(k.createdAt)}</span></li>)}
          </ul>
        </section>
      )}
    </div>
  );
}
