import type { Metadata } from "next";
import Link from "next/link";
import { desc, eq } from "drizzle-orm";
import { db, schema } from "@/db";
import { requireCustomer } from "@/lib/auth";
import { ProductCard } from "@/components/store/product-card";
import { getI18n } from "@/lib/i18n/server";
import { localize } from "@/lib/i18n/content";
import { toggleWishlist } from "../../actions";

export async function generateMetadata(): Promise<Metadata> {
  return { title: (await getI18n()).t("My wishlist"), robots: { index: false } };
}

export default async function Wishlist() {
  const c = await requireCustomer();
  const rows = await db.select({ p: schema.products }).from(schema.wishlist)
    .innerJoin(schema.products, eq(schema.products.id, schema.wishlist.productId))
    .where(eq(schema.wishlist.customerId, c.id)).orderBy(desc(schema.wishlist.createdAt));
  const { t, locale } = await getI18n();
  const tr = new Map((await localize("product", rows.map((r) => r.p), locale)).items.map((p) => [p.id, p]));
  return (
    <div>
      <h2 className="font-display text-3xl">{t("Wishlist")}</h2>
      <p className="mt-1 text-sm text-ink-soft">{t("Tap ♡ Save on any piece to keep it here.")}</p>
      {rows.length === 0 ? <p className="mt-8 text-ink-soft">{t("Nothing saved yet.")} <Link href="/shop" className="underline">{t("Browse the collection")}</Link></p> : (
        <div className="mt-8 grid grid-cols-2 gap-x-4 gap-y-10 sm:gap-x-6 lg:grid-cols-3">
          {rows.map(({ p }) => (
            <div key={p.id}>
              {p.status === "ACTIVE" && tr.has(p.id) ? <ProductCard p={tr.get(p.id)!} /> : <div className="card-lx p-5 text-sm text-ink-soft">{tr.get(p.id)?.title ?? p.brand}<br />{p.status === "ACTIVE" ? t("Not available in Hindi yet") : t("No longer available.")}</div>}
              <form action={toggleWishlist} className="mt-2"><input type="hidden" name="productId" value={p.id} /><input type="hidden" name="back" value="/account/wishlist" /><button className="text-[11px] uppercase tracking-[0.18em] underline underline-offset-4">{t("Remove")}</button></form>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
