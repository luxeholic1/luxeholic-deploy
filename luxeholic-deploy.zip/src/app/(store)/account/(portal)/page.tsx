import type { Metadata } from "next";
import Link from "next/link";
import { and, count, desc, eq, inArray, ne } from "drizzle-orm";
import { db, schema } from "@/db";
import { requireCustomer } from "@/lib/auth";
import { getI18n } from "@/lib/i18n/server";
import { formatMoney, LOCALE_INFO } from "@/lib/i18n/config";
import { prettyDateTime } from "@/lib/dates";
import { ACTIVE_ORDER, ORDER_LABEL, PAY_LABEL } from "@/lib/order-labels";
import { CallbackButton } from "@/components/store/callback";

export async function generateMetadata(): Promise<Metadata> {
  return { title: (await getI18n()).t("My account"), robots: { index: false } };
}

export default async function Overview() {
  const c = await requireCustomer();
  const { t, locale } = await getI18n();
  const formatINR = (p: number) => formatMoney(p, "INR", {}, locale);
  const intl = LOCALE_INFO[locale].intl;
  const [orders, [act], [wish], [tix]] = await Promise.all([
    db.select().from(schema.orders).where(eq(schema.orders.customerId, c.id)).orderBy(desc(schema.orders.createdAt)).limit(3),
    db.select({ n: count() }).from(schema.orders).where(and(eq(schema.orders.customerId, c.id), inArray(schema.orders.status, ACTIVE_ORDER as never))),
    db.select({ n: count() }).from(schema.wishlist).where(eq(schema.wishlist.customerId, c.id)),
    db.select({ n: count() }).from(schema.supportTickets).where(and(eq(schema.supportTickets.email, c.email), ne(schema.supportTickets.status, "RESOLVED"))),
  ]);
  const stats = [
    { label: t("Orders in progress"), value: act.n, href: "/account/orders" },
    { label: t("Saved pieces"), value: wish.n, href: "/account/wishlist" },
    { label: t("Open requests"), value: tix.n, href: "/account/support" },
  ];
  return (
    <div className="space-y-10">
      <div className="grid gap-3 sm:grid-cols-3">
        {stats.map((s) => <Link key={s.label} href={s.href} className="card-lx p-5 transition hover:border-ink"><p className="eyebrow">{s.label}</p><p className="mt-2 font-display text-4xl">{s.value}</p></Link>)}
      </div>
      <section>
        <div className="flex items-baseline justify-between"><h2 className="eyebrow !text-ink">{t("Recent orders")}</h2><Link href="/account/orders" className="text-sm underline">{t("All orders")}</Link></div>
        {orders.length === 0 ? <p className="mt-4 text-ink-soft">{t("No orders yet.")} <Link href="/shop" className="underline">{t("Find your first piece")}</Link></p> : (
          <ul className="mt-4 divide-y divide-ivory-line border-y border-ivory-line">
            {orders.map((o) => (
              <li key={o.id}><Link href={`/order/${o.number}?t=${o.accessToken}`} className="flex flex-wrap items-center justify-between gap-3 py-4 hover:bg-white/40">
                <span><span className="font-medium">{o.number}</span><span className="ml-3 text-sm text-ink-mute">{prettyDateTime(o.createdAt, intl)}</span></span>
                <span className="text-sm">{t(ORDER_LABEL[o.status])} · {t(PAY_LABEL[o.paymentStatus])} · {formatINR(o.total)}</span>
              </Link></li>
            ))}
          </ul>
        )}
      </section>
      <section className="card-lx flex flex-wrap items-center justify-between gap-4 p-6">
        <div><p className="font-display text-2xl">{t("Need a hand?")}</p><p className="mt-1 text-sm text-ink-soft">{t("Ask about an order, a return or a piece you’re looking for.")}</p></div>
        <div className="flex flex-wrap gap-3"><Link href="/account/support" className="btn-ink !py-3">{t("Write to us")}</Link><CallbackButton className="btn-line !py-3">{t("Request a call back")}</CallbackButton></div>
      </section>
    </div>
  );
}
