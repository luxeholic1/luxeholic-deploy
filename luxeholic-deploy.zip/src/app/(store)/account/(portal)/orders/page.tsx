import type { Metadata } from "next";
import Link from "next/link";
import { desc, eq, inArray } from "drizzle-orm";
import { db, schema } from "@/db";
import { requireCustomer } from "@/lib/auth";
import { getI18n } from "@/lib/i18n/server";
import { formatMoney, LOCALE_INFO } from "@/lib/i18n/config";
import { orderLineLabels } from "@/lib/i18n/content";
import { prettyDateTime } from "@/lib/dates";
import { ORDER_LABEL, PAY_LABEL } from "@/lib/order-labels";

export async function generateMetadata(): Promise<Metadata> {
  return { title: (await getI18n()).t("My orders"), robots: { index: false } };
}

export default async function Orders() {
  const c = await requireCustomer();
  const orders = await db.select().from(schema.orders).where(eq(schema.orders.customerId, c.id)).orderBy(desc(schema.orders.createdAt)).limit(100);
  const { t, locale } = await getI18n();
  const formatINR = (p: number) => formatMoney(p, "INR", {}, locale);
  const intl = LOCALE_INFO[locale].intl;
  const items = orders.length ? await db.select().from(schema.orderItems).where(inArray(schema.orderItems.orderId, orders.map((o) => o.id))) : [];
  return (
    <LabelledOrders t={t} formatINR={formatINR} intl={intl} orders={orders} items={items} labels={await orderLineLabels(items, locale)} />
  );
}

function LabelledOrders({ t, formatINR, intl, orders, items, labels }: { t: (s: string, v?: Record<string, string | number>) => string; formatINR: (p: number) => string; intl: string; orders: (typeof schema.orders.$inferSelect)[]; items: (typeof schema.orderItems.$inferSelect)[]; labels: Map<string, { title: string; variant: string | null }> }) {
  return (
    <div>
      <h2 className="font-display text-3xl">{t("Orders & returns")}</h2>
      <p className="mt-1 text-sm text-ink-soft">{t("Open an order to track it, pay a balance, download the GST invoice or request a return (within the return window after delivery).")}</p>
      {orders.length === 0 ? <p className="mt-8 text-ink-soft">{t("No orders yet.")} <Link href="/shop" className="underline">{t("Start shopping")}</Link></p> : (
        <div className="mt-8 space-y-4">
          {orders.map((o) => {
            const its = items.filter((i) => i.orderId === o.id);
            return (
              <article key={o.id} className="card-lx p-5">
                <div className="flex flex-wrap items-start justify-between gap-3">
                  <div><p className="font-medium">{o.number}</p><p className="text-xs text-ink-mute">{prettyDateTime(o.createdAt, intl)}</p></div>
                  <div className="text-right text-sm"><p className="font-medium">{formatINR(o.total)}</p><p className="text-ink-mute">{t(ORDER_LABEL[o.status])} · {t(PAY_LABEL[o.paymentStatus])}</p></div>
                </div>
                <ul className="mt-3 text-sm text-ink-soft">{its.map((i) => <li key={i.id}>{i.quantity} × {labels.get(i.id)!.title}{i.variant ? ` (${labels.get(i.id)!.variant})` : ""}</li>)}</ul>
                {o.trackingNumber && <p className="mt-2 text-sm">{t("Tracking:")} {o.courier ? `${o.courier} · ` : ""}{o.trackingNumber}</p>}
                <div className="mt-4 flex flex-wrap gap-3">
                  <Link href={`/order/${o.number}?t=${o.accessToken}`} className="btn-ink !px-5 !py-2.5">{o.status === "DELIVERED" ? t("View · return") : t("View & track")}</Link>
                  <Link href={`/account/support?order=${o.number}`} className="btn-line !px-5 !py-2.5">{t("Ask about this order")}</Link>
                </div>
              </article>
            );
          })}
        </div>
      )}
    </div>
  );
}
