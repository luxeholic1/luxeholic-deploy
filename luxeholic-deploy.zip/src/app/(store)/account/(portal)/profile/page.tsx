import type { Metadata } from "next";
import { requireCustomer } from "@/lib/auth";
import { ActionForm } from "@/components/store/action-form";
import { getI18n } from "@/lib/i18n/server";
import { saveProfile, changePassword } from "../../actions";

export async function generateMetadata(): Promise<Metadata> {
  return { title: (await getI18n()).t("Profile & password"), robots: { index: false } };
}

export default async function Profile() {
  const c = await requireCustomer();
  const { t } = await getI18n();
  return (
    <div className="grid gap-8 xl:grid-cols-2">
      <section className="card-lx p-6">
        <h2 className="font-display text-2xl">{t("Profile")}</h2>
        <p className="mt-1 text-sm text-ink-soft">{t("Sign-in email:")} <b>{c.email}</b></p>
        <ActionForm action={saveProfile} submit={t("Save profile")} className="mt-5">
          <div className="grid gap-4">
            <label><span className="label">{t("Full name")}</span><input name="name" defaultValue={c.name} required maxLength={80} className="field" autoComplete="name" /></label>
            <label><span className="label">{t("Mobile")}</span><input name="phone" defaultValue={c.phone ?? ""} required inputMode="tel" className="field" autoComplete="tel" /></label>
            <label className="flex items-start gap-3 text-sm text-ink-soft"><input type="checkbox" name="optin" defaultChecked={c.marketingOptIn} className="mt-1 h-4 w-4 accent-ink" /> {t("Email me about new arrivals and private previews (never more than twice a month).")}</label>
          </div>
        </ActionForm>
      </section>
      <section className="card-lx p-6">
        <h2 className="font-display text-2xl">{t("Change password")}</h2>
        <ActionForm action={changePassword} submit={t("Change password")} resetOnOk className="mt-5">
          <div className="grid gap-4">
            <label><span className="label">{t("Current password")}</span><input type="password" name="current" required className="field" autoComplete="current-password" /></label>
            <label><span className="label">{t("New password")}</span><input type="password" name="next" required minLength={10} className="field" autoComplete="new-password" /><span className="mt-1 block text-xs text-ink-mute">{t("At least 10 characters, with letters and a number.")}</span></label>
            <label><span className="label">{t("Repeat new password")}</span><input type="password" name="confirm" required className="field" autoComplete="new-password" /></label>
          </div>
        </ActionForm>
      </section>
    </div>
  );
}
