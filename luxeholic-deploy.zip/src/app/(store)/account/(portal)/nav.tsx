"use client";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { useT } from "@/lib/i18n/client";

const ITEMS = [
  ["/account", "Overview"], ["/account/orders", "Orders & returns"], ["/account/wishlist", "Wishlist"],
  ["/account/addresses", "Addresses"], ["/account/support", "Help & requests"], ["/account/profile", "Profile & password"],
] as const;

export function AccountNav() {
  const path = usePathname();
  const t = useT();
  return (
    <nav aria-label={t("Account")} className="no-scrollbar -mx-4 flex gap-1 overflow-x-auto px-4 lg:mx-0 lg:flex-col lg:px-0">
      {ITEMS.map(([href, label]) => {
        const on = href === "/account" ? path === "/account" : path.startsWith(href);
        return <Link key={href} href={href} aria-current={on ? "page" : undefined} className={`whitespace-nowrap border-b-2 px-3 py-2.5 text-sm lg:border-b-0 lg:border-l-2 ${on ? "border-ink font-medium" : "border-transparent text-ink-soft hover:text-ink"}`}>{t(label)}</Link>;
      })}
    </nav>
  );
}
