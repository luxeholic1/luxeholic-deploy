import type { Metadata } from "next";
import { asc, desc, eq } from "drizzle-orm";
import { db, schema } from "@/db";
import { requireCustomer } from "@/lib/auth";
import { ActionForm } from "@/components/store/action-form";
import { getI18n } from "@/lib/i18n/server";
import { saveAddress, deleteAddress, makeDefaultAddress } from "../../actions";

export async function generateMetadata(): Promise<Metadata> {
  return { title: (await getI18n()).t("My addresses"), robots: { index: false } };
}
const STATES = ["Andaman and Nicobar Islands","Andhra Pradesh","Arunachal Pradesh","Assam","Bihar","Chandigarh","Chhattisgarh","Dadra and Nagar Haveli and Daman and Diu","Delhi","Goa","Gujarat","Haryana","Himachal Pradesh","Jammu and Kashmir","Jharkhand","Karnataka","Kerala","Ladakh","Lakshadweep","Madhya Pradesh","Maharashtra","Manipur","Meghalaya","Mizoram","Nagaland","Odisha","Puducherry","Punjab","Rajasthan","Sikkim","Tamil Nadu","Telangana","Tripura","Uttar Pradesh","Uttarakhand","West Bengal"];

type A = typeof schema.addresses.$inferSelect;
type Tr = (s: string, v?: Record<string, string | number>) => string;
function Fields({ a, t }: { a?: A; t: Tr }) {
  return (
    <div className="grid gap-4 sm:grid-cols-2">
      {a && <input type="hidden" name="id" value={a.id} />}
      <label><span className="label">{t("Full name")}</span><input name="name" defaultValue={a?.name} required className="field" autoComplete="name" /></label>
      <label><span className="label">{t("Mobile")}</span><input name="phone" defaultValue={a?.phone} required inputMode="tel" className="field" autoComplete="tel" /></label>
      <label className="sm:col-span-2"><span className="label">{t("House, street")}</span><input name="line1" defaultValue={a?.line1} required className="field" autoComplete="address-line1" /></label>
      <label className="sm:col-span-2"><span className="label">{t("Area, landmark (optional)")}</span><input name="line2" defaultValue={a?.line2 ?? ""} className="field" autoComplete="address-line2" /></label>
      <label><span className="label">{t("City")}</span><input name="city" defaultValue={a?.city} required className="field" autoComplete="address-level2" /></label>
      <label><span className="label">{t("State")}</span><select name="state" defaultValue={a?.state ?? ""} required className="field"><option value="" disabled>{t("Choose")}</option>{STATES.map((s) => <option key={s} value={s}>{t(s)}</option>)}</select></label>
      <label><span className="label">{t("PIN code")}</span><input name="pincode" defaultValue={a?.pincode} required inputMode="numeric" maxLength={6} className="field" autoComplete="postal-code" /></label>
      <label className="flex items-center gap-2 self-end pb-3 text-sm"><input type="checkbox" name="isDefault" defaultChecked={a?.isDefault} className="h-4 w-4 accent-ink" /> {t("Use as default")}</label>
    </div>
  );
}

export default async function Addresses() {
  const c = await requireCustomer();
  const { t } = await getI18n();
  const list = await db.select().from(schema.addresses).where(eq(schema.addresses.customerId, c.id)).orderBy(desc(schema.addresses.isDefault), asc(schema.addresses.createdAt));
  return (
    <div className="space-y-10">
      <div><h2 className="font-display text-3xl">{t("Addresses")}</h2><p className="mt-1 text-sm text-ink-soft">{t("Your default address is filled in at checkout.")}</p></div>
      {list.length > 0 && (
        <div className="grid gap-4 md:grid-cols-2">
          {list.map((a) => (
            <details key={a.id} className="card-lx p-5">
              <summary className="cursor-pointer list-none">
                <p className="font-medium">{a.name} {a.isDefault && <span className="ml-2 bg-ink px-2 py-0.5 text-[10px] uppercase tracking-[0.16em] text-ivory">{t("Default")}</span>}</p>
                <p className="mt-1 text-sm leading-relaxed text-ink-soft">{a.line1}{a.line2 ? `, ${a.line2}` : ""}<br />{a.city}, {t(a.state)} {a.pincode}<br />{a.phone}</p>
                <span className="mt-3 inline-block text-[11px] uppercase tracking-[0.18em] underline underline-offset-4">{t("Edit")}</span>
              </summary>
              <div className="mt-5 border-t border-ivory-line pt-5">
                <ActionForm action={saveAddress} submit={t("Save address")}><Fields a={a} t={t} /></ActionForm>
                <div className="mt-4 flex flex-wrap gap-4 text-sm">
                  {!a.isDefault && <form action={makeDefaultAddress}><input type="hidden" name="id" value={a.id} /><button className="underline">{t("Make default")}</button></form>}
                  <form action={deleteAddress}><input type="hidden" name="id" value={a.id} /><button className="text-red-700 underline">{t("Delete address")}</button></form>
                </div>
              </div>
            </details>
          ))}
        </div>
      )}
      <section className="card-lx p-6">
        <h3 className="font-display text-2xl">{list.length ? t("Add another address") : t("Add your first address")}</h3>
        <div className="mt-5"><ActionForm action={saveAddress} submit={t("Add address")} resetOnOk><Fields t={t} /></ActionForm></div>
      </section>
    </div>
  );
}
