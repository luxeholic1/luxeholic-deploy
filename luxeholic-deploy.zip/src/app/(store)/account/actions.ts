"use server";
import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { and, eq } from "drizzle-orm";
import { z } from "zod";
import { db, schema } from "@/db";
import { getCustomer, hashPassword, verifyPassword, passwordProblem } from "@/lib/auth";
import { notifyTeams } from "@/lib/notify";
import { getI18n } from "@/lib/i18n/server";

export type AState = { ok?: string; error?: string } | null;

async function me() {
  const c = await getCustomer();
  if (!c) redirect("/login?next=/account");
  return c;
}

// ─────────── Profile ───────────
export async function saveProfile(_: AState, fd: FormData): Promise<AState> {
  const c = await me();
  const s = z.object({ name: z.string().trim().min(2).max(80), phone: z.string().trim().regex(/^(\+?\d[\d\s-]{8,16})$/) }).safeParse({ name: fd.get("name"), phone: fd.get("phone") });
  if (!s.success) return { error: "Enter your name and a valid mobile number." };
  await db.update(schema.customers).set({ name: s.data.name, phone: s.data.phone.replace(/[\s-]/g, ""), marketingOptIn: fd.get("optin") === "on" }).where(eq(schema.customers.id, c.id));
  revalidatePath("/account", "layout");
  return { ok: "Profile saved." };
}

export async function changePassword(_: AState, fd: FormData): Promise<AState> {
  const c = await me();
  const [row] = await db.select({ h: schema.customers.passwordHash }).from(schema.customers).where(eq(schema.customers.id, c.id));
  if (!row || !(await verifyPassword(String(fd.get("current") ?? ""), row.h))) return { error: "Your current password is incorrect." };
  const next = String(fd.get("next") ?? "");
  const p = passwordProblem(next); if (p) return { error: p };
  if (next !== String(fd.get("confirm") ?? "")) return { error: "The new passwords don’t match." };
  await db.update(schema.customers).set({ passwordHash: await hashPassword(next) }).where(eq(schema.customers.id, c.id));
  return { ok: "Password changed." };
}

// ─────────── Addresses ───────────
const addr = z.object({
  name: z.string().trim().min(2).max(80),
  phone: z.string().transform((v) => v.replace(/\D/g, "").slice(-10)).pipe(z.string().regex(/^[6-9]\d{9}$/, "Enter a 10-digit Indian mobile number")),
  line1: z.string().trim().min(4, "Add house / street").max(160), line2: z.string().trim().max(160).optional(),
  city: z.string().trim().min(2).max(60), state: z.string().trim().min(2).max(60),
  pincode: z.string().trim().regex(/^\d{6}$/, "Enter a 6-digit PIN code"),
});
export async function saveAddress(_: AState, fd: FormData): Promise<AState> {
  const c = await me();
  const s = addr.safeParse(Object.fromEntries(fd));
  if (!s.success) return { error: s.error.issues[0]?.message ?? "Please check the address." };
  const id = String(fd.get("id") ?? "");
  const isDefault = fd.get("isDefault") === "on";
  if (isDefault) await db.update(schema.addresses).set({ isDefault: false }).where(eq(schema.addresses.customerId, c.id));
  const values = { ...s.data, line2: s.data.line2 || null, isDefault };
  if (id) {
    const r = await db.update(schema.addresses).set(values).where(and(eq(schema.addresses.id, id), eq(schema.addresses.customerId, c.id))).returning({ id: schema.addresses.id });
    if (!r.length) return { error: "Address not found." };
  } else {
    const count = (await db.select({ id: schema.addresses.id }).from(schema.addresses).where(eq(schema.addresses.customerId, c.id))).length;
    if (count >= 10) return { error: "You can save up to 10 addresses." };
    await db.insert(schema.addresses).values({ ...values, customerId: c.id, isDefault: isDefault || count === 0 });
  }
  revalidatePath("/account/addresses");
  return { ok: id ? "Address updated." : "Address added." };
}
export async function deleteAddress(fd: FormData) {
  const c = await me();
  await db.delete(schema.addresses).where(and(eq(schema.addresses.id, String(fd.get("id"))), eq(schema.addresses.customerId, c.id)));
  revalidatePath("/account/addresses");
}
export async function makeDefaultAddress(fd: FormData) {
  const c = await me();
  const id = String(fd.get("id"));
  await db.update(schema.addresses).set({ isDefault: false }).where(eq(schema.addresses.customerId, c.id));
  await db.update(schema.addresses).set({ isDefault: true }).where(and(eq(schema.addresses.id, id), eq(schema.addresses.customerId, c.id)));
  revalidatePath("/account/addresses");
}

// ─────────── Wishlist ───────────
export async function toggleWishlist(fd: FormData) {
  const c = await getCustomer();
  const productId = String(fd.get("productId") ?? "");
  const back = String(fd.get("back") ?? "/account/wishlist");
  if (!c) redirect(`/login?next=${encodeURIComponent(back)}`);
  const [p] = await db.select({ id: schema.products.id }).from(schema.products).where(eq(schema.products.id, productId));
  if (!p) return;
  const [has] = await db.select().from(schema.wishlist).where(and(eq(schema.wishlist.customerId, c.id), eq(schema.wishlist.productId, productId)));
  if (has) await db.delete(schema.wishlist).where(and(eq(schema.wishlist.customerId, c.id), eq(schema.wishlist.productId, productId)));
  else await db.insert(schema.wishlist).values({ customerId: c.id, productId }).onConflictDoNothing();
  revalidatePath("/account/wishlist"); revalidatePath(back.startsWith("/") ? back : "/");
}

// ─────────── Support ───────────
export async function newTicket(_: AState, fd: FormData): Promise<AState> {
  const c = await me();
  const subject = String(fd.get("subject") ?? "").trim().slice(0, 120);
  const message = String(fd.get("message") ?? "").trim().slice(0, 4000);
  const orderNumber = String(fd.get("orderNumber") ?? "").trim().toUpperCase().slice(0, 30) || null;
  if (subject.length < 3 || message.length < 10) return { error: "Add a subject and a message of at least 10 characters." };
  if (orderNumber) {
    const [o] = await db.select({ id: schema.orders.id }).from(schema.orders).where(and(eq(schema.orders.number, orderNumber), eq(schema.orders.customerId, c.id)));
    if (!o) return { error: "That order number isn’t on your account." };
  }
  const number = `T${Date.now().toString(36).toUpperCase()}`;
  await db.insert(schema.supportTickets).values({ number, name: c.name, email: c.email, phone: c.phone, subject, message, orderNumber });
  await notifyTeams(["tech-support"], `New ticket ${number}: ${subject}`, `${c.name} · ${c.email} (account)`, "/team/tickets");
  revalidatePath("/account/support");
  const { t } = await getI18n();
  return { ok: t("Sent. Your reference is {number} — we reply within one working day.", { number }) };
}
export async function replyTicket(_: AState, fd: FormData): Promise<AState> {
  const c = await me();
  const body = String(fd.get("body") ?? "").trim().slice(0, 4000);
  if (body.length < 2) return { error: "Write a reply first." };
  const [t] = await db.select().from(schema.supportTickets).where(and(eq(schema.supportTickets.id, String(fd.get("id"))), eq(schema.supportTickets.email, c.email)));
  if (!t) return { error: "Ticket not found." };
  await db.update(schema.supportTickets).set({ replies: [...t.replies, { by: c.name, staff: false, body, at: new Date().toISOString() }], status: "OPEN" }).where(eq(schema.supportTickets.id, t.id));
  await notifyTeams(["tech-support"], `Customer replied on ${t.number}`, t.subject, `/team/tickets/${t.id}`);
  revalidatePath("/account/support");
  return { ok: "Reply sent." };
}
