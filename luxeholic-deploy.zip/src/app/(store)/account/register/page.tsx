import type { Metadata } from "next";
import Link from "next/link";
import { AuthForm } from "@/components/store/auth-form";
import { getI18n } from "@/lib/i18n/server";

export async function generateMetadata(): Promise<Metadata> {
  return { title: (await getI18n()).t("Create account"), robots: { index: false } };
}
export default async function Register({ searchParams }: { searchParams: Promise<{ next?: string }> }) {
  const { next } = await searchParams;
  const { t } = await getI18n();
  return (
    <div className="container-lx max-w-md py-16">
      <p className="eyebrow">{t("Join Luxeholic")}</p><h1 className="h-display mt-3 text-5xl">{t("Create your account")}</h1>
      <AuthForm mode="register" next={next} />
      <p className="mt-8 text-sm text-ink-soft">{t("Already have an account?")} <Link href="/login" className="underline">{t("Sign in")}</Link> · <Link href="/login?as=guest" className="underline">{t("continue as guest")}</Link></p>
    </div>
  );
}
