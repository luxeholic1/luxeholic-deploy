"use server";
import { redirect } from "next/navigation";
import { forgetGuestOrders } from "@/lib/auth";
export async function forgetGuest() { await forgetGuestOrders(); redirect("/guest"); }
