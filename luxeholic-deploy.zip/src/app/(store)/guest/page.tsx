import type { Metadata } from "next";
import Link from "next/link";
import { redirect } from "next/navigation";
import { inArray } from "drizzle-orm";
import { db, schema } from "@/db";
import { getCustomer, getGuestOrders } from "@/lib/auth";
import { getI18n } from "@/lib/i18n/server";
import { formatMoney, LOCALE_INFO } from "@/lib/i18n/config";
import { prettyDateTime } from "@/lib/dates";
import { ORDER_LABEL, PAY_LABEL } from "@/lib/order-labels";
import { TrackForm } from "@/components/store/track-form";
import { CallbackButton } from "@/components/store/callback";
import { forgetGuest } from "./actions";

export async function generateMetadata(): Promise<Metadata> {
  return { title: (await getI18n()).t("Guest orders"), robots: { index: false } };
}

export default async function Guest() {
  if (await getCustomer()) redirect("/account");
  const refs = await getGuestOrders();
  const { t, locale } = await getI18n();
  const formatINR = (p: number) => formatMoney(p, "INR", {}, locale);
  const intl = LOCALE_INFO[locale].intl;
  const found = refs.length ? await db.select().from(schema.orders).where(inArray(schema.orders.number, refs.map((r) => r.n))) : [];
  // only show orders whose secret token matches the one saved on this device
  const orders = refs.map((r) => found.find((o) => o.number === r.n && o.accessToken === r.t)).filter((o): o is NonNullable<typeof o> => !!o);
  return (
    <div className="container-lx py-12">
      <p className="eyebrow">{t("Guest")}</p>
      <h1 className="h-display mt-3 text-4xl sm:text-5xl">{t("Your guest orders")}</h1>
      <p className="mt-3 max-w-2xl text-ink-soft">{t("No account needed. Orders you place or look up as a guest on this device are listed here for 90 days. Your order link is also in your confirmation email.")}</p>
      <div className="mt-10 grid gap-10 lg:grid-cols-[1fr_360px]">
        <section>
          <h2 className="eyebrow !text-ink">{t("On this device")}</h2>
          {orders.length === 0 ? (
            <div className="mt-4 card-lx p-6 text-sm text-ink-soft">{t("No guest orders on this device yet.")} <Link href="/shop" className="underline">{t("Start shopping")}</Link> — {t("or find an earlier order with its number and email.")}</div>
          ) : (
            <ul className="mt-4 space-y-3">
              {orders.map((o) => (
                <li key={o.id} className="card-lx flex flex-wrap items-center justify-between gap-3 p-5">
                  <span><span className="font-medium">{o.number}</span><span className="block text-xs text-ink-mute">{prettyDateTime(o.createdAt, intl)}</span></span>
                  <span className="text-sm">{t(ORDER_LABEL[o.status])} · {t(PAY_LABEL[o.paymentStatus])} · {formatINR(o.total)}</span>
                  <Link href={`/order/${o.number}?t=${o.accessToken}`} className="btn-ink !px-5 !py-2.5">{t("View & track")}</Link>
                </li>
              ))}
            </ul>
          )}
          {orders.length > 0 && <form action={forgetGuest} className="mt-3"><button className="text-xs text-ink-mute underline">{t("Remove these orders from this device")}</button></form>}
          <div className="mt-10 card-lx p-6">
            <p className="font-display text-2xl">{t("Keep everything in one place")}</p>
            <p className="mt-2 text-sm text-ink-soft">{t("Create an account on this device with the email you ordered with — your guest orders move into it, with a wishlist, saved addresses and faster checkout.")}</p>
            <div className="mt-4 flex flex-wrap gap-3"><Link href="/account/register" className="btn-ink !py-3">{t("Create an account")}</Link><Link href="/login" className="btn-line !py-3">{t("Sign in")}</Link></div>
          </div>
        </section>
        <aside className="space-y-6">
          <div className="card-lx p-6"><p className="font-display text-2xl">{t("Find an order")}</p><p className="mb-4 mt-1 text-sm text-ink-soft">{t("Order number and the email used at checkout.")}</p><TrackForm /></div>
          <div className="card-lx p-6"><p className="font-display text-2xl">{t("Need help?")}</p><p className="mt-1 text-sm text-ink-soft">{t("Write to client care or ask us to call you.")}</p><div className="mt-4 flex flex-wrap gap-3"><Link href="/contact" className="btn-line !py-2.5">{t("Write to us")}</Link><CallbackButton className="btn-line !py-2.5">{t("Call me back")}</CallbackButton></div></div>
        </aside>
      </div>
    </div>
  );
}
