import Script from "next/script";
import { CartProvider } from "@/components/store/cart";
import { Header } from "@/components/store/header";
import { Footer } from "@/components/store/footer";
import { BagDrawer } from "@/components/store/bag-drawer";
import { ConsentManager } from "@/components/store/consent";
import { CallbackDialog, CallbackButton } from "@/components/store/callback";
import { getLocalizedTree } from "@/lib/catalog";
import { getSettings } from "@/lib/settings";
import { getCustomer } from "@/lib/auth";
import { SITE_NAME, SITE_URL } from "@/lib/site";
import { I18nProvider } from "@/lib/i18n/client";
import { getI18n } from "@/lib/i18n/server";
import { siteTexts } from "@/lib/i18n/content";

export const dynamic = "force-dynamic";

export default async function StoreLayout({ children }: { children: React.ReactNode }) {
  const [settings, customer, i18n] = await Promise.all([getSettings(), getCustomer(), getI18n()]);
  const { t: tr, locale } = i18n;
  const tree = await getLocalizedTree(locale);
  const { announcement } = await siteTexts({ announcement: settings.announcement }, locale, "hide");
  const b = settings.business;
  const t = settings.tracking;
  const org = {
    "@context": "https://schema.org",
    "@type": "OnlineStore",
    name: SITE_NAME,
    legalName: b.legalName || undefined,
    url: SITE_URL,
    logo: `${SITE_URL}/brand/logo-full-dark.png`,
    email: b.email,
    telephone: b.phone || undefined,
    address: { "@type": "PostalAddress", streetAddress: [b.addressLine1, b.addressLine2].filter(Boolean).join(", ") || undefined, addressLocality: b.city, addressRegion: b.state, postalCode: b.pincode || undefined, addressCountry: "IN" },
    contactPoint: { "@type": "ContactPoint", contactType: "customer service", email: b.email, telephone: b.phone || undefined, areaServed: "IN", availableLanguage: ["English", "Hindi"] },
    sameAs: [b.instagram, b.facebook, b.pinterest, b.youtube, ...Object.values(settings.marketplaces)].filter(Boolean),
    hasMerchantReturnPolicy: { "@type": "MerchantReturnPolicy", applicableCountry: "IN", returnPolicyCategory: "https://schema.org/MerchantReturnFiniteReturnWindow", merchantReturnDays: settings.returns.windowDays, returnMethod: "https://schema.org/ReturnByMail", returnFees: "https://schema.org/FreeReturn" },
  };
  const gtagIds = [t.ga4Id, t.googleAdsId].filter(Boolean);
  return (
    <I18nProvider value={{ locale, currency: i18n.currency, rates: i18n.rates, dict: i18n.dict, languages: i18n.languages }}>
    <CartProvider>
      {t.gmcVerification && <meta name="google-site-verification" content={t.gmcVerification} />}
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(org) }} />
      {gtagIds.length > 0 && (
        <>
          <Script id="consent-default" strategy="beforeInteractive">{`window.dataLayer=window.dataLayer||[];function gtag(){dataLayer.push(arguments)}gtag('consent','default',{ad_storage:'denied',ad_user_data:'denied',ad_personalization:'denied',analytics_storage:'denied',wait_for_update:500});try{if(localStorage.getItem('lx_consent')==='granted'){gtag('consent','update',{ad_storage:'granted',ad_user_data:'granted',ad_personalization:'granted',analytics_storage:'granted'})}}catch(e){}`}</Script>
          <Script src={`https://www.googletagmanager.com/gtag/js?id=${gtagIds[0]}`} strategy="afterInteractive" />
          <Script id="gtag-init" strategy="afterInteractive">{`gtag('js',new Date());${gtagIds.map((id) => `gtag('config','${id}');`).join("")}`}</Script>
        </>
      )}
      <Header tree={tree.map((c) => ({ slug: c.slug, name: c.name, tagline: c.tagline, children: c.children.map((s) => ({ slug: s.slug, name: s.name })) }))} announcement={announcement} signedIn={!!customer} tm={settings.business.trademark} />
      <main>{children}</main>
      <Footer settings={settings} tree={tree.map((c) => ({ slug: c.slug, name: c.name }))} />
      <BagDrawer advancePercent={settings.payments.advancePercent} />
      <ConsentManager tagsOn={gtagIds.length > 0} />
      <CallbackDialog phone={b.phone || "+91 92664 33722"} whatsapp={b.whatsapp || b.phone || "919266433722"} />
      <CallbackButton className="fixed bottom-4 left-4 z-40 flex items-center gap-2 bg-ink px-4 py-3 text-[11px] font-medium uppercase tracking-[0.2em] text-ivory shadow-xl transition hover:bg-gold-dark">
        <svg aria-hidden="true" viewBox="0 0 24 24" width="15" height="15" fill="none" stroke="currentColor" strokeWidth="1.7"><path d="M22 16.9v3a2 2 0 0 1-2.2 2 19.8 19.8 0 0 1-8.6-3.1 19.5 19.5 0 0 1-6-6A19.8 19.8 0 0 1 2.1 4.2 2 2 0 0 1 4.1 2h3a2 2 0 0 1 2 1.7c.1.9.4 1.8.7 2.7a2 2 0 0 1-.5 2.1L8 9.8a16 16 0 0 0 6 6l1.3-1.3a2 2 0 0 1 2.1-.4c.9.3 1.8.6 2.7.7a2 2 0 0 1 1.7 2z"/></svg>
        <span className="hidden sm:inline">{tr("Request a call back")}</span><span className="sm:hidden">{tr("Call back")}</span>
      </CallbackButton>
    </CartProvider>
    </I18nProvider>
  );
}

