"use server";
import { cookies } from "next/headers";
import { CUR_COOKIE, LANG_COOKIE, isCurrency, isLocale } from "@/lib/i18n/config";
import { getSettings } from "@/lib/settings";

/** Save the visitor's language / currency choice (1 year). The page re-renders fully in the new language. */
export async function setPrefs(fd: FormData) {
  const c = await cookies();
  const s = await getSettings();
  const year = { path: "/", maxAge: 60 * 60 * 24 * 365, sameSite: "lax" as const };
  const lang = fd.get("lang"), cur = fd.get("cur");
  if (isLocale(lang) && (s.display.languages ?? ["en"]).includes(lang)) c.set(LANG_COOKIE, lang, year);
  if (isCurrency(cur) && (cur === "INR" || s.display.rates[cur])) c.set(CUR_COOKIE, cur, year);
}
