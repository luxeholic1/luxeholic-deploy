import type { Metadata } from "next";
import { getSettings } from "@/lib/settings";
import { formatINR } from "@/lib/money";
import { PageHead } from "@/components/store/listing";
import { getI18n } from "@/lib/i18n/server";

export async function generateMetadata(): Promise<Metadata> {
  const { t } = await getI18n();
  return { title: t("FAQ"), alternates: { canonical: "/faq" } };
}

export default async function Faq() {
  const [s, { t }] = await Promise.all([getSettings(), getI18n()]);
  // Policy amounts are always stated in rupees — that is what the customer is charged.
  const qa: [string, string][] = [
    [t("Are the designer products authentic?"), t("Yes — 100%. They come through established European luxury distributors with original tags and packaging. See our Authenticity Promise.")],
    [t("How does “pay 10% now” work?"), t("Pay a {pct}% advance online to confirm your order (UPI, card or PhonePe). Pay the rest in cash or UPI when it’s delivered. Available on orders up to {max}.", { pct: s.payments.advancePercent, max: formatINR(s.payments.partialCodMaxOrder) })],
    [t("Is shipping really free?"), t("Yes. Every order ships free and insured across India, with tracking.")],
    [t("How long will delivery take?"), t("Usually 7–15 business days depending on the piece; each product page shows an estimated delivery window.")],
    [t("Can I return something?"), t("Yes, within {n} days of delivery, with free pickup. Refunds reach you within 5–7 business days after inspection.", { n: s.returns.windowDays })],
    [t("Do you provide GST invoices?"), t("Yes, with every order. Add your GSTIN at checkout for a business invoice.")],
    [t("Do you offer corporate or bulk gifting?"), t("We do — write to us via the contact page with quantities and dates, and our team will curate options for you.")],
    [t("Can I see prices in another currency?"), t("Yes. Use the globe button at the top of the page. Prices are converted for display only; you pay in Indian rupees (₹) at checkout.")],
  ];
  const ld = { "@context": "https://schema.org", "@type": "FAQPage", mainEntity: qa.map(([q, a]) => ({ "@type": "Question", name: q, acceptedAnswer: { "@type": "Answer", text: a } })) };
  return (
    <div className="container-lx max-w-3xl pb-10">
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(ld) }} />
      <PageHead eyebrow={t("Client care")} title={t("Questions, answered.")} />
      <div className="divide-y divide-ivory-line border-y border-ivory-line">
        {qa.map(([q, a]) => (
          <details key={q} className="group py-5"><summary className="flex cursor-pointer list-none justify-between font-display text-xl">{q}<span className="transition group-open:rotate-45">+</span></summary><p className="mt-3 text-ink-soft">{a}</p></details>
        ))}
      </div>
    </div>
  );
}
