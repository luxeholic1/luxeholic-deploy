import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { getLocalizedCategory } from "@/lib/catalog";
import { getI18n } from "@/lib/i18n/server";
import { Listing, PageHead } from "@/components/store/listing";
import { SITE_URL } from "@/lib/site";
import { CATEGORY_FILMS } from "@/lib/films";
import { ScrollVideo } from "@/components/store/scroll-video";

type P = { params: Promise<{ slug: string }>; searchParams: Promise<Record<string, string>> };

export async function generateMetadata({ params }: P): Promise<Metadata> {
  const { t, locale } = await getI18n();
  const r = await getLocalizedCategory((await params).slug, locale);
  if (!r) return { robots: { index: false } };
  const c = r.category;
  return {
    title: r.parent ? `${c.name} — ${r.parent.name}` : c.name,
    description: c.description || `${t("Shop {name} at Luxeholic.", { name: locale === "en" ? c.name.toLowerCase() : c.name })} ${c.tagline ?? ""} ${t("GST-inclusive prices, complimentary insured shipping across India.")}`,
    alternates: { canonical: `/c/${c.slug}` },
  };
}

export default async function CategoryPage({ params, searchParams }: P) {
  const [{ slug }, sp] = await Promise.all([params, searchParams]);
  const { t, locale } = await getI18n();
  const r = await getLocalizedCategory(slug, locale);
  if (!r) notFound();
  const { category: c, parent, children } = r;
  const ids = children.length ? [c.id, ...children.map((x) => x.id)] : [c.id];
  const crumbs = [{ href: "/", label: t("Home") }, ...(parent ? [{ href: `/c/${parent.slug}`, label: parent.name }] : []), { href: `/c/${c.slug}`, label: c.name }];
  const ld = { "@context": "https://schema.org", "@type": "BreadcrumbList", itemListElement: crumbs.map((x, i) => ({ "@type": "ListItem", position: i + 1, name: x.label, item: SITE_URL + x.href })) };
  const films = locale === "en" ? CATEGORY_FILMS[c.slug] ?? [] : []; // film captions are English-only
  return (
    <>
    <div className="container-lx">
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(ld) }} />
      <PageHead crumbs={crumbs} eyebrow={parent?.name ?? t("Collection")} title={c.name} intro={c.description ?? c.tagline} />
      {children.length > 0 && (
        <div className="no-scrollbar -mx-4 mb-8 flex gap-2 overflow-x-auto px-4 md:mx-0 md:flex-wrap md:px-0">
          {children.map((s) => (
            <Link key={s.slug} href={`/c/${s.slug}`} className="whitespace-nowrap border border-ivory-line bg-white/50 px-4 py-2.5 font-display text-lg transition hover:border-ink">{s.name}</Link>
          ))}
        </div>
      )}
      {parent && (
        <div className="no-scrollbar -mx-4 mb-8 flex gap-4 overflow-x-auto px-4 text-sm text-ink-mute md:mx-0 md:px-0">
          <Link href={`/c/${parent.slug}`} className="whitespace-nowrap hover:text-ink">← {t("All {name}", { name: parent.name })}</Link>
        </div>
      )}
    </div>
    {films.length > 0 && <div className="mb-14">{films.map((f) => <ScrollVideo key={f.id} film={f} />)}</div>}
    <div className="container-lx">
      <Listing base={`/c/${c.slug}`} sp={sp} filter={{ categoryIds: ids }} />
    </div>
    </>
  );
}
