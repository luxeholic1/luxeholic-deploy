import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { businessAddress, getSettings } from "@/lib/settings";
import { policyHtml } from "@/lib/policies";
import { policyHtmlHi } from "@/lib/policies-hi";
import { POLICY_PAGES } from "@/lib/site";
import { PageHead } from "@/components/store/listing";
import { getI18n } from "@/lib/i18n/server";
import { businessTexts } from "@/lib/i18n/content";
import { LOCALE_INFO } from "@/lib/i18n/config";

type P = { params: Promise<{ slug: string }> };
export async function generateMetadata({ params }: P): Promise<Metadata> {
  const slug = (await params).slug;
  const page = POLICY_PAGES.find((x) => x.slug === slug);
  const { t } = await getI18n();
  return page ? { title: t(page.title), alternates: { canonical: `/policies/${slug}` } } : {};
}
export default async function Policy({ params }: P) {
  const { slug } = await params;
  const [settings, { t, locale }] = await Promise.all([getSettings(), getI18n()]);
  const page = POLICY_PAGES.find((x) => x.slug === slug);
  const b = settings.business;
  const html = page && (locale === "hi"
    ? policyHtmlHi(slug, settings, await businessTexts(b, businessAddress(b), locale))
    : policyHtml(slug, settings));
  if (!page || !html) notFound();
  return (
    <div className="container-lx max-w-3xl pb-10">
      <PageHead eyebrow={t("Client care")} title={t(page.title)} />
      <article className="prose-lx text-[15px] text-ink-soft" dangerouslySetInnerHTML={{ __html: html }} />
      <p className="mt-10 text-xs text-ink-mute">{t("Last updated {date}", { date: new Date().toLocaleDateString(LOCALE_INFO[locale].intl, { month: "long", year: "numeric" }) })}</p>
    </div>
  );
}
