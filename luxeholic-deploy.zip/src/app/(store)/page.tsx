import Link from "next/link";
import { ArrowRight } from "lucide-react";
import { getLocalizedTree, listProducts } from "@/lib/catalog";
import { getI18n } from "@/lib/i18n/server";
import { getSettings } from "@/lib/settings";
import { PRICE_TIERS, tierLine } from "@/lib/money";
import { ProductCard } from "@/components/store/product-card";
import { ArtPlaceholder } from "@/components/store/art";
import { SubscribeForm } from "@/components/store/subscribe-form";
import { MarketplaceStrip } from "@/components/store/marketplaces";
import { ScrollHero } from "@/components/store/scroll-hero";
import { getLocalizedHero } from "@/lib/hero";

export default async function Home() {
  const { t, money, locale } = await getI18n();
  const [tree, featured, fresh, firstLuxe, settings, hero] = await Promise.all([
    getLocalizedTree(locale),
    listProducts({ featured: true, perPage: 8, locale }),
    listProducts({ sort: "new", perPage: 4, locale }),
    listProducts({ maxPrice: 500000, perPage: 4, sort: "featured", locale }),
    getSettings(),
    getLocalizedHero(locale),
  ]);
  const pay = settings.payments;
  return (
    <>
      <ScrollHero hero={hero} />

      {/* Promise strip */}
      <section className="border-b border-ivory-line bg-ivory-deep/60">
        <div className="container-lx grid grid-cols-2 gap-6 py-7 text-center md:grid-cols-4">
          {[
            [t("Complimentary"), t("insured shipping")],
            [t("Pay {pct}% now", { pct: pay.advancePercent }), t("rest on delivery")],
            [t("{n}-day", { n: settings.returns.windowDays }), t("easy returns")],
            [t("Authenticity"), t("guaranteed")],
          ].map(([a, b]) => (
            <div key={a}><p className="font-display text-xl">{a}</p><p className="eyebrow mt-1 !text-[10px]">{b}</p></div>
          ))}
        </div>
      </section>

      {/* A door for every home — price tiers */}
      <section className="container-lx py-20 lg:py-28">
        <div className="max-w-2xl">
          <p className="eyebrow">{t("A door for every home")}</p>
          <h2 className="h-display mt-4 text-4xl sm:text-6xl">{t("Luxury isn’t a price.")} <em>{t("It’s a feeling.")}</em></h2>
          <p className="mt-5 text-ink-soft">{t("Whether it’s your first beautiful thing or your hundredth, there’s a piece waiting for you.")}</p>
        </div>
        <div className="mt-12 grid gap-4 md:grid-cols-3">
          {PRICE_TIERS.map((tier, i) => (
            <Link key={tier.slug} href={`/collections/${tier.slug}`} className={`group relative flex min-h-[260px] flex-col justify-between overflow-hidden p-8 transition ${i === 2 ? "bg-ink text-ivory" : i === 1 ? "bg-ivory-deep" : "border border-ivory-line bg-white/50"}`}>
              <p className={`eyebrow ${i === 2 ? "!text-ivory/60" : ""}`}>0{i + 1}</p>
              <div>
                <h3 className="h-display text-5xl">{t(tier.name)}</h3>
                <p className={`mt-2 text-sm ${i === 2 ? "text-ivory/70" : "text-ink-mute"}`}>{tierLine(tier, t, money)}</p>
                <span className="mt-6 inline-flex items-center gap-2 text-[11px] uppercase tracking-[0.22em]">{t("Explore")} <ArrowRight size={14} className="transition group-hover:translate-x-1" /></span>
              </div>
            </Link>
          ))}
        </div>
      </section>

      {/* Categories gallery */}
      <section className="border-y border-ivory-line bg-white/40 py-20 lg:py-28">
        <div className="container-lx">
          <div className="flex items-end justify-between gap-6">
            <div><p className="eyebrow">{t("The houses of Luxeholic")}</p><h2 className="h-display mt-4 text-4xl sm:text-6xl">{t("Five worlds, one eye.")}</h2></div>
            <Link href="/shop" className="link-u hidden text-[11px] uppercase tracking-[0.22em] sm:block">{t("Shop everything")}</Link>
          </div>
          <div className="mt-12 grid grid-cols-2 gap-4 lg:grid-cols-5">
            {tree.map((c, i) => (
              <Link key={c.slug} href={`/c/${c.slug}`} className={`group ${i === 0 ? "col-span-2 lg:col-span-1" : ""}`}>
                <div className="relative aspect-[3/4] overflow-hidden bg-ivory-deep">
                  {c.image ? (
                    // eslint-disable-next-line @next/next/no-img-element
                    <img src={c.image} alt={c.name} className="h-full w-full object-cover transition duration-[1.2s] group-hover:scale-105" />
                  ) : (
                    <ArtPlaceholder seed={c.slug + "x"} className="h-full w-full transition duration-[1.2s] group-hover:scale-105" />
                  )}
                </div>
                <p className="mt-4 font-display text-2xl">{c.name}</p>
                <p className="text-xs text-ink-mute">{c.tagline}</p>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* Featured */}
      {featured.products.length > 0 && (
        <section className="container-lx py-20 lg:py-28">
          <div className="flex items-end justify-between"><div><p className="eyebrow">{t("Curator’s choice")}</p><h2 className="h-display mt-4 text-4xl sm:text-5xl">{t("Pieces we can’t stop looking at")}</h2></div></div>
          <div className="mt-12 grid grid-cols-2 gap-x-4 gap-y-10 sm:gap-x-6 lg:grid-cols-4">
            {featured.products.map((p, i) => <ProductCard key={p.id} p={p} priority={i < 4} />)}
          </div>
        </section>
      )}

      {/* New in the city */}
      <section className="bg-ink text-ivory">
        <div className="container-lx grid gap-12 py-20 lg:grid-cols-2 lg:py-28">
          <div>
            <p className="eyebrow !text-ivory/60">{t("Our promise")}</p>
            <h2 className="h-display mt-5 text-4xl sm:text-6xl">{t("We’re new here.")}<br /><em className="text-gold-light">{t("So we’ll work harder.")}</em></h2>
          </div>
          <div className="grid gap-8 sm:grid-cols-2">
            {[
              [t("Inspected by hand"), t("Every piece is checked, photographed and packed by our team before it travels to you.")],
              [t("Pay how you like"), t("UPI, cards, PhonePe, bank transfer — or pay just {pct}% now and the rest on delivery.", { pct: pay.advancePercent })],
              [t("Insured to your door"), t("Complimentary insured shipping across India with tracking from dispatch to doorstep.")],
              [t("A real person, always"), t("Call, WhatsApp or write to us. A member of our client-care team replies within a working day.")],
            ].map(([h, body]) => (
              <div key={h} className="border-t border-ivory/15 pt-5"><p className="font-display text-2xl">{h}</p><p className="mt-2 text-sm leading-relaxed text-ivory/70">{body}</p></div>
            ))}
          </div>
        </div>
      </section>

      <MarketplaceStrip links={settings.marketplaces} />

      {/* First Luxe + New */}
      {firstLuxe.products.length > 0 && (
        <section className="container-lx py-20 lg:py-28">
          <div className="flex items-end justify-between gap-6">
            <div><p className="eyebrow">{t("First Luxe")}</p><h2 className="h-display mt-4 text-4xl sm:text-5xl">{t("Your first beautiful thing, under {price}", { price: money(500000) })}</h2></div>
            <Link href="/collections/first-luxe" className="link-u hidden text-[11px] uppercase tracking-[0.22em] sm:block">{t("View all")}</Link>
          </div>
          <div className="mt-12 grid grid-cols-2 gap-x-4 gap-y-10 sm:gap-x-6 lg:grid-cols-4">
            {firstLuxe.products.map((p) => <ProductCard key={p.id} p={p} />)}
          </div>
        </section>
      )}
      {fresh.products.length > 0 && (
        <section className="container-lx pb-20 lg:pb-28">
          <div className="flex items-end justify-between gap-6">
            <div><p className="eyebrow">{t("Just arrived")}</p><h2 className="h-display mt-4 text-4xl sm:text-5xl">{t("New this week")}</h2></div>
            <Link href="/collections/new-arrivals" className="link-u hidden text-[11px] uppercase tracking-[0.22em] sm:block">{t("View all")}</Link>
          </div>
          <div className="mt-12 grid grid-cols-2 gap-x-4 gap-y-10 sm:gap-x-6 lg:grid-cols-4">
            {fresh.products.map((p) => <ProductCard key={p.id} p={p} />)}
          </div>
        </section>
      )}

      {/* Circle */}
      <section className="container-lx">
        <div className="grid items-center gap-10 border border-ivory-line bg-white/50 p-8 sm:p-14 lg:grid-cols-2">
          <div><p className="eyebrow">{t("The Luxeholic Circle")}</p><h2 className="h-display mt-4 text-4xl">{t("First looks, private previews, and gifting notes before every festival.")}</h2></div>
          <SubscribeForm tone="light" />
        </div>
      </section>
    </>
  );
}
