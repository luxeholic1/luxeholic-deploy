import type { Metadata } from "next";
import { PageHead } from "@/components/store/listing";
import { TrackForm } from "@/components/store/track-form";
import { getI18n } from "@/lib/i18n/server";

export async function generateMetadata(): Promise<Metadata> {
  return { title: (await getI18n()).t("Track Your Order"), alternates: { canonical: "/track-order" } };
}
export default async function Track() {
  const { t } = await getI18n();
  return <div className="container-lx max-w-xl pb-10"><PageHead eyebrow={t("Client care")} title={t("Track your order")} intro={t("Enter your order number and the email you used at checkout.")} /><TrackForm /></div>;
}
