"use server";
import { inArray } from "drizzle-orm";
import { db, schema } from "@/db";
import { getI18n } from "@/lib/i18n/server";
import { localize } from "@/lib/i18n/content";

/** Bag lines are saved in the browser; when the language changes, re-label them from the catalogue. */
export async function bagLabels(lines: { productId: string; variantId?: string | null }[]) {
  const { locale } = await getI18n();
  const pids = [...new Set(lines.map((l) => l.productId))].slice(0, 50);
  const vids = [...new Set(lines.map((l) => l.variantId).filter((v): v is string => !!v))].slice(0, 50);
  if (!pids.length) return {};
  const [prods, vars] = await Promise.all([
    db.select({ id: schema.products.id, title: schema.products.title }).from(schema.products).where(inArray(schema.products.id, pids)),
    vids.length ? db.select({ id: schema.productVariants.id, name: schema.productVariants.name }).from(schema.productVariants).where(inArray(schema.productVariants.id, vids)) : Promise.resolve([]),
  ]);
  const p = new Map((await localize("product", prods, locale)).items.map((x) => [x.id, x.title]));
  const v = new Map((await localize("variant", vars, locale)).items.map((x) => [x.id, x.name]));
  const out: Record<string, { title: string | null; variant: string | null }> = {};
  for (const l of lines) out[`${l.productId}:${l.variantId ?? ""}`] = { title: p.get(l.productId) ?? null, variant: l.variantId ? v.get(l.variantId) ?? null : null };
  return out;
}
