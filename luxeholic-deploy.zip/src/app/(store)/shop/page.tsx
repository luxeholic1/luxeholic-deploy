import type { Metadata } from "next";
import { Listing, PageHead } from "@/components/store/listing";
import { getI18n } from "@/lib/i18n/server";

export async function generateMetadata(): Promise<Metadata> {
  const { t } = await getI18n();
  return { title: t("Shop the Collection"), alternates: { canonical: "/shop" } };
}

export default async function Shop({ searchParams }: { searchParams: Promise<Record<string, string>> }) {
  const sp = await searchParams;
  const { t } = await getI18n();
  return (
    <div className="container-lx">
      <PageHead eyebrow={t("The collection")} title={t("Everything Luxeholic")} intro={t("Sculpture, décor, designer fashion, gifts and Lux-Tech — every piece hand-picked.")} />
      <Listing base="/shop" sp={sp} filter={{}} />
    </div>
  );
}
