import type { Metadata } from "next";
import { BagPage } from "@/components/store/bag-page";
import { getI18n } from "@/lib/i18n/server";

export async function generateMetadata(): Promise<Metadata> {
  return { title: (await getI18n()).t("Your Bag"), robots: { index: false } };
}
export default async function Cart() {
  const { t } = await getI18n();
  return <div className="container-lx py-14"><h1 className="h-display text-5xl">{t("Your bag")}</h1><BagPage /></div>;
}
