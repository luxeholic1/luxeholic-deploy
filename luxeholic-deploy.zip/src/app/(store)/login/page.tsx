import type { Metadata } from "next";
import { redirect } from "next/navigation";
import { asc } from "drizzle-orm";
import { db, schema } from "@/db";
import { getCustomer, getStaff } from "@/lib/auth";
import { LoginTabs } from "@/components/store/login-tabs";
import { getI18n } from "@/lib/i18n/server";

export async function generateMetadata(): Promise<Metadata> {
  return { title: (await getI18n()).t("Sign in"), robots: { index: false } };
}

/** One sign-in page with three doors: Customer (default), Guest, Luxeholic Team. */
export default async function Login({ searchParams }: { searchParams: Promise<{ as?: string; next?: string }> }) {
  const sp = await searchParams;
  const as = sp.as === "team" || sp.as === "guest" ? sp.as : "customer";
  if (as === "customer" && (await getCustomer())) redirect(sp.next?.startsWith("/") ? sp.next : "/account");
  if (as === "team" && (await getStaff())) redirect("/team");
  const { t } = await getI18n();
  const teams = await db.select({ slug: schema.teams.slug, name: schema.teams.name }).from(schema.teams).orderBy(asc(schema.teams.sortOrder));
  return (
    <div className="container-lx max-w-xl py-14">
      <p className="eyebrow">{t("Welcome to Luxeholic")}</p>
      <h1 className="h-display mt-3 text-5xl">{t("Sign in")}</h1>
      <LoginTabs initial={as} next={sp.next} teams={teams} />
    </div>
  );
}
