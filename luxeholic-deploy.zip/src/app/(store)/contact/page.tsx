import type { Metadata } from "next";
import { getSettings, businessAddress } from "@/lib/settings";
import { PageHead } from "@/components/store/listing";
import { ContactForm } from "@/components/store/contact-form";
import { getI18n } from "@/lib/i18n/server";
import { businessTexts } from "@/lib/i18n/content";

export async function generateMetadata(): Promise<Metadata> {
  const { t } = await getI18n();
  return { title: t("Contact Us"), description: t("Reach Luxeholic client care by phone, WhatsApp or email."), alternates: { canonical: "/contact" } };
}

export default async function Contact({ searchParams }: { searchParams: Promise<{ order?: string }> }) {
  const [{ business: b }, sp, { t, locale }] = await Promise.all([getSettings(), searchParams, getI18n()]);
  const tx = await businessTexts(b, businessAddress(b), locale);
  return (
    <div className="container-lx pb-10">
      <PageHead eyebrow={t("Client care")} title={t("We’re here for you.")} intro={t("Questions about a piece, an order or a gift? Write to us — a real person replies within one working day.")} />
      <div className="grid gap-14 lg:grid-cols-[1fr_380px]">
        <ContactForm order={sp.order} />
        <aside className="card-lx h-fit space-y-5 p-7 text-sm">
          {tx.legalName && <div><p className="eyebrow">{t("Registered business")}</p><p className="mt-1">{tx.legalName}</p></div>}
          <div><p className="eyebrow">{t("Address")}</p><p className="mt-1">{tx.address}</p></div>
          {b.phone && <div><p className="eyebrow">{t("Phone")}</p><p className="mt-1"><a href={`tel:${b.phone.replace(/\s/g, "")}`}>{b.phone}</a></p></div>}
          {b.whatsapp && <div><p className="eyebrow">{t("WhatsApp")}</p><p className="mt-1"><a href={`https://wa.me/${b.whatsapp.replace(/\D/g, "")}`} target="_blank" rel="noopener noreferrer">{b.whatsapp}</a></p></div>}
          <div><p className="eyebrow">{t("Email")}</p><p className="mt-1"><a href={`mailto:${b.email}`}>{b.email}</a></p></div>
          <div><p className="eyebrow">{t("Hours")}</p><p className="mt-1">{tx.supportHours}</p></div>
          {b.gstin && <div><p className="eyebrow">{t("GSTIN")}</p><p className="mt-1">{b.gstin}</p></div>}
        </aside>
      </div>
    </div>
  );
}
