import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { and, eq } from "drizzle-orm";
import { db, schema } from "@/db";
import { getSettings } from "@/lib/settings";
import { getI18n } from "@/lib/i18n/server";
import { formatMoney, LOCALE_INFO } from "@/lib/i18n/config";
import { orderLineLabels } from "@/lib/i18n/content";
import { prettyDateTime } from "@/lib/dates";
import { ProductImage } from "@/components/store/art";
import { ClearBag } from "@/components/store/clear-bag";
import { UtrForm, ReturnForm } from "@/components/store/order-forms";

export async function generateMetadata(): Promise<Metadata> {
  return { title: (await getI18n()).t("Your order"), robots: { index: false } };
}

const STEPS = ["PENDING", "CONFIRMED", "PROCESSING", "SHIPPED", "DELIVERED"] as const;
const LABEL: Record<string, string> = { PENDING: "Placed", CONFIRMED: "Confirmed", PROCESSING: "Being prepared", SHIPPED: "Shipped", DELIVERED: "Delivered", CANCELLED: "Cancelled", RETURN_REQUESTED: "Return requested", RETURNED: "Returned" };

export default async function OrderPage({ params, searchParams }: { params: Promise<{ number: string }>; searchParams: Promise<{ t?: string; placed?: string; payerr?: string }> }) {
  const [{ number }, sp] = await Promise.all([params, searchParams]);
  const o = await db.query.orders.findFirst({ where: and(eq(schema.orders.number, number), eq(schema.orders.accessToken, sp.t ?? "")), with: { items: true } });
  if (!o) notFound();
  const [settings, { t, locale }] = await Promise.all([getSettings(), getI18n()]);
  const formatINR = (p: number) => formatMoney(p, "INR", {}, locale); // orders are charged in rupees
  const intl = LOCALE_INFO[locale].intl;
  const labels = await orderLineLabels(o.items, locale);
  const bank = settings.bank;
  const step = STEPS.indexOf(o.status as (typeof STEPS)[number]);
  const needsOnline = (o.paymentMethod === "PAYU" || o.paymentMethod === "PHONEPE") && o.paymentStatus !== "PAID";
  const needsAdvance = o.paymentMethod === "PARTIAL_COD" && o.amountPaid < o.advanceDue;
  const needsBank = o.paymentMethod === "BANK_TRANSFER" && o.paymentStatus !== "PAID";
  const retry = `/checkout/pay/${o.number}?t=${o.accessToken}&via=${o.paymentMethod === "PHONEPE" ? "phonepe" : "payu"}`;
  const ship = o.shippingAddress;

  return (
    <div className="container-lx max-w-4xl py-14">
      {(sp.placed || o.paymentStatus === "PAID" || o.paymentStatus === "PARTIALLY_PAID") && <ClearBag />}
      <p className="eyebrow">{t("Order {number}", { number: o.number })} · {prettyDateTime(o.createdAt, intl)}</p>
      <h1 className="h-display mt-4 text-5xl">
        {o.status === "CANCELLED" ? t("This order was cancelled.") : needsOnline || needsAdvance ? t("Almost there.") : needsBank ? t("Reserved for you.") : t("Thank you. It’s yours.")}
      </h1>
      {sp.payerr && <p className="mt-4 bg-red-50 p-3 text-sm text-red-800">{t("We couldn’t start the payment. Please try again, or choose another method by contacting us.")}</p>}
      {o.paymentStatus === "FAILED" && <p className="mt-4 bg-red-50 p-3 text-sm text-red-800">{t("Your last payment attempt didn’t go through. No money was taken — or if it was, it will be refunded automatically by your bank.")}</p>}

      {needsBank && o.paymentStatus !== "AWAITING_VERIFICATION" && <p className="mt-4 text-ink-soft">{t("We’re holding your piece. Complete the bank transfer below within 48 hours to confirm the order.")}</p>}
      {o.paymentMethod === "COD" && o.status === "PENDING" && <p className="mt-4 text-ink-soft">{t("Our client-care team will call {phone} shortly to confirm your cash-on-delivery order.", { phone: o.phone })}</p>}
      {(needsOnline || needsAdvance) && o.status !== "CANCELLED" && (
        <div className="mt-8 border border-ink p-6">
          <p>{needsAdvance ? t("Pay the {amount} advance to confirm your order. The balance is paid on delivery.", { amount: formatINR(o.advanceDue) }) : t("Complete your payment of {amount} to confirm your order.", { amount: formatINR(o.total) })}</p>
          <Link href={retry} className="btn-ink mt-5">{t("Pay {amount} now", { amount: formatINR(needsAdvance ? o.advanceDue : o.total - o.amountPaid) })}</Link>
        </div>
      )}

      {o.paymentMethod === "BANK_TRANSFER" && o.paymentStatus !== "PAID" && (
        <div className="mt-8 card-lx p-6">
          <p className="eyebrow !text-ink">{t("Bank transfer details")}</p>
          {bank.accountNumber ? (
            <table className="mt-4 w-full text-sm"><tbody>
              {[[t("Amount"), formatINR(o.total)], [t("Account name"), bank.accountName], [t("Account number"), bank.accountNumber], [t("IFSC"), bank.ifsc], [t("Bank"), `${t(bank.bankName)}${bank.branch ? `, ${t(bank.branch)}` : ""}`], ...(bank.upiId ? [[t("UPI ID"), bank.upiId]] : []), [t("Reference / remarks"), o.number]].map(([k, v]) => (
                <tr key={k} className="border-b border-ivory-line"><td className="py-2 text-ink-mute">{k}</td><td className="py-2 font-medium">{v}</td></tr>
              ))}
            </tbody></table>
          ) : <p className="mt-3 text-sm">{t("Our team will share account details by phone and email shortly.")}</p>}
          {bank.qrImage && (
            <div className="mt-6 flex flex-col items-center gap-4 border-t border-ivory-line pt-6 sm:flex-row sm:items-start">
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img src={bank.qrImage} alt={t("Scan to pay {name} via UPI", { name: bank.accountName })} className="w-44 rounded-sm" loading="lazy" />
              <div className="text-sm text-ink-soft">
                <p className="font-medium text-ink">{t("Prefer UPI? Scan & pay {amount}", { amount: formatINR(o.total) })}</p>
                <p className="mt-2">{t("Open PhonePe, Google Pay, Paytm or any UPI app, scan the code, enter the exact amount and add {number} in the note. Then submit the UPI reference (UTR) below.", { number: o.number })}</p>
              </div>
            </div>
          )}
          {o.paymentStatus === "AWAITING_VERIFICATION" ? (
            <p className="mt-5 text-sm">{t("Thank you — we’re verifying UTR {utr}. You’ll receive a confirmation email within a few working hours.", { utr: o.bankUtr ?? "" })}</p>
          ) : <UtrForm number={o.number} token={o.accessToken} />}
        </div>
      )}

      {o.status !== "CANCELLED" && (
        <ol className="mt-12 grid grid-cols-5 gap-2 text-center text-[10px] uppercase tracking-[0.15em]">
          {STEPS.map((s, i) => (
            <li key={s}><div className={`h-0.5 ${i <= step ? "bg-ink" : "bg-ivory-line"}`} /><p className={`mt-3 ${i <= step ? "text-ink" : "text-ink-mute"}`}>{t(LABEL[s])}</p></li>
          ))}
        </ol>
      )}
      {o.trackingNumber && <p className="mt-6 text-sm">{t("Shipped with {courier}", { courier: o.courier ?? "" })} · {t("Tracking number")} <b>{o.trackingNumber}</b></p>}

      <div className="mt-12 grid gap-10 md:grid-cols-[1fr_300px]">
        <ul className="divide-y divide-ivory-line border-y border-ivory-line">
          {o.items.map((i) => (
            <li key={i.id} className="flex gap-4 py-4">
              <div className="h-24 w-20 shrink-0 overflow-hidden bg-ivory-deep"><ProductImage src={i.image} seed={i.sku} alt={labels.get(i.id)!.title} /></div>
              <div className="flex-1 text-sm"><p>{labels.get(i.id)!.title}</p>{i.variant && <p className="text-ink-mute">{labels.get(i.id)!.variant}</p>}<p className="text-ink-mute">{t("Qty {n}", { n: i.quantity })}</p></div>
              <p className="text-sm">{formatINR(i.unitPrice * i.quantity)}</p>
            </li>
          ))}
        </ul>
        <div className="space-y-6 text-sm">
          <dl className="space-y-1.5">
            <div className="flex justify-between"><dt>{t("Subtotal")}</dt><dd>{formatINR(o.subtotal)}</dd></div>
            {o.discount > 0 && <div className="flex justify-between"><dt>{t("Discount")}</dt><dd>−{formatINR(o.discount)}</dd></div>}
            <div className="flex justify-between"><dt>{t("Shipping")}</dt><dd>{o.shippingFee ? formatINR(o.shippingFee) : t("Free")}</dd></div>
            {o.codFee > 0 && <div className="flex justify-between"><dt>{t("COD fee")}</dt><dd>{formatINR(o.codFee)}</dd></div>}
            <div className="flex justify-between border-t border-ivory-line pt-2 text-base"><dt>{t("Total")}</dt><dd>{formatINR(o.total)}</dd></div>
            <div className="flex justify-between text-ink-mute"><dt>{t("Paid")}</dt><dd>{formatINR(o.amountPaid)}</dd></div>
            {o.total - o.amountPaid > 0 && o.paymentMethod !== "BANK_TRANSFER" && <div className="flex justify-between font-medium"><dt>{t("Due on delivery")}</dt><dd>{formatINR(o.total - o.amountPaid)}</dd></div>}
            <p className="pt-1 text-xs text-ink-mute">{t("Includes GST of {amount}", { amount: formatINR(o.taxIncluded) })}</p>
          </dl>
          <div><p className="eyebrow">{t("Delivering to")}</p><p className="mt-2 leading-relaxed">{ship.name}<br />{ship.line1}{ship.line2 ? `, ${ship.line2}` : ""}<br />{ship.city}, {t(ship.state)} {ship.pincode}<br />{ship.phone}</p></div>
          {o.status === "DELIVERED" && <ReturnForm number={o.number} token={o.accessToken} days={settings.returns.windowDays} />}
          {o.status !== "CANCELLED" && (o.paymentStatus === "PAID" || o.status === "DELIVERED") && <Link href={`/invoice/${o.number}?t=${o.accessToken}`} target="_blank" className="btn-line">{t("Download GST invoice")}</Link>}
          <p className="text-xs text-ink-mute">{t("Questions?")} <Link href={`/contact?order=${o.number}`} className="underline">{t("Contact client care")}</Link></p>
        </div>
      </div>
    </div>
  );
}
