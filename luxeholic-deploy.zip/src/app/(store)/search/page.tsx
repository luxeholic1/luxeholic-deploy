import type { Metadata } from "next";
import { Listing, PageHead } from "@/components/store/listing";
import { getI18n } from "@/lib/i18n/server";

export async function generateMetadata(): Promise<Metadata> {
  const { t } = await getI18n();
  return { title: t("Search"), robots: { index: false } };
}

export default async function Search({ searchParams }: { searchParams: Promise<Record<string, string>> }) {
  const sp = await searchParams;
  const { t } = await getI18n();
  const q = (sp.q ?? "").slice(0, 80);
  return (
    <div className="container-lx">
      <PageHead eyebrow={t("Search")} title={q ? `“${q}”` : t("Search")} />
      <form action="/search" className="mb-10 flex max-w-xl border-b border-ink">
        <input name="q" defaultValue={q} aria-label={t("Search")} placeholder={t("Search sculptures, brands, gifts…")} className="h-display flex-1 bg-transparent py-3 text-2xl italic outline-none" />
        <button className="text-[11px] uppercase tracking-[0.22em]">{t("Search")}</button>
      </form>
      {q && <Listing base="/search" sp={sp} filter={{ q }} />}
    </div>
  );
}
