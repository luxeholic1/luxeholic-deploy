import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { getProduct, getLocalizedCategory, listProducts, localizeProduct } from "@/lib/catalog";
import { getI18n } from "@/lib/i18n/server";
import { LOCALE_INFO, brandName } from "@/lib/i18n/config";
import { getSettings } from "@/lib/settings";
import { productCondition } from "@/lib/money";
import { SITE_URL } from "@/lib/site";
import { addDays, prettyDay, todayIST } from "@/lib/dates";
import { Gallery } from "@/components/store/gallery";
import { AddToBag } from "@/components/store/add-to-bag";
import { ProductCard } from "@/components/store/product-card";
import { MARKETPLACES } from "@/components/store/marketplaces";
import { getCustomer } from "@/lib/auth";
import { db, schema } from "@/db";
import { and, eq } from "drizzle-orm";
import { toggleWishlist } from "../../account/actions";

type P = { params: Promise<{ slug: string }> };

export async function generateMetadata({ params }: P): Promise<Metadata> {
  const raw = await getProduct((await params).slug);
  if (!raw || raw.status !== "ACTIVE") return { robots: { index: false } };
  const { t, money, locale } = await getI18n();
  const p = await localizeProduct(raw, locale);
  if (!p) return { title: t("Not available in Hindi yet"), robots: { index: false } };
  const en = locale === "en";
  const desc = (en && p.seoDescription) || `${p.brand} ${p.title} — ${t("{price} incl. GST.", { price: money(p.price) })} ${(p.shortDescription ?? p.description).slice(0, 120)}`;
  return {
    title: (en && p.seoTitle) || (p.brand !== "Luxeholic" ? t("{title} by {brand}", { title: p.title, brand: brandName(p.brand, locale) }) : p.title),
    description: desc,
    alternates: { canonical: `/p/${p.slug}` },
    openGraph: { title: p.title, description: desc, images: p.images.slice(0, 1), type: "website" },
  };
}

export default async function ProductPage({ params }: P) {
  const raw = await getProduct((await params).slug);
  if (!raw || raw.status !== "ACTIVE") notFound();
  const { t, money: formatINR, locale } = await getI18n();
  const p = await localizeProduct(raw, locale);
  if (!p) return (
    <div className="container-lx py-24 text-center">
      <p className="eyebrow">{t("Not available in Hindi yet")}</p>
      <h1 className="h-display mx-auto mt-4 max-w-2xl text-4xl">{t("This piece’s details are being translated.")}</h1>
      <p className="mx-auto mt-4 max-w-lg text-ink-soft">{t("Explore pieces already available in Hindi, or ask our team about this one.")}</p>
      <div className="mt-8 flex flex-wrap justify-center gap-3">
        <Link href="/shop" className="btn-ink">{t("Shop everything")}</Link>
        <Link href={`/contact`} className="btn-line">{t("Contact us")}</Link>
      </div>
    </div>
  );
  const [settings, cat, related, customer] = await Promise.all([
    getSettings(), getLocalizedCategory(raw.category.slug, locale), listProducts({ categoryIds: [p.categoryId], perPage: 5, locale }), getCustomer(),
  ]);
  const intl = LOCALE_INFO[locale].intl;
  const saved = customer ? (await db.select().from(schema.wishlist).where(and(eq(schema.wishlist.customerId, customer.id), eq(schema.wishlist.productId, p.id)))).length > 0 : false;
  const parent = cat?.parent;
  const today = todayIST();
  const eta = [addDays(today, p.dispatchDays + 2), addDays(today, p.dispatchDays + p.deliveryDays)];
  const soldOut = p.stock <= 0 && !p.variants.some((v) => v.stock > 0);
  const off = p.compareAtPrice && p.compareAtPrice > p.price ? Math.round(100 - (p.price / p.compareAtPrice) * 100) : 0;
  const pay = settings.payments;
  const url = `${SITE_URL}/p/${p.slug}`;

  // Product structured data — Merchant Center cross-checks price, availability, shipping & returns against it.
  const offer = (price: number, inStock: boolean, sku: string) => ({
    "@type": "Offer", url, priceCurrency: "INR", price: (price / 100).toFixed(2), sku,
    availability: inStock ? "https://schema.org/InStock" : "https://schema.org/OutOfStock",
    itemCondition: `https://schema.org/${{ new: "NewCondition", used: "UsedCondition", refurbished: "RefurbishedCondition" }[productCondition(p.tags)]}`,
    seller: { "@type": "Organization", name: "Luxeholic" },
    shippingDetails: {
      "@type": "OfferShippingDetails",
      shippingRate: { "@type": "MonetaryAmount", value: settings.shipping.freeAbove === 0 || price >= settings.shipping.freeAbove ? "0" : (settings.shipping.flatFee / 100).toFixed(2), currency: "INR" },
      shippingDestination: { "@type": "DefinedRegion", addressCountry: "IN" },
      deliveryTime: {
        "@type": "ShippingDeliveryTime",
        handlingTime: { "@type": "QuantitativeValue", minValue: 1, maxValue: p.dispatchDays, unitCode: "DAY" },
        transitTime: { "@type": "QuantitativeValue", minValue: 2, maxValue: p.deliveryDays, unitCode: "DAY" },
      },
    },
    hasMerchantReturnPolicy: {
      "@type": "MerchantReturnPolicy", applicableCountry: "IN", returnPolicyCategory: "https://schema.org/MerchantReturnFiniteReturnWindow",
      merchantReturnDays: settings.returns.windowDays, returnMethod: "https://schema.org/ReturnByMail", returnFees: "https://schema.org/FreeReturn",
    },
  });
  const ld = {
    "@context": "https://schema.org", "@type": "Product", name: p.title, description: p.description.slice(0, 5000),
    image: p.images.length ? p.images : [`${SITE_URL}/brand/logo-full-dark.png`], sku: p.sku, mpn: p.mpn ?? undefined, gtin: p.gtin ?? undefined,
    brand: { "@type": "Brand", name: p.brand }, category: p.category.googleCategory ?? p.category.name,
    color: p.color ?? undefined, material: p.material ?? undefined,
    offers: p.variants.length
      ? { "@type": "AggregateOffer", priceCurrency: "INR", lowPrice: (Math.min(...p.variants.map((v) => v.price ?? p.price)) / 100).toFixed(2), highPrice: (Math.max(...p.variants.map((v) => v.price ?? p.price)) / 100).toFixed(2), offerCount: p.variants.length, offers: p.variants.map((v) => offer(v.price ?? p.price, v.stock > 0, v.sku)) }
      : offer(p.price, !soldOut, p.sku),
  };
  const crumbs = [{ href: "/", label: t("Home") }, ...(parent ? [{ href: `/c/${parent.slug}`, label: parent.name }] : []), { href: `/c/${p.category.slug}`, label: p.category.name }];

  return (
    <div className="container-lx pt-8">
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(ld) }} />
      <nav aria-label={t("Breadcrumb")} className="mb-8 text-xs text-ink-mute">
        {crumbs.map((c, i) => <span key={c.href}>{i > 0 && " / "}<Link href={c.href} className="hover:text-ink">{c.label}</Link></span>)}
      </nav>
      <div className="grid gap-10 lg:grid-cols-[1.25fr_1fr] lg:gap-16">
        <Gallery images={p.images} seed={p.slug} alt={p.title} />
        <div className="lg:sticky lg:top-28 lg:self-start">
          <p className="eyebrow">{brandName(p.brand, locale)}</p>
          <h1 className="h-display mt-3 text-4xl sm:text-5xl">{p.title}</h1>
          <div className="mt-5 flex items-baseline gap-3">
            <p className="text-2xl">{formatINR(p.price)}</p>
            {off >= 5 && <><p className="text-ink-mute line-through">{formatINR(p.compareAtPrice!)}</p><p className="text-sm text-gold-dark">{t("{n}% off", { n: off })}</p></>}
          </div>
          <p className="mt-1 text-xs text-ink-mute">{t("Inclusive of all taxes (GST) · Complimentary insured shipping")}</p>
          {pay.partialCod && <p className="mt-3 inline-block bg-ivory-deep px-3 py-2 text-xs">{t("Pay just {amount} now, the rest on delivery", { amount: formatINR(Math.ceil((p.price * pay.advancePercent) / 10000) * 100) })}</p>}
          {p.shortDescription && <p className="mt-6 leading-relaxed text-ink-soft">{p.shortDescription}</p>}

          <div className="mt-8">
            <AddToBag
              product={{ id: p.id, slug: p.slug, title: p.title, brand: p.brand, price: p.price, image: p.images[0] ?? null, stock: p.stock }}
              variants={p.variants.map((v) => ({ id: v.id, name: v.name, price: v.price ?? p.price, stock: v.stock }))}
            />
            <form action={toggleWishlist} className="mt-3">
              <input type="hidden" name="productId" value={p.id} /><input type="hidden" name="back" value={`/p/${p.slug}`} />
              <button className="text-[11px] uppercase tracking-[0.2em] underline underline-offset-4" aria-pressed={saved}>{saved ? t("♥ Saved to your wishlist") : t("♡ Save to wishlist")}</button>
            </form>
          </div>

          <dl className="mt-8 divide-y divide-ivory-line border-y border-ivory-line text-sm">
            <div className="flex justify-between py-3.5"><dt className="text-ink-mute">{t("Estimated delivery")}</dt><dd>{soldOut ? "—" : `${prettyDay(eta[0], { day: "numeric", month: "short" }, intl)} – ${prettyDay(eta[1], { day: "numeric", month: "short" }, intl)}`}</dd></div>
            <div className="flex justify-between py-3.5"><dt className="text-ink-mute">{t("Returns")}</dt><dd>{t("{n}-day easy returns", { n: settings.returns.windowDays })} · <Link className="underline" href="/policies/returns">{t("policy")}</Link></dd></div>
            <div className="flex justify-between py-3.5"><dt className="text-ink-mute">{t("Payment")}</dt><dd>{t("UPI · Cards · PhonePe · Bank · COD")}</dd></div>
            {p.material && <div className="flex justify-between py-3.5"><dt className="text-ink-mute">{t("Material")}</dt><dd className="text-right">{p.material}</dd></div>}
            {p.color && <div className="flex justify-between py-3.5"><dt className="text-ink-mute">{t("Colour")}</dt><dd>{p.color}</dd></div>}
            {productCondition(p.tags) !== "new" && <div className="flex justify-between py-3.5"><dt className="text-ink-mute">{t("Condition")}</dt><dd className="capitalize">{productCondition(p.tags) === "used" ? t("Pre-owned") : t("Refurbished")}</dd></div>}
            <div className="flex justify-between py-3.5"><dt className="text-ink-mute">{t("Reference")}</dt><dd>{p.sku}</dd></div>
            <div className="flex flex-wrap justify-between gap-2 py-3.5">
              <dt className="text-ink-mute">{t("Also available on")}</dt>
              <dd className="flex flex-wrap gap-x-3 gap-y-1">
                {MARKETPLACES.map((m) => {
                  const url = p.marketplaceLinks?.[m.key] || settings.marketplaces[m.key];
                  return url
                    ? <a key={m.key} href={url} target="_blank" rel="noopener noreferrer nofollow" className="underline underline-offset-4 hover:text-gold-dark">{t(m.name)}</a>
                    : <span key={m.key}>{t(m.name)}</span>;
                })}
              </dd>
            </div>
          </dl>

          <details open className="group mt-6">
            <summary className="flex cursor-pointer list-none justify-between text-[11px] uppercase tracking-[0.2em]">{t("The piece")} <span className="group-open:rotate-45 transition">+</span></summary>
            <div className="prose-lx mt-4 text-[15px] text-ink-soft">{p.description.split(/\n{2,}/).map((para, i) => <p key={i}>{para}</p>)}</div>
          </details>
          {p.category.isApparel && p.brand !== "Luxeholic" && (
            <details className="group mt-4 border-t border-ivory-line pt-4">
              <summary className="flex cursor-pointer list-none justify-between text-[11px] uppercase tracking-[0.2em]">{t("Authenticity")} <span className="group-open:rotate-45 transition">+</span></summary>
              <p className="mt-3 text-sm leading-relaxed text-ink-soft">{t("Sourced through authorised European distribution. Every designer piece ships with its original tags and packaging.")} <Link href="/policies/authenticity" className="underline">{t("Our promise")}</Link></p>
            </details>
          )}
        </div>
      </div>

      {related.products.filter((r) => r.id !== p.id).length > 0 && (
        <section className="mt-24">
          <h2 className="h-display text-4xl">{t("You may also love")}</h2>
          <div className="mt-10 grid grid-cols-2 gap-x-4 gap-y-10 sm:gap-x-6 lg:grid-cols-4">
            {related.products.filter((r) => r.id !== p.id).slice(0, 4).map((r) => <ProductCard key={r.id} p={r} />)}
          </div>
        </section>
      )}
    </div>
  );
}
