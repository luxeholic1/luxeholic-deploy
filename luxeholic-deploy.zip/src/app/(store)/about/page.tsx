import type { Metadata } from "next";
import Link from "next/link";
import { PageHead } from "@/components/store/listing";
import { getI18n } from "@/lib/i18n/server";

export async function generateMetadata(): Promise<Metadata> {
  const { t } = await getI18n();
  return { title: t("Our Story"), description: t("Luxeholic is a new luxury house for art, décor, designer fashion and gifts — luxury for every home, at every price."), alternates: { canonical: "/about" } };
}

export default async function About() {
  const { t, money } = await getI18n();
  return (
    <div className="container-lx max-w-3xl pb-10">
      <PageHead eyebrow={t("Our story")} title={t("Luxury, made personal.")} />
      <div className="prose-lx text-[16px] text-ink-soft">
        <p>{t("Luxeholic began with a simple belief: beautiful things shouldn’t belong only to a few. A sculpture that stops you in a hallway, a vase that makes a room feel finished, a watch that marks a milestone — these are feelings everyone deserves.")}</p>
        <p>{t("So we built a house where a first beautiful piece under {price} sits proudly beside couture from Europe’s great fashion houses. Every item is chosen by our curators for its proportion, finish and presence, then inspected and packed by hand.", { price: money(500000) })}</p>
        <h2>{t("New in the city, here to earn your trust")}</h2>
        <p>{t("We’re new — and we know trust is earned. That’s why every order ships fully insured and free, you can pay just 10% upfront and the rest on delivery, and a real person answers every message.")}</p>
        <h2>{t("The five worlds of Luxeholic")}</h2>
        <ul>
          <li><b>{t("Art & Sculpture")}</b> — {t("hand-finished resin sculpture and wall art.")}</li>
          <li><b>{t("Home Décor")}</b> — {t("vases, lighting, mirrors, barware.")}</li>
          <li><b>{t("Designer Fashion")}</b> — {t("authentic European labels.")}</li>
          <li><b>{t("Gifting & Accessories")}</b> — {t("watches, leather goods, scarves, gift sets.")}</li>
          <li><b>{t("Lux-Tech")}</b> — {t("technology that’s as beautiful as it is clever.")}</li>
        </ul>
      </div>
      <Link href="/shop" className="btn-ink mt-10">{t("Discover the collection")}</Link>
    </div>
  );
}
