import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { PRICE_TIERS, tierLine } from "@/lib/money";
import { Listing, PageHead } from "@/components/store/listing";
import type { ProductFilter } from "@/lib/catalog";
import { getI18n } from "@/lib/i18n/server";

type Tr = Awaited<ReturnType<typeof getI18n>>;
function collections({ t, money }: Tr): Record<string, { title: string; eyebrow: string; intro: string; filter: ProductFilter; tiers: boolean }> {
  return {
    ...Object.fromEntries(PRICE_TIERS.map((x) => [x.slug, {
      title: t(x.name), eyebrow: tierLine(x, t, money),
      intro: {
        "first-luxe": t("Your first beautiful thing. Real craftsmanship, honest prices, all under {price}.", { price: money(500000) }),
        signature: t("The heart of Luxeholic — statement pieces and designer gifts for considered homes."),
        haute: t("Rare, large-format and couture pieces for collectors."),
      }[x.slug]!,
      filter: { minPrice: x.min, maxPrice: x.max }, tiers: false,
    }])),
    "new-arrivals": { title: t("New Arrivals"), eyebrow: t("Just landed"), intro: t("Fresh pieces, added every week."), filter: { newArrivals: true, sort: "new" }, tiers: true },
    "curators-choice": { title: t("Curator’s Choice"), eyebrow: t("Featured"), intro: t("The pieces our team can’t stop looking at."), filter: { featured: true }, tiers: true },
  };
}

type P = { params: Promise<{ slug: string }>; searchParams: Promise<Record<string, string>> };
export async function generateMetadata({ params }: P): Promise<Metadata> {
  const slug = (await params).slug;
  const c = collections(await getI18n())[slug];
  return c ? { title: `${c.title} — ${c.eyebrow}`, description: c.intro, alternates: { canonical: `/collections/${slug}` } } : {};
}
export default async function Collection({ params, searchParams }: P) {
  const [{ slug }, sp] = await Promise.all([params, searchParams]);
  const c = collections(await getI18n())[slug];
  if (!c) notFound();
  return (
    <div className="container-lx">
      <PageHead eyebrow={c.eyebrow} title={c.title} intro={c.intro} />
      <Listing base={`/collections/${slug}`} sp={sp} filter={c.filter} showTiers={c.tiers} />
    </div>
  );
}
