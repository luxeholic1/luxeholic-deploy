import { NextResponse } from "next/server";
import { mkdir, writeFile, unlink } from "node:fs/promises";
import { execFile } from "node:child_process";
import { promisify } from "node:util";
import path from "node:path";
import { randomBytes } from "node:crypto";
import { getStaff } from "@/lib/auth";
import { canWrite } from "@/lib/rbac";
import { audit } from "@/lib/notify";
import { UPLOAD_DIR } from "@/lib/uploads";

const run = promisify(execFile);
const MAX = 80 * 1024 * 1024;
export const maxDuration = 300;

function sniff(b: Buffer) {
  if (b.subarray(4, 8).toString() === "ftyp") return "mp4";            // MP4 / MOV
  if (b[0] === 0x1a && b[1] === 0x45 && b[2] === 0xdf && b[3] === 0xa3) return "webm";
  return null;
}

/** Upload a hero video. With ffmpeg on the server it is re-encoded for smooth scroll scrubbing
 *  (1280×720, 24 fps, keyframe every 6 frames, no audio) and a poster is made. */
export async function POST(req: Request) {
  const me = await getStaff();
  if (!me || me.mustChangePassword || !canWrite(me, "marketing")) return NextResponse.json({ error: "Only Marketing and the super admin can change the homepage hero." }, { status: 403 });
  const fd = await req.formData();
  const f = fd.get("file");
  if (!(f instanceof File) || !f.size) return NextResponse.json({ error: "Choose a video file." }, { status: 400 });
  if (f.size > MAX) return NextResponse.json({ error: "Video is over 80 MB — export a shorter (6–15 s) 1080p clip." }, { status: 400 });
  const buf = Buffer.from(await f.arrayBuffer());
  const kind = sniff(buf);
  if (!kind) return NextResponse.json({ error: "Use an MP4, MOV or WebM video." }, { status: 400 });
  const dir = path.join(UPLOAD_DIR, "hero");
  await mkdir(dir, { recursive: true });
  const name = `hero-${Date.now().toString(36)}-${randomBytes(3).toString("hex")}`;
  const raw = path.join(dir, `${name}-src.${kind}`);
  await writeFile(raw, buf);
  const ff = process.env.FFMPEG_PATH || "ffmpeg";
  try {
    await run(ff, ["-v", "error", "-y", "-i", raw, "-an", "-t", "20", "-vf", "scale=1280:720:force_original_aspect_ratio=increase,crop=1280:720,fps=24,format=yuv420p",
      "-c:v", "libx264", "-profile:v", "high", "-crf", "25", "-preset", "veryfast", "-g", "6", "-keyint_min", "6", "-sc_threshold", "0", "-movflags", "+faststart", path.join(dir, `${name}.mp4`)], { timeout: 240_000 });
    await run(ff, ["-v", "error", "-y", "-i", path.join(dir, `${name}.mp4`), "-frames:v", "1", "-q:v", "4", path.join(dir, `${name}.jpg`)], { timeout: 60_000 });
    await unlink(raw).catch(() => {});
    await audit(me.id, "hero.video_upload", "settings", "hero", { name, encoded: true });
    return NextResponse.json({ video: `/u/hero/${name}`, encoded: true });
  } catch {
    // No ffmpeg on this server: keep the original. It plays, but scrubbing is smoothest with a short-keyframe export.
    if (kind !== "mp4") { await unlink(raw).catch(() => {}); return NextResponse.json({ error: "This server can’t convert WebM. Upload an MP4 instead." }, { status: 400 }); }
    const final = path.join(dir, `${name}.mp4`);
    await writeFile(final, buf); await unlink(raw).catch(() => {});
    await audit(me.id, "hero.video_upload", "settings", "hero", { name, encoded: false });
    return NextResponse.json({ video: `/u/hero/${name}.mp4`, encoded: false });
  }
}
