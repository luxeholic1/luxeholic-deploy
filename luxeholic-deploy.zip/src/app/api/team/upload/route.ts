import { NextResponse } from "next/server";
import { mkdir, writeFile } from "node:fs/promises";
import path from "node:path";
import { randomBytes } from "node:crypto";
import { getStaff } from "@/lib/auth";
import { canWrite } from "@/lib/rbac";
import { slugify } from "@/lib/site";
import { IMAGE_TYPES, MAX_IMAGE_BYTES, UPLOAD_DIR } from "@/lib/uploads";

// Checks the real file signature, not just the browser-declared type.
function sniff(b: Buffer): string | null {
  if (b[0] === 0xff && b[1] === 0xd8 && b[2] === 0xff) return "image/jpeg";
  if (b.subarray(0, 8).equals(Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]))) return "image/png";
  if (b.subarray(0, 4).toString() === "RIFF" && b.subarray(8, 12).toString() === "WEBP") return "image/webp";
  return null;
}

export async function POST(req: Request) {
  const me = await getStaff();
  if (!me || me.mustChangePassword || !canWrite(me, "products")) return NextResponse.json({ error: "Not allowed" }, { status: 403 });
  const fd = await req.formData();
  const files = fd.getAll("files").filter((f): f is File => f instanceof File && f.size > 0).slice(0, 12);
  if (!files.length) return NextResponse.json({ error: "No files" }, { status: 400 });
  const now = new Date();
  const sub = `${now.getFullYear()}/${String(now.getMonth() + 1).padStart(2, "0")}`;
  await mkdir(path.join(UPLOAD_DIR, sub), { recursive: true });
  const urls: string[] = [], errors: string[] = [];
  for (const f of files) {
    if (f.size > MAX_IMAGE_BYTES) { errors.push(`${f.name}: over 5 MB`); continue; }
    const buf = Buffer.from(await f.arrayBuffer());
    const type = sniff(buf);
    if (!type) { errors.push(`${f.name}: use JPG, PNG or WebP`); continue; }
    const base = slugify(f.name.replace(/\.[^.]+$/, "")).slice(0, 50) || "photo";
    const name = `${base}-${randomBytes(3).toString("hex")}.${IMAGE_TYPES[type]}`;
    await writeFile(path.join(UPLOAD_DIR, sub, name), buf);
    urls.push(`/u/${sub}/${name}`);
  }
  return NextResponse.json({ urls, errors });
}
