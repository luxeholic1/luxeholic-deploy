import { NextResponse } from "next/server";
import { safeEqual } from "@/lib/crypto";
import { runJob } from "@/lib/jobs";

/**
 * Scheduled jobs for shared hosting cron (cPanel → Cron Jobs):
 *   curl -s "https://luxeholic.in/api/cron/daily?key=$CRON_SECRET"   (06:00 daily)
 *   curl -s "https://luxeholic.in/api/cron/sync?key=$CRON_SECRET"    (every 6 hours)
 *   curl -s "https://luxeholic.in/api/cron/cleanup?key=$CRON_SECRET" (hourly)
 */
export const maxDuration = 300;
export async function GET(req: Request, { params }: { params: Promise<{ job: string }> }) {
  const key = new URL(req.url).searchParams.get("key") ?? req.headers.get("x-cron-key") ?? "";
  const secret = process.env.CRON_SECRET ?? "";
  if (!secret || !safeEqual(key, secret)) return NextResponse.json({ error: "unauthorized" }, { status: 401 });
  try {
    return NextResponse.json({ ok: true, result: await runJob((await params).job) });
  } catch (e) {
    return NextResponse.json({ ok: false, error: (e as Error).message }, { status: 500 });
  }
}
