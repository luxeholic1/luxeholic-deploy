import { NextResponse } from "next/server";
import { eq } from "drizzle-orm";
import { db, schema } from "@/db";
import { verifyPayuResponse } from "@/lib/payments/payu";
import { settlePayment } from "@/lib/orders";
import { SITE_URL } from "@/lib/site";

/** PayU posts the result here (surl + furl). Hash-verified before anything changes. */
export async function POST(req: Request) {
  const fd = await req.formData();
  const fields = Object.fromEntries([...fd.entries()].map(([k, v]) => [k, String(v)]));
  const r = verifyPayuResponse(fields);
  if (!r) return NextResponse.redirect(`${SITE_URL}/?payment=invalid`, 303);
  const order = await settlePayment(r.txnid, r.success, r.amountPaise, r.providerRef ?? null, { status: fields.status, mihpayid: fields.mihpayid, mode: fields.mode, bank_ref_num: fields.bank_ref_num, error: fields.error_Message });
  if (!order) return NextResponse.redirect(`${SITE_URL}/`, 303);
  const [o] = await db.select({ number: schema.orders.number, t: schema.orders.accessToken }).from(schema.orders).where(eq(schema.orders.id, order.id));
  return NextResponse.redirect(`${SITE_URL}/order/${o.number}?t=${o.t}${r.success ? "&placed=1" : ""}`, 303);
}
