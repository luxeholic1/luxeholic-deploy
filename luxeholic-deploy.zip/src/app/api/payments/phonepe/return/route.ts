import { NextResponse } from "next/server";
import { eq } from "drizzle-orm";
import { db, schema } from "@/db";
import { phonepeStatus } from "@/lib/payments/phonepe";
import { settlePayment } from "@/lib/orders";
import { SITE_URL } from "@/lib/site";

/** Customer returns from PhonePe. We confirm the result server-to-server before trusting it. */
export async function GET(req: Request) {
  const txn = new URL(req.url).searchParams.get("txn") ?? "";
  const [p] = await db.select().from(schema.payments).where(eq(schema.payments.txnId, txn));
  if (!p) return NextResponse.redirect(`${SITE_URL}/`, 303);
  const s = await phonepeStatus(txn).catch(() => null);
  if (s && s.state !== "PENDING") await settlePayment(txn, s.state === "COMPLETED", s.amount, s.providerRef, s.raw);
  const [o] = await db.select({ number: schema.orders.number, t: schema.orders.accessToken }).from(schema.orders).where(eq(schema.orders.id, p.orderId));
  return NextResponse.redirect(`${SITE_URL}/order/${o.number}?t=${o.t}${s?.state === "COMPLETED" ? "&placed=1" : ""}`, 303);
}
