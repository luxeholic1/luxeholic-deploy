import { NextResponse } from "next/server";
import { phonepeStatus, verifyPhonepeWebhook } from "@/lib/payments/phonepe";
import { settlePayment } from "@/lib/orders";

/** PhonePe server callback (configure in PhonePe dashboard → Webhooks). */
export async function POST(req: Request) {
  if (!verifyPhonepeWebhook(req.headers.get("authorization"))) return NextResponse.json({ ok: false }, { status: 401 });
  const body = await req.json().catch(() => ({}));
  const txn = body?.payload?.merchantOrderId as string | undefined;
  if (!txn) return NextResponse.json({ ok: true });
  const s = await phonepeStatus(txn); // re-check rather than trusting the payload
  if (s.state !== "PENDING") await settlePayment(txn, s.state === "COMPLETED", s.amount, s.providerRef, s.raw);
  return NextResponse.json({ ok: true });
}
