import type { Metadata } from "next";
import { redirect } from "next/navigation";
import { asc } from "drizzle-orm";
import { db, schema } from "@/db";
import { getStaff } from "@/lib/auth";
import { LoginForm } from "./form";

export const metadata: Metadata = { title: "Team sign in", robots: { index: false, follow: false } };
export const dynamic = "force-dynamic";

export default async function TeamLogin() {
  if (await getStaff()) redirect("/team");
  const teams = await db.select({ slug: schema.teams.slug, name: schema.teams.name }).from(schema.teams).orderBy(asc(schema.teams.sortOrder));
  return (
    <div className="grid min-h-screen lg:grid-cols-2">
      <div className="relative hidden flex-col justify-between bg-ink p-12 text-ivory lg:flex">
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img src="/brand/logo-full-light.png" alt="Luxeholic" className="w-40" />
        <div>
          <p className="h-display text-5xl italic">The house behind the pieces.</p>
          <p className="mt-4 max-w-sm text-sm text-ivory/60">Luxeholic team workspace — orders, catalogue, vendors, tasks and the calendar, one sign-in per team.</p>
        </div>
        <p className="text-xs text-ivory/40">Authorised staff only. Activity is logged.</p>
      </div>
      <div className="flex items-center justify-center bg-stone-50 p-6">
        <div className="w-full max-w-sm">
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img src="/brand/mark-dark.png" alt="" className="mb-8 h-10 w-auto lg:hidden" />
          <h1 className="text-2xl font-semibold tracking-tight text-stone-900">Team sign in</h1>
          <p className="mt-1 text-sm text-stone-500">Use the email address issued to you by Luxeholic.</p>
          <LoginForm teams={teams} />
        </div>
      </div>
    </div>
  );
}
