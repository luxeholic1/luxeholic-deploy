"use client";
import { useActionState } from "react";
import { staffLogin } from "../actions/auth";
import { useT } from "@/lib/i18n/client";

export function LoginForm({ teams }: { teams: { slug: string; name: string }[] }) {
  const [s, action, pending] = useActionState(staffLogin, null);
  const tr = useT();
  return (
    <form action={action} className="mt-8 space-y-4">
      <div>
        <label className="t-label" htmlFor="team">{tr("Team")}</label>
        <select id="team" name="team" required defaultValue="" className="t-input">
          <option value="" disabled>{tr("Select your team")}</option>
          <option value="super-admin">{tr("Super Admin")}</option>
          {teams.map((t) => <option key={t.slug} value={t.slug}>{tr(t.name)}</option>)}
        </select>
      </div>
      <div><label className="t-label" htmlFor="email">{tr("Work email")}</label><input id="email" name="email" type="email" required autoComplete="username" className="t-input" /></div>
      <div><label className="t-label" htmlFor="password">{tr("Password")}</label><input id="password" name="password" type="password" required autoComplete="current-password" className="t-input" /></div>
      {s?.error && <p className="rounded-md bg-red-50 px-3 py-2 text-sm text-red-700" role="alert">{tr(s.error)}</p>}
      <button disabled={pending} className="t-btn w-full !py-2.5">{pending ? tr("Signing in…") : tr("Sign in")}</button>
      <p className="text-xs text-stone-400">{tr("Forgot your password? Ask the super admin to reset it.")}</p>
    </form>
  );
}
