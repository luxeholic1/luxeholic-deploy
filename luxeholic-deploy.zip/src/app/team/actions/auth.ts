"use server";
import { redirect } from "next/navigation";
import { eq, sql } from "drizzle-orm";
import { db, schema } from "@/db";
import {
  endStaffSession, getStaff, hashPassword, passwordProblem, recordAttempt, startStaffSession, tooManyAttempts, verifyPassword, clientIp,
} from "@/lib/auth";
import { audit } from "@/lib/notify";

type S = { error?: string } | null;

/** Team-wise login: the person picks their team, and the account must belong to it. */
export async function staffLogin(_: S, fd: FormData): Promise<S> {
  const team = String(fd.get("team") ?? "");
  const email = String(fd.get("email") ?? "").trim().toLowerCase();
  const password = String(fd.get("password") ?? "");
  if (!team) return { error: "Select your team." };
  const ip = (await clientIp()) ?? "x";
  if ((await tooManyAttempts(`s:${email}`)) || (await tooManyAttempts(`sip:${ip}`))) return { error: "Too many attempts. Try again in 15 minutes." };
  const s = await db.query.staff.findFirst({ where: eq(schema.staff.email, email), with: { team: true } });
  const pwOk = !!s && (await verifyPassword(password, s.passwordHash));
  const teamOk = !!s && (team === "super-admin" ? s.role === "SUPER_ADMIN" : s.team?.slug === team);
  const ok = pwOk && teamOk && !!s?.active;
  await recordAttempt(`s:${email}`, ok);
  await recordAttempt(`sip:${ip}`, ok);
  if (!ok) {
    if (pwOk && s && !s.active) return { error: "This account has been deactivated. Contact the super admin." };
    if (pwOk && !teamOk) return { error: "This account isn't part of the selected team." };
    return { error: "Email or password is incorrect." };
  }
  await db.update(schema.staff).set({ lastLoginAt: new Date() }).where(eq(schema.staff.id, s!.id));
  await startStaffSession(s!.id, s!.sessionVersion);
  await audit(s!.id, "login", "staff", s!.id);
  redirect(s!.mustChangePassword ? "/team/change-password" : "/team");
}

export async function staffLogout() {
  const s = await getStaff();
  if (s) await audit(s.id, "logout", "staff", s.id);
  await endStaffSession();
  redirect("/team/login");
}

export async function changePassword(_: S, fd: FormData): Promise<S> {
  const s = await getStaff();
  if (!s) redirect("/team/login");
  const current = String(fd.get("current") ?? ""), next = String(fd.get("next") ?? ""), confirm = String(fd.get("confirm") ?? "");
  const [row] = await db.select().from(schema.staff).where(eq(schema.staff.id, s.id));
  if (!(await verifyPassword(current, row.passwordHash))) return { error: "Current password is incorrect." };
  const p = passwordProblem(next);
  if (p) return { error: p };
  if (next !== confirm) return { error: "The new passwords don't match." };
  if (next === current) return { error: "Choose a password different from the temporary one." };
  const [u] = await db.update(schema.staff)
    .set({ passwordHash: await hashPassword(next), mustChangePassword: false, sessionVersion: sql`${schema.staff.sessionVersion} + 1` })
    .where(eq(schema.staff.id, s.id)).returning();
  await startStaffSession(u.id, u.sessionVersion);
  await audit(s.id, "password.change", "staff", s.id);
  redirect("/team?ok=Password%20updated");
}
