"use server";
import { eq } from "drizzle-orm";
import { db, schema } from "@/db";
import { guard, run, str, optStr, int, bool, rupees } from "@/lib/team";
import { audit, sendMail, notifyStaff } from "@/lib/notify";

export async function replyTicket(fd: FormData) {
  const id = str(fd, "id");
  await run(`/team/tickets/${id}`, async () => {
    const me = await guard("tickets");
    const [t] = await db.select().from(schema.supportTickets).where(eq(schema.supportTickets.id, id));
    if (!t) throw new Error("Ticket not found");
    const body = str(fd, "body");
    const status = (["OPEN", "IN_PROGRESS", "WAITING_CUSTOMER", "RESOLVED"].includes(str(fd, "status")) ? str(fd, "status") : t.status) as typeof t.status;
    const internal = fd.get("internal") === "on";
    const replies = body ? [...t.replies, { by: me.name, staff: true, body, at: new Date().toISOString(), ...(internal ? { internal: true } : {}) }] : t.replies;
    await db.update(schema.supportTickets).set({ replies, status, assigneeId: t.assigneeId ?? me.id }).where(eq(schema.supportTickets.id, id));
    if (body && fd.get("internal") !== "on") {
      await sendMail(t.email, `Re: ${t.subject} [${t.number}]`, `Hello ${t.name.split(" ")[0]},`, body.replace(/\n/g, "<br>") + `<br><br>— ${me.name.split(" ")[0]}, Luxeholic Client Care<br><span style="color:#6B655C;font-size:12px">Reply to this email to continue the conversation. Ref ${t.number}</span>`);
    }
    await audit(me.id, "ticket.reply", "ticket", id, { status });
    return body ? (fd.get("internal") === "on" ? "Internal note added" : "Reply sent to customer") : "Ticket updated";
  });
}

export async function assignTicket(fd: FormData) {
  const id = str(fd, "id");
  await run(`/team/tickets/${id}`, async () => {
    const me = await guard("tickets");
    const to = str(fd, "assigneeId") || null;
    await db.update(schema.supportTickets).set({ assigneeId: to }).where(eq(schema.supportTickets.id, id));
    if (to && to !== me.id) await notifyStaff([to], "A support ticket was assigned to you", undefined, `/team/tickets/${id}`);
    return "Assigned";
  });
}

export async function saveCoupon(fd: FormData) {
  await run("/team/marketing", async () => {
    const me = await guard("marketing");
    const code = str(fd, "code").toUpperCase().replace(/[^A-Z0-9]/g, "");
    if (code.length < 3) throw new Error("Coupon code must be at least 3 letters/numbers.");
    const percentOff = int(fd, "percentOff") || null, amountOff = rupees(fd, "amountOff");
    if (!percentOff && !amountOff) throw new Error("Set a % or ₹ discount.");
    if (percentOff && (percentOff < 1 || percentOff > 90)) throw new Error("Percent must be 1–90.");
    await db.insert(schema.coupons).values({
      code, description: optStr(fd, "description"), percentOff, amountOff, minSubtotal: rupees(fd, "minSubtotal") ?? 0,
      maxUses: int(fd, "maxUses") || null, startsAt: str(fd, "startsAt") ? new Date(str(fd, "startsAt")) : null,
      endsAt: str(fd, "endsAt") ? new Date(`${str(fd, "endsAt")}T23:59:59+05:30`) : null, active: true,
    }).onConflictDoUpdate({ target: schema.coupons.code, set: { percentOff, amountOff, description: optStr(fd, "description"), active: true } });
    await audit(me.id, "coupon.save", "coupon", code);
    return `Coupon ${code} saved`;
  });
}

export async function toggleCoupon(fd: FormData) {
  await run("/team/marketing", async () => {
    await guard("marketing");
    await db.update(schema.coupons).set({ active: bool(fd, "active") }).where(eq(schema.coupons.id, str(fd, "id")));
    return "Updated";
  });
}
