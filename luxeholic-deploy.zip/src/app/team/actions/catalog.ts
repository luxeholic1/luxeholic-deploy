"use server";
import { and, eq, inArray } from "drizzle-orm";
import { db, schema } from "@/db";
import { guard, run, str, optStr, int, rupees, bool } from "@/lib/team";
import { audit } from "@/lib/notify";
import { slugify } from "@/lib/site";
import { uniqueSlug } from "@/lib/vendors/sync";

const lines = (s: string) => s.split(/\r?\n/).map((x) => x.trim()).filter(Boolean);

export async function saveProduct(fd: FormData) {
  const id = str(fd, "id");
  const isNew = !id || id === "new";
  await run(isNew ? "/team/products/new" : `/team/products/${id}`, async () => {
    const me = await guard("products");
    const title = str(fd, "title");
    if (title.length < 3) throw new Error("Title is required.");
    const price = rupees(fd, "price");
    if (!price || price < 100) throw new Error("Enter a selling price (₹, GST inclusive).");
    const categoryId = str(fd, "categoryId");
    if (!categoryId) throw new Error("Choose a category.");
    const images = lines(str(fd, "images")).filter((u) => /^https?:\/\//.test(u) || u.startsWith("/"));
    const status = (["DRAFT", "ACTIVE", "ARCHIVED"].includes(str(fd, "status")) ? str(fd, "status") : "DRAFT") as "DRAFT" | "ACTIVE" | "ARCHIVED";
    const description = str(fd, "description");
    if (status === "ACTIVE") {
      if (!images.length) throw new Error("Add at least one product image before publishing (required by Google Merchant Center).");
      if (description.length < 40) throw new Error("Write a description of at least 40 characters before publishing.");
      const [cat] = await db.select().from(schema.categories).where(eq(schema.categories.id, categoryId));
      if (cat?.slug === "needs-review") throw new Error("Move the product out of “Needs review” into a real category before publishing.");
    }
    const values = {
      title, description, shortDescription: optStr(fd, "shortDescription"), brand: str(fd, "brand") || "Luxeholic",
      gtin: optStr(fd, "gtin"), mpn: optStr(fd, "mpn"), categoryId, price, compareAtPrice: rupees(fd, "compareAtPrice"),
      priceLocked: bool(fd, "priceLocked"), stock: int(fd, "stock"), status, images, material: optStr(fd, "material"), color: optStr(fd, "color"),
      gender: optStr(fd, "gender"), ageGroup: optStr(fd, "gender") ? "adult" : null, weightGrams: int(fd, "weightGrams") || null,
      dispatchDays: int(fd, "dispatchDays", 3), deliveryDays: int(fd, "deliveryDays", 7), isFeatured: bool(fd, "isFeatured"), isNewArrival: bool(fd, "isNewArrival"),
      seoTitle: optStr(fd, "seoTitle"), seoDescription: optStr(fd, "seoDescription"),
      vendorId: str(fd, "vendorId") || null, vendorSku: optStr(fd, "vendorSku"),
      tags: str(fd, "tags").split(",").map((t) => t.trim()).filter(Boolean),
      marketplaceLinks: Object.fromEntries((["amazon", "flipkart", "blinkit", "walmart"] as const).map((k) => {
        const v = str(fd, `mkt_${k}`);
        if (v && !/^https:\/\//.test(v)) throw new Error(`${k} link must start with https://`);
        return [k, v];
      }).filter(([, v]) => v)),
    };
    let pid = id;
    if (isNew) {
      const sku = str(fd, "sku") || `LX-${Date.now().toString(36).toUpperCase()}`;
      const [p] = await db.insert(schema.products).values({ ...values, sku, slug: await uniqueSlug(title) }).returning();
      pid = p.id;
    } else {
      const slug = str(fd, "slug") ? slugify(str(fd, "slug")) : undefined;
      if (slug) { const [hit] = await db.select({ id: schema.products.id }).from(schema.products).where(eq(schema.products.slug, slug)); if (hit && hit.id !== id) throw new Error("That URL slug is already used."); }
      await db.update(schema.products).set({ ...values, ...(slug ? { slug } : {}) }).where(eq(schema.products.id, id));
    }
    // Variants: one per line → "Size M | SKU (optional) | price ₹ (optional) | stock"
    const vlines = lines(str(fd, "variants"));
    await db.delete(schema.productVariants).where(eq(schema.productVariants.productId, pid));
    if (vlines.length) {
      const rows = vlines.map((l, i) => {
        const [name, sku, p, s] = l.split("|").map((x) => x.trim());
        return { productId: pid, name, sku: sku || `${values.vendorSku ?? pid.slice(0, 6)}-${i + 1}-${slugify(name)}`.slice(0, 80), vendorSku: sku || null,
          size: /size/i.test(name) ? name.replace(/size\s*/i, "") : null, price: p ? Math.round(parseFloat(p.replace(/[₹,]/g, "")) * 100) : null, stock: parseInt(s ?? "0") || 0 };
      });
      await db.insert(schema.productVariants).values(rows);
      await db.update(schema.products).set({ stock: rows.reduce((a, r) => a + r.stock, 0) }).where(eq(schema.products.id, pid));
    }
    await audit(me.id, isNew ? "product.create" : "product.update", "product", pid, { title, status, price });
    return { msg: isNew ? "Product created" : "Product saved", to: `/team/products/${pid}` };
  });
}

/** Bulk actions from the products list. */
export async function bulkProducts(fd: FormData) {
  await run(str(fd, "back") || "/team/products", async () => {
    const me = await guard("products");
    const ids = fd.getAll("ids").map(String).filter(Boolean);
    if (!ids.length) throw new Error("Select at least one product.");
    const op = str(fd, "op");
    if (op === "publish") {
      const list = await db.select().from(schema.products).where(inArray(schema.products.id, ids));
      const review = (await db.select().from(schema.categories).where(eq(schema.categories.slug, "needs-review")))[0]?.id;
      const ok = list.filter((p) => p.images.length && p.description.length >= 40 && p.categoryId !== review).map((p) => p.id);
      if (ok.length) await db.update(schema.products).set({ status: "ACTIVE" }).where(inArray(schema.products.id, ok));
      await audit(me.id, "product.bulk_publish", "product", null, { count: ok.length });
      return `Published ${ok.length}${list.length - ok.length ? ` · ${list.length - ok.length} skipped (need image, description & real category)` : ""}`;
    }
    if (op === "draft" || op === "archive") {
      await db.update(schema.products).set({ status: op === "draft" ? "DRAFT" : "ARCHIVED" }).where(inArray(schema.products.id, ids));
      return `${ids.length} product(s) ${op === "draft" ? "unpublished" : "archived"}`;
    }
    if (op === "move") {
      const cat = str(fd, "categoryId");
      if (!cat) throw new Error("Pick a category to move to.");
      await db.update(schema.products).set({ categoryId: cat }).where(inArray(schema.products.id, ids));
      return `Moved ${ids.length} product(s)`;
    }
    if (op === "feature" || op === "unfeature") {
      await db.update(schema.products).set({ isFeatured: op === "feature" }).where(inArray(schema.products.id, ids));
      return "Updated";
    }
    if (op === "delete-demo") {
      const r = await db.delete(schema.products).where(and(inArray(schema.products.id, ids))).returning({ id: schema.products.id }).catch(() => { throw new Error("Some products have orders and can't be deleted — archive them instead."); });
      await audit(me.id, "product.delete", "product", null, { count: r.length });
      return `Deleted ${r.length}`;
    }
    throw new Error("Unknown action");
  });
}

export async function saveCategory(fd: FormData) {
  await run("/team/categories", async () => {
    const me = await guard("categories");
    const id = str(fd, "id");
    const name = str(fd, "name");
    if (!name) throw new Error("Name is required.");
    const values = {
      name, tagline: optStr(fd, "tagline"), description: optStr(fd, "description"), image: optStr(fd, "image"),
      googleCategory: optStr(fd, "googleCategory"), sortOrder: int(fd, "sortOrder"), active: bool(fd, "active"), isApparel: bool(fd, "isApparel"),
      parentId: str(fd, "parentId") || null,
    };
    if (id) await db.update(schema.categories).set(values).where(eq(schema.categories.id, id));
    else await db.insert(schema.categories).values({ ...values, slug: slugify(str(fd, "slug") || name) });
    await audit(me.id, id ? "category.update" : "category.create", "category", id || null, { name });
    return id ? "Category saved" : "Category added";
  });
}
