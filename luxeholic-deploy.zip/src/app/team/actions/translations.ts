"use server";
import { revalidatePath } from "next/cache";
import { and, eq } from "drizzle-orm";
import { db, schema } from "@/db";
import { guard, run } from "@/lib/team";
import { audit } from "@/lib/notify";
import { saveTranslation, FIELDS, type Entity } from "@/lib/i18n/content";
import { sources, workItems } from "@/lib/i18n/workbench";
import { translateFields } from "@/lib/i18n/auto";
import { UI_KEYS, uiDict, saveUiStrings } from "@/lib/i18n/ui-dict";
import { CURRENCIES, LOCALES, LOCALE_INFO, isLocale, type Locale } from "@/lib/i18n/config";
import { getSetting, saveSetting } from "@/lib/settings";
import { refreshDisplayRates } from "@/lib/fx-display";

const ENTITIES = Object.keys(FIELDS) as Entity[];
const isEntity = (v: unknown): v is Entity => ENTITIES.includes(v as Entity);
const langName = (l: Locale) => LOCALE_INFO[l].english;
const back = (fd: FormData) => { const b = String(fd.get("back") ?? ""); return b.startsWith("/team/") ? b : "/team/marketing/translations"; };

/** Save the translations typed for one record. Empty boxes remove the translation (the record then hides in that language). */
export async function saveTranslations(fd: FormData) {
  await run(back(fd), async () => {
    const me = await guard("marketing", "write");
    const entity = fd.get("entity"), id = String(fd.get("id") ?? ""), locale = String(fd.get("locale") ?? "hi");
    if (!isEntity(entity) || !isLocale(locale) || locale === "en") throw new Error("Unknown content.");
    const src = (await sources(entity)).find((s) => s.id === id);
    if (!src) throw new Error("That item no longer exists.");
    let saved = 0;
    for (const [field, en] of Object.entries(src.values)) {
      const v = String(fd.get(`tr_${field}`) ?? "").trim();
      if (v) { await saveTranslation(entity, id, field, locale, v, en, "manual"); saved++; }
      else await db.delete(schema.translations).where(and(eq(schema.translations.entity, entity), eq(schema.translations.entityId, id), eq(schema.translations.field, field), eq(schema.translations.locale, locale)));
    }
    await audit(me.id, "translation.save", entity, id, { locale, fields: saved });
    revalidatePath("/", "layout");
    return `Saved ${saved} field${saved === 1 ? "" : "s"} — live on the ${langName(locale)} site.`;
  });
}

/** Draft translations with Claude for one record, or for every incomplete record of a kind (up to 15 at a time). */
export async function autoTranslate(fd: FormData) {
  await run(back(fd), async () => {
    const me = await guard("marketing", "write");
    const entity = fd.get("entity"), id = String(fd.get("id") ?? ""), locale = String(fd.get("locale") ?? "hi") as Locale;
    if (!isEntity(entity) || !isLocale(locale) || locale === "en") throw new Error("Choose a language first.");
    const items = (await workItems(entity, locale)).filter((w) => (id ? w.id === id : w.fields.some((f) => f.state !== "ok"))).slice(0, 15);
    if (!items.length) return "Everything here is already translated.";
    let n = 0;
    for (const w of items) {
      const todo = Object.fromEntries(w.fields.filter((f) => id || f.state !== "ok").map((f) => [f.field, f.en]));
      if (!Object.keys(todo).length) continue;
      const out = await translateFields(todo, locale, `Kind of content: ${entity}. Item: ${w.label}.`);
      for (const [field, text] of Object.entries(out)) { await saveTranslation(entity, w.id, field, locale, text, todo[field], "auto"); n++; }
    }
    await audit(me.id, "translation.auto", entity, id || "*", { fields: n });
    revalidatePath("/", "layout");
    return `Drafted ${n} field${n === 1 ? "" : "s"} in ${langName(locale)}. Please read them through — they're marked “auto” until someone saves them.`;
  });
}

/** Which languages are switched on, and the display currency rates. */
export async function saveDisplay(fd: FormData) {
  await run(back(fd), async () => {
    const me = await guard("marketing", "write");
    const d = await getSetting("display");
    const languages = ["en", ...LOCALES.filter((l) => l !== "en" && fd.get(`lang_${l}`) === "on")];
    const rates: Record<string, number> = {};
    for (const c of CURRENCIES) {
      if (c === "INR") continue;
      const v = Number(String(fd.get(`rate_${c}`) ?? "").replace(/,/g, ""));
      if (fd.get(`on_${c}`) === "on" && v > 0 && v < 100000) rates[c] = Math.round(v * 100) / 100;
    }
    const off = CURRENCIES.filter((c) => c !== "INR" && !rates[c]);
    await saveSetting("display", { ...d, languages, rates, off, auto: fd.get("auto") === "on" });
    await audit(me.id, "display.save", "settings", "display", { languages, currencies: Object.keys(rates) });
    revalidatePath("/", "layout");
    return "Languages and currencies saved.";
  });
}

export async function refreshRatesNow(fd: FormData) {
  await run(back(fd), async () => {
    await guard("marketing", "write");
    await refreshDisplayRates(true);
    revalidatePath("/", "layout");
    return "Exchange rates updated.";
  });
}

/** Draft the site's interface text (menus, buttons, checkout, account…) for one language with Claude.
 *  Does up to 300 phrases per click so the request stays short; press again to continue. */
export async function translateUi(fd: FormData) {
  await run(back(fd), async () => {
    const me = await guard("marketing", "write");
    const locale = String(fd.get("locale") ?? "") as Locale;
    if (!isLocale(locale) || locale === "en" || locale === "hi") throw new Error("Choose a language first.");
    const have = await uiDict(locale);
    const missing = UI_KEYS.filter((k) => !have[k]);
    if (!missing.length) return `${langName(locale)} interface text is complete (${UI_KEYS.length} phrases).`;
    let n = 0;
    for (let i = 0; i < Math.min(missing.length, 300); i += 60) {
      const chunk = missing.slice(i, i + 60);
      const out = await translateFields(Object.fromEntries(chunk.map((k, j) => [`k${j}`, k])), locale, "Website interface text: menu items, buttons, form labels, checkout and account messages.", 8000);
      const map: Record<string, string> = {};
      chunk.forEach((k, j) => { if (out[`k${j}`]) map[k] = out[`k${j}`]; });
      await saveUiStrings(locale, map, "auto"); n += Object.keys(map).length;
    }
    await audit(me.id, "translation.ui", "ui", locale, { phrases: n });
    revalidatePath("/", "layout");
    const left = missing.length - n;
    return left > 0 ? `Drafted ${n} ${langName(locale)} phrases — ${left} to go. Press “Translate interface” again to continue.` : `${langName(locale)} interface text is complete. Switch it on under “Languages on the site”.`;
  });
}
