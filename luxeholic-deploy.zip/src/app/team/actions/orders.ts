"use server";
import { eq } from "drizzle-orm";
import { db, schema } from "@/db";
import { guard, run, str, optStr, rupees } from "@/lib/team";
import { audit, sendMail } from "@/lib/notify";
import { restock, routeToVendors } from "@/lib/orders";
import { formatINR } from "@/lib/money";
import { SITE_URL } from "@/lib/site";

async function load(id: string) {
  const [o] = await db.select().from(schema.orders).where(eq(schema.orders.id, id));
  if (!o) throw new Error("Order not found");
  return o;
}
const link = (o: { number: string; accessToken: string }) => `${SITE_URL}/order/${o.number}?t=${o.accessToken}`;

/** Sales confirmed the COD order by phone → it becomes real and is routed to vendors. */
export async function confirmCod(fd: FormData) {
  const id = str(fd, "id");
  await run(`/team/orders/${id}`, async () => {
    const me = await guard("orders");
    const o = await load(id);
    if (o.status !== "PENDING") throw new Error("Only pending orders can be confirmed.");
    await db.update(schema.orders).set({ status: "CONFIRMED", internalNotes: append(o.internalNotes, `Confirmed by phone by ${me.name}`) }).where(eq(schema.orders.id, id));
    await routeToVendors(id);
    await sendMail(o.email, `Order ${o.number} confirmed`, "Your order is confirmed.", "Thank you for confirming. We're preparing your piece and will email tracking details once it ships.", { label: "View order", url: link(o) });
    await audit(me.id, "order.confirm_cod", "order", id);
    return "Order confirmed and sent to procurement";
  });
}

/** Bank transfer received (UTR matched on the bank statement). */
export async function verifyBankTransfer(fd: FormData) {
  const id = str(fd, "id");
  await run(`/team/orders/${id}`, async () => {
    const me = await guard("orders");
    const o = await load(id);
    const amount = rupees(fd, "amount") ?? o.total;
    const paid = o.amountPaid + amount;
    await db.insert(schema.payments).values({ orderId: id, provider: "BANK_TRANSFER", txnId: `BT-${o.number}-${Date.now().toString(36)}`, amount, status: "PAID", providerRef: o.bankUtr, purpose: "FULL" });
    await db.update(schema.orders).set({ amountPaid: paid, paymentStatus: paid >= o.total ? "PAID" : "PARTIALLY_PAID", status: o.status === "PENDING" ? "CONFIRMED" : o.status }).where(eq(schema.orders.id, id));
    await routeToVendors(id);
    await sendMail(o.email, `Payment received for ${o.number}`, "Payment received — thank you.", `We've received ${formatINR(amount)} by bank transfer. Your order is confirmed.`, { label: "View order", url: link(o) });
    await audit(me.id, "order.verify_bank", "order", id, { amount, utr: o.bankUtr });
    return "Payment verified";
  });
}

/** COD / balance cash collected by courier and remitted. */
export async function markBalanceCollected(fd: FormData) {
  const id = str(fd, "id");
  await run(`/team/orders/${id}`, async () => {
    const me = await guard("orders");
    const o = await load(id);
    const due = o.total - o.amountPaid;
    if (due <= 0) throw new Error("Nothing outstanding on this order.");
    await db.insert(schema.payments).values({ orderId: id, provider: "COD", txnId: `COD-${o.number}-${Date.now().toString(36)}`, amount: due, status: "PAID", purpose: "BALANCE" });
    await db.update(schema.orders).set({ amountPaid: o.total, paymentStatus: "PAID" }).where(eq(schema.orders.id, id));
    await audit(me.id, "order.balance_collected", "order", id, { amount: due });
    return `${formatINR(due)} marked as collected`;
  });
}

const FLOW = ["PENDING", "CONFIRMED", "PROCESSING", "SHIPPED", "DELIVERED", "CANCELLED", "RETURN_REQUESTED", "RETURNED"] as const;
export async function updateOrderStatus(fd: FormData) {
  const id = str(fd, "id");
  await run(`/team/orders/${id}`, async () => {
    const me = await guard("orders");
    const o = await load(id);
    const status = str(fd, "status") as (typeof FLOW)[number];
    if (!FLOW.includes(status)) throw new Error("Invalid status");
    const courier = optStr(fd, "courier") ?? o.courier, tracking = optStr(fd, "trackingNumber") ?? o.trackingNumber;
    if (status === "SHIPPED" && !tracking) throw new Error("Add the courier and tracking number to mark as shipped.");
    await db.update(schema.orders).set({ status, courier, trackingNumber: tracking }).where(eq(schema.orders.id, id));
    if ((status === "CANCELLED" || status === "RETURNED") && o.status !== "CANCELLED" && o.status !== "RETURNED") await restock(id);
    const mails: Partial<Record<typeof status, [string, string]>> = {
      SHIPPED: [`Your order ${o.number} has shipped`, `It's on its way with <b>${courier}</b>. Tracking number: <b>${tracking}</b>.${o.total - o.amountPaid > 0 ? `<br><br>Please keep ${formatINR(o.total - o.amountPaid)} ready for the courier.` : ""}`],
      DELIVERED: [`Delivered: ${o.number}`, "We hope it makes you smile every time you see it. If anything isn't perfect, you can request a return from your order page."],
      CANCELLED: [`Order ${o.number} cancelled`, o.amountPaid > 0 ? `Your refund of ${formatINR(o.amountPaid)} will reach your original payment method within 5–7 business days.` : "Your order has been cancelled. No payment was taken."],
      RETURNED: [`Return received for ${o.number}`, "We've received your return. Your refund is being processed and will reach you within 5–7 business days."],
    };
    const m = mails[status];
    if (m && fd.get("notify") !== "off") await sendMail(o.email, m[0], m[0], m[1], { label: "View order", url: link(o) });
    await audit(me.id, `order.status.${status.toLowerCase()}`, "order", id, { from: o.status });
    if (status === "CONFIRMED") await routeToVendors(id);
    return `Order ${status.toLowerCase().replace("_", " ")}`;
  });
}

export async function saveOrderNote(fd: FormData) {
  const id = str(fd, "id");
  await run(`/team/orders/${id}`, async () => {
    const me = await guard("orders");
    const o = await load(id);
    const note = str(fd, "note");
    if (!note) throw new Error("Write a note first.");
    await db.update(schema.orders).set({ internalNotes: append(o.internalNotes, `${me.name}: ${note}`) }).where(eq(schema.orders.id, id));
    return "Note added";
  });
}

export async function markRefunded(fd: FormData) {
  const id = str(fd, "id");
  await run(`/team/orders/${id}`, async () => {
    const me = await guard("orders");
    const o = await load(id);
    await db.update(schema.orders).set({ paymentStatus: "REFUNDED", internalNotes: append(o.internalNotes, `Refund of ${formatINR(o.amountPaid)} recorded by ${me.name} (ref ${str(fd, "ref") || "—"})`) }).where(eq(schema.orders.id, id));
    await audit(me.id, "order.refunded", "order", id, { amount: o.amountPaid, ref: str(fd, "ref") });
    return "Refund recorded";
  });
}

function append(prev: string | null, line: string) {
  const stamp = new Date().toLocaleString("en-IN", { timeZone: "Asia/Kolkata", day: "numeric", month: "short", hour: "numeric", minute: "2-digit" });
  return `${prev ? prev + "\n" : ""}[${stamp}] ${line}`;
}
