"use server";
import { redirect } from "next/navigation";
import { revalidatePath } from "next/cache";
import { eq, sql } from "drizzle-orm";
import { db, schema } from "@/db";
import { cookies } from "next/headers";
import { guard, run, str, optStr, int, rupees, bool } from "@/lib/team";
import { audit, sendMail } from "@/lib/notify";
import { hashPassword } from "@/lib/auth";
import { tempPassword, encryptJson } from "@/lib/crypto";
import { MODULES, type ModuleKey } from "@/lib/rbac";
import { getSettings, saveSetting, DEFAULT_SETTINGS } from "@/lib/settings";
import { SITE_URL, slugify } from "@/lib/site";

/** Creates a team login. The temporary password is shown once to the super admin (and emailed if SMTP is set). */
export async function createStaff(fd: FormData) {
  const me = await guard("super");
  const name = str(fd, "name"), email = str(fd, "email").toLowerCase();
  const teamId = str(fd, "teamId");
  const role = str(fd, "role") === "TEAM_LEAD" ? "TEAM_LEAD" : "MEMBER";
  let error = "";
  if (name.length < 2 || !/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email) || !teamId) error = "Name, a valid email and a team are required.";
  else if ((await db.select({ id: schema.staff.id }).from(schema.staff).where(eq(schema.staff.email, email))).length) error = "A team member with that email already exists.";
  if (error) redirect(`/team/staff?err=${encodeURIComponent(error)}`);
  const pw = tempPassword();
  const [s] = await db.insert(schema.staff).values({ name, email, phone: optStr(fd, "phone"), teamId, role, passwordHash: await hashPassword(pw), mustChangePassword: true }).returning();
  const [team] = await db.select().from(schema.teams).where(eq(schema.teams.id, teamId));
  if (bool(fd, "sendEmail")) {
    await sendMail(email, "Your Luxeholic team login", `Welcome to Luxeholic, ${name.split(" ")[0]}.`,
      `You've been added to the <b>${team?.name}</b> team.<br><br>Sign in at <b>${SITE_URL}/team/login</b><br>Team: <b>${team?.name}</b><br>Email: <b>${email}</b><br>Temporary password: <b>${pw}</b><br><br>You'll be asked to choose your own password on first sign-in.`,
      { label: "Sign in", url: `${SITE_URL}/team/login` });
  }
  await audit(me.id, "staff.create", "staff", s.id, { email, team: team?.slug, role });
  revalidatePath("/team/staff");
  await showOnce(email, pw, false);
  redirect("/team/staff?ok=Login%20created");
}

export async function updateStaff(fd: FormData) {
  await run("/team/staff", async () => {
    const me = await guard("super");
    const id = str(fd, "id");
    const [s] = await db.select().from(schema.staff).where(eq(schema.staff.id, id));
    if (!s) throw new Error("Not found");
    if (s.role === "SUPER_ADMIN") throw new Error("The super admin account can't be changed here.");
    const active = bool(fd, "active");
    const teamId = str(fd, "teamId") || s.teamId;
    const moved = teamId !== s.teamId || active !== s.active;
    await db.update(schema.staff).set({
      name: str(fd, "name") || s.name, phone: optStr(fd, "phone"), teamId, active,
      role: str(fd, "role") === "TEAM_LEAD" ? "TEAM_LEAD" : "MEMBER",
      ...(moved ? { sessionVersion: sql`${schema.staff.sessionVersion} + 1` } : {}), // force re-login on team change / deactivation
    }).where(eq(schema.staff.id, id));
    await audit(me.id, "staff.update", "staff", id, { active, teamId });
    return `${s.name} updated`;
  });
}

export async function resetStaffPassword(fd: FormData) {
  const me = await guard("super");
  const id = str(fd, "id");
  const [s] = await db.select().from(schema.staff).where(eq(schema.staff.id, id));
  if (!s || s.role === "SUPER_ADMIN") redirect("/team/staff?err=Can%27t%20reset%20that%20account");
  const pw = tempPassword();
  await db.update(schema.staff).set({ passwordHash: await hashPassword(pw), mustChangePassword: true, sessionVersion: sql`${schema.staff.sessionVersion} + 1` }).where(eq(schema.staff.id, id));
  await audit(me.id, "staff.reset_password", "staff", id);
  await showOnce(s!.email, pw, true);
  redirect("/team/staff?ok=Password%20reset");
}

export async function saveTeam(fd: FormData) {
  await run("/team/teams", async () => {
    const me = await guard("super");
    const id = str(fd, "id");
    const modules: Record<string, "read" | "write"> = {};
    for (const m of Object.keys(MODULES) as ModuleKey[]) {
      const v = str(fd, `m_${m}`);
      if (v === "read" || v === "write") modules[m] = v;
    }
    const values = { name: str(fd, "name"), description: optStr(fd, "description"), color: str(fd, "color") || "#A8834A", sortOrder: int(fd, "sortOrder"), modules };
    if (!values.name) throw new Error("Team name is required.");
    if (id) await db.update(schema.teams).set(values).where(eq(schema.teams.id, id));
    else await db.insert(schema.teams).values({ ...values, slug: slugify(values.name) });
    await audit(me.id, id ? "team.update" : "team.create", "team", id || null, { name: values.name, modules });
    return id ? "Team access saved" : "Team created";
  });
}

export async function saveSettings(fd: FormData) {
  await run("/team/settings", async () => {
    const me = await guard("super");
    const section = str(fd, "section");
    const cur = await getSettings();
    switch (section) {
      case "business": {
        const b = { ...cur.business };
        for (const k of Object.keys(DEFAULT_SETTINGS.business) as (keyof typeof b)[]) b[k] = str(fd, k);
        b.gstin = b.gstin.toUpperCase();
        await saveSetting("business", b);
        await saveSetting("announcement", str(fd, "announcement"));
        break;
      }
      case "payments":
        await saveSetting("payments", {
          payu: bool(fd, "payu"), phonepe: bool(fd, "phonepe"), bankTransfer: bool(fd, "bankTransfer"), cod: bool(fd, "cod"), partialCod: bool(fd, "partialCod"),
          advancePercent: Math.min(50, Math.max(1, int(fd, "advancePercent", 10))), codMaxOrder: rupees(fd, "codMaxOrder") ?? 1000000,
          partialCodMaxOrder: rupees(fd, "partialCodMaxOrder") ?? 20000000, codFee: rupees(fd, "codFee") ?? 0,
        });
        break;
      case "bank":
        await saveSetting("bank", { accountName: str(fd, "accountName"), accountNumber: str(fd, "accountNumber"), ifsc: str(fd, "ifsc").toUpperCase(), bankName: str(fd, "bankName"), branch: str(fd, "branch"), upiId: str(fd, "upiId"), qrImage: str(fd, "qrImage") });
        break;
      case "shipping":
        await saveSetting("shipping", { freeAbove: rupees(fd, "freeAbove") ?? 0, flatFee: rupees(fd, "flatFee") ?? 0, domesticOnly: true });
        await saveSetting("returns", { windowDays: Math.max(1, int(fd, "windowDays", 7)), finalSaleCategories: [] });
        break;
      case "fx": {
        const fx: Record<string, number> = {};
        for (const line of str(fd, "fx").split(/\r?\n/)) {
          const [c, v] = line.split(/[=:\s]+/).map((x) => x.trim());
          const n = parseFloat(v ?? "");
          if (c && n > 0) fx[c.toUpperCase()] = n;
        }
        if (!Object.keys(fx).length) throw new Error("Enter at least one rate, e.g. USD = 88");
        await saveSetting("fx", fx);
        break;
      }
      case "marketplaces": {
        const url = (k: string) => { const v = str(fd, k); if (v && !/^https:\/\//.test(v)) throw new Error(`${k} link must start with https://`); return v; };
        await saveSetting("marketplaces", { amazon: url("amazon"), flipkart: url("flipkart"), blinkit: url("blinkit"), walmart: url("walmart") });
        break;
      }
      case "tracking":
        await saveSetting("tracking", { ga4Id: str(fd, "ga4Id"), googleAdsId: str(fd, "googleAdsId"), metaPixelId: str(fd, "metaPixelId"), gmcVerification: str(fd, "gmcVerification") });
        break;
      default: throw new Error("Unknown section");
    }
    await audit(me.id, `settings.${section}`, "settings", section);
    return "Settings saved";
  });
}

/** Temporary passwords are handed to the super admin once via a short-lived encrypted cookie — never in the URL. */
async function showOnce(email: string, pw: string, reset: boolean) {
  (await cookies()).set("lx_onetime", encryptJson({ email, pw, reset }), { httpOnly: true, sameSite: "strict", secure: process.env.NODE_ENV === "production", path: "/team/staff", maxAge: 90 });
}
