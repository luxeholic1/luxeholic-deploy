"use server";
import { and, eq, inArray } from "drizzle-orm";
import { db, schema } from "@/db";
import { guard, run, str, optStr, bool } from "@/lib/team";
import { notifyStaff, audit } from "@/lib/notify";
import { materializeRecurring } from "@/lib/tasks";
import { addDays, todayIST, prettyDay } from "@/lib/dates";

const PRIORITIES = ["LOW", "MEDIUM", "HIGH", "URGENT"] as const;
const RECUR = ["NONE", "DAILY", "WEEKDAYS", "WEEKLY", "MONTHLY"] as const;
const STATUSES = ["TODO", "IN_PROGRESS", "BLOCKED", "DONE"] as const;

/**
 * Create a task / to-do / meeting.
 * - Super admin: any team, or company-wide; any person; "each member" gives everyone their own copy.
 * - Team lead: own team only.
 * - Member: personal tasks for themselves.
 * Recurring (daily / working days / weekly / monthly) tasks are saved as templates and appear on each day.
 */
export async function createTask(fd: FormData) {
  await run("/team/tasks", async () => {
    const me = await guard();
    const title = str(fd, "title");
    if (title.length < 3) throw new Error("Give the task a title.");
    let teamId = str(fd, "teamId") || null;
    let assignee = str(fd, "assigneeId") || null;
    if (teamId === "ALL") teamId = null;
    if (me.role === "TEAM_LEAD") { teamId = me.teamId; }
    if (me.role === "MEMBER") { teamId = me.teamId; assignee = me.id; }
    const dueDate = str(fd, "dueDate") || todayIST();
    const recurrence = (RECUR.includes(str(fd, "recurrence") as never) ? str(fd, "recurrence") : "NONE") as (typeof RECUR)[number];
    const base = {
      title, description: optStr(fd, "description"), kind: ["TASK", "MEETING", "REMINDER"].includes(str(fd, "kind")) ? str(fd, "kind") : "TASK",
      teamId, createdById: me.id, dueDate, dueTime: optStr(fd, "dueTime"),
      priority: (PRIORITIES.includes(str(fd, "priority") as never) ? str(fd, "priority") : "MEDIUM") as (typeof PRIORITIES)[number],
      recurrence, recurUntil: optStr(fd, "recurUntil"), isTemplate: recurrence !== "NONE",
    };
    // Resolve who gets it
    let people: (string | null)[] = [assignee];
    if (assignee === "EACH") {
      if (!teamId) {
        const all = await db.select({ id: schema.staff.id }).from(schema.staff).where(eq(schema.staff.active, true));
        people = all.map((p) => p.id);
      } else {
        const members = await db.select({ id: schema.staff.id }).from(schema.staff).where(and(eq(schema.staff.teamId, teamId), eq(schema.staff.active, true)));
        if (!members.length) throw new Error("That team has no active members yet.");
        people = members.map((m) => m.id);
      }
    } else if (assignee) {
      const [p] = await db.select().from(schema.staff).where(eq(schema.staff.id, assignee));
      if (!p) throw new Error("Unknown person.");
      if (me.role === "TEAM_LEAD" && p.teamId !== me.teamId) throw new Error("Leads can assign within their own team only.");
    }
    const rows = await db.insert(schema.tasks).values(people.map((a) => ({ ...base, assigneeId: a }))).returning();
    if (recurrence !== "NONE") await materializeRecurring(todayIST(), addDays(todayIST(), 7));

    // Notify
    const when = `${prettyDay(dueDate)}${base.dueTime ? ` ${base.dueTime}` : ""}${recurrence !== "NONE" ? ` · repeats ${recurrence.toLowerCase().replace("weekdays", "Mon–Sat")}` : ""}`;
    const direct = people.filter((p): p is string => !!p && p !== me.id);
    if (direct.length) await notifyStaff(direct, `New ${base.kind.toLowerCase()}: ${title}`, `From ${me.name} · ${when}`, "/team/tasks", bool(fd, "email"));
    else if (!assignee) {
      const audience = await db.select({ id: schema.staff.id }).from(schema.staff).where(teamId ? and(eq(schema.staff.teamId, teamId), eq(schema.staff.active, true)) : eq(schema.staff.active, true));
      await notifyStaff(audience.map((a) => a.id).filter((id) => id !== me.id), `New team ${base.kind.toLowerCase()}: ${title}`, `From ${me.name} · ${when}`, "/team/tasks", bool(fd, "email"));
    }
    await audit(me.id, "task.create", "task", rows[0].id, { title, teamId, people: people.length, recurrence });
    return { msg: rows.length > 1 ? `Assigned to ${rows.length} people` : "Task created", to: str(fd, "back") || "/team/tasks" };
  });
}

async function loadEditable(id: string) {
  const me = await guard();
  const [t] = await db.select().from(schema.tasks).where(eq(schema.tasks.id, id));
  if (!t) throw new Error("Task not found");
  const isMine = t.assigneeId === me.id;
  const teamWide = !t.assigneeId && (t.teamId === me.teamId || !t.teamId);
  const lead = me.role === "TEAM_LEAD" && t.teamId === me.teamId;
  const canWork = me.role === "SUPER_ADMIN" || isMine || teamWide || lead;
  const canManage = me.role === "SUPER_ADMIN" || t.createdById === me.id || lead;
  return { me, t, canWork, canManage };
}

export async function setTaskStatus(fd: FormData) {
  await run(str(fd, "back") || "/team/tasks", async () => {
    const { me, t, canWork } = await loadEditable(str(fd, "id"));
    if (!canWork) throw new Error("This task isn't yours to update.");
    const status = str(fd, "status") as (typeof STATUSES)[number];
    if (!STATUSES.includes(status)) throw new Error("Invalid status");
    await db.update(schema.tasks).set({ status, completedAt: status === "DONE" ? new Date() : null }).where(eq(schema.tasks.id, t.id));
    if (status === "DONE" && t.createdById !== me.id) await notifyStaff([t.createdById], `✓ ${me.name} completed: ${t.title}`, undefined, `/team/tasks/${t.id}`);
    if (status === "BLOCKED" && t.createdById !== me.id) await notifyStaff([t.createdById], `Blocked: ${t.title}`, `${me.name} marked this as blocked`, `/team/tasks/${t.id}`);
    return status === "DONE" ? "Marked done" : "Updated";
  });
}

export async function commentTask(fd: FormData) {
  const id = str(fd, "id");
  await run(`/team/tasks/${id}`, async () => {
    const { me, t, canWork, canManage } = await loadEditable(id);
    if (!canWork && !canManage) throw new Error("No access.");
    const body = str(fd, "body");
    if (!body) throw new Error("Write a comment first.");
    await db.insert(schema.taskComments).values({ taskId: id, authorId: me.id, body: body.slice(0, 4000) });
    const to = [t.createdById, t.assigneeId].filter((x): x is string => !!x && x !== me.id);
    await notifyStaff(to, `${me.name} commented on: ${t.title}`, body.slice(0, 120), `/team/tasks/${id}`);
    return "Comment added";
  });
}

export async function updateTask(fd: FormData) {
  const id = str(fd, "id");
  await run(`/team/tasks/${id}`, async () => {
    const { me, t, canManage } = await loadEditable(id);
    if (!canManage) throw new Error("Only the creator, team lead or super admin can edit this.");
    await db.update(schema.tasks).set({
      title: str(fd, "title") || t.title, description: optStr(fd, "description"), dueDate: str(fd, "dueDate") || t.dueDate,
      dueTime: optStr(fd, "dueTime"), priority: (PRIORITIES.includes(str(fd, "priority") as never) ? str(fd, "priority") : t.priority) as (typeof PRIORITIES)[number],
    }).where(eq(schema.tasks.id, id));
    await audit(me.id, "task.update", "task", id);
    return "Task updated";
  });
}

export async function deleteTask(fd: FormData) {
  await run("/team/tasks", async () => {
    const { me, t, canManage } = await loadEditable(str(fd, "id"));
    if (!canManage) throw new Error("Only the creator, team lead or super admin can delete this.");
    if (t.isTemplate) {
      // Stop the series: delete future, keep history
      const today = todayIST();
      const future = await db.select({ id: schema.tasks.id, dueDate: schema.tasks.dueDate, status: schema.tasks.status }).from(schema.tasks).where(eq(schema.tasks.templateId, t.id));
      const drop = future.filter((f) => f.dueDate > today && f.status !== "DONE").map((f) => f.id);
      if (drop.length) await db.delete(schema.tasks).where(inArray(schema.tasks.id, drop));
    }
    await db.delete(schema.tasks).where(eq(schema.tasks.id, t.id));
    await audit(me.id, "task.delete", "task", t.id, { title: t.title });
    return { msg: t.isTemplate ? "Recurring series stopped" : "Task deleted", to: "/team/tasks" };
  });
}

export async function markAllRead() {
  await run("/team/notifications", async () => {
    const me = await guard();
    await db.update(schema.notifications).set({ read: true }).where(eq(schema.notifications.staffId, me.id));
    return "All caught up";
  });
}
