"use server";
import { eq, inArray } from "drizzle-orm";
import { db, schema } from "@/db";
import { guard, run, str, optStr } from "@/lib/team";
import { audit, notifyTeams, sendMail } from "@/lib/notify";
import { newPoNumber } from "@/lib/orders";
import { placePurchaseOrder } from "@/lib/vendors/sync";
import { SITE_URL } from "@/lib/site";

const STATUSES = ["DRAFT", "SENT", "CONFIRMED", "SHIPPED", "RECEIVED", "CANCELLED"] as const;

export async function placeWithVendor(fd: FormData) {
  const id = str(fd, "id");
  await run(`/team/purchase-orders/${id}`, async () => {
    const me = await guard("purchaseOrders");
    const r = await placePurchaseOrder(id);
    if (!r.ok) throw new Error(r.message);
    await db.update(schema.purchaseOrders).set({ status: "SENT", vendorRef: r.vendorRef ?? null }).where(eq(schema.purchaseOrders.id, id));
    await audit(me.id, "po.place_api", "purchase_order", id, r);
    return r.message;
  });
}

export async function updatePo(fd: FormData) {
  const id = str(fd, "id");
  await run(`/team/purchase-orders/${id}`, async () => {
    const me = await guard("purchaseOrders");
    const po = await db.query.purchaseOrders.findFirst({ where: eq(schema.purchaseOrders.id, id), with: { order: true, items: true } });
    if (!po) throw new Error("PO not found");
    const status = str(fd, "status") as (typeof STATUSES)[number];
    if (!STATUSES.includes(status)) throw new Error("Invalid status");
    const tracking = optStr(fd, "trackingNumber");
    await db.update(schema.purchaseOrders).set({ status, vendorRef: optStr(fd, "vendorRef"), trackingNumber: tracking, notes: optStr(fd, "notes"), expectedDate: optStr(fd, "expectedDate") }).where(eq(schema.purchaseOrders.id, id));
    // Vendor shipped a dropship order → move customer order to SHIPPED with the tracking number
    if (status === "SHIPPED" && po.order && tracking && fd.get("syncCustomer") === "on" && !["SHIPPED", "DELIVERED"].includes(po.order.status)) {
      const courier = optStr(fd, "courier") ?? "Courier";
      await db.update(schema.orders).set({ status: "SHIPPED", trackingNumber: tracking, courier }).where(eq(schema.orders.id, po.order.id));
      await sendMail(po.order.email, `Your order ${po.order.number} has shipped`, "Your order has shipped", `It's on its way with <b>${courier}</b>. Tracking number: <b>${tracking}</b>.`, { label: "View order", url: `${SITE_URL}/order/${po.order.number}?t=${po.order.accessToken}` });
    }
    // Stock PO received → add to stock
    if (status === "RECEIVED" && po.status !== "RECEIVED" && !po.order) {
      for (const i of po.items) if (i.productId) {
        const [p] = await db.select({ stock: schema.products.stock }).from(schema.products).where(eq(schema.products.id, i.productId));
        await db.update(schema.products).set({ stock: (p?.stock ?? 0) + i.quantity }).where(eq(schema.products.id, i.productId));
      }
      await notifyTeams(["inventory"], `Stock received: ${po.number}`, `${po.items.length} line(s) added to stock`, `/team/purchase-orders/${id}`);
    }
    await audit(me.id, `po.status.${status.toLowerCase()}`, "purchase_order", id);
    return "Purchase order updated";
  });
}

/** Manual stock PO: lines of "SKU, qty, unit cost ₹" */
export async function createStockPo(fd: FormData) {
  await run("/team/purchase-orders", async () => {
    const me = await guard("purchaseOrders");
    const vendorId = str(fd, "vendorId");
    if (!vendorId) throw new Error("Choose a vendor.");
    const rows = str(fd, "lines").split(/\r?\n/).map((l) => l.split(",").map((x) => x.trim())).filter((l) => l[0]);
    if (!rows.length) throw new Error("Add at least one line: SKU, qty, unit cost");
    const skus = rows.map((r) => r[0]);
    const prods = await db.select().from(schema.products).where(inArray(schema.products.sku, skus));
    const items = rows.map(([sku, qty, cost]) => {
      const p = prods.find((x) => x.sku === sku);
      return { productId: p?.id ?? null, title: p?.title ?? sku, vendorSku: p?.vendorSku ?? sku, quantity: Math.max(1, parseInt(qty) || 1), unitCost: Math.round((parseFloat((cost ?? "0").replace(/[₹,]/g, "")) || 0) * 100) };
    });
    const [po] = await db.insert(schema.purchaseOrders).values({ number: newPoNumber(), vendorId, status: "DRAFT", createdById: me.id, notes: optStr(fd, "notes"), totalCost: items.reduce((s, i) => s + i.unitCost * i.quantity, 0) }).returning();
    await db.insert(schema.purchaseOrderItems).values(items.map((i) => ({ ...i, poId: po.id })));
    await audit(me.id, "po.create", "purchase_order", po.id);
    return { msg: `PO ${po.number} created`, to: `/team/purchase-orders/${po.id}` };
  });
}
