"use server";
import { revalidatePath } from "next/cache";
import { z } from "zod";
import { db, schema } from "@/db";
import { guard } from "@/lib/team";
import { audit } from "@/lib/notify";
import { checkChapter, type HeroContent } from "@/lib/hero-shared";

const link = z.object({ label: z.string().trim().max(40), href: z.string().trim().max(200) });
const chapter = z.object({
  id: z.string().regex(/^[a-z0-9-]{1,40}$/), show: z.boolean(),
  video: z.string().trim().regex(/^\/(media|u)\/[a-z0-9/._-]+$/i, "Video path must be one of our uploads"),
  mobile: z.string().trim().regex(/^\/(media|u)\/[a-z0-9/._-]+$/i).optional().or(z.literal("")),
  theme: z.enum(["dark", "light"]), focus: z.number().min(0).max(100),
  alt: z.string().trim().max(160), eyebrow: z.string().trim().max(48), headline: z.string().trim().max(90), text: z.string().trim().max(260),
  cta1: link, cta2: link,
});
const trustLink = z.object({ label: z.string().trim().max(60, "Promise text: keep it under 60 characters"), href: z.string().trim().max(200) });
const content = z.object({ chapters: z.array(chapter).min(1).max(8), trust: z.array(trustLink).max(6) });

export async function saveHero(raw: HeroContent): Promise<{ ok?: string; error?: string }> {
  try {
    const me = await guard("marketing", "write");
    const p = content.safeParse(raw);
    if (!p.success) {
      const i = p.error.issues[0];
      const where = i?.path[0] === "chapters" ? `Chapter ${Number(i.path[1]) + 1}, ${String(i.path.slice(2).join(" ")).replace("cta1 label", "main button").replace("cta2 label", "second link").replace("cta1 href", "main button link").replace("cta2 href", "second link address")}: ` : i?.path[0] === "trust" ? "Promise bar: " : "";
      return { error: where + (i?.message ?? "Please check the hero.") };
    }
    const v = p.data;
    if (!v.chapters.some((c) => c.show)) return { error: "Keep at least one chapter visible." };
    const blocking = v.chapters.flatMap((c, i) => (c.show ? checkChapter({ ...c, mobile: c.mobile || undefined }, i === 0).filter((x) => x.level === "bad").map((x) => `Chapter ${i + 1}: ${x.msg}`) : []));
    if (blocking.length) return { error: blocking[0] };
    const value = { ...v, chapters: v.chapters.map((c) => ({ ...c, mobile: c.mobile || undefined })) };
    await db.insert(schema.settings).values({ key: "hero", value }).onConflictDoUpdate({ target: schema.settings.key, set: { value } });
    await audit(me.id, "hero.save", "settings", "hero", { chapters: v.chapters.length });
    revalidatePath("/");
    return { ok: "Saved — the homepage is updated." };
  } catch (e) { return { error: (e as Error).message }; }
}
