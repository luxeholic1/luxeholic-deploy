"use server";
import { eq } from "drizzle-orm";
import { db, schema } from "@/db";
import { guard, run, str, optStr, int, num, rupees, bool } from "@/lib/team";
import { audit, notifyTeams } from "@/lib/notify";
import { encryptJson, decryptJson } from "@/lib/crypto";
import { slugify } from "@/lib/site";
import { importVendorItems, repriceVendor, syncVendor, testVendor } from "@/lib/vendors/sync";
import { sunskyDetails } from "@/lib/vendors/sunsky";
import type { VendorConfig } from "@/db/schema";

const TYPES = ["SUNSKY", "BRANDSGATEWAY", "CSV_FEED", "MANUAL"] as const;

export async function saveVendor(fd: FormData) {
  const id = str(fd, "id");
  const isNew = !id || id === "new";
  await run(isNew ? "/team/vendors/new" : `/team/vendors/${id}`, async () => {
    const me = await guard("vendors");
    const name = str(fd, "name");
    if (!name) throw new Error("Vendor name is required.");
    const type = (TYPES.includes(str(fd, "type") as never) ? str(fd, "type") : "MANUAL") as (typeof TYPES)[number];
    const categoryMap = Object.fromEntries(str(fd, "categoryMap").split(/\r?\n/).map((l) => l.split("=>").map((x) => x.trim())).filter((x) => x.length === 2 && x[0] && x[1]));
    const prevCfg = isNew ? {} : ((await db.select({ c: schema.vendors.config }).from(schema.vendors).where(eq(schema.vendors.id, id)))[0]?.c ?? {});
    const config: VendorConfig = {
      ...prevCfg, // keep API method / search-parameter overrides that this form doesn’t show
      autoPublish: bool(fd, "autoPublish"), maxItems: int(fd, "maxItems", 1500), categoryMap,
      sunskyCategoryIds: str(fd, "sunskyCategoryIds").split(/[,\s]+/).filter(Boolean),
      brandsAllow: str(fd, "brandsAllow").split(",").map((b) => b.trim()).filter(Boolean),
      keywords: str(fd, "keywords").split(",").map((b) => b.trim().toLowerCase()).filter(Boolean),
      minCost: num(fd, "minCost") || undefined, maxCost: num(fd, "maxCost") || undefined,
    };
    const values = {
      name, type, website: optStr(fd, "website"), apiBaseUrl: optStr(fd, "apiBaseUrl"), feedUrl: optStr(fd, "feedUrl"),
      currency: (str(fd, "currency") || "USD").toUpperCase(), markupPercent: num(fd, "markupPercent", 60), dutyPercent: num(fd, "dutyPercent"),
      gstPercent: num(fd, "gstPercent", 18), shippingFlat: rupees(fd, "shippingFlat") ?? 0, dispatchDays: int(fd, "dispatchDays", 3), deliveryDays: int(fd, "deliveryDays", 12),
      contactName: optStr(fd, "contactName"), contactEmail: optStr(fd, "contactEmail"), contactPhone: optStr(fd, "contactPhone"), notes: optStr(fd, "notes"),
      active: bool(fd, "active"), autoRouteOrders: bool(fd, "autoRouteOrders"), config,
    };
    // Credentials are write-only: only overwrite fields that were typed in
    const prev = isNew ? null : decryptJson<Record<string, string>>((await db.select({ c: schema.vendors.credentialsEnc }).from(schema.vendors).where(eq(schema.vendors.id, id)))[0]?.c);
    const creds = { ...(prev ?? {}) };
    for (const k of ["key", "secret", "username", "password", "feedToken"]) { const v = str(fd, `cred_${k}`); if (v) creds[k] = v; }
    if (bool(fd, "clearCreds")) for (const k of Object.keys(creds)) delete creds[k];
    const credentialsEnc = Object.keys(creds).length ? encryptJson(creds) : null;
    let vid = id;
    if (isNew) {
      const [v] = await db.insert(schema.vendors).values({ ...values, credentialsEnc, slug: slugify(name) || `vendor-${Date.now()}` }).returning();
      vid = v.id;
      await notifyTeams(["alliances", "procurement"], `New vendor added: ${name}`, `${type.replace("_", " ").toLowerCase()} · by ${me.name}`, `/team/vendors/${vid}`);
    } else {
      await db.update(schema.vendors).set({ ...values, credentialsEnc }).where(eq(schema.vendors.id, id));
    }
    await audit(me.id, isNew ? "vendor.create" : "vendor.update", "vendor", vid, { name, type, credsChanged: Object.keys(creds).length !== Object.keys(prev ?? {}).length });
    return { msg: isNew ? "Vendor added" : "Vendor saved", to: `/team/vendors/${vid}` };
  });
}

export async function testVendorAction(fd: FormData) {
  const id = str(fd, "id");
  await run(`/team/vendors/${id}`, async () => {
    await guard("vendors");
    const [v] = await db.select().from(schema.vendors).where(eq(schema.vendors.id, id));
    return await testVendor(v);
  });
}

/** Sync runs in the background (large catalogues can take minutes). */
export async function syncVendorAction(fd: FormData) {
  const id = str(fd, "id");
  await run(`/team/vendors/${id}`, async () => {
    const me = await guard("vendors");
    void syncVendor(id).catch((e) => console.error("[sync]", e));
    await audit(me.id, "vendor.sync", "vendor", id);
    return "Sync started — new products will appear as drafts. Refresh in a few minutes.";
  });
}

export async function repriceVendorAction(fd: FormData) {
  const id = str(fd, "id");
  await run(`/team/vendors/${id}`, async () => {
    const me = await guard("vendors");
    const n = await repriceVendor(id);
    await audit(me.id, "vendor.reprice", "vendor", id, { n });
    return `Re-priced ${n} products from current markup & FX`;
  });
}

// ─────────── SunSky product finder ───────────
const finderBack = (fd: FormData, id: string) => { const b = str(fd, "back"); return b.startsWith(`/team/vendors/${id}/finder`) ? b : `/team/vendors/${id}/finder`; };

/** Import the ticked SunSky products (full details are fetched first). */
export async function importFromSunsky(fd: FormData) {
  const id = str(fd, "id");
  await run(finderBack(fd, id), async () => {
    const me = await guard("vendors");
    const skus = [...new Set(fd.getAll("sku").map(String).filter(Boolean))].slice(0, 50);
    if (!skus.length) throw new Error("Tick at least one product to import.");
    const [v] = await db.select().from(schema.vendors).where(eq(schema.vendors.id, id));
    if (!v || v.type !== "SUNSKY") throw new Error("This is not a SunSky vendor.");
    const creds = decryptJson<Record<string, string>>(v.credentialsEnc);
    if (!creds?.key || !creds?.secret) throw new Error("Save the SunSky API key and secret first.");
    const items = await sunskyDetails({ key: creds.key, secret: creds.secret }, { ...(v.config ?? {}), apiBaseUrl: v.apiBaseUrl }, skus);
    const categorySlug = str(fd, "category") || undefined;
    const r = await importVendorItems(v, items, { categorySlug, publish: bool(fd, "publish") });
    await audit(me.id, "vendor.finder.import", "vendor", id, { skus: skus.length, created: r.created, updated: r.updated });
    if (r.created) await notifyTeams(["inventory"], `${r.created} SunSky products imported by ${me.name}`, "Review them in Products.", "/team/products?status=DRAFT");
    const live = bool(fd, "publish") ? " Complete ones are live; the rest are drafts." : " They're drafts — review and publish in Products.";
    return `Imported ${r.created} new, updated ${r.updated}.${r.created ? live : ""}`;
  });
}

/** Keep these finder filters for the scheduled sync (keyword, brand, category, cost range). */
export async function saveFinderRule(fd: FormData) {
  const id = str(fd, "id");
  await run(finderBack(fd, id), async () => {
    const me = await guard("vendors");
    const [v] = await db.select().from(schema.vendors).where(eq(schema.vendors.id, id));
    if (!v) throw new Error("Vendor not found");
    const c: VendorConfig = { ...(v.config ?? {}) };
    const add = (list: string[] | undefined, x: string) => (x ? [...new Set([...(list ?? []), x])] : list);
    c.keywords = add(c.keywords, str(fd, "q").toLowerCase());
    c.brandsAllow = add(c.brandsAllow, str(fd, "brand"));
    c.sunskyCategoryIds = add(c.sunskyCategoryIds, str(fd, "cat"));
    if (num(fd, "min")) c.minCost = num(fd, "min");
    if (num(fd, "max")) c.maxCost = num(fd, "max");
    await db.update(schema.vendors).set({ config: c }).where(eq(schema.vendors.id, id));
    await audit(me.id, "vendor.finder.rule", "vendor", id, { keywords: c.keywords, brands: c.brandsAllow, cats: c.sunskyCategoryIds });
    return "Saved to the import rules — the scheduled sync will follow them.";
  });
}
