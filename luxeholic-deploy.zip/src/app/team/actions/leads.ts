"use server";
import { eq } from "drizzle-orm";
import { db, schema } from "@/db";
import { guard, run, str } from "@/lib/team";
import { audit, notifyStaff } from "@/lib/notify";

const STATUSES = ["NEW", "CALLED", "CLOSED"] as const;

/** Change status, take/assign, and add a call note — one form on each request card. */
export async function updateLead(fd: FormData) {
  const id = str(fd, "id");
  const back = str(fd, "back") || "/team/leads";
  await run(back.startsWith("/team/leads") ? back : "/team/leads", async () => {
    const me = await guard("leads");
    const [l] = await db.select().from(schema.callbacks).where(eq(schema.callbacks.id, id));
    if (!l) throw new Error("Request not found");
    const status = (STATUSES.includes(str(fd, "status") as never) ? str(fd, "status") : l.status) as (typeof STATUSES)[number];
    const assignee = fd.has("assigneeId") ? str(fd, "assigneeId") || null : l.assigneeId;
    const note = str(fd, "note").slice(0, 1000);
    const notes = note ? [...l.notes, { by: me.name, body: note, at: new Date().toISOString() }] : l.notes;
    await db.update(schema.callbacks).set({ status, assigneeId: assignee ?? (status !== "NEW" ? me.id : null), notes }).where(eq(schema.callbacks.id, id));
    if (assignee && assignee !== l.assigneeId && assignee !== me.id) {
      await notifyStaff([assignee], `Call back ${l.name}`, `${l.phone} · ${l.interest} · ${l.bestTime}`, "/team/leads", true);
    }
    await audit(me.id, "lead.update", "callback", id, { status, note: !!note });
    return note ? "Note saved" : `Marked ${status.toLowerCase()}`;
  });
}
