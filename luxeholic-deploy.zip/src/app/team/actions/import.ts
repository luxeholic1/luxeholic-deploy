"use server";
import { revalidatePath } from "next/cache";
import { and, eq, sql } from "drizzle-orm";
import { db, schema } from "@/db";
import { guard } from "@/lib/team";
import { audit, notifyTeams } from "@/lib/notify";
import { parseCsv } from "@/lib/vendors/csv";
import { importListings, rowToListing, type RowResult } from "@/lib/listings";
import { fetchWooStore, wooToListing } from "@/lib/importers/woocommerce";

export type ImportState = {
  ok: boolean; message: string; dryRun?: boolean;
  created?: number; updated?: number; failed?: number; results?: RowResult[];
} | null;

const MAX_ROWS = 2000;

export async function importCsv(_prev: ImportState, fd: FormData): Promise<ImportState> {
  try {
    const me = await guard("products");
    const file = fd.get("file");
    const pasted = String(fd.get("pasted") ?? "").trim();
    let text = "";
    if (file instanceof File && file.size > 0) {
      if (file.size > 6 * 1024 * 1024) return { ok: false, message: "File is over 6 MB — split it into smaller files." };
      if (!/\.(csv|txt)$/i.test(file.name)) return { ok: false, message: "Upload a .csv file (in Excel / Google Sheets: File → Download → CSV)." };
      text = await file.text();
    } else text = pasted;
    if (!text) return { ok: false, message: "Choose a CSV file first." };
    const rows = parseCsv(text);
    if (!rows.length) return { ok: false, message: "No product rows found. Keep the header row from the template." };
    if (rows.length > MAX_ROWS) return { ok: false, message: `${rows.length} rows — please upload at most ${MAX_ROWS} per file.` };
    const dryRun = fd.get("intent") !== "import";
    const mode = (["upsert", "create", "update"].includes(String(fd.get("mode"))) ? fd.get("mode") : "upsert") as "upsert";
    const defaultStatus = fd.get("defaultStatus") === "ACTIVE" ? "ACTIVE" : "DRAFT";
    const r = await importListings(rows.map(rowToListing), { mode, defaultStatus, dryRun, source: "csv" });
    if (!dryRun) {
      await audit(me.id, "products.csv_import", "product", null, { file: file instanceof File ? file.name : "pasted", created: r.created, updated: r.updated, failed: r.failed });
      if (r.created) await notifyTeams(["inventory"], `${r.created} products added by CSV`, `Uploaded by ${me.name}.`, "/team/products?status=DRAFT");
      revalidatePath("/", "layout");
    }
    return {
      ok: true, dryRun, ...r,
      message: dryRun
        ? `Checked ${rows.length} rows: ${r.created} new, ${r.updated} updates, ${r.failed} with errors. Nothing saved yet.`
        : `Imported: ${r.created} created, ${r.updated} updated, ${r.failed} skipped with errors.`,
    };
  } catch (e) {
    return { ok: false, message: (e as Error).message };
  }
}

export async function importFromWoo(_prev: ImportState, fd: FormData): Promise<ImportState> {
  try {
    const me = await guard("products");
    const url = String(fd.get("url") ?? "").trim() || "https://luxeholic.in";
    if (!/^https:\/\/[^\s/]+/.test(url)) return { ok: false, message: "Enter the store address, e.g. https://luxeholic.in" };
    const dryRun = fd.get("intent") !== "import";
    let raw;
    try { raw = await fetchWooStore(url); }
    catch (e) { return { ok: false, message: `Couldn't read ${url}: ${(e as Error).message}` }; }
    const r = await importListings(raw.map((p) => wooToListing(p)), { mode: "upsert", defaultStatus: "ACTIVE", dryRun, source: "woocommerce" });
    let archived = 0;
    if (!dryRun) {
      if (fd.get("archiveDemo") === "on") {
        archived = (await db.update(schema.products).set({ status: "ARCHIVED" })
          .where(and(sql`${schema.products.tags} ? 'demo'`, eq(schema.products.status, "ACTIVE"))).returning({ id: schema.products.id })).length;
      }
      await audit(me.id, "products.woo_import", "product", null, { url, created: r.created, updated: r.updated, archived });
      // Hindi for the products we have translations for (the rest appear in Languages & translations as "to do")
      const { seedHindi } = await import("@/lib/i18n/seed-hi");
      await seedHindi(() => {}).catch(() => 0);
      revalidatePath("/", "layout");
    }
    return { ok: true, dryRun, ...r, message: `${raw.length} products found on ${url}. ${dryRun ? "Preview only — nothing saved." : `${r.created} created, ${r.updated} updated${archived ? `, ${archived} demo products hidden` : ""}.`}` };
  } catch (e) {
    return { ok: false, message: (e as Error).message };
  }
}
