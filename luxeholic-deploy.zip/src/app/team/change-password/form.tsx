"use client";
import { useActionState } from "react";
import { changePassword } from "../actions/auth";

export function ChangePasswordForm() {
  const [s, action, pending] = useActionState(changePassword, null);
  return (
    <form action={action} className="mt-8 space-y-4">
      <div><label className="t-label" htmlFor="current">Current (temporary) password</label><input id="current" name="current" type="password" required className="t-input" autoComplete="current-password" /></div>
      <div><label className="t-label" htmlFor="next">New password</label><input id="next" name="next" type="password" required minLength={10} className="t-input" autoComplete="new-password" /><p className="mt-1 text-xs text-stone-400">10+ characters, letters and a number.</p></div>
      <div><label className="t-label" htmlFor="confirm">Confirm new password</label><input id="confirm" name="confirm" type="password" required className="t-input" autoComplete="new-password" /></div>
      {s?.error && <p className="rounded-md bg-red-50 px-3 py-2 text-sm text-red-700">{s.error}</p>}
      <button disabled={pending} className="t-btn w-full !py-2.5">Save password</button>
    </form>
  );
}
