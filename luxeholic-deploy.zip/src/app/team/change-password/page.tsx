import { redirect } from "next/navigation";
import { getStaff } from "@/lib/auth";
import { ChangePasswordForm } from "./form";

export const metadata = { title: "Set your password", robots: { index: false } };
export default async function ChangePassword() {
  const s = await getStaff();
  if (!s) redirect("/team/login");
  return (
    <div className="flex min-h-screen items-center justify-center bg-stone-50 p-6">
      <div className="w-full max-w-sm">
        <h1 className="text-2xl font-semibold tracking-tight">{s.mustChangePassword ? "Set your own password" : "Change password"}</h1>
        <p className="mt-1 text-sm text-stone-500">{s.mustChangePassword ? "Your account was created with a temporary password. Choose a private one to continue." : s.email}</p>
        <ChangePasswordForm />
      </div>
    </div>
  );
}
