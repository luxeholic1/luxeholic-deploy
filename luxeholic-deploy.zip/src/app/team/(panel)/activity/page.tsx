import { desc } from "drizzle-orm";
import { db, schema } from "@/db";
import { requireSuper } from "@/lib/auth";
import { prettyDateTime } from "@/lib/dates";
import { PageHeader } from "@/components/team/ui";

export const metadata = { title: "Audit log" };
export default async function Activity() {
  await requireSuper();
  const rows = await db.query.activityLogs.findMany({ with: { staff: true }, orderBy: desc(schema.activityLogs.createdAt), limit: 300 });
  return (
    <div>
      <PageHeader title="Audit log" sub="Every sign-in and change made in the team workspace." />
      <div className="t-card overflow-x-auto"><table className="t-table"><thead><tr><th>When</th><th>Who</th><th>Action</th><th>Record</th><th>IP</th></tr></thead><tbody>
        {rows.map((r) => <tr key={r.id}><td className="whitespace-nowrap text-stone-500">{prettyDateTime(r.createdAt)}</td><td>{r.staff?.name ?? "System"}</td><td className="font-mono text-xs">{r.action}</td><td className="text-xs text-stone-500">{r.entity}{r.entityId ? ` · ${r.entityId.slice(0, 10)}` : ""}{r.meta ? <span className="block max-w-md truncate" title={JSON.stringify(r.meta)}>{JSON.stringify(r.meta)}</span> : null}</td><td className="text-xs text-stone-400">{r.ip}</td></tr>)}
      </tbody></table></div>
    </div>
  );
}
