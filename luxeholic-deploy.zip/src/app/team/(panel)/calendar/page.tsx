import Link from "next/link";
import { and, asc, eq, gte, lte, type SQL } from "drizzle-orm";
import { db, schema } from "@/db";
import { requireStaff } from "@/lib/auth";
import { taskScope } from "@/lib/team";
import { withQuery } from "@/lib/url";
import { materializeRecurring, occursOn } from "@/lib/tasks";
import { addDays, monthGrid, monthLabel, shiftMonth, todayIST } from "@/lib/dates";
import { PageHeader, TeamDot } from "@/components/team/ui";

export const metadata = { title: "Calendar" };

type Item = { id: string; title: string; done: boolean; color: string; time: string | null; virtual?: boolean; kind: string };

export default async function Calendar({ searchParams }: { searchParams: Promise<{ m?: string; team?: string }> }) {
  const me = await requireStaff();
  const sp = await searchParams;
  const today = todayIST();
  const month = /^\d{4}-\d{2}$/.test(sp.m ?? "") ? sp.m! : today.slice(0, 7);
  const days = monthGrid(month);
  const from = days[0], to = days[days.length - 1];
  await materializeRecurring(from > addDays(today, -1) ? from : addDays(today, -1), to);
  const horizon = addDays(today, 14);

  const teams = await db.select().from(schema.teams).orderBy(asc(schema.teams.sortOrder));
  const color = (id: string | null) => teams.find((t) => t.id === id)?.color ?? "#57534e";
  const w: SQL[] = [gte(schema.tasks.dueDate, from), lte(schema.tasks.dueDate, to), eq(schema.tasks.isTemplate, false)];
  const scope = taskScope(me);
  if (scope) w.push(scope);
  if (sp.team) w.push(eq(schema.tasks.teamId, sp.team));
  const rows = await db.select().from(schema.tasks).where(and(...w)).orderBy(asc(schema.tasks.dueTime));
  const byDay = new Map<string, Item[]>();
  for (const r of rows) byDay.set(r.dueDate, [...(byDay.get(r.dueDate) ?? []), { id: r.id, title: r.title, done: r.status === "DONE", color: color(r.teamId), time: r.dueTime, kind: r.kind }]);

  // Project recurring templates beyond the materialised horizon so the whole month is visible
  if (to > horizon) {
    const tw: SQL[] = [eq(schema.tasks.isTemplate, true), lte(schema.tasks.dueDate, to)];
    if (scope) tw.push(scope);
    if (sp.team) tw.push(eq(schema.tasks.teamId, sp.team));
    const templates = await db.select().from(schema.tasks).where(and(...tw));
    for (const d of days.filter((x) => x > horizon)) {
      for (const t of templates) if (occursOn(t, d)) byDay.set(d, [...(byDay.get(d) ?? []), { id: t.id, title: t.title, done: false, color: color(t.teamId), time: t.dueTime, virtual: true, kind: t.kind }]);
    }
  }
  const link = (patch: Record<string, string | undefined>) => withQuery("/team/calendar", { m: month, team: sp.team, ...patch });

  return (
    <div>
      <PageHeader title="Calendar" sub="Tasks, daily to-dos and meetings by team"
        actions={<>
          <Link href={link({ m: shiftMonth(month, -1) })} className="t-btn-ghost">←</Link>
          <Link href={link({ m: today.slice(0, 7) })} className="t-btn-ghost">Today</Link>
          <Link href={link({ m: shiftMonth(month, 1) })} className="t-btn-ghost">→</Link>
          <Link href="/team/tasks/new" className="t-btn">+ New</Link>
        </>} />
      <div className="mb-4 flex flex-wrap items-center gap-2 text-sm">
        <span className="mr-2 text-lg font-semibold">{monthLabel(month)}</span>
        <Link href={link({ team: undefined })} className={`rounded-full border px-3 py-1 ${!sp.team ? "border-stone-900 bg-stone-900 text-white" : "border-stone-300 bg-white"}`}>All</Link>
        {teams.filter((t) => me.role === "SUPER_ADMIN" || t.id === me.teamId).map((t) => (
          <Link key={t.id} href={link({ team: t.id })} className={`flex items-center gap-1.5 rounded-full border px-3 py-1 ${sp.team === t.id ? "border-stone-900 bg-stone-900 text-white" : "border-stone-300 bg-white"}`}><TeamDot color={t.color} />{t.name}</Link>
        ))}
      </div>
      <div className="t-card overflow-hidden">
        <div className="grid grid-cols-7 border-b border-stone-200 bg-stone-50 text-center text-xs font-medium uppercase tracking-wide text-stone-500">
          {["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"].map((d) => <div key={d} className="py-2">{d}</div>)}
        </div>
        <div className="grid grid-cols-7">
          {days.map((d) => {
            const items = byDay.get(d) ?? [];
            const inMonth = d.startsWith(month);
            return (
              <div key={d} className={`min-h-[104px] border-b border-r border-stone-100 p-1.5 ${inMonth ? "bg-white" : "bg-stone-50/70"} ${d === today ? "ring-2 ring-inset ring-stone-900" : ""}`}>
                <div className="flex items-center justify-between">
                  <Link href={`/team/tasks?day=${d}`} className={`text-xs ${inMonth ? "text-stone-700" : "text-stone-400"} ${d === today ? "font-bold" : ""} hover:underline`}>{Number(d.slice(8))}</Link>
                  <Link href={`/team/tasks/new?date=${d}`} className="hidden text-xs text-stone-300 hover:text-stone-700 sm:block" aria-label={`Add task on ${d}`}>+</Link>
                </div>
                <ul className="mt-1 space-y-0.5">
                  {items.slice(0, 4).map((i, n) => (
                    <li key={i.id + n}>
                      <Link href={`/team/tasks/${i.id}`} className={`flex items-center gap-1 truncate rounded px-1 py-0.5 text-[11px] leading-tight hover:bg-stone-100 ${i.done ? "text-stone-400 line-through" : "text-stone-700"} ${i.virtual ? "italic opacity-70" : ""}`} title={i.title}>
                        <TeamDot color={i.color} /><span className="truncate">{i.kind === "MEETING" ? "📅 " : ""}{i.time ? `${i.time} ` : ""}{i.title}</span>
                      </Link>
                    </li>
                  ))}
                  {items.length > 4 && <li><Link href={`/team/tasks?day=${d}`} className="px-1 text-[11px] text-stone-500 hover:underline">+{items.length - 4} more</Link></li>}
                </ul>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
