import Link from "next/link";
import { asc, isNotNull } from "drizzle-orm";
import { db, schema } from "@/db";
import { requireStaff } from "@/lib/auth";
import { CSV_COLUMNS } from "@/lib/listings";
import { PageHeader, Section } from "@/components/team/ui";
import { CsvImportForm, WooImportForm } from "@/components/team/import-forms";

export const metadata = { title: "Upload products" };

export default async function ImportProducts() {
  const me = await requireStaff("products", "write");
  const cats = await db.select({ slug: schema.categories.slug, name: schema.categories.name, parentId: schema.categories.parentId })
    .from(schema.categories).where(isNotNull(schema.categories.parentId)).orderBy(asc(schema.categories.name));
  return (
    <div>
      <PageHeader title="Upload products" sub="List products in bulk from a spreadsheet, or one at a time with photos." actions={<Link href="/team/products" className="t-btn-ghost">All products</Link>} />

      <div className="grid gap-4 md:grid-cols-3">
        {[
          ["1", "Bulk upload (CSV)", "Fill the template in Excel or Google Sheets and upload it below. Same SKU again updates price, stock or photos.", "#csv"],
          ["2", "Add one product", "Form with photo upload from your computer, category, price, stock and marketplace links.", "/team/products/new"],
          ["3", "Bring over luxeholic.in", "Copy every product already listed on the current WooCommerce site in one click.", "#woo"],
        ].map(([n, t, d, href]) => (
          <Link key={n} href={href} className="t-card block p-4 transition hover:border-stone-400">
            <p className="text-xs text-stone-400">Option {n}</p>
            <p className="mt-1 font-medium">{t}</p>
            <p className="mt-1 text-sm text-stone-500">{d}</p>
          </Link>
        ))}
      </div>

      <div id="csv" className="mt-6 grid gap-6 xl:grid-cols-[1.6fr_1fr]">
        <Section title="Bulk upload from CSV" actions={<a href="/team/products/import/template.csv" className="t-btn-ghost !py-1.5">Download template</a>}>
          <CsvImportForm />
        </Section>
        <Section title="Template columns">
          <p className="mb-3 text-xs text-stone-500">Only <b>sku, title, category, price</b> are required. WooCommerce and Shopify export files also work.</p>
          <dl className="max-h-[420px] space-y-2 overflow-auto pr-2 text-xs">
            {CSV_COLUMNS.map(([k, help]) => (
              <div key={k}><dt className="font-mono font-medium">{k}</dt>{help && <dd className="text-stone-500">{help}</dd>}</div>
            ))}
          </dl>
          <details className="mt-4 text-xs">
            <summary className="cursor-pointer font-medium">Category names you can use ({cats.length})</summary>
            <ul className="mt-2 grid grid-cols-2 gap-x-3 gap-y-1 text-stone-600">
              {cats.map((c) => <li key={c.slug}><span className="font-mono">{c.slug}</span></li>)}
            </ul>
          </details>
          <ul className="mt-4 list-disc space-y-1 pl-4 text-xs text-stone-500">
            <li>Prices are in rupees, GST inclusive — what the customer pays.</li>
            <li>Products only go live with a photo, a real category and a 40+ character description (Google Merchant Center rules) — otherwise they&apos;re saved as drafts.</li>
            <li>For pre-owned items set <b>condition</b> to <i>used</i> — Google suspends stores that list used goods as new.</li>
            <li>Need photos hosted? Upload them in “Add one product”, copy the links into the images column.</li>
          </ul>
        </Section>
      </div>

      {me.role !== "MEMBER" && (
        <div id="woo" className="mt-6">
          <Section title="Import from the current luxeholic.in store">
            <p className="mb-4 text-sm text-stone-500">Reads the public product list of the WooCommerce site (titles, prices, photos, descriptions, stock) and adds them here as live products. Safe to run again — it updates by SKU instead of duplicating.</p>
            <WooImportForm />
          </Section>
        </div>
      )}
    </div>
  );
}
