import { getStaff } from "@/lib/auth";
import { templateCsv } from "@/lib/listings";

export async function GET() {
  if (!(await getStaff())) return new Response("Sign in first", { status: 401 });
  return new Response(templateCsv(), { headers: { "Content-Type": "text/csv; charset=utf-8", "Content-Disposition": 'attachment; filename="luxeholic-products-template.csv"' } });
}
