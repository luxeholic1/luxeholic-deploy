import Link from "next/link";
import { and, asc, count, desc, eq, ilike, lte, or, type SQL } from "drizzle-orm";
import { db, schema } from "@/db";
import { requireStaff } from "@/lib/auth";
import { canWrite } from "@/lib/rbac";
import { formatINR } from "@/lib/money";
import { withQuery } from "@/lib/url";
import { Badge, Empty, PageHeader, Tabs } from "@/components/team/ui";
import { SelectAll, Submit } from "@/components/team/client";
import { ProductImage } from "@/components/store/art";
import { bulkProducts } from "../../actions/catalog";

export const metadata = { title: "Products" };

export default async function Products({ searchParams }: { searchParams: Promise<Record<string, string>> }) {
  const me = await requireStaff("products");
  const sp = await searchParams;
  const p = schema.products;
  const w: SQL[] = [];
  if (sp.status) w.push(eq(p.status, sp.status as "ACTIVE"));
  if (sp.cat) w.push(eq(p.categoryId, sp.cat));
  if (sp.vendor) w.push(eq(p.vendorId, sp.vendor));
  if (sp.low) w.push(lte(p.stock, 2));
  if (sp.q) w.push(or(ilike(p.title, `%${sp.q}%`), ilike(p.sku, `%${sp.q}%`), ilike(p.brand, `%${sp.q}%`), ilike(p.vendorSku, `%${sp.q}%`))!);
  const page = Math.max(1, Number(sp.page) || 1);
  const [rows, counts, cats, vendors] = await Promise.all([
    db.query.products.findMany({ where: and(...w), with: { category: true, vendor: true }, orderBy: desc(p.updatedAt), limit: 60, offset: (page - 1) * 60 }),
    db.select({ s: p.status, n: count() }).from(p).groupBy(p.status),
    db.select().from(schema.categories).orderBy(asc(schema.categories.sortOrder), asc(schema.categories.name)),
    db.select({ id: schema.vendors.id, name: schema.vendors.name }).from(schema.vendors),
  ]);
  const write = canWrite(me, "products");
  const q = (patch: Record<string, string | undefined>) => withQuery("/team/products", { ...sp, page: undefined, ok: undefined, err: undefined, ...patch });
  const parents = cats.filter((c) => !c.parentId && c.slug !== "needs-review");
  const catOptions = parents.flatMap((pa) => [pa, ...cats.filter((c) => c.parentId === pa.id)]).concat(cats.filter((c) => c.parentId && !parents.find((x) => x.id === c.parentId)));
  const back = q({});
  return (
    <div>
      <PageHeader title="Products" sub="Synced vendor products arrive as drafts — review, then publish." actions={write && <div className="flex gap-2"><Link href="/team/products/import" className="t-btn-ghost">Upload CSV</Link><Link href="/team/products/new" className="t-btn">+ Add product</Link></div>} />
      <Tabs active={sp.status ?? "all"} items={[
        { key: "all", label: "All", href: q({ status: undefined }) },
        ...(["ACTIVE", "DRAFT", "ARCHIVED"] as const).map((s) => ({ key: s, label: s === "ACTIVE" ? "Live" : s.toLowerCase(), href: q({ status: s }), count: counts.find((c) => c.s === s)?.n ?? 0 })),
      ]} />
      <form action="/team/products" className="mb-4 flex flex-wrap gap-2">
        {sp.status && <input type="hidden" name="status" value={sp.status} />}
        <input name="q" defaultValue={sp.q} placeholder="Title, SKU, brand, vendor SKU" className="t-input max-w-xs" />
        <select name="cat" defaultValue={sp.cat ?? ""} className="t-input max-w-[220px]"><option value="">All categories</option>{catOptions.map((c) => <option key={c.id} value={c.id}>{c.parentId ? "— " : ""}{c.name}</option>)}</select>
        <select name="vendor" defaultValue={sp.vendor ?? ""} className="t-input max-w-[180px]"><option value="">All vendors</option>{vendors.map((v) => <option key={v.id} value={v.id}>{v.name}</option>)}</select>
        <label className="flex items-center gap-1.5 text-sm"><input type="checkbox" name="low" value="1" defaultChecked={!!sp.low} /> Low stock</label>
        <button className="t-btn-ghost">Filter</button>
      </form>
      {rows.length === 0 ? <Empty>No products. {write && <>Sync a vendor in <Link className="underline" href="/team/vendors">Vendors</Link> or add one manually.</>}</Empty> : (
        <form id="bulk" action={bulkProducts}>
          <input type="hidden" name="back" value={back} />
          {write && (
            <div className="mb-3 flex flex-wrap items-center gap-2 rounded-lg border border-stone-200 bg-white p-2 text-sm">
              <span className="px-1 text-stone-500">With selected:</span>
              <Submit name="op" value="publish" className="t-btn !py-1.5">Publish</Submit>
              <Submit name="op" value="draft" className="t-btn-ghost !py-1.5">Unpublish</Submit>
              <Submit name="op" value="feature" className="t-btn-ghost !py-1.5">Feature</Submit>
              <Submit name="op" value="archive" className="t-btn-ghost !py-1.5">Archive</Submit>
              <select name="categoryId" className="t-input !w-auto !py-1.5"><option value="">Move to…</option>{catOptions.filter((c) => c.parentId).map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}</select>
              <Submit name="op" value="move" className="t-btn-ghost !py-1.5">Move</Submit>
              {me.role === "SUPER_ADMIN" && <Submit name="op" value="delete-demo" className="t-btn-danger !py-1.5" confirm="Permanently delete the selected products? (Use for demo data.)">Delete</Submit>}
            </div>
          )}
          <div className="t-card overflow-x-auto">
            <table className="t-table">
              <thead><tr>{write && <th className="w-8"><SelectAll form="bulk" /></th>}<th>Product</th><th>Category</th><th>Vendor</th><th>Stock</th><th>Status</th><th className="text-right">Price</th></tr></thead>
              <tbody>{rows.map((r) => (
                <tr key={r.id} className="hover:bg-stone-50">
                  {write && <td><input type="checkbox" name="ids" value={r.id} /></td>}
                  <td><div className="flex items-center gap-3"><div className="h-12 w-10 shrink-0 overflow-hidden rounded bg-stone-100"><ProductImage src={r.images[0]} seed={r.slug} alt="" /></div>
                    <div className="min-w-0"><Link href={`/team/products/${r.id}`} className="line-clamp-1 font-medium hover:underline">{r.title}</Link><div className="text-xs text-stone-500">{r.brand} · {r.sku}{r.isFeatured ? " · ★" : ""}</div></div></div></td>
                  <td className={r.category.slug === "needs-review" ? "text-amber-700" : ""}>{r.category.name}</td>
                  <td className="text-stone-500">{r.vendor?.name ?? "—"}</td>
                  <td className={r.stock <= 2 ? "font-medium text-amber-700" : ""}>{r.stock}</td>
                  <td><Badge>{r.status}</Badge>{!r.images.length && <span className="ml-1 text-xs text-red-600" title="No image">⚠</span>}</td>
                  <td className="text-right">{formatINR(r.price)}{r.priceLocked && <span title="Price locked" className="ml-1 text-xs">🔒</span>}</td>
                </tr>
              ))}</tbody>
            </table>
          </div>
        </form>
      )}
      <div className="mt-4 flex justify-between">{page > 1 ? <Link href={q({ page: String(page - 1) })} className="t-btn-ghost">← Prev</Link> : <span />}{rows.length === 60 && <Link href={q({ page: String(page + 1) })} className="t-btn-ghost">Next →</Link>}</div>
    </div>
  );
}
