import { PhotoUploader } from "@/components/team/import-forms";
import Link from "next/link";
import { notFound } from "next/navigation";
import { asc, eq } from "drizzle-orm";
import { db, schema } from "@/db";
import { requireStaff } from "@/lib/auth";
import { canWrite } from "@/lib/rbac";
import { getSettings } from "@/lib/settings";
import { formatINR, priceFromCost, tierOf } from "@/lib/money";
import { prettyDateTime } from "@/lib/dates";
import { Badge, Field, PageHeader, Section } from "@/components/team/ui";
import { Submit } from "@/components/team/client";
import { ProductImage } from "@/components/store/art";
import { saveProduct } from "../../../actions/catalog";

export default async function ProductEdit({ params }: { params: Promise<{ id: string }> }) {
  const me = await requireStaff("products");
  const { id } = await params;
  const isNew = id === "new";
  const p = isNew ? null : await db.query.products.findFirst({ where: eq(schema.products.id, id), with: { variants: true, vendor: true, category: true } });
  if (!isNew && !p) notFound();
  const [cats, vendors, settings] = await Promise.all([
    db.select().from(schema.categories).orderBy(asc(schema.categories.sortOrder)),
    db.select().from(schema.vendors).orderBy(asc(schema.vendors.name)),
    getSettings(),
  ]);
  const write = canWrite(me, "products");
  const parents = cats.filter((c) => !c.parentId && c.slug !== "needs-review");
  let suggested: number | null = null;
  if (p?.vendor && p.costAmount) {
    try { suggested = priceFromCost({ costMinor: p.costAmount, currency: p.costCurrency, fx: settings.fx, markupPercent: p.vendor.markupPercent, dutyPercent: p.vendor.dutyPercent, gstPercent: p.vendor.gstPercent, shippingFlat: p.vendor.shippingFlat }).price; } catch { /* missing fx */ }
  }
  const r = (v?: number | null) => (v ? String(v / 100) : "");
  return (
    <div className="max-w-5xl">
      <Link href="/team/products" className="text-sm text-stone-500 hover:text-stone-900">← Products</Link>
      <PageHeader title={isNew ? "Add product" : p!.title} sub={p && <span className="flex flex-wrap items-center gap-2"><Badge>{p.status}</Badge>{p.status === "ACTIVE" && <Link href={`/p/${p.slug}`} target="_blank" className="underline">View on store ↗</Link>}{p.lastSyncedAt && <span>Synced {prettyDateTime(p.lastSyncedAt)}</span>}</span>} />
      <form action={saveProduct} className="grid gap-6 lg:grid-cols-[1.6fr_1fr]">
        <input type="hidden" name="id" value={p?.id ?? "new"} />
        <fieldset disabled={!write} className="space-y-6">
          <Section title="Details">
            <div className="grid gap-4 sm:grid-cols-2">
              <Field label="Title" className="sm:col-span-2"><input name="title" defaultValue={p?.title} required className="t-input" /></Field>
              <Field label="Brand"><input name="brand" defaultValue={p?.brand ?? "Luxeholic"} className="t-input" /></Field>
              <Field label="Category"><select name="categoryId" defaultValue={p?.categoryId ?? ""} required className="t-input"><option value="" disabled>Choose…</option>
                {parents.map((pa) => <optgroup key={pa.id} label={pa.name}>{cats.filter((c) => c.parentId === pa.id).map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}</optgroup>)}
                {cats.filter((c) => c.slug === "needs-review").map((c) => <option key={c.id} value={c.id}>⚠ Needs review</option>)}
              </select></Field>
              <Field label="Short description (shown near price)" className="sm:col-span-2"><input name="shortDescription" defaultValue={p?.shortDescription ?? ""} className="t-input" /></Field>
              <Field label="Description" className="sm:col-span-2" hint="Blank line = new paragraph. Be accurate: materials, size, finish. 40+ characters to publish."><textarea name="description" rows={8} defaultValue={p?.description} className="t-input" /></Field>
              <Field label="Material"><input name="material" defaultValue={p?.material ?? ""} className="t-input" /></Field>
              <Field label="Colour"><input name="color" defaultValue={p?.color ?? ""} className="t-input" /></Field>
              <Field label="Gender (fashion only)"><select name="gender" defaultValue={p?.gender ?? ""} className="t-input"><option value="">—</option><option value="female">Women</option><option value="male">Men</option><option value="unisex">Unisex</option></select></Field>
              <Field label="Tags (comma separated)" hint="Add “used” or “refurbished” for pre-owned items — Google requires the correct condition."><input name="tags" defaultValue={p?.tags.join(", ")} className="t-input" /></Field>
            </div>
          </Section>
          <Section title="Images">
            {p && p.images.length > 0 && <div className="mb-3 flex gap-2 overflow-x-auto">{p.images.map((u) => <div key={u} className="h-24 w-20 shrink-0 overflow-hidden rounded bg-stone-100"><ProductImage src={u} seed={u} alt="" /></div>)}</div>}
            <PhotoUploader />
            <Field label="Image URLs — one per line, first is the main image" hint="Use clean, well-lit photos on a plain background; no watermarks or text (Merchant Center rule)."><textarea name="images" rows={4} defaultValue={p?.images.join("\n")} className="t-input font-mono text-xs" /></Field>
          </Section>
          <Section title="Variants (sizes / options)">
            <Field label="One per line:  Name | Vendor SKU | Price ₹ (optional) | Stock" hint="e.g.  Size M | BG-1234-M | | 3   — leave empty if the product has no options."><textarea name="variants" rows={4} defaultValue={p?.variants.map((v) => `${v.name} | ${v.vendorSku ?? v.sku} | ${v.price ? v.price / 100 : ""} | ${v.stock}`).join("\n")} className="t-input font-mono text-xs" /></Field>
          </Section>
          <Section title="Also sold on (marketplace listings)">
            <div className="grid gap-4 sm:grid-cols-2">
              {(["amazon", "flipkart", "blinkit", "walmart"] as const).map((k) => (
                <Field key={k} label={`${k[0].toUpperCase()}${k.slice(1)} listing URL`}><input name={`mkt_${k}`} defaultValue={p?.marketplaceLinks?.[k] ?? ""} placeholder="https://…" className="t-input" /></Field>
              ))}
            </div>
            <p className="mt-2 text-xs text-stone-400">Shown on the product page as “Also available on”. Empty ones fall back to your store links in Store Settings.</p>
          </Section>
          <Section title="Search & Google">
            <div className="grid gap-4 sm:grid-cols-2">
              <Field label="GTIN / EAN (if any)"><input name="gtin" defaultValue={p?.gtin ?? ""} className="t-input" /></Field>
              <Field label="MPN"><input name="mpn" defaultValue={p?.mpn ?? ""} className="t-input" /></Field>
              <Field label="SEO title"><input name="seoTitle" defaultValue={p?.seoTitle ?? ""} className="t-input" /></Field>
              <Field label="URL slug">{isNew ? <input disabled placeholder="auto from title" className="t-input" /> : <input name="slug" defaultValue={p?.slug} className="t-input" />}</Field>
              <Field label="SEO description" className="sm:col-span-2"><textarea name="seoDescription" rows={2} defaultValue={p?.seoDescription ?? ""} className="t-input" /></Field>
            </div>
          </Section>
        </fieldset>
        <fieldset disabled={!write} className="space-y-6">
          <Section title="Publish">
            <Field label="Status"><select name="status" defaultValue={p?.status ?? "DRAFT"} className="t-input"><option value="DRAFT">Draft (hidden)</option><option value="ACTIVE">Live on store</option><option value="ARCHIVED">Archived</option></select></Field>
            <div className="mt-3 space-y-2 text-sm">
              <label className="flex items-center gap-2"><input type="checkbox" name="isFeatured" defaultChecked={p?.isFeatured} /> Curator&apos;s choice (homepage)</label>
              <label className="flex items-center gap-2"><input type="checkbox" name="isNewArrival" defaultChecked={p?.isNewArrival ?? true} /> New arrival</label>
            </div>
            {write && <div className="mt-4"><Submit className="t-btn w-full">{isNew ? "Create product" : "Save changes"}</Submit></div>}
          </Section>
          <Section title="Price & stock">
            <div className="grid gap-4 sm:grid-cols-2">
              <Field label="Price ₹ (incl. GST)"><input name="price" defaultValue={r(p?.price)} required className="t-input" /></Field>
              <Field label="Compare-at ₹ (MRP)"><input name="compareAtPrice" defaultValue={r(p?.compareAtPrice)} className="t-input" /></Field>
              <Field label="Stock"><input name="stock" type="number" defaultValue={p?.stock ?? 0} className="t-input" /></Field>
              <Field label="SKU">{isNew ? <input name="sku" placeholder="auto" className="t-input" /> : <input disabled defaultValue={p?.sku} className="t-input" />}</Field>
            </div>
            <label className="mt-3 flex items-center gap-2 text-sm"><input type="checkbox" name="priceLocked" defaultChecked={p?.priceLocked} /> Lock price (vendor sync won&apos;t change it)</label>
            {p && <p className="mt-3 text-xs text-stone-500">Tier: <b>{tierOf(p.price).name}</b>{p.costAmount ? <> · Cost {p.costCurrency} {(p.costAmount / 100).toFixed(2)}</> : null}{suggested ? <> · Formula price {formatINR(suggested)}</> : null}</p>}
          </Section>
          <Section title="Supply & delivery">
            <div className="grid gap-4 sm:grid-cols-2">
              <Field label="Vendor"><select name="vendorId" defaultValue={p?.vendorId ?? ""} className="t-input"><option value="">Own stock</option>{vendors.map((v) => <option key={v.id} value={v.id}>{v.name}</option>)}</select></Field>
              <Field label="Vendor SKU"><input name="vendorSku" defaultValue={p?.vendorSku ?? ""} className="t-input" /></Field>
              <Field label="Dispatch days"><input name="dispatchDays" type="number" defaultValue={p?.dispatchDays ?? 3} className="t-input" /></Field>
              <Field label="Transit days (max)"><input name="deliveryDays" type="number" defaultValue={p?.deliveryDays ?? 7} className="t-input" /></Field>
              <Field label="Weight (grams)"><input name="weightGrams" type="number" defaultValue={p?.weightGrams ?? ""} className="t-input" /></Field>
            </div>
          </Section>
        </fieldset>
      </form>
    </div>
  );
}
