import { desc } from "drizzle-orm";
import { db, schema } from "@/db";
import { getStaff } from "@/lib/auth";
import { canRead } from "@/lib/rbac";

export async function GET() {
  const s = await getStaff();
  if (!s || !canRead(s, "marketing")) return new Response("Forbidden", { status: 403 });
  const rows = await db.select().from(schema.subscribers).orderBy(desc(schema.subscribers.createdAt));
  const csv = ["email,source,joined", ...rows.map((r) => `${r.email},${r.source},${r.createdAt.toISOString()}`)].join("\n");
  return new Response(csv, { headers: { "Content-Type": "text/csv", "Content-Disposition": "attachment; filename=luxeholic-subscribers.csv" } });
}
