import Link from "next/link";
import { and, count, desc, eq, sql } from "drizzle-orm";
import { db, schema } from "@/db";
import { requireStaff } from "@/lib/auth";
import { canWrite } from "@/lib/rbac";
import { getSettings } from "@/lib/settings";
import { formatINR } from "@/lib/money";
import { prettyDateTime } from "@/lib/dates";
import { SITE_URL } from "@/lib/site";
import { Badge, Field, PageHeader, Section, Stat } from "@/components/team/ui";
import { CopyText, Submit } from "@/components/team/client";
import { saveCoupon, toggleCoupon } from "../../actions/support";

export const metadata = { title: "Marketing" };

export default async function Marketing() {
  const me = await requireStaff("marketing");
  const write = canWrite(me, "marketing");
  const p = schema.products;
  const live = and(eq(p.status, "ACTIVE"));
  const [coupons, subs, [subN], [feed], settings] = await Promise.all([
    db.select().from(schema.coupons).orderBy(desc(schema.coupons.createdAt)).limit(50),
    db.select().from(schema.subscribers).orderBy(desc(schema.subscribers.createdAt)).limit(10),
    db.select({ n: count() }).from(schema.subscribers),
    db.select({
      live: sql<number>`count(*)::int`,
      inStock: sql<number>`count(case when ${p.stock} > 0 then 1 end)::int`,
      noImage: sql<number>`count(case when jsonb_array_length(${p.images}) = 0 then 1 end)::int`,
      shortDesc: sql<number>`count(case when length(${p.description}) < 80 then 1 end)::int`,
      noIds: sql<number>`count(case when ${p.gtin} is null and ${p.brand} <> 'Luxeholic' and ${p.mpn} is null then 1 end)::int`,
      demo: sql<number>`count(case when ${p.tags} ? 'demo' then 1 end)::int`,
    }).from(p).where(live),
    getSettings(),
  ]);
  const b = settings.business;
  const checks: [string, boolean, string][] = [
    ["Registered business name set", !!b.legalName, "Store Settings → Business"],
    ["Full business address", !!(b.addressLine1 && b.pincode), "Store Settings → Business"],
    ["Customer-care phone number", !!b.phone, "Store Settings → Business"],
    ["GSTIN shown on site", !!b.gstin, "Store Settings → Business"],
    ["Site served over HTTPS", SITE_URL.startsWith("https://"), "NEXT_PUBLIC_SITE_URL in .env"],
    ["Merchant Center verification tag", !!settings.tracking.gmcVerification, "Store Settings → Tracking (or verify via DNS)"],
    ["Live products all have images", feed.noImage === 0, `${feed.noImage} live without images`],
    ["Descriptions ≥ 80 characters", feed.shortDesc === 0, `${feed.shortDesc} too short`],
    ["Designer items have GTIN or MPN", feed.noIds === 0, `${feed.noIds} missing identifiers`],
    ["No demo/sample products live", feed.demo === 0, `${feed.demo} demo products — delete them before applying`],
    ["Online payment gateway live (PayU or PhonePe)", Boolean(process.env.PAYU_KEY || process.env.PHONEPE_CLIENT_ID), "Add PayU / PhonePe live keys to .env"],
    ["Bank details for bank transfer", !settings.payments.bankTransfer || !!settings.bank.accountNumber, "Store Settings → Bank"],
  ];
  const ready = checks.filter((c) => c[1]).length;
  const feedUrl = `${SITE_URL}/feed/google.xml`;
  return (
    <div>
      <PageHeader title="Marketing" sub="Product listings, coupons, the Luxeholic Circle and Google Merchant Center readiness." actions={<div className="flex gap-2"><Link href="/team/products/new" className="t-btn-ghost">+ Add product</Link><Link href="/team/products/import" className="t-btn">Upload products (CSV)</Link></div>} />
      <div className="mb-6 grid grid-cols-2 gap-3 md:grid-cols-4">
        <Stat label="Products in feed" value={feed.live} hint={`${feed.inStock} in stock`} />
        <Stat label="Subscribers" value={subN.n} />
        <Stat label="Active coupons" value={coupons.filter((c) => c.active).length} />
        <Stat label="GMC readiness" value={`${ready}/${checks.length}`} tone={ready === checks.length ? "ok" : "warn"} />
      </div>
      <div className="grid gap-6 xl:grid-cols-2">
        <Section title="Google Merchant Center" actions={<a href="https://merchants.google.com" target="_blank" rel="noopener noreferrer" className="text-xs underline">Open GMC ↗</a>}>
          <div className="mb-4 flex items-center gap-2 rounded bg-stone-50 p-2 text-sm"><code className="flex-1 truncate">{feedUrl}</code><CopyText text={feedUrl} /><Link href="/feed/google.xml" target="_blank" className="t-btn-ghost !py-1 !text-xs">Open</Link></div>
          <ul className="space-y-1.5 text-sm">
            {checks.map(([label, ok, hint]) => <li key={label} className="flex items-start gap-2"><span className={ok ? "text-emerald-600" : "text-amber-600"}>{ok ? "✓" : "○"}</span><span className="flex-1">{label}{!ok && <span className="block text-xs text-stone-500">{hint}</span>}</span></li>)}
          </ul>
          <Link href="/team/marketing/gmc" className="t-btn mt-4 inline-flex">Product-by-product quality scores →</Link>
          <p className="mt-4 text-xs text-stone-500">In GMC: Products → Feeds → Add primary feed → India / English → “Scheduled fetch” → paste the feed URL, daily. Also set Shipping (free, 2–15 days) and Returns ({settings.returns.windowDays} days, free) to match the policies.</p>
        </Section>
        <Section title="Coupons">
          {write && (
            <form action={saveCoupon} className="mb-4 grid gap-3 sm:grid-cols-4">
              <Field label="Code"><input name="code" required className="t-input uppercase" placeholder="DIWALI10" /></Field>
              <Field label="% off"><input name="percentOff" className="t-input" /></Field>
              <Field label="or ₹ off"><input name="amountOff" className="t-input" /></Field>
              <Field label="Min order ₹"><input name="minSubtotal" className="t-input" /></Field>
              <Field label="Max uses"><input name="maxUses" className="t-input" /></Field>
              <Field label="Starts"><input type="date" name="startsAt" className="t-input" /></Field>
              <Field label="Ends"><input type="date" name="endsAt" className="t-input" /></Field>
              <div className="flex items-end"><Submit className="t-btn w-full">Save</Submit></div>
              <Field label="Description (internal)" className="sm:col-span-4"><input name="description" className="t-input" /></Field>
            </form>
          )}
          <table className="t-table"><thead><tr><th>Code</th><th>Discount</th><th>Used</th><th>Ends</th><th /></tr></thead><tbody>
            {coupons.map((c) => (
              <tr key={c.id}><td className="font-mono">{c.code}</td><td>{c.percentOff ? `${c.percentOff}%` : formatINR(c.amountOff ?? 0)}{c.minSubtotal ? <span className="text-xs text-stone-500"> over {formatINR(c.minSubtotal)}</span> : null}</td><td>{c.usedCount}{c.maxUses ? `/${c.maxUses}` : ""}</td><td className="text-xs">{c.endsAt ? prettyDateTime(c.endsAt) : "—"}</td>
                <td>{write ? <form action={toggleCoupon}><input type="hidden" name="id" value={c.id} /><input type="hidden" name="active" value={c.active ? "false" : "true"} /><Submit className="t-btn-ghost !py-0.5 !text-xs">{c.active ? "Disable" : "Enable"}</Submit></form> : <Badge tone={c.active ? "green" : "gray"}>{c.active ? "active" : "off"}</Badge>}</td></tr>
            ))}
          </tbody></table>
        </Section>
        <Section title="Luxeholic Circle (newsletter)" actions={<Link href="/team/marketing/subscribers.csv" className="text-xs underline">Export CSV</Link>}>
          <ul className="space-y-1 text-sm">{subs.map((s) => <li key={s.id} className="flex justify-between"><span>{s.email}</span><span className="text-xs text-stone-400">{prettyDateTime(s.createdAt)}</span></li>)}</ul>
          {!subs.length && <p className="text-sm text-stone-500">No subscribers yet.</p>}
        </Section>
      </div>
    </div>
  );
}

