import Link from "next/link";
import { and, asc, eq, ilike, or, sql } from "drizzle-orm";
import { db, schema } from "@/db";
import { requireStaff } from "@/lib/auth";
import { formatINR } from "@/lib/money";
import { GMC_CHECKS, gmcBand, gmcFlagsSql, gmcScoreSql } from "@/lib/gmc-quality";
import { Badge, PageHeader, Section, Stat } from "@/components/team/ui";

export const metadata = { title: "Merchant Center quality" };
type SP = { q?: string; show?: string; check?: string; page?: string };
const PER = 50;

export default async function GmcQuality({ searchParams }: { searchParams: Promise<SP> }) {
  await requireStaff("marketing");
  const sp = await searchParams;
  const p = schema.products, c = schema.categories;
  const page = Math.max(1, Number(sp.page) || 1);
  const check = GMC_CHECKS.find((k) => k.key === sp.check);
  const show = (["all", "ready", "risk"] as const).find((x) => x === sp.show) ?? "issues";
  const where = and(
    eq(p.status, "ACTIVE"),
    sp.q ? or(ilike(p.title, `%${sp.q}%`), ilike(p.sku, `%${sp.q}%`), ilike(p.brand, `%${sp.q}%`)) : undefined,
    check ? sql`not (${check.pass})` : show === "issues" ? sql`(${gmcScoreSql}) < 100` : show === "ready" ? sql`(${gmcScoreSql}) >= 90` : show === "risk" ? sql`(${gmcScoreSql}) < 70` : undefined,
  );
  const [[sum], perCheck, rows, [{ n }]] = await Promise.all([
    db.select({
      live: sql<number>`count(*)::int`,
      avg: sql<number>`coalesce(round(avg(${gmcScoreSql})), 0)::int`,
      ready: sql<number>`count(case when (${gmcScoreSql}) >= 90 then 1 end)::int`,
      bad: sql<number>`count(case when (${gmcScoreSql}) < 70 then 1 end)::int`,
    }).from(p).innerJoin(c, eq(p.categoryId, c.id)).where(eq(p.status, "ACTIVE")),
    db.select(Object.fromEntries(GMC_CHECKS.map((k) => [k.key, sql<number>`count(case when not (${k.pass}) then 1 end)::int`])) as Record<string, ReturnType<typeof sql<number>>>)
      .from(p).innerJoin(c, eq(p.categoryId, c.id)).where(eq(p.status, "ACTIVE")),
    db.select({ id: p.id, title: p.title, sku: p.sku, price: p.price, stock: p.stock, brand: p.brand, score: sql<number>`(${gmcScoreSql})::int`, flags: sql<string>`${gmcFlagsSql}` })
      .from(p).innerJoin(c, eq(p.categoryId, c.id)).where(where).orderBy(sql`(${gmcScoreSql}) asc`, asc(p.title)).limit(PER).offset((page - 1) * PER),
    db.select({ n: sql<number>`count(*)::int` }).from(p).innerJoin(c, eq(p.categoryId, c.id)).where(where),
  ]);
  const missing = (perCheck[0] ?? {}) as Record<string, number>;
  const pages = Math.max(1, Math.ceil(n / PER));
  const url = (patch: Partial<SP>) => {
    const m = { ...sp, page: undefined, ...patch } as Record<string, string | undefined>;
    const q = new URLSearchParams(Object.entries(m).filter((e): e is [string, string] => !!e[1]));
    return `/team/marketing/gmc${q.toString() ? `?${q}` : ""}`;
  };
  const label = Object.fromEntries(GMC_CHECKS.map((k) => [k.key, k]));

  return (
    <div className="max-w-6xl space-y-6">
      <Link href="/team/marketing" className="text-sm text-stone-500 hover:text-stone-900">← Marketing</Link>
      <PageHeader title="Merchant Center quality" sub="Every live product scored against Google’s listing rules, worst first. Fix the top rows and the feed health goes up." />
      <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
        <Stat label="Feed health" value={`${sum?.avg ?? 0}%`} tone={(sum?.avg ?? 0) >= 90 ? "ok" : "warn"} hint="see what’s pulling it down →" href="#fix" />
        <Stat label="Live products" value={(sum?.live ?? 0).toLocaleString("en-IN")} hint="show all →" href={url({ show: "all", check: undefined })} />
        <Stat label="Ready (90+)" value={(sum?.ready ?? 0).toLocaleString("en-IN")} tone="ok" hint="show ready →" href={url({ show: "ready", check: undefined })} />
        <Stat label="At risk (under 70)" value={(sum?.bad ?? 0).toLocaleString("en-IN")} tone={(sum?.bad ?? 0) ? "warn" : "ok"} hint="fix these first →" href={url({ show: "risk", check: undefined })} />
      </div>

      <div id="fix" className="scroll-mt-20" />
      <Section title="What to fix first">
        <ul className="grid gap-2 text-sm sm:grid-cols-2">
          {GMC_CHECKS.map((k) => (
            <li key={k.key}>
              <Link href={url({ check: missing[k.key] ? k.key : undefined, show: undefined })} className={`flex items-center justify-between gap-3 rounded border px-3 py-2 ${sp.check === k.key ? "border-stone-900" : "border-stone-200"} ${missing[k.key] ? "hover:border-stone-500" : "pointer-events-none opacity-70"}`}>
                <span><span className={missing[k.key] ? "text-amber-600" : "text-emerald-600"}>{missing[k.key] ? "○" : "✓"}</span> {k.label} <span className="text-xs text-stone-500">({k.weight} pts)</span></span>
                <span className={missing[k.key] ? "font-medium" : "text-stone-400"}>{missing[k.key] ? `${missing[k.key].toLocaleString("en-IN")} missing` : "all good"}</span>
              </Link>
            </li>
          ))}
        </ul>
      </Section>

      <Section title={check ? `Missing: ${check.label} · ${n.toLocaleString("en-IN")}` : `${{ issues: "Products with something to fix", ready: "Ready for Google (90+)", risk: "At risk — under 70", all: "All live products" }[show]} · ${n.toLocaleString("en-IN")}`}
        actions={<div className="flex flex-wrap items-center gap-2 text-sm">
          <form action="/team/marketing/gmc" className="flex gap-2">{sp.check && <input type="hidden" name="check" value={sp.check} />}{sp.show && <input type="hidden" name="show" value={sp.show} />}
            <input name="q" defaultValue={sp.q} placeholder="Title, SKU or brand" aria-label="Search products" className="t-input !w-48 !py-1.5" /><button className="t-btn-ghost">Search</button></form>
          {check ? <Link href={url({ check: undefined })} className="underline">Show all issues</Link> : <Link href={url({ show: show === "issues" ? "all" : undefined })} className="underline">{show === "issues" ? "Show every product" : "Only products with issues"}</Link>}
        </div>}>
        {rows.length === 0 ? <p className="text-sm text-stone-500">{check || show === "issues" || show === "risk" ? "Nothing to fix here — every matching product passes." : "No live products match."}</p> : (
          <div className="overflow-x-auto">
            <table className="t-table">
              <thead><tr><th>Product</th><th className="text-right">Price</th><th className="text-right">Stock</th><th>Score</th><th>To fix</th><th /></tr></thead>
              <tbody>{rows.map((r) => {
                const band = gmcBand(r.score); const flags = r.flags.split(",").filter(Boolean);
                return (
                  <tr key={r.id}>
                    <td className="max-w-xs"><span className="line-clamp-2 font-medium">{r.title}</span><span className="text-xs text-stone-500">{r.sku} · {r.brand}</span></td>
                    <td className="text-right">{formatINR(r.price)}</td>
                    <td className="text-right">{r.stock > 0 ? r.stock : <span className="text-xs text-stone-500">out · feed says out of stock</span>}</td>
                    <td><div className="flex items-center gap-2"><span className="h-1.5 w-16 overflow-hidden rounded-full bg-stone-200"><span className={`block h-full ${r.score >= 90 ? "bg-emerald-500" : r.score >= 70 ? "bg-amber-500" : "bg-red-500"}`} style={{ width: `${r.score}%` }} /></span><span className="tabular-nums">{r.score}%</span><Badge tone={band.tone}>{band.label}</Badge></div></td>
                    <td className="text-xs">{flags.length ? <ul className="space-y-0.5">{flags.map((f) => <li key={f}>{label[f]?.fix}</li>)}</ul> : <span className="text-emerald-700">All set</span>}</td>
                    <td><Link href={`/team/products/${r.id}`} className="t-btn-ghost !py-1 !text-xs">Fix</Link></td>
                  </tr>
                );
              })}</tbody>
            </table>
          </div>
        )}
        {pages > 1 && <div className="mt-4 flex items-center justify-end gap-2 text-sm">
          {page > 1 && <Link className="t-btn-ghost" href={url({ page: String(page - 1) })}>← Previous</Link>}
          <span className="px-2 text-stone-500">Page {page} of {pages}</span>
          {page < pages && <Link className="t-btn-ghost" href={url({ page: String(page + 1) })}>Next →</Link>}
        </div>}
        <p className="mt-4 text-xs text-stone-500">Out-of-stock items are fine — the feed marks them “out of stock” automatically. Own-label (Luxeholic) items don’t need a GTIN; the feed sends “no identifier”.</p>
      </Section>
    </div>
  );
}
