import Link from "next/link";
import { requireStaff } from "@/lib/auth";
import { canWrite } from "@/lib/rbac";
import { PageHeader, Section, Stat } from "@/components/team/ui";
import { workItems, itemState, type WorkItem } from "@/lib/i18n/workbench";
import { autoTranslateEnabled } from "@/lib/i18n/auto";
import { CURRENCIES, CURRENCY_LABEL, LOCALES, LOCALE_INFO, isLocale, markets, type Locale } from "@/lib/i18n/config";
import { UI_KEYS, uiDict } from "@/lib/i18n/ui-dict";
import { getSetting } from "@/lib/settings";
import { prettyDateTime } from "@/lib/dates";
import type { Entity } from "@/lib/i18n/content";
import { autoTranslate, refreshRatesNow, saveDisplay, saveTranslations, translateUi } from "../../../actions/translations";

export const metadata = { title: "Languages & translations" };

const KINDS: { key: Entity; label: string; note: string }[] = [
  { key: "product", label: "Products", note: "In Hindi a product appears only when every field is translated; in other languages untranslated products show in English." },
  { key: "variant", label: "Product options", note: "Sizes, colours and other options. In Hindi a product with an untranslated option stays hidden; elsewhere it shows in English." },
  { key: "category", label: "Categories", note: "In Hindi untranslated categories are left out of the menus; elsewhere they show in English." },
  { key: "hero", label: "Homepage hero", note: "In Hindi untranslated chapters are skipped; elsewhere they show in English." },
  { key: "site", label: "Site texts", note: "Announcement bar, business details and the hero promise bar. Untranslated business details show in English." },
];
const STATE_TXT = { ok: "Translated", stale: "English changed — check", missing: "Not translated" } as const;
const STATE_CLS = { ok: "bg-emerald-50 text-emerald-700", stale: "bg-amber-50 text-amber-800", missing: "bg-red-50 text-red-700" } as const;

export default async function Translations({ searchParams }: { searchParams: Promise<{ kind?: string; show?: string; lang?: string }> }) {
  const s = await requireStaff("marketing", "read");
  const sp = await searchParams;
  const kind = (KINDS.find((k) => k.key === sp.kind)?.key ?? "product") as Entity;
  const show = sp.show === "all" ? "all" : "todo";
  const lang: Locale = isLocale(sp.lang) && sp.lang !== "en" ? sp.lang : "hi";
  const L = LOCALE_INFO[lang];
  const write = canWrite(s, "marketing");
  const auto = autoTranslateEnabled();
  const [display, ...lists] = await Promise.all([getSetting("display"), ...KINDS.map((k) => workItems(k.key, lang))]);
  const others = LOCALES.filter((l) => l !== "en" && l !== "hi");
  const uiDone = Object.fromEntries(await Promise.all(others.map(async (l) => [l, Object.keys(await uiDict(l).catch(() => ({}))).length] as const))) as Record<string, number>;
  const all = Object.fromEntries(KINDS.map((k, i) => [k.key, lists[i]])) as Record<Entity, WorkItem[]>;
  const items = all[kind].filter((w) => show === "all" || itemState(w) !== "ok");
  const done = (k: Entity) => all[k].filter((w) => itemState(w) === "ok").length;
  const back = `/team/marketing/translations?kind=${kind}&show=${show}&lang=${lang}`;
  const q = (o: Record<string, string>) => `/team/marketing/translations?${new URLSearchParams({ kind, show, lang, ...o })}`;

  return (
    <div className="space-y-8">
      <PageHeader title="Languages & translations" sub="Visitors choose a language and a display currency from the globe button. Hindi is fully curated (untranslated items are hidden); other languages show English for anything not yet translated." actions={<a className="t-btn-ghost" href={`/?lang=${lang}`} target="_blank" rel="noopener">View {L.english} site ↗</a>} />

      <Section title="Languages">
        <p className="mb-3 text-sm text-stone-500">Each language needs its interface text (menus, buttons, checkout — {UI_KEYS.length} phrases) before you switch it on. {auto ? "“Translate interface” drafts it with Claude in a few minutes." : "Set ANTHROPIC_API_KEY on the server to draft it with Claude."}</p>
        <div className="overflow-x-auto"><table className="t-table">
          <thead><tr><th>Language</th><th>On the site</th><th>Interface text</th><th>Catalogue text</th><th /></tr></thead>
          <tbody>
            <tr><td><b className="font-medium">हिन्दी</b> <span className="text-xs text-stone-500">Hindi</span></td><td>{display.languages.includes("hi") ? "On" : "Off"}</td><td className="text-emerald-700">Complete ({UI_KEYS.length})</td><td><Link className="underline" href={q({ lang: "hi" })}>Translate content</Link></td><td /></tr>
            {others.map((l) => { const d = uiDone[l] ?? 0, full = d >= UI_KEYS.length; return (
              <tr key={l}>
                <td lang={LOCALE_INFO[l].html}><b className="font-medium">{LOCALE_INFO[l].label}</b> <span className="text-xs text-stone-500">{LOCALE_INFO[l].english}</span></td>
                <td>{display.languages.includes(l) ? "On" : "Off"}</td>
                <td className={full ? "text-emerald-700" : d ? "text-amber-700" : "text-stone-500"}>{full ? `Complete (${UI_KEYS.length})` : `${d} / ${UI_KEYS.length}`}</td>
                <td><Link className="underline" href={q({ lang: l })}>Translate content</Link></td>
                <td>{write && auto && !full && <form action={translateUi}><input type="hidden" name="locale" value={l} /><input type="hidden" name="back" value={back} /><button className="t-btn-ghost !py-1 !text-xs">Translate interface</button></form>}</td>
              </tr>); })}
          </tbody>
        </table></div>
      </Section>

      <div className="grid gap-3 sm:grid-cols-3 lg:grid-cols-5">
        {KINDS.map((k) => <Stat key={k.key} label={k.label} value={`${done(k.key)} / ${all[k.key].length}`} hint={`in ${L.english}`} href={q({ kind: k.key })} tone={done(k.key) === all[k.key].length ? "ok" : "warn"} />)}
      </div>

      <Section title={`${L.english} content translations`} actions={write && auto && items.some((w) => itemState(w) !== "ok") ? (
        <form action={autoTranslate}><input type="hidden" name="entity" value={kind} /><input type="hidden" name="locale" value={lang} /><input type="hidden" name="back" value={back} /><button className="t-btn">Draft missing with Claude</button></form>
      ) : undefined}>
        <div className="mb-4 flex flex-wrap items-center gap-2 text-sm">
          {KINDS.map((k) => <Link key={k.key} href={q({ kind: k.key })} className={`rounded-full border px-3 py-1 ${k.key === kind ? "border-stone-900 bg-stone-900 text-white" : "border-stone-200 bg-white hover:border-stone-400"}`}>{k.label} <span className="opacity-60">{all[k.key].length - done(k.key) || "✓"}</span></Link>)}
          <span className="ml-auto flex gap-1">
            <Link href={q({ show: "todo" })} className={`rounded px-2 py-1 ${show === "todo" ? "bg-stone-200 font-medium" : ""}`}>To do</Link>
            <Link href={q({ show: "all" })} className={`rounded px-2 py-1 ${show === "all" ? "bg-stone-200 font-medium" : ""}`}>All</Link>
          </span>
        </div>
        <p className="mb-4 text-sm text-stone-500">{KINDS.find((k) => k.key === kind)!.note}{!auto && " Automatic drafts turn on when ANTHROPIC_API_KEY is set on the server."}</p>
        {items.length === 0 ? <p className="rounded-md border border-dashed border-stone-200 p-6 text-center text-sm text-stone-500">Nothing to do here — every item is translated. <Link className="underline" href={q({ show: "all" })}>Show all</Link></p> : (
          <div className="space-y-3">
            {items.slice(0, 60).map((w) => {
              const st = itemState(w);
              return (
                <details key={w.id} className="t-card p-4" open={items.length <= 3}>
                  <summary className="flex cursor-pointer list-none flex-wrap items-center gap-2">
                    <span className={`rounded px-2 py-0.5 text-xs ${STATE_CLS[st]}`}>{STATE_TXT[st]}</span>
                    <span className="font-medium">{w.label}</span>
                    {w.fields.some((f) => f.auto) && <span className="rounded bg-violet-50 px-2 py-0.5 text-xs text-violet-700">auto draft</span>}
                    {w.href && <a href={w.href} target="_blank" rel="noopener" className="ml-auto text-xs text-stone-500 underline">Open ↗</a>}
                  </summary>
                  <form action={saveTranslations} className="mt-4 space-y-3">
                    <input type="hidden" name="entity" value={w.entity} /><input type="hidden" name="id" value={w.id} /><input type="hidden" name="locale" value={lang} /><input type="hidden" name="back" value={back} />
                    {w.fields.map((f) => (
                      <div key={f.field} className="grid gap-2 lg:grid-cols-2">
                        <div><p className="t-label">{f.label} · English</p><p className="whitespace-pre-line rounded-md bg-stone-50 p-2.5 text-sm text-stone-700">{f.en}</p></div>
                        <label className="block"><span className="t-label flex justify-between">{f.label} · हिन्दी <span className={f.state === "ok" ? "text-emerald-700" : f.state === "stale" ? "text-amber-700" : "text-red-700"}>{STATE_TXT[f.state]}</span></span>
                          {f.en.length > 90 ? <textarea name={`tr_${f.field}`} lang={L.html} rows={Math.min(8, Math.ceil(f.en.length / 70))} defaultValue={f.tr} disabled={!write} className="t-input" /> : <input name={`tr_${f.field}`} lang={L.html} defaultValue={f.tr} disabled={!write} className="t-input" />}
                        </label>
                      </div>
                    ))}
                    {write && <div className="flex flex-wrap gap-2"><button className="t-btn">Save Hindi</button></div>}
                  </form>
                  {write && auto && <form action={autoTranslate} className="mt-2"><input type="hidden" name="entity" value={w.entity} /><input type="hidden" name="id" value={w.id} /><input type="hidden" name="back" value={back} /><button className="t-btn-ghost">Draft this with Claude</button></form>}
                </details>
              );
            })}
            {items.length > 60 && <p className="text-sm text-stone-500">Showing the first 60 of {items.length}. Save some and the list moves on.</p>}
          </div>
        )}
      </Section>

      <Section title="Languages & display currencies">
        <form action={saveDisplay} className="space-y-5">
          <input type="hidden" name="back" value={back} />
          <div>
            <p className="t-label">Languages on the site</p>
            <div className="flex flex-wrap gap-4 text-sm">
              <label className="flex items-center gap-2"><input type="checkbox" checked disabled /> English (always on)</label>
              {LOCALES.filter((l) => l !== "en").map((l) => <label key={l} className="flex items-center gap-2"><input type="checkbox" name={`lang_${l}`} defaultChecked={display.languages.includes(l)} disabled={!write} /> <span lang={LOCALE_INFO[l].html}>{LOCALE_INFO[l].label}</span> <span className="text-stone-400">{LOCALE_INFO[l].english}</span></label>)}
            </div>
          </div>
          <div>
            <p className="t-label">Display currencies · rupees per 1 unit</p>
            <p className="mb-2 text-xs text-stone-500">Prices are converted for display only. Checkout, invoices, the Merchant Center feed and all payments stay in INR.</p>
            <div className="grid gap-2 sm:grid-cols-2 lg:grid-cols-4">
              {CURRENCIES.filter((c) => c !== "INR").map((c) => (
                <label key={c} className="flex items-center gap-2 rounded-md border border-stone-200 bg-white p-2 text-sm">
                  <input type="checkbox" name={`on_${c}`} defaultChecked={!!display.rates[c]} disabled={!write} />
                  <span className="w-16">{CURRENCY_LABEL[c]}</span>
                  <span className="text-stone-400">₹</span><input name={`rate_${c}`} inputMode="decimal" defaultValue={display.rates[c] ?? ""} disabled={!write} className="t-input !py-1" aria-label={`Rupees per 1 ${c}`} />
                </label>
              ))}
            </div>
          </div>
          <label className="flex items-center gap-2 text-sm"><input type="checkbox" name="auto" defaultChecked={display.auto} disabled={!write} /> Update rates automatically every day (open.er-api.com)</label>
          <p className="text-xs text-stone-500">Last automatic update: {display.updatedAt ? prettyDateTime(display.updatedAt) : "not yet"}.</p>
          {write && <button className="t-btn">Save languages & currencies</button>}
        </form>
        {write && <form action={refreshRatesNow} className="mt-3"><input type="hidden" name="back" value={back} /><button className="t-btn-ghost">Update rates now</button></form>}
      </Section>

      <Section title="Domains">
        <p className="mb-3 text-sm text-stone-500">A first-time visitor starts in the language and currency of the domain they arrive on; after that their own choice is remembered. Change this list with MARKETS_JSON on the server.</p>
        <table className="w-full text-sm"><thead><tr className="text-left text-stone-500"><th className="py-1.5">Domain</th><th>Country</th><th>Language</th><th>Currency</th></tr></thead><tbody>
          {markets().map((m) => <tr key={m.hosts[0]} className="border-t border-stone-100"><td className="py-1.5">{m.hosts.join(", ")}</td><td>{m.country}</td><td>{LOCALE_INFO[m.locale].label}</td><td>{m.currency}</td></tr>)}
        </tbody></table>
      </Section>
    </div>
  );
}
