import { requireStaff } from "@/lib/auth";
import { getHero } from "@/lib/hero";
import { PageHeader } from "@/components/team/ui";
import { HeroEditor } from "@/components/team/hero-editor";

export const metadata = { title: "Homepage hero" };

export default async function HeroPage() {
  await requireStaff("marketing", "write");
  return (
    <div>
      <PageHeader title="Homepage hero" sub="The scroll-video chapters at the top of the homepage. Each chapter plays as visitors scroll and fades into the next. A chapter with a red Merchant Center check can’t be published. After changing any text, update its Hindi under Languages &amp; translations — until then that chapter is skipped on the Hindi site." />
      <HeroEditor initial={await getHero()} />
    </div>
  );
}
