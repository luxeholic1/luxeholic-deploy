import Link from "next/link";
import { asc, count, eq } from "drizzle-orm";
import { db, schema } from "@/db";
import { requireStaff } from "@/lib/auth";
import { canWrite } from "@/lib/rbac";
import { Field, PageHeader } from "@/components/team/ui";
import { Submit } from "@/components/team/client";
import { saveCategory } from "../../actions/catalog";

export const metadata = { title: "Categories" };
type Cat = typeof schema.categories.$inferSelect;

export default async function Categories() {
  const me = await requireStaff("categories");
  const write = canWrite(me, "categories");
  const [cats, counts] = await Promise.all([
    db.select().from(schema.categories).orderBy(asc(schema.categories.sortOrder), asc(schema.categories.name)),
    db.select({ id: schema.products.categoryId, n: count() }).from(schema.products).where(eq(schema.products.status, "ACTIVE")).groupBy(schema.products.categoryId),
  ]);
  const n = (id: string) => counts.find((c) => c.id === id)?.n ?? 0;
  const parents = cats.filter((c) => !c.parentId && c.slug !== "needs-review");
  const Editor = ({ c, parentId }: { c?: Cat; parentId?: string | null }) => (
    <form action={saveCategory} className="grid gap-3 p-3 sm:grid-cols-6">
      <input type="hidden" name="id" value={c?.id ?? ""} />
      <Field label="Name" className="sm:col-span-2"><input name="name" defaultValue={c?.name} required className="t-input" /></Field>
      <Field label="Parent" className="sm:col-span-2"><select name="parentId" defaultValue={c ? c.parentId ?? "" : parentId ?? ""} className="t-input"><option value="">— Top level —</option>{parents.filter((p) => p.id !== c?.id).map((p) => <option key={p.id} value={p.id}>{p.name}</option>)}</select></Field>
      <Field label="Order"><input name="sortOrder" type="number" defaultValue={c?.sortOrder ?? 0} className="t-input" /></Field>
      <div className="flex items-end gap-3 text-sm"><label className="flex items-center gap-1"><input type="checkbox" name="active" defaultChecked={c?.active ?? true} /> Live</label><label className="flex items-center gap-1"><input type="checkbox" name="isApparel" defaultChecked={c?.isApparel} /> Apparel</label></div>
      <Field label="Tagline" className="sm:col-span-3"><input name="tagline" defaultValue={c?.tagline ?? ""} className="t-input" /></Field>
      <Field label="Image URL" className="sm:col-span-3"><input name="image" defaultValue={c?.image ?? ""} className="t-input" /></Field>
      <Field label="Google product category" className="sm:col-span-4" hint="From Google's product taxonomy, e.g. Home & Garden > Decor > Vases"><input name="googleCategory" defaultValue={c?.googleCategory ?? ""} className="t-input" /></Field>
      {!c && <Field label="URL slug" className="sm:col-span-2"><input name="slug" placeholder="auto" className="t-input" /></Field>}
      <Field label="Intro text (category page)" className="sm:col-span-6"><textarea name="description" rows={2} defaultValue={c?.description ?? ""} className="t-input" /></Field>
      {write && <div className="sm:col-span-6"><Submit className="t-btn">{c ? "Save" : "Add category"}</Submit></div>}
    </form>
  );
  return (
    <div className="max-w-5xl">
      <PageHeader title="Categories" sub="Five houses with sub-categories. Synced products are auto-sorted by keyword; unsure ones land in “Needs review”." />
      <div className="space-y-4">
        {parents.map((p) => (
          <div key={p.id} className="t-card">
            <details>
              <summary className="flex cursor-pointer items-center justify-between px-4 py-3"><span className="font-semibold">{p.name} <span className="ml-2 text-xs font-normal text-stone-500">/c/{p.slug}</span>{!p.active && <span className="ml-2 text-xs text-amber-700">hidden</span>}</span><span className="text-xs text-stone-500">edit</span></summary>
              <fieldset disabled={!write}><Editor c={p} /></fieldset>
            </details>
            <ul className="divide-y divide-stone-100 border-t border-stone-100">
              {cats.filter((c) => c.parentId === p.id).map((c) => (
                <li key={c.id}><details><summary className="flex cursor-pointer items-center justify-between px-4 py-2 pl-8 text-sm"><span>{c.name} <span className="ml-1 text-xs text-stone-400">{n(c.id)} live</span>{!c.active && <span className="ml-2 text-xs text-amber-700">hidden</span>}</span><Link href={`/team/products?cat=${c.id}`} className="text-xs text-stone-500 hover:underline">products →</Link></summary><fieldset disabled={!write} className="bg-stone-50"><Editor c={c} /></fieldset></details></li>
              ))}
              {write && <li><details><summary className="cursor-pointer px-4 py-2 pl-8 text-sm text-stone-500">+ Add sub-category to {p.name}</summary><Editor parentId={p.id} /></details></li>}
            </ul>
          </div>
        ))}
        {cats.filter((c) => c.slug === "needs-review").map((c) => <Link key={c.id} href={`/team/products?cat=${c.id}`} className="block rounded-lg border border-amber-200 bg-amber-50 px-4 py-3 text-sm text-amber-900">⚠ Needs review — synced products the auto-sorter couldn&apos;t place →</Link>)}
        {write && <div className="t-card"><details><summary className="cursor-pointer px-4 py-3 text-sm font-medium">+ Add a new top-level category</summary><Editor /></details></div>}
      </div>
    </div>
  );
}
