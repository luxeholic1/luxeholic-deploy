import { requireSuper } from "@/lib/auth";
import { getSettings } from "@/lib/settings";
import { SITE_URL } from "@/lib/site";
import { Field, PageHeader, Section } from "@/components/team/ui";
import { Submit } from "@/components/team/client";
import { saveSettings } from "../../actions/admin";

export const metadata = { title: "Store settings" };

export default async function Settings() {
  await requireSuper();
  const s = await getSettings();
  const b = s.business, p = s.payments;
  const env: [string, boolean][] = [
    ["PayU keys", !!(process.env.PAYU_KEY && process.env.PAYU_SALT)], ["PayU live mode", process.env.PAYU_MODE === "live"],
    ["PhonePe keys", !!(process.env.PHONEPE_CLIENT_ID && process.env.PHONEPE_CLIENT_SECRET)], ["PhonePe live mode", process.env.PHONEPE_MODE === "live"],
    ["SMTP email", !!process.env.SMTP_HOST], ["Cron secret", !!process.env.CRON_SECRET], ["HTTPS site URL", SITE_URL.startsWith("https://")],
  ];
  const r = (v: number) => String(v / 100);
  const S = ({ name }: { name: string }) => <input type="hidden" name="section" value={name} />;
  return (
    <div className="max-w-5xl">
      <PageHeader title="Store settings" sub="These details appear on the site, invoices, policies and the Google feed — keep them accurate." />
      <div className="mb-6 flex flex-wrap gap-2">{env.map(([k, ok]) => <span key={k} className={`t-badge ${ok ? "bg-emerald-50 text-emerald-700" : "bg-amber-50 text-amber-800"}`}>{ok ? "✓" : "○"} {k}</span>)}</div>
      <div className="grid gap-6 lg:grid-cols-2">
        <Section title="Business details (required by Google Merchant Center)" className="lg:col-span-2">
          <form action={saveSettings} className="grid gap-3 sm:grid-cols-3">
            <S name="business" />
            <Field label="Brand"><input name="brand" defaultValue={b.brand} className="t-input" /></Field>
            <Field label="Registered business name"><input name="legalName" defaultValue={b.legalName} className="t-input" placeholder="e.g. WEDECOR4U Pvt Ltd" /></Field>
            <Field label="GSTIN"><input name="gstin" defaultValue={b.gstin} className="t-input uppercase" /></Field>
            <Field label="Contact email (shown on every page, policies and invoices)"><input name="email" type="email" defaultValue={b.email} className="t-input" /></Field>
            <Field label="Phone"><input name="phone" defaultValue={b.phone} className="t-input" /></Field>
            <Field label="WhatsApp"><input name="whatsapp" defaultValue={b.whatsapp} className="t-input" /></Field>
            <Field label="IEC (import-export code)"><input name="iec" defaultValue={b.iec} className="t-input uppercase" /></Field>
            <Field label="Trademark symbol"><select name="trademark" defaultValue={b.trademark} className="t-input"><option value="™">™ (applied / unregistered)</option><option value="®">® (registered — certificate issued)</option><option value="">None</option></select></Field>
            <Field label="Address line 1" className="sm:col-span-2"><input name="addressLine1" defaultValue={b.addressLine1} className="t-input" /></Field>
            <Field label="Address line 2"><input name="addressLine2" defaultValue={b.addressLine2} className="t-input" /></Field>
            <Field label="City"><input name="city" defaultValue={b.city} className="t-input" /></Field>
            <Field label="State"><input name="state" defaultValue={b.state} className="t-input" /></Field>
            <Field label="PIN code"><input name="pincode" defaultValue={b.pincode} className="t-input" /></Field>
            <Field label="Country"><input name="country" defaultValue={b.country} className="t-input" /></Field>
            <Field label="Support hours" className="sm:col-span-2"><input name="supportHours" defaultValue={b.supportHours} className="t-input" /></Field>
            <Field label="Instagram URL"><input name="instagram" defaultValue={b.instagram} className="t-input" /></Field>
            <Field label="Facebook URL"><input name="facebook" defaultValue={b.facebook} className="t-input" /></Field>
            <Field label="Pinterest URL"><input name="pinterest" defaultValue={b.pinterest} className="t-input" /></Field>
            <Field label="YouTube URL"><input name="youtube" defaultValue={b.youtube} className="t-input" /></Field>
            <Field label="Announcement bar" className="sm:col-span-3"><input name="announcement" defaultValue={s.announcement} className="t-input" /></Field>
            <div className="sm:col-span-3"><Submit>Save business details</Submit></div>
          </form>
        </Section>
        <Section title="Payments">
          <form action={saveSettings} className="space-y-3">
            <S name="payments" />
            <div className="grid grid-cols-2 gap-2 text-sm">
              {([["payu", "PayU (UPI/cards/netbanking)"], ["phonepe", "PhonePe"], ["bankTransfer", "Bank transfer"], ["cod", "Cash on delivery"], ["partialCod", "Advance % + COD"]] as const).map(([k, l]) => (
                <label key={k} className="flex items-center gap-2"><input type="checkbox" name={k} defaultChecked={p[k]} /> {l}</label>
              ))}
            </div>
            <div className="grid grid-cols-2 gap-3">
              <Field label="Advance % for COD"><input name="advancePercent" defaultValue={p.advancePercent} className="t-input" /></Field>
              <Field label="COD fee ₹"><input name="codFee" defaultValue={r(p.codFee)} className="t-input" /></Field>
              <Field label="Plain COD up to ₹"><input name="codMaxOrder" defaultValue={r(p.codMaxOrder)} className="t-input" /></Field>
              <Field label="Advance-COD up to ₹"><input name="partialCodMaxOrder" defaultValue={r(p.partialCodMaxOrder)} className="t-input" /></Field>
            </div>
            <p className="text-xs text-stone-400">Gateway keys live in the server .env (never in the database).</p>
            <Submit>Save payments</Submit>
          </form>
        </Section>
        <Section title="Bank account (for bank transfers)">
          <form action={saveSettings} className="grid grid-cols-2 gap-3">
            <S name="bank" />
            <Field label="Account name" className="col-span-2"><input name="accountName" defaultValue={s.bank.accountName} className="t-input" /></Field>
            <Field label="Account number"><input name="accountNumber" defaultValue={s.bank.accountNumber} className="t-input" /></Field>
            <Field label="IFSC"><input name="ifsc" defaultValue={s.bank.ifsc} className="t-input uppercase" /></Field>
            <Field label="Bank"><input name="bankName" defaultValue={s.bank.bankName} className="t-input" /></Field>
            <Field label="Branch"><input name="branch" defaultValue={s.bank.branch} className="t-input" /></Field>
            <Field label="UPI ID (optional)"><input name="upiId" defaultValue={s.bank.upiId} className="t-input" /></Field>
            <Field label="Scan-to-pay QR image URL"><input name="qrImage" defaultValue={s.bank.qrImage} className="t-input" placeholder="/brand/phonepe-qr.jpg" /></Field>
            <div className="col-span-2"><Submit>Save bank details</Submit></div>
          </form>
        </Section>
        <Section title="Shipping & returns">
          <form action={saveSettings} className="grid grid-cols-2 gap-3">
            <S name="shipping" />
            <Field label="Free shipping above ₹ (0 = always free)"><input name="freeAbove" defaultValue={r(s.shipping.freeAbove)} className="t-input" /></Field>
            <Field label="Otherwise charge ₹"><input name="flatFee" defaultValue={r(s.shipping.flatFee)} className="t-input" /></Field>
            <Field label="Return window (days)"><input name="windowDays" defaultValue={s.returns.windowDays} className="t-input" /></Field>
            <div className="col-span-2"><Submit>Save</Submit></div>
          </form>
        </Section>
        <Section title="FX rates (INR per unit)">
          <form action={saveSettings} className="space-y-3">
            <S name="fx" />
            <textarea name="fx" rows={5} className="t-input font-mono text-sm" defaultValue={Object.entries(s.fx).map(([k, v]) => `${k} = ${v}`).join("\n")} />
            <p className="text-xs text-stone-400">Update weekly. After changing, use “Re-price” on each vendor to apply.</p>
            <Submit>Save rates</Submit>
          </form>
        </Section>
        <Section title="Marketplace store links">
          <form action={saveSettings} className="grid gap-3">
            <S name="marketplaces" />
            {(["amazon", "flipkart", "blinkit", "walmart"] as const).map((k) => (
              <Field key={k} label={`${k[0].toUpperCase()}${k.slice(1)} store page`}><input name={k} defaultValue={s.marketplaces[k]} className="t-input" placeholder="https://…" /></Field>
            ))}
            <p className="text-xs text-stone-400">Shown in the “Also available on” section and footer. Empty = name shown without a link.</p>
            <Submit>Save</Submit>
          </form>
        </Section>
        <Section title="Tracking & verification">
          <form action={saveSettings} className="grid gap-3">
            <S name="tracking" />
            <Field label="GA4 measurement ID"><input name="ga4Id" defaultValue={s.tracking.ga4Id} className="t-input" placeholder="G-XXXXXXX" /></Field>
            <Field label="Google Ads ID"><input name="googleAdsId" defaultValue={s.tracking.googleAdsId} className="t-input" placeholder="AW-XXXXXXX" /></Field>
            <Field label="Merchant Center site verification (meta content)"><input name="gmcVerification" defaultValue={s.tracking.gmcVerification} className="t-input" /></Field>
            <Field label="Meta Pixel ID (stored for later)"><input name="metaPixelId" defaultValue={s.tracking.metaPixelId} className="t-input" /></Field>
            <Submit>Save</Submit>
          </form>
        </Section>
      </div>
    </div>
  );
}
