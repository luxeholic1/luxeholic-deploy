import { and, count, desc, eq } from "drizzle-orm";
import { db, schema } from "@/db";
import { requireStaff } from "@/lib/auth";
import { accessLevel } from "@/lib/rbac";
import { prettyDateTime } from "@/lib/dates";
import { withQuery } from "@/lib/url";
import { Badge, Empty, PageHeader, Tabs } from "@/components/team/ui";
import { updateLead } from "@/app/team/actions/leads";

export const metadata = { title: "Call-back requests" };
const ST = ["NEW", "CALLED", "CLOSED"] as const;
const LABEL = { NEW: "New", CALLED: "Called", CLOSED: "Closed" } as const;

export default async function Leads({ searchParams }: { searchParams: Promise<{ status?: string; mine?: string }> }) {
  const me = await requireStaff("leads");
  const canWrite = accessLevel(me, "leads") === "write";
  const sp = await searchParams;
  const status = (ST.includes(sp.status as never) ? sp.status : "NEW") as (typeof ST)[number];
  const mine = sp.mine === "1";
  const where = mine ? and(eq(schema.callbacks.status, status), eq(schema.callbacks.assigneeId, me.id)) : eq(schema.callbacks.status, status);
  const [rows, counts, people] = await Promise.all([
    db.query.callbacks.findMany({ where, with: { assignee: true }, orderBy: desc(schema.callbacks.createdAt), limit: 200 }),
    db.select({ s: schema.callbacks.status, n: count() }).from(schema.callbacks).groupBy(schema.callbacks.status),
    db.select({ id: schema.staff.id, name: schema.staff.name }).from(schema.staff).where(eq(schema.staff.active, true)),
  ]);
  const back = withQuery("/team/leads", { status, mine: mine ? "1" : undefined });
  return (
    <div>
      <PageHeader title="Call-back requests" sub="From “Request a call back” on the website. Call within working hours, add what was discussed, then mark it called or closed." />
      <div className="mb-4 flex flex-wrap items-center gap-3">
        <Tabs active={status} items={ST.map((s) => ({ key: s, label: LABEL[s], href: withQuery("/team/leads", { status: s, mine: mine ? "1" : undefined }), count: counts.find((c) => c.s === s)?.n ?? 0 }))} />
        <a href={withQuery("/team/leads", { status, mine: mine ? undefined : "1" })} className="t-btn-ghost !py-1.5 text-xs">{mine ? "Show everyone’s" : "Only mine"}</a>
      </div>
      {rows.length === 0 ? <Empty>{status === "NEW" ? "No new requests — nice work." : "Nothing here."}</Empty> : (
        <div className="space-y-3">
          {rows.map((l) => {
            const wa = l.phone.replace(/[^\d]/g, "");
            return (
              <article key={l.id} className="t-card p-4">
                <div className="flex flex-wrap items-start justify-between gap-3">
                  <div className="min-w-0">
                    <p className="font-medium">{l.name} <span className="ml-1 text-xs text-stone-400">{l.number}</span></p>
                    <p className="text-sm text-stone-600">{l.phone}{l.email ? ` · ${l.email}` : ""}{l.city ? ` · ${l.city}` : ""}</p>
                    <p className="mt-1 flex flex-wrap gap-1.5 text-xs"><Badge tone="blue">{l.interest}</Badge><Badge>{l.bestTime}</Badge>{l.customerId && <Badge tone="green">Has account</Badge>}<span className="text-stone-400">{prettyDateTime(l.createdAt)} · {l.source}</span></p>
                  </div>
                  <div className="flex flex-wrap gap-2 text-sm">
                    <a className="t-btn !py-1.5" href={`tel:${l.phone}`}>Call</a>
                    <a className="t-btn-ghost !py-1.5" href={`https://wa.me/${wa}`} target="_blank" rel="noopener noreferrer">WhatsApp</a>
                  </div>
                </div>
                {l.message && <p className="mt-3 rounded-md bg-stone-50 p-3 text-sm">“{l.message}”</p>}
                {l.notes.length > 0 && (
                  <ul className="mt-3 space-y-1 border-l-2 border-stone-200 pl-3 text-sm">
                    {l.notes.map((n, i) => <li key={i}><span className="text-stone-500">{n.by} · {prettyDateTime(new Date(n.at))}:</span> {n.body}</li>)}
                  </ul>
                )}
                {canWrite ? (
                  <form action={updateLead} className="mt-3 grid gap-2 sm:grid-cols-[1fr_160px_180px_auto] sm:items-end">
                    <input type="hidden" name="id" value={l.id} /><input type="hidden" name="back" value={back} />
                    <label className="text-xs text-stone-500">Call note<input name="note" maxLength={1000} placeholder="e.g. Wants Armor 33 Pro, send link on WhatsApp" className="t-input mt-1" /></label>
                    <label className="text-xs text-stone-500">Status<select name="status" defaultValue={l.status} className="t-input mt-1">{ST.map((s) => <option key={s} value={s}>{LABEL[s]}</option>)}</select></label>
                    <label className="text-xs text-stone-500">Assigned to<select name="assigneeId" defaultValue={l.assigneeId ?? ""} className="t-input mt-1"><option value="">Nobody yet</option>{people.map((p) => <option key={p.id} value={p.id}>{p.name}</option>)}</select></label>
                    <button className="t-btn">Save</button>
                  </form>
                ) : <p className="mt-3 text-xs text-stone-500">Assigned to {l.assignee?.name ?? "nobody yet"} · view only for your team</p>}
              </article>
            );
          })}
        </div>
      )}
    </div>
  );
}
