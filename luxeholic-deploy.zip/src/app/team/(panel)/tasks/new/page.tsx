import { asc, eq } from "drizzle-orm";
import { db, schema } from "@/db";
import { requireStaff } from "@/lib/auth";
import { todayIST } from "@/lib/dates";
import { PageHeader, Field } from "@/components/team/ui";
import { Submit, TeamAssignee } from "@/components/team/client";
import { createTask } from "../../../actions/tasks";

export const metadata = { title: "New task" };

export default async function NewTask({ searchParams }: { searchParams: Promise<{ date?: string; team?: string }> }) {
  const me = await requireStaff();
  const sp = await searchParams;
  const teams = await db.select({ id: schema.teams.id, name: schema.teams.name }).from(schema.teams).orderBy(asc(schema.teams.sortOrder));
  const staff = await db.select({ id: schema.staff.id, name: schema.staff.name, teamId: schema.staff.teamId }).from(schema.staff).where(eq(schema.staff.active, true)).orderBy(asc(schema.staff.name));
  const lead = me.role === "TEAM_LEAD";
  const member = me.role === "MEMBER";
  return (
    <div className="max-w-2xl">
      <PageHeader title={member ? "New personal task" : "Assign a task"} sub={member ? "Only you will see this task." : lead ? `For the ${me.team?.name} team` : "Send a task or a daily to-do to a team, a person, or everyone."} />
      <form action={createTask} className="t-card space-y-4 p-5">
        <Field label="What needs doing?"><input name="title" required className="t-input" placeholder="e.g. Call all pending COD orders" /></Field>
        <Field label="Details (optional)"><textarea name="description" rows={3} className="t-input" /></Field>
        {!member && (
          <div className="grid gap-4 sm:grid-cols-2">
            <TeamAssignee teams={lead ? teams.filter((t) => t.id === me.teamId) : teams} staff={lead ? staff.filter((s) => s.teamId === me.teamId) : staff}
              defaultTeam={lead ? me.teamId! : sp.team ?? teams[0]?.id} lockTeam={lead} />
          </div>
        )}
        <div className="grid gap-4 sm:grid-cols-3">
          <Field label="Date"><input type="date" name="dueDate" defaultValue={sp.date ?? todayIST()} required className="t-input" /></Field>
          <Field label="Time (optional)"><input type="time" name="dueTime" className="t-input" /></Field>
          <Field label="Priority"><select name="priority" defaultValue="MEDIUM" className="t-input"><option>LOW</option><option>MEDIUM</option><option>HIGH</option><option>URGENT</option></select></Field>
        </div>
        <div className="grid gap-4 sm:grid-cols-3">
          <Field label="Type"><select name="kind" className="t-input"><option value="TASK">Task</option><option value="MEETING">Meeting</option><option value="REMINDER">Reminder</option></select></Field>
          <Field label="Repeat"><select name="recurrence" className="t-input"><option value="NONE">Does not repeat</option><option value="DAILY">Every day</option><option value="WEEKDAYS">Working days (Mon–Sat)</option><option value="WEEKLY">Weekly</option><option value="MONTHLY">Monthly</option></select></Field>
          <Field label="Repeat until (optional)"><input type="date" name="recurUntil" className="t-input" /></Field>
        </div>
        {!member && <label className="flex items-center gap-2 text-sm"><input type="checkbox" name="email" /> Also email the people assigned</label>}
        <div className="flex justify-end gap-2 border-t border-stone-100 pt-4"><Submit>{member ? "Add task" : "Assign"}</Submit></div>
      </form>
    </div>
  );
}
