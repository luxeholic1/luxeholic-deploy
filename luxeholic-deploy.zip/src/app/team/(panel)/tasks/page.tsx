import Link from "next/link";
import { and, asc, desc, eq, gte, lt, lte, ne, type SQL } from "drizzle-orm";
import { alias } from "drizzle-orm/pg-core";
import { db, schema } from "@/db";
import { requireStaff } from "@/lib/auth";
import { taskScope } from "@/lib/team";
import { withQuery } from "@/lib/url";
import { materializeRecurring } from "@/lib/tasks";
import { addDays, prettyDay, todayIST } from "@/lib/dates";
import { Badge, Empty, PageHeader, Tabs, TeamDot } from "@/components/team/ui";
import { Submit } from "@/components/team/client";
import { setTaskStatus, deleteTask } from "../../actions/tasks";

export const metadata = { title: "Tasks" };

export default async function Tasks({ searchParams }: { searchParams: Promise<Record<string, string>> }) {
  const me = await requireStaff();
  const sp = await searchParams;
  const view = sp.view ?? (sp.day ? "day" : "today");
  const today = todayIST();
  await materializeRecurring(addDays(today, -1), addDays(today, 7));

  const scope = taskScope(me);
  const w: SQL[] = [];
  if (scope) w.push(scope);
  if (sp.team && me.role === "SUPER_ADMIN") w.push(eq(schema.tasks.teamId, sp.team));
  if (sp.person) w.push(eq(schema.tasks.assigneeId, sp.person));
  if (sp.mine) w.push(eq(schema.tasks.assigneeId, me.id));
  const notTpl = eq(schema.tasks.isTemplate, false);
  const byView: Record<string, SQL[]> = {
    today: [notTpl, eq(schema.tasks.dueDate, today)],
    day: [notTpl, eq(schema.tasks.dueDate, sp.day ?? today)],
    upcoming: [notTpl, gte(schema.tasks.dueDate, addDays(today, 1)), lte(schema.tasks.dueDate, addDays(today, 14)), ne(schema.tasks.status, "DONE")],
    overdue: [notTpl, lt(schema.tasks.dueDate, today), ne(schema.tasks.status, "DONE")],
    done: [notTpl, eq(schema.tasks.status, "DONE"), gte(schema.tasks.dueDate, addDays(today, -30))],
    recurring: [eq(schema.tasks.isTemplate, true)],
  };
  const assignee = alias(schema.staff, "assignee");
  const creator = alias(schema.staff, "creator");
  const rows = await db
    .select({ t: schema.tasks, team: schema.teams, assignee: assignee.name, creator: creator.name })
    .from(schema.tasks)
    .leftJoin(schema.teams, eq(schema.tasks.teamId, schema.teams.id))
    .leftJoin(assignee, eq(schema.tasks.assigneeId, assignee.id))
    .leftJoin(creator, eq(schema.tasks.createdById, creator.id))
    .where(and(...w, ...(byView[view] ?? byView.today)))
    .orderBy(view === "done" ? desc(schema.tasks.completedAt) : asc(schema.tasks.dueDate), asc(schema.tasks.status), desc(schema.tasks.priority), asc(schema.tasks.dueTime))
    .limit(300);

  const teams = me.role === "SUPER_ADMIN" ? await db.select().from(schema.teams).orderBy(asc(schema.teams.sortOrder)) : [];
  const qs = (patch: Record<string, string | undefined>) => withQuery("/team/tasks", { ...sp, ok: undefined, err: undefined, ...patch });
  const back = qs({});
  const done = rows.filter((r) => r.t.status === "DONE").length;

  return (
    <div>
      <PageHeader
        title={view === "day" ? `Tasks · ${prettyDay(sp.day!)}` : "Tasks & to-dos"}
        sub={view === "today" ? `${prettyDay(today, { weekday: "long", day: "numeric", month: "long" })} · ${done}/${rows.length} done` : undefined}
        actions={<><Link href="/team/calendar" className="t-btn-ghost">Calendar</Link><Link href={`/team/tasks/new${sp.day ? `?date=${sp.day}` : ""}`} className="t-btn">+ New {me.role === "MEMBER" ? "personal task" : "task"}</Link></>}
      />
      <Tabs active={view} items={[
        { key: "today", label: "Today", href: qs({ view: undefined, day: undefined }) },
        { key: "upcoming", label: "Upcoming", href: qs({ view: "upcoming", day: undefined }) },
        { key: "overdue", label: "Overdue", href: qs({ view: "overdue", day: undefined }) },
        { key: "done", label: "Done", href: qs({ view: "done", day: undefined }) },
        ...(me.role !== "MEMBER" ? [{ key: "recurring", label: "Recurring to-dos", href: qs({ view: "recurring", day: undefined }) }] : []),
      ]} />
      <div className="mb-4 flex flex-wrap gap-2 text-sm">
        <Link href={qs({ mine: sp.mine ? undefined : "1" })} className={`rounded-full border px-3 py-1 ${sp.mine ? "border-stone-900 bg-stone-900 text-white" : "border-stone-300 bg-white"}`}>Assigned to me</Link>
        {teams.map((t) => (
          <Link key={t.id} href={qs({ team: sp.team === t.id ? undefined : t.id })} className={`flex items-center gap-1.5 rounded-full border px-3 py-1 ${sp.team === t.id ? "border-stone-900 bg-stone-900 text-white" : "border-stone-300 bg-white"}`}><TeamDot color={t.color} />{t.name}</Link>
        ))}
      </div>

      {view === "today" && rows.length > 0 && (
        <div className="mb-4 h-1.5 overflow-hidden rounded-full bg-stone-200"><div className="h-full bg-emerald-600 transition-all" style={{ width: `${(done / rows.length) * 100}%` }} /></div>
      )}

      {rows.length === 0 ? <Empty>{view === "today" ? "Nothing scheduled for today. 🎉" : "No tasks here."}</Empty> : (
        <div className="t-card divide-y divide-stone-100">
          {rows.map(({ t, team, assignee: who, creator: by }) => (
            <div key={t.id} className={`flex items-start gap-3 px-4 py-3 ${t.status === "DONE" ? "opacity-60" : ""}`}>
              {!t.isTemplate && (
                <form action={setTaskStatus}>
                  <input type="hidden" name="id" value={t.id} /><input type="hidden" name="back" value={back} />
                  <input type="hidden" name="status" value={t.status === "DONE" ? "TODO" : "DONE"} />
                  <button aria-label={t.status === "DONE" ? "Mark not done" : "Mark done"} className={`mt-0.5 flex h-5 w-5 items-center justify-center rounded border ${t.status === "DONE" ? "border-emerald-600 bg-emerald-600 text-white" : "border-stone-300 hover:border-stone-900"}`}>{t.status === "DONE" ? "✓" : ""}</button>
                </form>
              )}
              <div className="min-w-0 flex-1">
                <Link href={`/team/tasks/${t.id}`} className={`font-medium hover:underline ${t.status === "DONE" ? "line-through" : ""}`}>{t.kind === "MEETING" ? "📅 " : ""}{t.title}</Link>
                <div className="mt-1 flex flex-wrap items-center gap-x-3 gap-y-1 text-xs text-stone-500">
                  <span className="flex items-center gap-1.5"><TeamDot color={team?.color} />{team?.name ?? "Company-wide"}</span>
                  <span>{who ? `→ ${who}` : "Whole team"}</span>
                  {view !== "today" && view !== "day" && <span>{t.isTemplate ? `from ${prettyDay(t.dueDate)}` : prettyDay(t.dueDate)}</span>}
                  {t.dueTime && <span>⏰ {t.dueTime}</span>}
                  {t.isTemplate && <span>🔁 {t.recurrence === "WEEKDAYS" ? "Mon–Sat" : t.recurrence.toLowerCase()}{t.recurUntil ? ` until ${prettyDay(t.recurUntil)}` : ""}</span>}
                  {t.templateId && <span title="Recurring">🔁</span>}
                  <span>by {by}</span>
                </div>
              </div>
              <div className="flex shrink-0 items-center gap-2">
                {t.priority !== "MEDIUM" && <Badge>{t.priority}</Badge>}
                {t.status !== "TODO" && t.status !== "DONE" && <Badge>{t.status}</Badge>}
                {t.isTemplate && (
                  <form action={deleteTask}><input type="hidden" name="id" value={t.id} /><Submit className="t-btn-danger !px-2 !py-1 !text-xs" confirm="Stop this recurring to-do? Past entries are kept.">Stop</Submit></form>
                )}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
