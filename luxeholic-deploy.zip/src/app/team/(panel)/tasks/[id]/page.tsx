import Link from "next/link";
import { notFound } from "next/navigation";
import { asc, eq } from "drizzle-orm";
import { db, schema } from "@/db";
import { requireStaff } from "@/lib/auth";
import { prettyDay, prettyDateTime } from "@/lib/dates";
import { Badge, Field, PageHeader, Section, TeamDot } from "@/components/team/ui";
import { Submit } from "@/components/team/client";
import { commentTask, deleteTask, setTaskStatus, updateTask } from "../../../actions/tasks";

export default async function TaskPage({ params }: { params: Promise<{ id: string }> }) {
  const me = await requireStaff();
  const { id } = await params;
  const t = await db.query.tasks.findFirst({ where: eq(schema.tasks.id, id), with: { team: true, assignee: true, createdBy: true } });
  if (!t) notFound();
  const lead = me.role === "TEAM_LEAD" && t.teamId === me.teamId;
  const visible = me.role === "SUPER_ADMIN" || t.assigneeId === me.id || lead || (!t.assigneeId && (t.teamId === me.teamId || !t.teamId)) || t.createdById === me.id;
  if (!visible) notFound();
  const canManage = me.role === "SUPER_ADMIN" || t.createdById === me.id || lead;
  const comments = await db.query.taskComments.findMany({ where: eq(schema.taskComments.taskId, id), with: { author: true }, orderBy: asc(schema.taskComments.createdAt) });
  return (
    <div className="max-w-3xl">
      <Link href="/team/tasks" className="text-sm text-stone-500 hover:text-stone-900">← Tasks</Link>
      <PageHeader title={t.title} sub={<span className="flex flex-wrap items-center gap-3"><span className="flex items-center gap-1.5"><TeamDot color={t.team?.color} />{t.team?.name ?? "Company-wide"}</span><span>{t.assignee ? `Assigned to ${t.assignee.name}` : "Whole team"}</span><span>{prettyDay(t.dueDate, { weekday: "long", day: "numeric", month: "long" })}{t.dueTime ? ` · ${t.dueTime}` : ""}</span><span>by {t.createdBy.name}</span></span>} />
      <div className="mb-5 flex flex-wrap items-center gap-2">
        <Badge>{t.status}</Badge><Badge>{t.priority}</Badge>{t.isTemplate && <Badge tone="violet">recurring template</Badge>}
        {!t.isTemplate && (["TODO", "IN_PROGRESS", "BLOCKED", "DONE"] as const).filter((s) => s !== t.status).map((s) => (
          <form key={s} action={setTaskStatus}><input type="hidden" name="id" value={t.id} /><input type="hidden" name="status" value={s} /><input type="hidden" name="back" value={`/team/tasks/${t.id}`} /><Submit className="t-btn-ghost !py-1 !text-xs">{s === "DONE" ? "✓ Mark done" : s === "IN_PROGRESS" ? "Start" : s === "BLOCKED" ? "Blocked" : "Reopen"}</Submit></form>
        ))}
      </div>
      {t.description && <div className="t-card mb-5 whitespace-pre-wrap p-4 text-sm">{t.description}</div>}
      <Section title={`Discussion (${comments.length})`} className="mb-5">
        <ul className="space-y-3">{comments.map((c) => (
          <li key={c.id} className="text-sm"><p><span className="font-medium">{c.author.name}</span> <span className="text-xs text-stone-400">{prettyDateTime(c.createdAt)}</span></p><p className="mt-0.5 whitespace-pre-wrap text-stone-700">{c.body}</p></li>
        ))}</ul>
        <form action={commentTask} className="mt-4 flex gap-2"><input type="hidden" name="id" value={t.id} /><input name="body" className="t-input" placeholder="Add an update or question…" /><Submit>Post</Submit></form>
      </Section>
      {canManage && (
        <Section title="Edit">
          <form action={updateTask} className="grid gap-4 sm:grid-cols-2">
            <input type="hidden" name="id" value={t.id} />
            <Field label="Title" className="sm:col-span-2"><input name="title" defaultValue={t.title} className="t-input" /></Field>
            <Field label="Details" className="sm:col-span-2"><textarea name="description" defaultValue={t.description ?? ""} rows={3} className="t-input" /></Field>
            <Field label={t.isTemplate ? "Starts" : "Date"}><input type="date" name="dueDate" defaultValue={t.dueDate} className="t-input" /></Field>
            <Field label="Time"><input type="time" name="dueTime" defaultValue={t.dueTime ?? ""} className="t-input" /></Field>
            <Field label="Priority"><select name="priority" defaultValue={t.priority} className="t-input"><option>LOW</option><option>MEDIUM</option><option>HIGH</option><option>URGENT</option></select></Field>
            <div className="flex items-end justify-end gap-2 sm:col-span-2"><Submit>Save</Submit></div>
          </form>
          <form action={deleteTask} className="mt-4 border-t border-stone-100 pt-4"><input type="hidden" name="id" value={t.id} /><Submit className="t-btn-danger" confirm={t.isTemplate ? "Stop this recurring series?" : "Delete this task?"}>{t.isTemplate ? "Stop recurring series" : "Delete task"}</Submit></form>
        </Section>
      )}
    </div>
  );
}
