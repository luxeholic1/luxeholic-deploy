import Link from "next/link";
import { and, asc, count, desc, eq, gte, inArray, lt, lte, ne, sql, sum } from "drizzle-orm";
import { db, schema } from "@/db";
import { requireStaff } from "@/lib/auth";
import { canRead, isSuper } from "@/lib/rbac";
import { taskScope } from "@/lib/team";
import { materializeRecurring } from "@/lib/tasks";
import { addDays, prettyDateTime, prettyDay, todayIST } from "@/lib/dates";
import { formatINR } from "@/lib/money";
import { Badge, PageHeader, Section, Stat, TeamDot } from "@/components/team/ui";

export const metadata = { title: "Dashboard" };

export default async function Dashboard({ searchParams }: { searchParams: Promise<{ denied?: string }> }) {
  const me = await requireStaff();
  const { denied } = await searchParams;
  const today = todayIST();
  await materializeRecurring(addDays(today, -1), addDays(today, 7));
  const startOfDay = new Date(`${today}T00:00:00+05:30`);
  const monthStart = new Date(`${today.slice(0, 7)}-01T00:00:00+05:30`);
  const scope = taskScope(me);

  const myToday = await db.select({ t: schema.tasks, team: schema.teams }).from(schema.tasks)
    .leftJoin(schema.teams, eq(schema.tasks.teamId, schema.teams.id))
    .where(and(eq(schema.tasks.isTemplate, false), lte(schema.tasks.dueDate, today), ...(scope ? [scope] : []),
      me.role === "SUPER_ADMIN" ? eq(schema.tasks.assigneeId, me.id) : sql`true`,
      sql`(${schema.tasks.status} <> 'DONE' or ${schema.tasks.dueDate} = ${today})`))
    .orderBy(asc(schema.tasks.dueDate), asc(schema.tasks.dueTime)).limit(12);

  const c = async (q: Promise<{ n: number }[]>) => (await q)[0]?.n ?? 0;
  const o = schema.orders;
  const stats = {
    pendingCod: canRead(me, "orders") ? await c(db.select({ n: count() }).from(o).where(and(eq(o.status, "PENDING"), eq(o.paymentMethod, "COD")))) : 0,
    bankVerify: canRead(me, "orders") ? await c(db.select({ n: count() }).from(o).where(eq(o.paymentStatus, "AWAITING_VERIFICATION"))) : 0,
    toShip: canRead(me, "orders") ? await c(db.select({ n: count() }).from(o).where(inArray(o.status, ["CONFIRMED", "PROCESSING"]))) : 0,
    returns: canRead(me, "orders") ? await c(db.select({ n: count() }).from(o).where(eq(o.status, "RETURN_REQUESTED"))) : 0,
    draftPos: canRead(me, "purchaseOrders") ? await c(db.select({ n: count() }).from(schema.purchaseOrders).where(eq(schema.purchaseOrders.status, "DRAFT"))) : 0,
    drafts: canRead(me, "products") ? await c(db.select({ n: count() }).from(schema.products).where(eq(schema.products.status, "DRAFT"))) : 0,
    lowStock: canRead(me, "products") ? await c(db.select({ n: count() }).from(schema.products).where(and(eq(schema.products.status, "ACTIVE"), lte(schema.products.stock, 2)))) : 0,
    live: canRead(me, "products") ? await c(db.select({ n: count() }).from(schema.products).where(and(eq(schema.products.status, "ACTIVE"), gte(schema.products.stock, 1)))) : 0,
    tickets: canRead(me, "tickets") ? await c(db.select({ n: count() }).from(schema.supportTickets).where(ne(schema.supportTickets.status, "RESOLVED"))) : 0,
    subscribers: canRead(me, "marketing") ? await c(db.select({ n: count() }).from(schema.subscribers)) : 0,
  };
  const paidStatuses = ["PAID", "PARTIALLY_PAID"] as const;
  const revenue = isSuper(me) || canRead(me, "orders")
    ? await db.select({
        today: sql<number>`coalesce(sum(case when ${o.createdAt} >= ${startOfDay} then ${o.total} end),0)::int`,
        todayN: sql<number>`count(case when ${o.createdAt} >= ${startOfDay} then 1 end)::int`,
        month: sql<number>`coalesce(sum(${o.total}),0)::int`, monthN: count(),
      }).from(o).where(and(gte(o.createdAt, monthStart), ne(o.status, "CANCELLED"), sql`(${inArray(o.paymentStatus, [...paidStatuses])} or ${o.paymentMethod} = 'COD' and ${o.status} <> 'PENDING')`))
    : null;

  // Team progress for today (super admin)
  const teams = isSuper(me) ? await db.select().from(schema.teams).orderBy(asc(schema.teams.sortOrder)) : [];
  const progress = isSuper(me) ? await db.select({
    teamId: schema.tasks.teamId, total: count(), done: sql<number>`count(case when ${schema.tasks.status} = 'DONE' then 1 end)::int`,
  }).from(schema.tasks).where(and(eq(schema.tasks.isTemplate, false), eq(schema.tasks.dueDate, today))).groupBy(schema.tasks.teamId) : [];
  const overdueBy = isSuper(me) ? await db.select({ teamId: schema.tasks.teamId, n: count() }).from(schema.tasks)
    .where(and(eq(schema.tasks.isTemplate, false), lt(schema.tasks.dueDate, today), ne(schema.tasks.status, "DONE"))).groupBy(schema.tasks.teamId) : [];
  const headcount = isSuper(me) ? await db.select({ teamId: schema.staff.teamId, n: count() }).from(schema.staff).where(eq(schema.staff.active, true)).groupBy(schema.staff.teamId) : [];

  const recentOrders = canRead(me, "orders") ? await db.select().from(o).orderBy(desc(o.createdAt)).limit(6) : [];
  const syncs = canRead(me, "vendors") || isSuper(me) ? await db.query.syncLogs.findMany({ with: { vendor: true }, orderBy: desc(schema.syncLogs.startedAt), limit: 4 }) : [];
  const activity = isSuper(me) ? await db.query.activityLogs.findMany({ with: { staff: true }, orderBy: desc(schema.activityLogs.createdAt), limit: 8 }) : [];

  const hour = Number(new Intl.DateTimeFormat("en-IN", { hour: "numeric", hour12: false, timeZone: "Asia/Kolkata" }).format(new Date()));
  return (
    <div>
      <PageHeader title={`Good ${hour < 12 ? "morning" : hour < 17 ? "afternoon" : "evening"}, ${me.name.split(" ")[0]}`} sub={prettyDay(today, { weekday: "long", day: "numeric", month: "long", year: "numeric" })}
        actions={me.role !== "MEMBER" ? <Link href="/team/tasks/new" className="t-btn">+ Assign task</Link> : <Link href="/team/tasks/new" className="t-btn">+ Personal task</Link>} />
      {denied && <p className="mb-5 rounded-md bg-amber-50 px-3 py-2 text-sm text-amber-800">Your team doesn&apos;t have access to that area. Ask the super admin if you need it.</p>}

      <div className="grid grid-cols-2 gap-3 md:grid-cols-4 xl:grid-cols-6">
        {revenue && <><Stat label="Today" value={formatINR(revenue[0].today)} hint={`${revenue[0].todayN} orders`} /><Stat label="This month" value={formatINR(revenue[0].month)} hint={`${revenue[0].monthN} orders`} /></>}
        {canRead(me, "orders") && <><Stat label="COD to confirm" value={stats.pendingCod} href="/team/orders?status=PENDING&method=COD" tone={stats.pendingCod ? "warn" : undefined} />
          <Stat label="Bank transfers to verify" value={stats.bankVerify} href="/team/orders?pay=AWAITING_VERIFICATION" tone={stats.bankVerify ? "warn" : undefined} />
          <Stat label="To dispatch" value={stats.toShip} href="/team/orders?status=CONFIRMED" />
          {stats.returns > 0 && <Stat label="Return requests" value={stats.returns} href="/team/orders?status=RETURN_REQUESTED" tone="warn" />}</>}
        {canRead(me, "purchaseOrders") && <Stat label="Vendor orders to place" value={stats.draftPos} href="/team/purchase-orders?status=DRAFT" tone={stats.draftPos ? "warn" : undefined} />}
        {canRead(me, "products") && <><Stat label="Live products" value={stats.live} href="/team/products?status=ACTIVE" /><Stat label="Drafts to review" value={stats.drafts} href="/team/products?status=DRAFT" /><Stat label="Low stock (≤2)" value={stats.lowStock} href="/team/products?low=1" /></>}
        {canRead(me, "tickets") && <Stat label="Open tickets" value={stats.tickets} href="/team/tickets" tone={stats.tickets ? "warn" : undefined} />}
        {canRead(me, "marketing") && <Stat label="Subscribers" value={stats.subscribers} href="/team/marketing" />}
      </div>

      <div className="mt-6 grid gap-6 xl:grid-cols-[1.2fr_1fr]">
        <Section title={me.role === "SUPER_ADMIN" ? "My to-dos" : "Today & overdue"} actions={<Link href="/team/tasks" className="text-xs text-stone-500 hover:text-stone-900">All tasks →</Link>}>
          {myToday.length === 0 ? <p className="text-sm text-stone-500">You&apos;re all clear.</p> : (
            <ul className="divide-y divide-stone-100">
              {myToday.map(({ t, team }) => (
                <li key={t.id} className="flex items-center gap-3 py-2 text-sm">
                  <span className={`h-4 w-4 shrink-0 rounded border ${t.status === "DONE" ? "border-emerald-600 bg-emerald-600" : "border-stone-300"}`} />
                  <Link href={`/team/tasks/${t.id}`} className={`flex-1 truncate hover:underline ${t.status === "DONE" ? "text-stone-400 line-through" : ""}`}>{t.title}</Link>
                  <TeamDot color={team?.color} />
                  {t.dueDate < today ? <Badge tone="red">overdue</Badge> : t.dueTime ? <span className="text-xs text-stone-400">{t.dueTime}</span> : null}
                </li>
              ))}
            </ul>
          )}
        </Section>

        {isSuper(me) && (
          <Section title="Teams today" actions={<Link href="/team/calendar" className="text-xs text-stone-500 hover:text-stone-900">Calendar →</Link>}>
            <table className="t-table"><thead><tr><th>Team</th><th>People</th><th>Done today</th><th>Overdue</th></tr></thead><tbody>
              {teams.map((t) => {
                const p = progress.find((x) => x.teamId === t.id);
                const od = overdueBy.find((x) => x.teamId === t.id)?.n ?? 0;
                const pct = p && p.total ? Math.round((p.done / p.total) * 100) : 0;
                return (
                  <tr key={t.id}>
                    <td><Link href={`/team/tasks?team=${t.id}`} className="flex items-center gap-2 hover:underline"><TeamDot color={t.color} />{t.name}</Link></td>
                    <td>{headcount.find((h) => h.teamId === t.id)?.n ?? 0}</td>
                    <td><div className="flex items-center gap-2"><div className="h-1.5 w-20 overflow-hidden rounded-full bg-stone-100"><div className="h-full bg-emerald-600" style={{ width: `${pct}%` }} /></div><span className="text-xs text-stone-500">{p?.done ?? 0}/{p?.total ?? 0}</span></div></td>
                    <td>{od ? <Badge tone="red">{od}</Badge> : <span className="text-stone-300">0</span>}</td>
                  </tr>
                );
              })}
            </tbody></table>
          </Section>
        )}

        {recentOrders.length > 0 && (
          <Section title="Latest orders" actions={<Link href="/team/orders" className="text-xs text-stone-500 hover:text-stone-900">All orders →</Link>}>
            <ul className="divide-y divide-stone-100 text-sm">
              {recentOrders.map((r) => (
                <li key={r.id} className="flex items-center justify-between gap-3 py-2">
                  <Link href={`/team/orders/${r.id}`} className="font-medium hover:underline">{r.number}</Link>
                  <span className="hidden text-xs text-stone-400 sm:block">{prettyDateTime(r.createdAt)}</span>
                  <span className="text-xs">{r.paymentMethod.replace("_", " ")}</span>
                  <Badge>{r.status}</Badge>
                  <span className="w-24 text-right">{formatINR(r.total)}</span>
                </li>
              ))}
            </ul>
          </Section>
        )}

        {syncs.length > 0 && (
          <Section title="Vendor syncs" actions={<Link href="/team/vendors" className="text-xs text-stone-500 hover:text-stone-900">Vendors →</Link>}>
            <ul className="space-y-2 text-sm">
              {syncs.map((s) => (
                <li key={s.id} className="flex items-center justify-between gap-2">
                  <span>{s.vendor.name}</span>
                  <span className="text-xs text-stone-500">{prettyDateTime(s.startedAt)}</span>
                  {s.ok ? <Badge tone="green">{`+${s.created} / ${s.updated} upd`}</Badge> : <Badge tone="red">failed</Badge>}
                </li>
              ))}
            </ul>
          </Section>
        )}

        {activity.length > 0 && (
          <Section title="Recent activity" actions={<Link href="/team/activity" className="text-xs text-stone-500 hover:text-stone-900">Audit log →</Link>}>
            <ul className="space-y-1.5 text-sm">
              {activity.map((a) => <li key={a.id} className="flex justify-between gap-3"><span className="truncate"><b className="font-medium">{a.staff?.name ?? "System"}</b> · {a.action}</span><span className="shrink-0 text-xs text-stone-400">{prettyDateTime(a.createdAt)}</span></li>)}
            </ul>
          </Section>
        )}
      </div>
    </div>
  );
}
