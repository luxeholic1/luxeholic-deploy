import { cookies } from "next/headers";
import { asc, eq } from "drizzle-orm";
import { db, schema } from "@/db";
import { requireSuper } from "@/lib/auth";
import { decryptJson } from "@/lib/crypto";
import { prettyDateTime } from "@/lib/dates";
import { SITE_URL } from "@/lib/site";
import { Badge, Field, PageHeader, Section, TeamDot } from "@/components/team/ui";
import { CopyText, Submit } from "@/components/team/client";
import { createStaff, resetStaffPassword, updateStaff } from "../../actions/admin";

export const metadata = { title: "Staff & logins" };

export default async function Staff() {
  await requireSuper();
  const once = decryptJson<{ email: string; pw: string; reset: boolean }>((await cookies()).get("lx_onetime")?.value);
  const [teams, people] = await Promise.all([
    db.select().from(schema.teams).orderBy(asc(schema.teams.sortOrder)),
    db.select().from(schema.staff).orderBy(asc(schema.staff.name)),
  ]);
  const smtp = Boolean(process.env.SMTP_HOST);
  return (
    <div>
      <PageHeader title="Staff & logins" sub="Create a login for each employee with the email you provide. They sign in at /team/login by choosing their team." />
      {once && (
        <div className="mb-6 rounded-lg border border-emerald-200 bg-emerald-50 p-4 text-sm">
          <p className="font-medium text-emerald-900">{once.reset ? "Password reset" : "Login created"} for {once.email}</p>
          <p className="mt-1">Temporary password: <code className="rounded bg-white px-2 py-0.5 text-base">{once.pw}</code> <CopyText text={`Luxeholic team login\n${SITE_URL}/team/login\nEmail: ${once.email}\nTemporary password: ${once.pw}\n(You'll set your own password on first sign-in.)`} /></p>
          <p className="mt-1 text-xs text-emerald-800">Shown once (for 90 seconds). Share it privately — they must change it on first sign-in.</p>
        </div>
      )}
      <div className="grid gap-6 xl:grid-cols-[1fr_380px]">
        <div className="space-y-4">
          {[...teams.map((t) => ({ t, list: people.filter((p) => p.teamId === t.id) })), { t: null, list: people.filter((p) => !p.teamId) }].map(({ t, list }) => (
            <Section key={t?.id ?? "admins"} title={t ? t.name : "Super admin"} actions={t && <TeamDot color={t.color} />}>
              {list.length === 0 ? <p className="text-sm text-stone-500">No one yet.</p> : (
                <ul className="divide-y divide-stone-100">{list.map((p) => (
                  <li key={p.id} className="py-2">
                    <details>
                      <summary className="flex cursor-pointer flex-wrap items-center gap-3 text-sm">
                        <span className="font-medium">{p.name}</span><span className="text-stone-500">{p.email}</span>
                        {p.role === "TEAM_LEAD" && <Badge tone="violet">lead</Badge>}{p.role === "SUPER_ADMIN" && <Badge tone="ink">super admin</Badge>}
                        {!p.active && <Badge tone="red">deactivated</Badge>}{p.mustChangePassword && p.active && <Badge tone="amber">invite pending</Badge>}
                        <span className="ml-auto text-xs text-stone-400">{p.lastLoginAt ? `last in ${prettyDateTime(p.lastLoginAt)}` : "never signed in"}</span>
                      </summary>
                      {p.role !== "SUPER_ADMIN" && (
                        <div className="mt-3 rounded-md bg-stone-50 p-3">
                          <form action={updateStaff} className="grid gap-3 sm:grid-cols-5">
                            <input type="hidden" name="id" value={p.id} />
                            <Field label="Name"><input name="name" defaultValue={p.name} className="t-input" /></Field>
                            <Field label="Phone"><input name="phone" defaultValue={p.phone ?? ""} className="t-input" /></Field>
                            <Field label="Team"><select name="teamId" defaultValue={p.teamId ?? ""} className="t-input">{teams.map((x) => <option key={x.id} value={x.id}>{x.name}</option>)}</select></Field>
                            <Field label="Role"><select name="role" defaultValue={p.role} className="t-input"><option value="MEMBER">Member</option><option value="TEAM_LEAD">Team lead</option></select></Field>
                            <div className="flex items-end gap-3"><label className="flex items-center gap-1 text-sm"><input type="checkbox" name="active" defaultChecked={p.active} /> Active</label><Submit className="t-btn !px-3">Save</Submit></div>
                          </form>
                          <form action={resetStaffPassword} className="mt-3"><input type="hidden" name="id" value={p.id} /><Submit className="t-btn-ghost !py-1 !text-xs" confirm={`Reset ${p.name}'s password? They'll be signed out.`}>Reset password</Submit></form>
                        </div>
                      )}
                    </details>
                  </li>
                ))}</ul>
              )}
            </Section>
          ))}
        </div>
        <Section title="Add a team member" className="h-fit">
          <form action={createStaff} className="space-y-3">
            <Field label="Full name"><input name="name" required className="t-input" /></Field>
            <Field label="Work email (their login)"><input name="email" type="email" required className="t-input" placeholder="name@luxeholic.in" /></Field>
            <Field label="Phone"><input name="phone" className="t-input" /></Field>
            <Field label="Team"><select name="teamId" required className="t-input"><option value="">Choose…</option>{teams.map((t) => <option key={t.id} value={t.id}>{t.name}</option>)}</select></Field>
            <Field label="Role"><select name="role" className="t-input"><option value="MEMBER">Member</option><option value="TEAM_LEAD">Team lead (can assign tasks to their team)</option></select></Field>
            <label className="flex items-center gap-2 text-sm"><input type="checkbox" name="sendEmail" defaultChecked={smtp} disabled={!smtp} /> Email them their login {!smtp && <span className="text-xs text-stone-400">(set up SMTP first)</span>}</label>
            <Submit className="t-btn w-full">Create login</Submit>
          </form>
        </Section>
      </div>
    </div>
  );
}
