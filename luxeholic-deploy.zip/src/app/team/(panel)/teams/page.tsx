import { asc, count } from "drizzle-orm";
import { db, schema } from "@/db";
import { requireSuper } from "@/lib/auth";
import { MODULES, type ModuleKey } from "@/lib/rbac";
import { Field, PageHeader, TeamDot } from "@/components/team/ui";
import { Submit } from "@/components/team/client";
import { saveTeam } from "../../actions/admin";

export const metadata = { title: "Teams & access" };
type Team = typeof schema.teams.$inferSelect;

export default async function Teams() {
  await requireSuper();
  const [teams, sizes] = await Promise.all([
    db.select().from(schema.teams).orderBy(asc(schema.teams.sortOrder)),
    db.select({ t: schema.staff.teamId, n: count() }).from(schema.staff).groupBy(schema.staff.teamId),
  ]);
  const Form = ({ t }: { t?: Team }) => (
    <form action={saveTeam} className="t-card p-4">
      <input type="hidden" name="id" value={t?.id ?? ""} />
      <div className="grid gap-3 sm:grid-cols-6">
        <Field label="Team name" className="sm:col-span-2"><input name="name" defaultValue={t?.name} required className="t-input" /></Field>
        <Field label="Purpose" className="sm:col-span-3"><input name="description" defaultValue={t?.description ?? ""} className="t-input" /></Field>
        <div className="grid grid-cols-2 gap-2"><Field label="Colour"><input type="color" name="color" defaultValue={t?.color ?? "#A8834A"} className="h-[38px] w-full rounded-md border border-stone-300" /></Field><Field label="Order"><input name="sortOrder" defaultValue={t?.sortOrder ?? 9} className="t-input" /></Field></div>
      </div>
      <p className="mb-2 mt-4 text-xs font-medium uppercase tracking-wide text-stone-500">Panel access {t && <span className="normal-case text-stone-400">· {sizes.find((s) => s.t === t.id)?.n ?? 0} people · everyone always gets Dashboard, Tasks, Calendar</span>}</p>
      <div className="grid gap-2 sm:grid-cols-2 lg:grid-cols-4">
        {(Object.keys(MODULES) as ModuleKey[]).map((m) => (
          <label key={m} className="flex items-center justify-between gap-2 rounded-md border border-stone-200 px-3 py-2 text-sm">
            <span title={MODULES[m].hint}>{MODULES[m].label}</span>
            <select name={`m_${m}`} defaultValue={t?.modules?.[m] ?? ""} className="rounded border-stone-300 text-xs"><option value="">No access</option><option value="read">View</option><option value="write">Edit</option></select>
          </label>
        ))}
      </div>
      <div className="mt-4 flex justify-end"><Submit>{t ? "Save" : "Create team"}</Submit></div>
    </form>
  );
  return (
    <div className="max-w-5xl">
      <PageHeader title="Teams & access" sub="Each team gets its own panel. Choose what every team can view or edit." />
      <div className="space-y-4">
        {teams.map((t) => <div key={t.id}><p className="mb-2 flex items-center gap-2 font-semibold"><TeamDot color={t.color} />{t.name}<span className="text-xs font-normal text-stone-400">login code: {t.slug}</span></p><Form t={t} /></div>)}
        <details className="t-card"><summary className="cursor-pointer px-4 py-3 text-sm font-medium">+ Create a new team (e.g. Design, Finance, Logistics)</summary><div className="p-2"><Form /></div></details>
      </div>
    </div>
  );
}
