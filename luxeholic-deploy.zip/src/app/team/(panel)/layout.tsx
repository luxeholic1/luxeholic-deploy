import Link from "next/link";
import { Suspense } from "react";
import { Bell, LayoutDashboard, ListTodo, CalendarDays, ShoppingCart, Users, Package, FolderTree, ClipboardList, Handshake, LifeBuoy, Megaphone, UserCog, Shield, Settings, ScrollText, Upload, PhoneCall, Clapperboard, Languages } from "lucide-react";
import { requireStaff } from "@/lib/auth";
import { canRead, canWrite, MODULES, ADMIN_AREAS, type ModuleKey } from "@/lib/rbac";
import { unreadCount } from "@/lib/notify";
import { Flash, MobileNav, NavLink } from "@/components/team/client";
import { TeamDot } from "@/components/team/ui";
import { staffLogout } from "../actions/auth";

export const dynamic = "force-dynamic";
export const metadata = { title: { default: "Team", template: "%s · Luxeholic Team" }, robots: { index: false, follow: false } };

const ICONS: Record<string, React.ComponentType<{ size?: number }>> = {
  orders: ShoppingCart, leads: PhoneCall, customers: Users, products: Package, categories: FolderTree, purchaseOrders: ClipboardList,
  vendors: Handshake, tickets: LifeBuoy, marketing: Megaphone, staff: UserCog, teams: Shield, settings: Settings, activity: ScrollText,
};

export default async function PanelLayout({ children }: { children: React.ReactNode }) {
  const s = await requireStaff();
  const unread = await unreadCount(s.id);
  const mods = (Object.keys(MODULES) as ModuleKey[]).filter((m) => canRead(s, m));
  const nav = (
    <nav className="space-y-6">
      <div className="space-y-0.5">
        <NavLink href="/team"><LayoutDashboard size={16} />Dashboard</NavLink>
        <NavLink href="/team/tasks"><ListTodo size={16} />Tasks & to-dos</NavLink>
        <NavLink href="/team/calendar"><CalendarDays size={16} />Calendar</NavLink>
        <NavLink href="/team/notifications"><Bell size={16} />Notifications{unread > 0 && <span className="ml-auto rounded-full bg-amber-500 px-1.5 text-[11px] text-white">{unread}</span>}</NavLink>
      </div>
      {mods.length > 0 && (
        <div>
          <p className="mb-1.5 px-2.5 text-[11px] font-medium uppercase tracking-wider text-stone-400">{s.role === "SUPER_ADMIN" ? "Operations" : s.team?.name}</p>
          <div className="space-y-0.5">{mods.map((m) => { const I = ICONS[m]; return [<NavLink key={m} href={MODULES[m].href}><I size={16} />{MODULES[m].label}</NavLink>, m === "products" && canWrite(s, "products") && <NavLink key="upload" href="/team/products/import"><Upload size={16} />Upload products</NavLink>, m === "marketing" && canWrite(s, "marketing") && <NavLink key="hero" href="/team/marketing/hero"><Clapperboard size={16} />Homepage hero</NavLink>, m === "marketing" && <NavLink key="i18n" href="/team/marketing/translations"><Languages size={16} />Languages & translations</NavLink>]; })}</div>
        </div>
      )}
      {s.role === "SUPER_ADMIN" && (
        <div>
          <p className="mb-1.5 px-2.5 text-[11px] font-medium uppercase tracking-wider text-stone-400">Super admin</p>
          <div className="space-y-0.5">{(Object.keys(ADMIN_AREAS) as (keyof typeof ADMIN_AREAS)[]).map((k) => { const I = ICONS[k]; return <NavLink key={k} href={ADMIN_AREAS[k].href}><I size={16} />{ADMIN_AREAS[k].label}</NavLink>; })}</div>
        </div>
      )}
    </nav>
  );
  return (
    <div className="min-h-screen bg-stone-50 text-stone-800">
      <aside className="fixed inset-y-0 left-0 hidden w-60 flex-col border-r border-stone-200 bg-white lg:flex">
        <Link href="/team" className="flex items-center gap-2.5 border-b border-stone-100 px-5 py-4">
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img src="/brand/mark-dark.png" alt="" className="h-6 w-auto" />
          <span className="text-sm font-semibold tracking-[0.2em]">LUXEHOLIC</span>
        </Link>
        <div className="flex-1 overflow-y-auto px-3 py-5">{nav}</div>
        <div className="border-t border-stone-100 p-3 text-xs">
          <p className="truncate font-medium text-stone-800">{s.name}</p>
          <p className="flex items-center gap-1.5 truncate text-stone-500">{s.team && <TeamDot color={s.team.color} />}{s.role === "SUPER_ADMIN" ? "Super admin" : `${s.team?.name ?? ""} · ${s.role === "TEAM_LEAD" ? "Lead" : "Member"}`}</p>
          <div className="mt-2 flex gap-3">
            <Link href="/team/change-password" className="text-stone-500 hover:text-stone-900">Password</Link>
            <form action={staffLogout}><button className="text-stone-500 hover:text-stone-900">Sign out</button></form>
            <Link href="/" target="_blank" className="ml-auto text-stone-500 hover:text-stone-900">View store ↗</Link>
          </div>
        </div>
      </aside>
      <header className="sticky top-0 z-30 flex items-center justify-between border-b border-stone-200 bg-white px-3 py-2 lg:hidden">
        <MobileNav>{nav}<form action={staffLogout} className="mt-6 px-2.5"><button className="text-sm text-stone-500">Sign out</button></form></MobileNav>
        <span className="text-sm font-semibold tracking-[0.2em]">LUXEHOLIC</span>
        <Link href="/team/notifications" className="relative p-2"><Bell size={18} />{unread > 0 && <span className="absolute right-1 top-1 h-2 w-2 rounded-full bg-amber-500" />}</Link>
      </header>
      <main className="px-4 py-6 lg:ml-60 lg:px-8 lg:py-8">{children}</main>
      <Suspense><Flash /></Suspense>
    </div>
  );
}
