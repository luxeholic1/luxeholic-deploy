import { desc, eq, ilike, or, sql } from "drizzle-orm";
import { db, schema } from "@/db";
import { requireStaff } from "@/lib/auth";
import { formatINR } from "@/lib/money";
import { prettyDateTime } from "@/lib/dates";
import { Empty, PageHeader, Stat } from "@/components/team/ui";

export const metadata = { title: "Customers" };
export default async function Customers({ searchParams }: { searchParams: Promise<{ q?: string }> }) {
  await requireStaff("customers");
  const { q } = await searchParams;
  const c = schema.customers, o = schema.orders;
  const rows = await db.select({
    c, orders: sql<number>`count(${o.id})::int`, spent: sql<number>`coalesce(sum(case when ${o.status} <> 'CANCELLED' then ${o.total} end),0)::int`, last: sql<Date | null>`max(${o.createdAt})`,
  }).from(c).leftJoin(o, eq(o.customerId, c.id)).where(q ? or(ilike(c.name, `%${q}%`), ilike(c.email, `%${q}%`), ilike(c.phone, `%${q}%`)) : undefined)
    .groupBy(c.id).orderBy(desc(c.createdAt)).limit(200);
  const guests = await db.select({ n: sql<number>`count(distinct ${o.email})::int` }).from(o).where(eq(o.isGuest, true));
  return (
    <div>
      <PageHeader title="Customers" sub="Registered accounts. Guest buyers appear on their orders." />
      <div className="mb-5 grid grid-cols-2 gap-3 md:grid-cols-4">
        <Stat label="Accounts" value={rows.length} /><Stat label="Guest buyers" value={guests[0]?.n ?? 0} />
        <Stat label="Opted into marketing" value={rows.filter((r) => r.c.marketingOptIn).length} />
      </div>
      <form className="mb-4"><input name="q" defaultValue={q} placeholder="Search name, email, phone" className="t-input max-w-sm" /></form>
      {rows.length === 0 ? <Empty>No customers yet.</Empty> : (
        <div className="t-card overflow-x-auto"><table className="t-table"><thead><tr><th>Name</th><th>Contact</th><th>Joined</th><th>Orders</th><th className="text-right">Lifetime value</th></tr></thead><tbody>
          {rows.map(({ c: x, orders, spent }) => <tr key={x.id}><td className="font-medium">{x.name}{x.marketingOptIn && <span className="ml-1.5 text-xs text-emerald-700">✉</span>}</td><td><div>{x.email}</div><div className="text-xs text-stone-500">{x.phone}</div></td><td className="text-stone-500">{prettyDateTime(x.createdAt)}</td><td>{orders}</td><td className="text-right">{formatINR(spent)}</td></tr>)}
        </tbody></table></div>
      )}
    </div>
  );
}
