import Link from "next/link";
import { and, count, desc, eq, ilike, or, type SQL } from "drizzle-orm";
import { db, schema } from "@/db";
import { requireStaff } from "@/lib/auth";
import { formatINR } from "@/lib/money";
import { prettyDateTime } from "@/lib/dates";
import { withQuery } from "@/lib/url";
import { Badge, Empty, PageHeader, Tabs } from "@/components/team/ui";

export const metadata = { title: "Orders" };
const STATUSES = ["PENDING", "CONFIRMED", "PROCESSING", "SHIPPED", "DELIVERED", "RETURN_REQUESTED", "CANCELLED"] as const;

export default async function Orders({ searchParams }: { searchParams: Promise<Record<string, string>> }) {
  await requireStaff("orders");
  const sp = await searchParams;
  const o = schema.orders;
  const w: SQL[] = [];
  if (sp.status) w.push(eq(o.status, sp.status as (typeof STATUSES)[number]));
  if (sp.pay) w.push(eq(o.paymentStatus, sp.pay as "PAID"));
  if (sp.method) w.push(eq(o.paymentMethod, sp.method as "COD"));
  if (sp.q) w.push(or(ilike(o.number, `%${sp.q}%`), ilike(o.email, `%${sp.q}%`), ilike(o.phone, `%${sp.q}%`))!);
  const page = Math.max(1, Number(sp.page) || 1);
  const [rows, counts] = await Promise.all([
    db.select().from(o).where(and(...w)).orderBy(desc(o.createdAt)).limit(50).offset((page - 1) * 50),
    db.select({ status: o.status, n: count() }).from(o).groupBy(o.status),
  ]);
  const q = (p: Record<string, string | undefined>) => withQuery("/team/orders", { ...sp, page: undefined, ok: undefined, err: undefined, ...p });
  return (
    <div>
      <PageHeader title="Orders" sub="Confirm COD orders by phone, verify bank transfers, dispatch and track." />
      <Tabs active={sp.status ?? "all"} items={[{ key: "all", label: "All", href: q({ status: undefined }) }, ...STATUSES.map((s) => ({ key: s, label: s.replace("_", " ").toLowerCase(), href: q({ status: s }), count: counts.find((c) => c.status === s)?.n ?? 0 }))]} />
      <form className="mb-4 flex flex-wrap gap-2" action="/team/orders">
        {sp.status && <input type="hidden" name="status" value={sp.status} />}
        <input name="q" defaultValue={sp.q} placeholder="Order no., email or phone" className="t-input max-w-xs" />
        <select name="method" defaultValue={sp.method ?? ""} className="t-input max-w-[180px]"><option value="">Any payment method</option><option value="PAYU">PayU</option><option value="PHONEPE">PhonePe</option><option value="PARTIAL_COD">10% + COD</option><option value="COD">COD</option><option value="BANK_TRANSFER">Bank transfer</option></select>
        <select name="pay" defaultValue={sp.pay ?? ""} className="t-input max-w-[200px]"><option value="">Any payment status</option><option value="PENDING">Pending</option><option value="AWAITING_VERIFICATION">Awaiting verification</option><option value="PARTIALLY_PAID">Partially paid</option><option value="PAID">Paid</option><option value="FAILED">Failed</option><option value="REFUNDED">Refunded</option></select>
        <button className="t-btn-ghost">Filter</button>
      </form>
      {rows.length === 0 ? <Empty>No orders match.</Empty> : (
        <div className="t-card overflow-x-auto">
          <table className="t-table">
            <thead><tr><th>Order</th><th>Date</th><th>Customer</th><th>Payment</th><th>Status</th><th className="text-right">Total</th></tr></thead>
            <tbody>{rows.map((r) => (
              <tr key={r.id} className="hover:bg-stone-50">
                <td><Link href={`/team/orders/${r.id}`} className="font-medium hover:underline">{r.number}</Link>{r.isGuest && <span className="ml-1.5 text-[10px] uppercase text-stone-400">guest</span>}</td>
                <td className="whitespace-nowrap text-stone-500">{prettyDateTime(r.createdAt)}</td>
                <td><div>{r.shippingAddress.name}</div><div className="text-xs text-stone-500">{r.shippingAddress.city} · {r.phone}</div></td>
                <td><div className="text-xs">{r.paymentMethod.replace("_", " ")}</div><Badge>{r.paymentStatus}</Badge></td>
                <td><Badge>{r.status}</Badge></td>
                <td className="text-right font-medium">{formatINR(r.total)}</td>
              </tr>
            ))}</tbody>
          </table>
        </div>
      )}
      <div className="mt-4 flex justify-between text-sm">
        {page > 1 ? <Link href={q({ page: String(page - 1) })} className="t-btn-ghost">← Newer</Link> : <span />}
        {rows.length === 50 && <Link href={q({ page: String(page + 1) })} className="t-btn-ghost">Older →</Link>}
      </div>
    </div>
  );
}
