"use client";
export function PrintButton() { return <button className="t-btn" onClick={() => window.print()}>Print / Save PDF</button>; }
