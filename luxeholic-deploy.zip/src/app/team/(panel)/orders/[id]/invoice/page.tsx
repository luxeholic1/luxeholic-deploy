import { notFound } from "next/navigation";
import { eq } from "drizzle-orm";
import { db, schema } from "@/db";
import { requireStaff } from "@/lib/auth";
import { getSettings } from "@/lib/settings";
import { TaxInvoice } from "@/components/invoice";
import { PrintButton } from "./print";

export default async function Invoice({ params }: { params: Promise<{ id: string }> }) {
  await requireStaff("orders");
  const { id } = await params;
  const o = await db.query.orders.findFirst({ where: eq(schema.orders.id, id), with: { items: true } });
  if (!o) notFound();
  const { business: b } = await getSettings();
  return (
    <div className="mx-auto max-w-3xl bg-white p-10 text-sm text-stone-800 print:p-0">
      <div className="mb-6 flex justify-end print:hidden"><PrintButton /></div>
      <TaxInvoice o={o} b={b} />
    </div>
  );
}
