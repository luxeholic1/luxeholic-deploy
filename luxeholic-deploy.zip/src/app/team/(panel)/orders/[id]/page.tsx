import Link from "next/link";
import { notFound } from "next/navigation";
import { desc, eq } from "drizzle-orm";
import { db, schema } from "@/db";
import { requireStaff } from "@/lib/auth";
import { canWrite } from "@/lib/rbac";
import { formatINR } from "@/lib/money";
import { prettyDateTime } from "@/lib/dates";
import { Badge, Field, PageHeader, Section } from "@/components/team/ui";
import { Submit } from "@/components/team/client";
import { confirmCod, markBalanceCollected, markRefunded, saveOrderNote, updateOrderStatus, verifyBankTransfer } from "../../../actions/orders";

export default async function OrderDetail({ params }: { params: Promise<{ id: string }> }) {
  const me = await requireStaff("orders");
  const { id } = await params;
  const o = await db.query.orders.findFirst({ where: eq(schema.orders.id, id), with: { items: true, payments: true, purchaseOrders: { with: { vendor: true } }, customer: true } });
  if (!o) notFound();
  const write = canWrite(me, "orders");
  const a = o.shippingAddress;
  const due = o.total - o.amountPaid;
  const history = o.customer ? await db.select({ n: schema.orders.number, id: schema.orders.id, total: schema.orders.total }).from(schema.orders).where(eq(schema.orders.customerId, o.customer.id)).orderBy(desc(schema.orders.createdAt)).limit(5) : [];
  const Hidden = () => <input type="hidden" name="id" value={o.id} />;
  return (
    <div>
      <Link href="/team/orders" className="text-sm text-stone-500 hover:text-stone-900">← Orders</Link>
      <PageHeader title={`Order ${o.number}`} sub={<span className="flex flex-wrap items-center gap-2">{prettyDateTime(o.createdAt)} · <Badge>{o.status}</Badge><Badge>{o.paymentStatus}</Badge><span className="text-xs">{o.paymentMethod.replace("_", " ")}</span></span>}
        actions={<Link href={`/team/orders/${o.id}/invoice`} target="_blank" className="t-btn-ghost">GST invoice</Link>} />

      {write && (
        <div className="mb-6 flex flex-wrap gap-2">
          {o.status === "PENDING" && o.paymentMethod === "COD" && <form action={confirmCod}><Hidden /><Submit>✓ Confirmed by phone</Submit></form>}
          {o.paymentMethod === "BANK_TRANSFER" && o.paymentStatus !== "PAID" && (
            <form action={verifyBankTransfer} className="flex gap-2"><Hidden /><input name="amount" placeholder={`Amount (₹${o.total / 100})`} className="t-input w-40" /><Submit confirm="Confirm you've seen this amount in the bank statement?">Verify transfer{o.bankUtr ? ` (UTR ${o.bankUtr})` : ""}</Submit></form>
          )}
          {due > 0 && (o.paymentMethod === "COD" || o.paymentMethod === "PARTIAL_COD") && ["SHIPPED", "DELIVERED"].includes(o.status) && (
            <form action={markBalanceCollected}><Hidden /><Submit className="t-btn-ghost" confirm={`Mark ${formatINR(due)} as collected?`}>Balance {formatINR(due)} collected</Submit></form>
          )}
        </div>
      )}

      <div className="grid gap-6 xl:grid-cols-[1.5fr_1fr]">
        <div className="space-y-6">
          <Section title={`Items (${o.items.length})`}>
            <table className="t-table"><thead><tr><th>Item</th><th>SKU</th><th>Qty</th><th className="text-right">Amount</th></tr></thead><tbody>
              {o.items.map((i) => <tr key={i.id}><td>{i.title}{i.variant && <span className="text-stone-500"> · {i.variant}</span>}</td><td className="text-xs text-stone-500">{i.sku}</td><td>{i.quantity}</td><td className="text-right">{formatINR(i.unitPrice * i.quantity)}</td></tr>)}
            </tbody></table>
            <dl className="ml-auto mt-4 w-64 space-y-1 text-sm">
              <div className="flex justify-between"><dt>Subtotal</dt><dd>{formatINR(o.subtotal)}</dd></div>
              {o.discount > 0 && <div className="flex justify-between"><dt>Discount {o.couponCode}</dt><dd>−{formatINR(o.discount)}</dd></div>}
              <div className="flex justify-between"><dt>Shipping</dt><dd>{formatINR(o.shippingFee)}</dd></div>
              {o.codFee > 0 && <div className="flex justify-between"><dt>COD fee</dt><dd>{formatINR(o.codFee)}</dd></div>}
              <div className="flex justify-between border-t pt-1 font-semibold"><dt>Total</dt><dd>{formatINR(o.total)}</dd></div>
              <div className="flex justify-between text-stone-500"><dt>Paid</dt><dd>{formatINR(o.amountPaid)}</dd></div>
              {due > 0 && <div className="flex justify-between font-medium text-amber-700"><dt>Due</dt><dd>{formatINR(due)}</dd></div>}
              <div className="flex justify-between text-xs text-stone-400"><dt>GST included</dt><dd>{formatINR(o.taxIncluded)}</dd></div>
            </dl>
          </Section>

          {write && (
            <Section title="Fulfilment">
              <form action={updateOrderStatus} className="grid gap-3 sm:grid-cols-4">
                <Hidden />
                <Field label="Status"><select name="status" defaultValue={o.status} className="t-input">{["PENDING", "CONFIRMED", "PROCESSING", "SHIPPED", "DELIVERED", "RETURN_REQUESTED", "RETURNED", "CANCELLED"].map((s) => <option key={s} value={s}>{s.replace("_", " ").toLowerCase()}</option>)}</select></Field>
                <Field label="Courier"><input name="courier" defaultValue={o.courier ?? ""} placeholder="Delhivery, Blue Dart…" className="t-input" /></Field>
                <Field label="Tracking no."><input name="trackingNumber" defaultValue={o.trackingNumber ?? ""} className="t-input" /></Field>
                <div className="flex items-end"><Submit className="t-btn w-full">Update & email customer</Submit></div>
                <label className="flex items-center gap-2 text-xs text-stone-500 sm:col-span-4"><input type="checkbox" name="notify" value="off" /> Don&apos;t email the customer</label>
              </form>
            </Section>
          )}

          <Section title="Vendor purchase orders">
            {o.purchaseOrders.length === 0 ? <p className="text-sm text-stone-500">{o.paymentStatus === "PAID" || o.paymentStatus === "PARTIALLY_PAID" || o.status === "CONFIRMED" ? "No vendor-linked items (or vendor auto-routing is off)." : "Created automatically once the order is paid or confirmed."}</p> : (
              <ul className="space-y-2 text-sm">{o.purchaseOrders.map((p) => <li key={p.id} className="flex items-center gap-3"><Link href={`/team/purchase-orders/${p.id}`} className="font-medium hover:underline">{p.number}</Link><span>{p.vendor.name}</span><Badge>{p.status}</Badge>{p.trackingNumber && <span className="text-xs text-stone-500">Tracking {p.trackingNumber}</span>}</li>)}</ul>
            )}
          </Section>

          <Section title="Internal notes">
            {o.internalNotes && <pre className="mb-3 whitespace-pre-wrap font-sans text-sm text-stone-700">{o.internalNotes}</pre>}
            {o.notes && <p className="mb-3 rounded bg-amber-50 p-2 text-sm"><b>Customer note:</b> {o.notes}</p>}
            {write && <form action={saveOrderNote} className="flex gap-2"><Hidden /><input name="note" placeholder="e.g. Customer asked for evening delivery" className="t-input" /><Submit>Add</Submit></form>}
          </Section>
        </div>

        <div className="space-y-6">
          <Section title="Customer">
            <p className="font-medium">{a.name}</p>
            <p className="text-sm"><a href={`tel:${o.phone}`} className="hover:underline">{o.phone}</a> · <a href={`https://wa.me/91${o.phone}`} target="_blank" rel="noopener noreferrer" className="text-emerald-700 hover:underline">WhatsApp</a></p>
            <p className="text-sm"><a href={`mailto:${o.email}`} className="hover:underline">{o.email}</a></p>
            <p className="mt-3 text-sm leading-relaxed text-stone-600">{a.line1}{a.line2 ? `, ${a.line2}` : ""}<br />{a.city}, {a.state} {a.pincode}</p>
            {o.gstin && <p className="mt-2 text-sm">GSTIN: <b>{o.gstin}</b></p>}
            {history.length > 1 && <div className="mt-3 border-t pt-3 text-xs text-stone-500">Other orders: {history.filter((h) => h.id !== o.id).map((h) => <Link key={h.id} href={`/team/orders/${h.id}`} className="mr-2 underline">{h.n}</Link>)}</div>}
          </Section>
          <Section title="Payments">
            {o.payments.length === 0 ? <p className="text-sm text-stone-500">No payment records yet.</p> : (
              <ul className="space-y-2 text-sm">{o.payments.map((p) => <li key={p.id} className="flex flex-wrap items-center justify-between gap-2"><span>{p.provider} · {p.purpose.toLowerCase()}</span><span>{formatINR(p.amount)}</span><Badge>{p.status}</Badge><span className="w-full text-xs text-stone-400">{p.txnId}{p.providerRef ? ` · ref ${p.providerRef}` : ""} · {prettyDateTime(p.createdAt)}</span></li>)}</ul>
            )}
            {write && o.amountPaid > 0 && o.paymentStatus !== "REFUNDED" && ["CANCELLED", "RETURNED"].includes(o.status) && (
              <form action={markRefunded} className="mt-4 flex gap-2 border-t pt-3"><Hidden /><input name="ref" placeholder="Refund ref / UTR" className="t-input" /><Submit className="t-btn-ghost">Record refund</Submit></form>
            )}
          </Section>
        </div>
      </div>
    </div>
  );
}
