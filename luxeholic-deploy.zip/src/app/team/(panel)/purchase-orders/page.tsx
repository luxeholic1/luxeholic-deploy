import Link from "next/link";
import { and, asc, count, desc, eq, type SQL } from "drizzle-orm";
import { db, schema } from "@/db";
import { requireStaff } from "@/lib/auth";
import { canWrite } from "@/lib/rbac";
import { formatINR } from "@/lib/money";
import { prettyDateTime } from "@/lib/dates";
import { withQuery } from "@/lib/url";
import { Badge, Empty, Field, PageHeader, Section, Tabs } from "@/components/team/ui";
import { Submit } from "@/components/team/client";
import { createStockPo } from "../../actions/procurement";

export const metadata = { title: "Purchase orders" };
const ST = ["DRAFT", "SENT", "CONFIRMED", "SHIPPED", "RECEIVED", "CANCELLED"] as const;

export default async function Pos({ searchParams }: { searchParams: Promise<Record<string, string>> }) {
  const me = await requireStaff("purchaseOrders");
  const sp = await searchParams;
  const w: SQL[] = [];
  if (sp.status) w.push(eq(schema.purchaseOrders.status, sp.status as "DRAFT"));
  if (sp.vendor) w.push(eq(schema.purchaseOrders.vendorId, sp.vendor));
  const [rows, counts, vendors] = await Promise.all([
    db.query.purchaseOrders.findMany({ where: and(...w), with: { vendor: true, order: true, items: true }, orderBy: desc(schema.purchaseOrders.createdAt), limit: 100 }),
    db.select({ s: schema.purchaseOrders.status, n: count() }).from(schema.purchaseOrders).groupBy(schema.purchaseOrders.status),
    db.select().from(schema.vendors).orderBy(asc(schema.vendors.name)),
  ]);
  const q = (p: Record<string, string | undefined>) => withQuery("/team/purchase-orders", { ...sp, ok: undefined, err: undefined, ...p });
  return (
    <div>
      <PageHeader title="Purchase orders" sub="Dropship POs are created automatically when a customer order is paid/confirmed. Place them with the vendor, then track to delivery." />
      <Tabs active={sp.status ?? "all"} items={[{ key: "all", label: "All", href: q({ status: undefined }) }, ...ST.map((s) => ({ key: s, label: s === "DRAFT" ? "To place" : s.toLowerCase(), href: q({ status: s }), count: counts.find((c) => c.s === s)?.n ?? 0 }))]} />
      {rows.length === 0 ? <Empty>No purchase orders here.</Empty> : (
        <div className="t-card overflow-x-auto"><table className="t-table">
          <thead><tr><th>PO</th><th>Vendor</th><th>For order</th><th>Items</th><th>Status</th><th>Created</th><th className="text-right">Est. cost</th></tr></thead>
          <tbody>{rows.map((r) => (
            <tr key={r.id} className="hover:bg-stone-50">
              <td><Link href={`/team/purchase-orders/${r.id}`} className="font-medium hover:underline">{r.number}</Link></td>
              <td>{r.vendor.name}</td>
              <td>{r.order ? r.order.number : <span className="text-stone-400">stock</span>}</td>
              <td>{r.items.reduce((s, i) => s + i.quantity, 0)}</td>
              <td><Badge>{r.status}</Badge></td>
              <td className="text-stone-500">{prettyDateTime(r.createdAt)}</td>
              <td className="text-right">{formatINR(r.totalCost)}</td>
            </tr>
          ))}</tbody>
        </table></div>
      )}
      {canWrite(me, "purchaseOrders") && (
        <Section title="New stock purchase order" className="mt-6">
          <form action={createStockPo} className="grid gap-4 sm:grid-cols-3">
            <Field label="Vendor"><select name="vendorId" required className="t-input"><option value="">Choose…</option>{vendors.map((v) => <option key={v.id} value={v.id}>{v.name}</option>)}</select></Field>
            <Field label="Lines — SKU, qty, unit cost ₹ (one per line)" className="sm:col-span-2"><textarea name="lines" rows={3} className="t-input font-mono text-xs" placeholder={"LX-SUN-12345, 5, 1450\nDEMO-001, 2, 1800"} /></Field>
            <Field label="Notes" className="sm:col-span-2"><input name="notes" className="t-input" /></Field>
            <div className="flex items-end"><Submit>Create PO</Submit></div>
          </form>
        </Section>
      )}
    </div>
  );
}
