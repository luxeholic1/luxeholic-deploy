import Link from "next/link";
import { notFound } from "next/navigation";
import { eq } from "drizzle-orm";
import { db, schema } from "@/db";
import { requireStaff } from "@/lib/auth";
import { canWrite } from "@/lib/rbac";
import { formatINR } from "@/lib/money";
import { prettyDateTime } from "@/lib/dates";
import { Badge, Field, PageHeader, Section } from "@/components/team/ui";
import { CopyText, Submit } from "@/components/team/client";
import { placeWithVendor, updatePo } from "../../../actions/procurement";

export default async function PoDetail({ params }: { params: Promise<{ id: string }> }) {
  const me = await requireStaff("purchaseOrders");
  const { id } = await params;
  const po = await db.query.purchaseOrders.findFirst({ where: eq(schema.purchaseOrders.id, id), with: { vendor: true, order: true, items: true, createdBy: true } });
  if (!po) notFound();
  const write = canWrite(me, "purchaseOrders");
  const ship = po.order?.shippingAddress;
  const shipText = ship ? `${ship.name}\n${ship.line1}${ship.line2 ? ", " + ship.line2 : ""}\n${ship.city}, ${ship.state} ${ship.pincode}\nIndia\nPhone: ${ship.phone}` : "";
  return (
    <div className="max-w-5xl">
      <Link href="/team/purchase-orders" className="text-sm text-stone-500 hover:text-stone-900">← Purchase orders</Link>
      <PageHeader title={`PO ${po.number}`} sub={<span className="flex flex-wrap items-center gap-2"><Badge>{po.status}</Badge>{po.vendor.name} · {prettyDateTime(po.createdAt)}{po.createdBy && ` · by ${po.createdBy.name}`}</span>} />
      {write && po.status === "DRAFT" && (
        <div className="mb-6 rounded-lg border border-amber-200 bg-amber-50 p-4 text-sm">
          {po.vendor.type === "SUNSKY" && po.order ? (
            <form action={placeWithVendor} className="flex flex-wrap items-center gap-3"><input type="hidden" name="id" value={po.id} /><span>Place this order on SunSky through the API (charges your SunSky balance).</span><Submit confirm="Place this order with SunSky now?">Place with SunSky</Submit></form>
          ) : (
            <p>Place this order in the <a href={po.vendor.website ?? "#"} target="_blank" rel="noopener noreferrer" className="underline">{po.vendor.name} portal</a>{po.order ? " using the ship-to address below (dropship)" : ""}, then set status to <b>Sent</b> with their order reference.</p>
          )}
        </div>
      )}
      <div className="grid gap-6 lg:grid-cols-[1.4fr_1fr]">
        <Section title="Items">
          <table className="t-table"><thead><tr><th>Item</th><th>Vendor SKU</th><th>Qty</th><th className="text-right">Unit cost</th></tr></thead><tbody>
            {po.items.map((i) => <tr key={i.id}><td>{i.title}</td><td className="font-mono text-xs">{i.vendorSku}</td><td>{i.quantity}</td><td className="text-right">{formatINR(i.unitCost)}</td></tr>)}
          </tbody></table>
          <p className="mt-3 text-right text-sm">Estimated total <b>{formatINR(po.totalCost)}</b></p>
        </Section>
        <div className="space-y-6">
          {po.order && ship && (
            <Section title="Ship to (customer)" actions={<CopyText text={shipText} />}>
              <pre className="whitespace-pre-wrap font-sans text-sm">{shipText}</pre>
              <p className="mt-2 text-xs text-stone-500">Customer order <Link href={`/team/orders/${po.order.id}`} className="underline">{po.order.number}</Link> · <Badge>{po.order.status}</Badge></p>
            </Section>
          )}
          <Section title="Update">
            <form action={updatePo} className="space-y-3">
              <fieldset disabled={!write} className="space-y-3">
                <input type="hidden" name="id" value={po.id} />
                <Field label="Status"><select name="status" defaultValue={po.status} className="t-input">{["DRAFT", "SENT", "CONFIRMED", "SHIPPED", "RECEIVED", "CANCELLED"].map((s) => <option key={s} value={s}>{s.toLowerCase()}</option>)}</select></Field>
                <Field label="Vendor order ref"><input name="vendorRef" defaultValue={po.vendorRef ?? ""} className="t-input" /></Field>
                <div className="grid grid-cols-2 gap-3"><Field label="Courier"><input name="courier" className="t-input" placeholder="e.g. DHL" /></Field><Field label="Tracking no."><input name="trackingNumber" defaultValue={po.trackingNumber ?? ""} className="t-input" /></Field></div>
                <Field label="Expected date"><input type="date" name="expectedDate" defaultValue={po.expectedDate ?? ""} className="t-input" /></Field>
                <Field label="Notes"><textarea name="notes" rows={2} defaultValue={po.notes ?? ""} className="t-input" /></Field>
                {po.order && <label className="flex items-center gap-2 text-sm"><input type="checkbox" name="syncCustomer" defaultChecked /> When shipped, mark the customer order shipped & email tracking</label>}
                {write && <Submit>Save</Submit>}
              </fieldset>
            </form>
          </Section>
        </div>
      </div>
    </div>
  );
}
