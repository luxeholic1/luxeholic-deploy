import Link from "next/link";
import { desc, eq } from "drizzle-orm";
import { db, schema } from "@/db";
import { requireStaff } from "@/lib/auth";
import { prettyDateTime } from "@/lib/dates";
import { Empty, PageHeader } from "@/components/team/ui";
import { Submit } from "@/components/team/client";
import { markAllRead } from "../../actions/tasks";

export const metadata = { title: "Notifications" };
export default async function Notifications() {
  const me = await requireStaff();
  const rows = await db.select().from(schema.notifications).where(eq(schema.notifications.staffId, me.id)).orderBy(desc(schema.notifications.createdAt)).limit(100);
  return (
    <div className="max-w-3xl">
      <PageHeader title="Notifications" actions={<form action={markAllRead}><Submit className="t-btn-ghost">Mark all read</Submit></form>} />
      {rows.length === 0 ? <Empty>No notifications yet.</Empty> : (
        <ul className="t-card divide-y divide-stone-100">
          {rows.map((n) => {
            const body = <div className="flex gap-3 px-4 py-3">{!n.read && <span className="mt-1.5 h-2 w-2 shrink-0 rounded-full bg-amber-500" />}<div className={n.read ? "pl-5" : ""}><p className="text-sm font-medium">{n.title}</p>{n.body && <p className="text-sm text-stone-500">{n.body}</p>}<p className="mt-0.5 text-xs text-stone-400">{prettyDateTime(n.createdAt)}</p></div></div>;
            return <li key={n.id}>{n.link ? <Link href={n.link} className="block hover:bg-stone-50">{body}</Link> : body}</li>;
          })}
        </ul>
      )}
    </div>
  );
}
