import Link from "next/link";
import { notFound } from "next/navigation";
import { and, eq, inArray } from "drizzle-orm";
import { db, schema } from "@/db";
import { requireStaff } from "@/lib/auth";
import { canWrite } from "@/lib/rbac";
import { prettyDateTime } from "@/lib/dates";
import { Badge, PageHeader, Section } from "@/components/team/ui";
import { Submit } from "@/components/team/client";
import { assignTicket, replyTicket } from "../../../actions/support";

export default async function Ticket({ params }: { params: Promise<{ id: string }> }) {
  const me = await requireStaff("tickets");
  const { id } = await params;
  const t = await db.query.supportTickets.findFirst({ where: eq(schema.supportTickets.id, id), with: { assignee: true } });
  if (!t) notFound();
  const order = t.orderNumber ? (await db.select({ id: schema.orders.id }).from(schema.orders).where(eq(schema.orders.number, t.orderNumber.toUpperCase())))[0] : null;
  const team = await db.select({ id: schema.staff.id, name: schema.staff.name }).from(schema.staff).leftJoin(schema.teams, eq(schema.staff.teamId, schema.teams.id))
    .where(and(eq(schema.staff.active, true), inArray(schema.teams.slug, ["tech-support", "sales"])));
  const write = canWrite(me, "tickets");
  return (
    <div className="max-w-3xl">
      <Link href="/team/tickets" className="text-sm text-stone-500 hover:text-stone-900">← Tickets</Link>
      <PageHeader title={t.subject} sub={<span className="flex flex-wrap items-center gap-2"><Badge>{t.status}</Badge>{t.number} · {t.name} · <a href={`mailto:${t.email}`} className="underline">{t.email}</a>{t.phone && <> · <a href={`tel:${t.phone}`}>{t.phone}</a></>}{order && <> · <Link href={`/team/orders/${order.id}`} className="underline">order {t.orderNumber}</Link></>}</span>} />
      <div className="space-y-3">
        <div className="t-card p-4"><p className="text-xs text-stone-500">{t.name} · {prettyDateTime(t.createdAt)}</p><p className="mt-2 whitespace-pre-wrap text-sm">{t.message}</p></div>
        {t.replies.map((r, i) => <div key={i} className={`rounded-lg border p-4 ${r.staff ? "ml-8 border-stone-900/10 bg-stone-900/[.03]" : "t-card"}`}><p className="text-xs text-stone-500">{r.by} · {prettyDateTime(r.at)}{r.internal ? " · internal note (customer can’t see)" : r.staff ? "" : " · customer"}</p><p className="mt-2 whitespace-pre-wrap text-sm">{r.body}</p></div>)}
      </div>
      {write && (
        <Section title="Reply" className="mt-6">
          <form action={replyTicket} className="space-y-3">
            <input type="hidden" name="id" value={t.id} />
            <textarea name="body" rows={5} className="t-input" placeholder={`Hello ${t.name.split(" ")[0]}, …`} />
            <div className="flex flex-wrap items-center gap-3">
              <select name="status" defaultValue={t.status === "OPEN" ? "WAITING_CUSTOMER" : t.status} className="t-input !w-auto"><option value="OPEN">Open</option><option value="IN_PROGRESS">In progress</option><option value="WAITING_CUSTOMER">Waiting on customer</option><option value="RESOLVED">Resolved</option></select>
              <label className="flex items-center gap-1.5 text-sm"><input type="checkbox" name="internal" /> Internal note (don&apos;t email)</label>
              <Submit>Send</Submit>
            </div>
          </form>
          <form action={assignTicket} className="mt-4 flex items-center gap-2 border-t pt-4 text-sm"><input type="hidden" name="id" value={t.id} /><span>Assigned to</span><select name="assigneeId" defaultValue={t.assigneeId ?? ""} className="t-input !w-auto"><option value="">Nobody</option>{team.map((p) => <option key={p.id} value={p.id}>{p.name}</option>)}</select><Submit className="t-btn-ghost">Assign</Submit></form>
        </Section>
      )}
    </div>
  );
}
