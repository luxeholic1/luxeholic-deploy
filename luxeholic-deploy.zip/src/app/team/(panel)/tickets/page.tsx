import Link from "next/link";
import { count, desc, eq } from "drizzle-orm";
import { db, schema } from "@/db";
import { requireStaff } from "@/lib/auth";
import { prettyDateTime } from "@/lib/dates";
import { withQuery } from "@/lib/url";
import { Badge, Empty, PageHeader, Tabs } from "@/components/team/ui";

export const metadata = { title: "Support tickets" };
const ST = ["OPEN", "IN_PROGRESS", "WAITING_CUSTOMER", "RESOLVED"] as const;
export default async function Tickets({ searchParams }: { searchParams: Promise<{ status?: string }> }) {
  await requireStaff("tickets");
  const sp = await searchParams;
  const status = (ST.includes(sp.status as never) ? sp.status : "OPEN") as (typeof ST)[number];
  const [rows, counts] = await Promise.all([
    db.query.supportTickets.findMany({ where: eq(schema.supportTickets.status, status), with: { assignee: true }, orderBy: desc(schema.supportTickets.updatedAt), limit: 100 }),
    db.select({ s: schema.supportTickets.status, n: count() }).from(schema.supportTickets).groupBy(schema.supportTickets.status),
  ]);
  return (
    <div>
      <PageHeader title="Support tickets" sub="Messages from the contact page. Replies are emailed to the customer." />
      <Tabs active={status} items={ST.map((s) => ({ key: s, label: s.replace("_", " ").toLowerCase(), href: withQuery("/team/tickets", { status: s }), count: counts.find((c) => c.s === s)?.n ?? 0 }))} />
      {rows.length === 0 ? <Empty>No tickets here.</Empty> : (
        <div className="t-card divide-y divide-stone-100">
          {rows.map((t) => (
            <Link key={t.id} href={`/team/tickets/${t.id}`} className="flex flex-wrap items-center gap-3 px-4 py-3 hover:bg-stone-50">
              <span className="w-24 text-xs text-stone-500">{t.number}</span>
              <span className="min-w-0 flex-1"><span className="font-medium">{t.subject}</span><span className="block truncate text-sm text-stone-500">{t.name} · {t.message.slice(0, 90)}</span></span>
              {t.orderNumber && <Badge tone="blue">{t.orderNumber}</Badge>}
              <span className="text-xs text-stone-500">{t.assignee?.name ?? "Unassigned"}</span>
              <span className="text-xs text-stone-400">{prettyDateTime(t.updatedAt)}</span>
            </Link>
          ))}
        </div>
      )}
    </div>
  );
}
