import type { MetadataRoute } from "next";
import { and, eq, gt } from "drizzle-orm";
import { db, schema } from "@/db";
import { POLICY_PAGES, SITE_URL } from "@/lib/site";
import { PRICE_TIERS } from "@/lib/money";

export const dynamic = "force-dynamic";

export default async function sitemap(): Promise<MetadataRoute.Sitemap> {
  const [cats, prods] = await Promise.all([
    db.select({ slug: schema.categories.slug }).from(schema.categories).where(eq(schema.categories.active, true)),
    db.select({ slug: schema.products.slug, updatedAt: schema.products.updatedAt, images: schema.products.images }).from(schema.products).where(and(eq(schema.products.status, "ACTIVE"), gt(schema.products.stock, 0))),
  ]);
  const fixed = ["", "/shop", "/about", "/contact", "/faq", "/track-order", "/collections/new-arrivals", ...PRICE_TIERS.map((t) => `/collections/${t.slug}`), ...POLICY_PAGES.map((p) => `/policies/${p.slug}`)];
  return [
    ...fixed.map((p) => ({ url: SITE_URL + p, changeFrequency: "weekly" as const, priority: p === "" ? 1 : 0.6 })),
    ...cats.map((c) => ({ url: `${SITE_URL}/c/${c.slug}`, changeFrequency: "daily" as const, priority: 0.8 })),
    ...prods.map((p) => ({ url: `${SITE_URL}/p/${p.slug}`, lastModified: p.updatedAt, changeFrequency: "weekly" as const, priority: 0.7, images: p.images.slice(0, 1) })),
  ];
}
