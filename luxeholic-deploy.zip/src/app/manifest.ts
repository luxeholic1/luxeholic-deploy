import type { MetadataRoute } from "next";

export default function manifest(): MetadataRoute.Manifest {
  return {
    name: "Luxeholic",
    short_name: "Luxeholic",
    description: "Luxury art, décor, designer fashion & gifts",
    start_url: "/",
    display: "standalone",
    background_color: "#F7F3EC",
    theme_color: "#0E0D0B",
    icons: [
      { src: "/icon-192.png", sizes: "192x192", type: "image/png" },
      { src: "/icon-512.png", sizes: "512x512", type: "image/png" },
    ],
  };
}
