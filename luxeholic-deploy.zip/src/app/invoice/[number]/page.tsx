import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { and, eq } from "drizzle-orm";
import { db, schema } from "@/db";
import { getSettings } from "@/lib/settings";
import { TaxInvoice } from "@/components/invoice";
import { PrintButton } from "@/app/team/(panel)/orders/[id]/invoice/print";

export const metadata: Metadata = { title: "GST invoice", robots: { index: false } };

/** Customer copy of the GST invoice — same secret link as the order page (?t=). Issued once the order is paid or delivered. */
export default async function CustomerInvoice({ params, searchParams }: { params: Promise<{ number: string }>; searchParams: Promise<{ t?: string }> }) {
  const [{ number }, sp] = await Promise.all([params, searchParams]);
  const o = await db.query.orders.findFirst({ where: and(eq(schema.orders.number, number), eq(schema.orders.accessToken, sp.t ?? "")), with: { items: true } });
  if (!o || o.status === "CANCELLED" || !(o.paymentStatus === "PAID" || o.status === "DELIVERED")) notFound();
  const { business: b } = await getSettings();
  return (
    <div className="min-h-screen bg-stone-100 py-8 print:bg-white print:py-0">
      <div className="mx-auto max-w-3xl bg-white p-10 text-sm text-stone-800 shadow-sm print:p-0 print:shadow-none">
        <div className="mb-6 flex items-center justify-between gap-4 print:hidden">
          <Link href={`/order/${o.number}?t=${o.accessToken}`} className="text-sm underline">← Back to your order</Link>
          <PrintButton />
        </div>
        <TaxInvoice o={o} b={b} />
      </div>
    </div>
  );
}
