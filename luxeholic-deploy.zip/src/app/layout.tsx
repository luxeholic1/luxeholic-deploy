import type { Metadata, Viewport } from "next";
import "./globals.css";
import { cookies } from "next/headers";
import { SITE_DESCRIPTION, SITE_NAME, SITE_URL } from "@/lib/site";
import { LANG_COOKIE, LOCALE_INFO, fontHref, isLocale, type Locale } from "@/lib/i18n/config";

const cookieLocale = async (): Promise<Locale> => { const v = (await cookies()).get(LANG_COOKIE)?.value; return isLocale(v) ? v : "en"; };

export async function generateMetadata(): Promise<Metadata> {
  const loc = await cookieLocale(), hi = loc === "hi";
  return {
  metadataBase: new URL(SITE_URL),
  title: { default: hi ? `${SITE_NAME} — लग्ज़री कला, सज्जा, डिज़ाइनर फ़ैशन और उपहार` : `${SITE_NAME} — Luxury Art, Décor, Designer Fashion & Gifts`, template: `%s | ${SITE_NAME}` },
  description: hi ? "हर घर के लिए लग्ज़री — कला और मूर्तियाँ, गृह सज्जा, डिज़ाइनर फ़ैशन, उपहार और लक्स-टेक। GST सहित कीमतें, पूरे भारत में मुफ़्त बीमित शिपिंग।" : SITE_DESCRIPTION,
  applicationName: SITE_NAME,
  openGraph: { type: "website", siteName: SITE_NAME, locale: LOCALE_INFO[loc].og, images: ["/brand/logo-full-dark.png"] },
  twitter: { card: "summary_large_image" },
  icons: { icon: [{ url: "/favicon-32.png", sizes: "32x32" }, { url: "/icon-192.png", sizes: "192x192" }], apple: "/apple-icon.png" },
  manifest: "/manifest.webmanifest",
  alternates: { canonical: "/" },
  };
}

export const viewport: Viewport = { themeColor: "#F7F3EC", width: "device-width", initialScale: 1 };

export default async function RootLayout({ children }: { children: React.ReactNode }) {
  const loc = await cookieLocale(), info = LOCALE_INFO[loc], font = fontHref(loc);
  const cls = loc === "hi" ? "lang-hi" : info.font ? "lang-script" : undefined;
  return (
    <html lang={info.html} dir={info.dir ?? "ltr"} className={cls} style={info.font && loc !== "hi" ? ({ ["--lang-font" as string]: `"${info.font}"` } as React.CSSProperties) : undefined}>
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="" />
        <link
          rel="stylesheet"
          href="https://fonts.googleapis.com/css2?family=Cormorant+Garamond:ital,wght@0,300;0,400;0,500;1,300;1,400&family=Jost:wght@300;400;500&family=Noto+Sans+Devanagari:wght@300;400;500&family=Noto+Serif+Devanagari:wght@400;500&display=swap"
        />
        {font && loc !== "hi" && <link rel="stylesheet" href={font} />}
      </head>
      <body className="min-h-screen antialiased">{children}</body>
    </html>
  );
}
