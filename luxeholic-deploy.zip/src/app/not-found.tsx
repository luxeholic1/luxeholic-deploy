import Link from "next/link";
import { getI18n } from "@/lib/i18n/server";

export default async function NotFound() {
  const { t } = await getI18n();
  return (
    <div className="flex min-h-[70vh] flex-col items-center justify-center px-6 text-center">
      {/* eslint-disable-next-line @next/next/no-img-element */}
      <img src="/brand/mark-dark.png" alt="Luxeholic" className="h-14 w-auto opacity-80" />
      <h1 className="h-display mt-8 text-5xl italic">{t("This piece has moved on.")}</h1>
      <p className="mt-3 text-sm text-ink-mute">{t("The page you were looking for isn’t here.")}</p>
      <Link href="/" className="btn-ink mt-8">{t("Return home")}</Link>
    </div>
  );
}
