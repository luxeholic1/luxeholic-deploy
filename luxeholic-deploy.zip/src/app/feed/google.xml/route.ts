import { productCondition } from "@/lib/money";
import { and, eq, ne } from "drizzle-orm";
import { db, schema } from "@/db";
import { SITE_URL, SITE_NAME } from "@/lib/site";
import { getSettings } from "@/lib/settings";

/**
 * Google Merchant Center product feed (RSS 2.0 + g: namespace).
 * In Merchant Center → Products → Feeds → Add → Scheduled fetch:  https://luxeholic.in/feed/google.xml  (daily)
 * Every attribute mirrors what the product page + JSON-LD show (price incl. GST, availability, shipping, returns).
 */
export const dynamic = "force-dynamic";

const esc = (s: string) => s.replace(/[<>&'"\u0000-\u0008\u000B\u000C\u000E-\u001F]/g, (c) => ({ "<": "&lt;", ">": "&gt;", "&": "&amp;", "'": "&apos;", '"': "&quot;" }[c] ?? ""));
const money = (p: number) => `${(p / 100).toFixed(2)} INR`;

export async function GET() {
  const settings = await getSettings();
  const rows = await db.query.products.findMany({
    where: and(eq(schema.products.status, "ACTIVE"), ne(schema.products.description, "")),
    with: { category: true, variants: true },
  });
  const ship = (price: number) => (settings.shipping.freeAbove === 0 || price >= settings.shipping.freeAbove ? 0 : settings.shipping.flatFee);
  const items: string[] = [];
  for (const p of rows) {
    if (p.category.slug === "needs-review" || !p.images.length || p.tags.includes("demo")) continue; // no placeholder/demo items: Google rejects them and may flag the account
    const parent = p.category.parentId ? await parentName(p.category.parentId) : null;
    const productType = [parent, p.category.name].filter(Boolean).join(" > ");
    const base = (id: string, price: number, stock: number, extra: Record<string, string | null | undefined>, link: string) => {
      const sale = p.compareAtPrice && p.compareAtPrice > price;
      const f: Record<string, string | null | undefined> = {
        "g:id": id, "g:title": `${p.brand !== SITE_NAME && !p.title.includes(p.brand) ? p.brand + " " : ""}${p.title}`.slice(0, 150),
        "g:description": p.description.slice(0, 5000), "g:link": link, "g:image_link": p.images[0],
        "g:availability": stock > 0 ? "in_stock" : "out_of_stock",
        "g:price": money(sale ? p.compareAtPrice! : price), "g:sale_price": sale ? money(price) : null,
        "g:brand": p.brand, "g:condition": productCondition(p.tags), "g:google_product_category": p.category.googleCategory, "g:product_type": productType,
        "g:mpn": p.gtin ? null : p.brand === SITE_NAME ? null : p.mpn, "g:gtin": p.gtin,
        "g:identifier_exists": p.gtin || (p.brand !== SITE_NAME && p.mpn) ? null : "no",
        "g:material": p.material, "g:color": p.color, "g:gender": p.gender, "g:age_group": p.ageGroup ?? (p.category.isApparel ? "adult" : null),
        "g:shipping_weight": p.weightGrams ? `${p.weightGrams} g` : null,
        ...extra,
      };
      const imgs = p.images.slice(1, 10).map((u) => `<g:additional_image_link>${esc(u)}</g:additional_image_link>`).join("");
      const shipping = `<g:shipping><g:country>IN</g:country><g:service>Insured Standard</g:service><g:price>${money(ship(price))}</g:price><g:min_handling_time>1</g:min_handling_time><g:max_handling_time>${p.dispatchDays}</g:max_handling_time><g:min_transit_time>2</g:min_transit_time><g:max_transit_time>${p.deliveryDays}</g:max_transit_time></g:shipping>`;
      return `<item>${Object.entries(f).filter(([, v]) => v).map(([k, v]) => `<${k}>${esc(String(v))}</${k}>`).join("")}${imgs}${shipping}</item>`;
    };
    const link = `${SITE_URL}/p/${p.slug}`;
    if (p.variants.length) {
      for (const v of p.variants) items.push(base(v.sku, v.price ?? p.price, v.stock, { "g:item_group_id": p.sku, "g:size": v.size, "g:color": v.color ?? p.color, "g:gtin": v.gtin ?? p.gtin }, link));
    } else items.push(base(p.sku, p.price, p.stock, {}, link));
  }
  const xml = `<?xml version="1.0" encoding="UTF-8"?>
<rss version="2.0" xmlns:g="http://base.google.com/ns/1.0"><channel><title>${SITE_NAME}</title><link>${SITE_URL}</link><description>${SITE_NAME} product feed</description>
${items.join("\n")}
</channel></rss>`;
  return new Response(xml, { headers: { "Content-Type": "application/xml; charset=utf-8", "Cache-Control": "public, max-age=900" } });
}

const names = new Map<string, string>();
async function parentName(id: string) {
  if (!names.size) for (const c of await db.select({ id: schema.categories.id, name: schema.categories.name }).from(schema.categories)) names.set(c.id, c.name);
  return names.get(id) ?? null;
}
