CREATE TYPE "public"."callback_status" AS ENUM('NEW', 'CALLED', 'CLOSED');--> statement-breakpoint
CREATE TABLE "callbacks" (
	"id" text PRIMARY KEY NOT NULL,
	"number" text NOT NULL,
	"name" text NOT NULL,
	"phone" text NOT NULL,
	"email" text,
	"interest" text NOT NULL,
	"best_time" text NOT NULL,
	"city" text,
	"message" text,
	"source" text DEFAULT 'home' NOT NULL,
	"customer_id" text,
	"status" "callback_status" DEFAULT 'NEW' NOT NULL,
	"assignee_id" text,
	"notes" jsonb DEFAULT '[]'::jsonb NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "callbacks_number_unique" UNIQUE("number")
);
--> statement-breakpoint
ALTER TABLE "callbacks" ADD CONSTRAINT "callbacks_customer_id_customers_id_fk" FOREIGN KEY ("customer_id") REFERENCES "public"."customers"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "callbacks" ADD CONSTRAINT "callbacks_assignee_id_staff_id_fk" FOREIGN KEY ("assignee_id") REFERENCES "public"."staff"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
CREATE INDEX "callbacks_status_idx" ON "callbacks" USING btree ("status","created_at");--> statement-breakpoint
UPDATE "teams" SET "modules" = "modules" || '{"leads":"write"}'::jsonb WHERE "slug" IN ('sales','tech-support') AND NOT ("modules" ? 'leads');--> statement-breakpoint
UPDATE "teams" SET "modules" = "modules" || '{"leads":"read"}'::jsonb WHERE "slug" = 'marketing' AND NOT ("modules" ? 'leads');
