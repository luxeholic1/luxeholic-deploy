# Luxeholic — luxury storefront + team workspace (Next.js)

One Next.js 15 app containing:

| Part | URL | Who |
|---|---|---|
| Luxury storefront | `/` | Customers — guest checkout or account |
| Team workspace | `/team` | Super admin + 6 teams, each with its own panel |
| Merchant Center feed | `/feed/google.xml` | Google Shopping |
| Cron jobs | `/api/cron/{daily,sync,cleanup}?key=…` | Server cron |

**Stack:** Next.js 15 (App Router, server actions) · React 19 · TypeScript · Tailwind · PostgreSQL + Drizzle ORM (no binary engines → works on VPS *and* cPanel Node hosting) · bcrypt + signed JWT cookies · PayU · PhonePe PG v2 · Nodemailer.

---

## 1. What's inside

### Storefront
- 5 houses → 31 sub-categories: **Art & Sculpture**, **Home Décor**, **Lux-Tech** (SunSky) · **Designer Fashion**, **Gifting & Accessories** (BrandsGateway). Editable in Team → Categories.
- **Price tiers** so every budget has a door: *First Luxe* (< ₹5k), *Signature* (₹5k–25k), *Haute* (₹25k+), plus New Arrivals / Curator's Choice.
- Product pages with gallery, sizes, delivery estimate, GST-inclusive price, “pay 10% now” line, authenticity note.
- Bag drawer, guest **or** account checkout, coupons, GSTIN for business invoices, gift note.
- Payments: **PayU** (UPI/cards/netbanking), **PhonePe**, **Bank transfer** (UTR submit + team verification), **COD**, **10% advance + COD** (advance via PayU or PhonePe). Limits, fees and toggles in Store Settings.
- Order page (works for guests via secret link), track-order, return request, customer account.
- Policies written for Google review: Shipping, Returns & Refunds, Payments & COD, Authenticity, Privacy (DPDP Act 2023), Terms — all fed from Store Settings so they match checkout.

### Google Merchant Center readiness
- `/feed/google.xml` — price incl. GST, sale price, availability, brand, GTIN/MPN or `identifier_exists=no`, Google category, product type, images, shipping with handling/transit times, gender/age group/size/colour for fashion, `item_group_id` for variants.
- Product JSON-LD with `Offer`, `shippingDetails`, `hasMerchantReturnPolicy`; Organization/OnlineStore schema; FAQ + breadcrumb schema.
- `sitemap.xml`, `robots.txt`, canonical URLs, HTTPS headers (HSTS etc.), Consent Mode v2 banner when GA4/Ads IDs are set, GMC verification meta tag.
- Products can't be published without image + 40-char description + real category; sold-out items vanish from listings (no ghost inventory).
- Team → Marketing shows a **GMC readiness checklist**.

### Team workspace (`/team/login`)
- **Team-wise login**: choose team → work email → password. An account only works with its own team. First sign-in forces a private password. 8 failed tries = 15-minute lock. Every action is in the **Audit log**.
- **Super admin** (`karykalita1012@gmail.com`): everything + Staff & Logins, Teams & Access, Store Settings, Audit log.
- **Tasks & calendar**: assign to a team, a person, everyone, or *each member their own copy*; priority, time, type (task/meeting/reminder); repeat **daily / Mon–Sat / weekly / monthly**. Recurring to-dos appear every day automatically; a 6 AM digest (bell + email) tells each person their to-dos; overdue reminders. Month calendar colour-coded by team. Comments and status (to do / in progress / blocked / done) notify the assigner.
- Team leads assign within their team; members add personal tasks.
- **Panels** (access per team is editable in Teams & Access — view/edit per module):

| Team | Panel |
|---|---|
| Sales | Orders (confirm COD by phone, verify bank transfers, dispatch with tracking, mark balance collected, returns/refunds, GST invoice), Customers |
| Marketing | Coupons, newsletter subscribers (CSV export), Merchant Center checklist & feed, featured products, categories |
| Procurement | Purchase orders — auto-created per vendor when a customer order is paid/confirmed; one-click *Place with SunSky* (API); copy-paste ship-to for BrandsGateway; stock POs |
| Inventory | Products (review synced drafts, bulk publish/move/feature), stock, pricing lock, categories |
| Tech support | Support tickets from the contact form (email replies, internal notes, assign) |
| Alliances | Vendors & OEMs — add new vendors, encrypted API credentials, pricing formula, import rules, test, sync, re-price, sync history |

- New teams (e.g. Design, Finance) can be created by the super admin with any combination of panels.

### Vendor engine
- **Pricing:** `cost × FX × (1 + duty) + shipping → × (1 + markup) × (1 + GST)`, rounded up to clean luxury price points. FX rates in Store Settings; per-vendor markup/duty/GST/shipping; price lock per product.
- **SunSky** Open API adapter (`key` + MD5 signature as documented at doc.sunsky-online.com). Method paths are overridable per vendor if SunSky changes them.
- **BrandsGateway / any CSV-JSON vendor:** feed URL importer that understands WooCommerce-style exports (variations → sizes).
- Auto-sorts products into sub-categories by keyword (overrides per vendor); unsure ones go to *Needs review*. New products arrive as **drafts** (or auto-publish if enabled).
- Items missing from a full feed are set to stock 0 automatically.

---

## 1b. Languages & currencies (domain-wise)

- **Languages:** English, हिन्दी, मराठी, తెలుగు, தமிழ், ಕನ್ನಡ, മലയാളം, বাংলা, ગુજરાતી, ਪੰਜਾਬੀ, ଓଡ଼ିଆ, Français, Español, Deutsch and العربية (right-to-left). The whole storefront switches together. **Hindi** is fully curated: any product, category, option or hero chapter without an up-to-date Hindi translation is hidden. **Other languages** show catalogue text in English until it is translated. Each language loads its own Noto font.
- **Adding a language:** Team → Marketing → Languages & translations → *Translate interface* (drafts the 621 interface phrases with Claude, 300 per click; needs `ANTHROPIC_API_KEY`) → tick it under *Languages on the site* → optionally *Translate content* for products/categories/hero in that language.
- **Currencies:** INR, USD, GBP, EUR, AED, AUD, CAD, SGD for *display*. Checkout, invoices, payments and the Merchant Center feed always stay in INR (checkout shows "about $X" next to the rupee total).
- **By domain:** first visit picks language + currency from the domain (luxeholic.in → English/₹, hi.luxeholic.in → Hindi/₹, luxeholic.com → $, .co.uk → £, .ae → AED, .com.au → A$). After that the visitor's choice from the globe button is remembered for a year. Override the domain list with `MARKETS_JSON`. Links like `/?lang=hi&cur=USD` also set it (handy in ads/emails).
- **Team page:** *Marketing → Languages & translations* — coverage per content type, side-by-side English/Hindi editing, "Draft with Claude" (set `ANTHROPIC_API_KEY`), languages on/off, display rates (auto-refreshed daily by `cron:daily`, or "Update rates now").
- **SunSky product finder:** *Vendors → SunSky → Find & import products* — browse SunSky categories, search by keyword/brand/cost/in-stock, see your selling price, tick products and import them (choose our category, draft or publish). "Use these filters for the scheduled sync" saves the keyword/brand/category/cost as import rules; products SunSky still lists but your rules skip are never marked sold out.
- **Commands:** `npm run seed:hindi` (Hindi for the current catalogue/hero/site texts), `npm run i18n:check` (fails if any interface string lacks Hindi — run before each deploy).
- Codes stay in Latin letters on purpose: GST/GSTIN, UPI, IFSC, UTR, order numbers, SKUs, model numbers (5G, 12GB), emails. Third-party brand names (OnePlus, REMOID…) stay as trademarks; our own label shows as लक्ज़हॉलिक.

## 2. Run locally

**Quick preview (Windows/macOS/Linux, no database install):**
```bash
npm install
npm run setup:local      # creates .env + embedded database + demo data
npm run dev              # open http://localhost:3000  ·  team: http://localhost:3000/team/login
```
Super admin `karykalita1012@gmail.com` / `Luxeholic@Admin1` · any team e.g. Sales `sales@luxeholic.in` / `Luxeholic@2026`.

**With real PostgreSQL:**
```bash
cp .env.example .env            # fill DATABASE_URL, AUTH_SECRET, CRON_SECRET
npm install
npx drizzle-kit migrate         # create tables
npm run db:seed                 # teams, super admin (prints temp password), categories, vendors
# optional preview data:  SEED_DEMO=1 npm run db:seed   (36 demo products, demo staff, sample to-dos)
npm run dev                     # http://localhost:3000  ·  team: http://localhost:3000/team/login
```

Demo staff (only with `SEED_DEMO=1`): `sales@luxeholic.in`, `marketing@…`, `procurement@…`, `inventory@…`, `tech-support@…`, `alliances@…` — password `Luxeholic@2026`. **Delete demo products and staff before going live** (Products → select → Delete; Staff → deactivate).

---

## 3. Deploy on BookMyHost

### A. VPS — BookMyHost "luxeholic-web" (Ubuntu 24.04, 160.22.109.18)
**1. DNS** (at each domain's registrar / DNS panel) — for `luxeholic.in` and `luxeholic.co.nz`:

| Type | Name | Value |
|---|---|---|
| A | `@` | `160.22.109.18` |
| A | `www` | `160.22.109.18` |

Delete any old A/AAAA/CNAME for `@` and `www`. Keep MX/TXT (email) records as they are.

**2. Upload & install** — upload `luxeholic-complete.zip` to `/root` (WinSCP / FileZilla SFTP, or BookMyHost web console), then run once:
```bash
mkdir -p /var/www/luxeholic && unzip -o /root/luxeholic-complete.zip -d /var/www/luxeholic && sudo bash /var/www/luxeholic/deploy/install.sh
```
It installs Node 22, PostgreSQL, pm2, Nginx, firewall and HTTPS for all four hostnames, creates `.env` with fresh secrets, builds, starts the app, and adds the scheduled jobs + daily DB backup. The super-admin password is printed at the end and saved in `/root/LUXEHOLIC-FIRST-LOGIN.txt`.

Domains → currency: `luxeholic.in` → ₹ INR · `luxeholic.co.nz` → NZ$ NZD (change in `src/lib/i18n/config.ts` or `MARKETS_JSON`). If DNS hasn't spread yet, the script skips HTTPS for those names — just run it again later.

**Old WooCommerce products (31k+):** the installer starts `npm run import:woo` then `npm run mirror:images` in the background (log: `/var/log/luxeholic-import.log`). Both resume if stopped. Switch `luxeholic.in` DNS **only after** the log says `ALL DONE` — the old images are copied to `/var/www/luxeholic-wp-uploads` and keep their `/wp-content/uploads/…` URLs.

**Updates:** upload the new zip, unzip over the folder, run `deploy/install.sh` again (keeps `.env`, database and uploads).

### B. cPanel plan with “Setup Node.js App”
Shared cPanel usually has **no PostgreSQL** — create a free/paid managed Postgres (e.g. Neon or Supabase, region Mumbai) and use its URL as `DATABASE_URL`. Then: build locally with `./deploy/build.sh`, upload the contents of `.next/standalone/` to the app folder, set *Application startup file* = `server.js`, Node 20+, add the `.env` variables in the cPanel UI, and add the three `curl` lines from `deploy/crontab.txt` under **Cron Jobs**.

The current `luxeholic.in` WordPress/WooCommerce site is replaced: point the domain to the new server once you're happy (keep a WordPress backup). Recreate any important WooCommerce product URLs as redirects if they had traffic.

---

## 4. Go-live checklist

1. **Store Settings → Business**: registered name, full address, phone, GSTIN, social links. **Bank** details. Check payment toggles/limits.
2. `.env`: PayU live key/salt (`PAYU_MODE=live`), PhonePe live client id/secret (`PHONEPE_MODE=live`) + webhook user/pass, SMTP, `CRON_SECRET`.
   - PayU success/failure URL (auto-sent): `https://luxeholic.in/api/payments/payu/callback`
   - PhonePe webhook: `https://luxeholic.in/api/payments/phonepe/webhook`
3. **Vendors**: SunSky API key + secret (from your SunSky sales manager) → *Test connection* → set category IDs/markup → *Sync now*. BrandsGateway: paste the custom-store product feed URL (+ login if protected) → *Test* → *Sync now*.
4. **Inventory** reviews drafts → bulk publish. Make sure every live product has real photos.
5. **Staff & Logins**: create each employee's login (temporary password shown once / emailed); assign team + lead.
6. **Tasks**: set the recurring daily to-dos for each team.
7. **Google Merchant Center**: verify & claim `luxeholic.in` (meta tag in Settings → Tracking, or DNS) → Business info must match the site → Shipping: free, handling 1–3 days, transit 2–15 days → Returns: 7 days, free → Products → Feeds → add `https://luxeholic.in/feed/google.xml` (scheduled daily) → link Google Ads.
8. Place one real ₹1-ish test order on each gateway, then refund it.

## 5. Things only you can provide
SunSky API key/secret · BrandsGateway feed URL/credentials · PayU & PhonePe live keys · SMTP mailbox · registered business name, address, phone, GSTIN · bank account for transfers · real product/category photography · trademark/brand authorisation documents if Google asks about designer brands.

## 6. Code map
```
src/app/(store)/…           storefront pages + server actions (checkout, auth, contact)
src/app/team/…              team workspace (login, panels, server actions in team/actions)
src/app/api/payments/…      PayU callback, PhonePe return + webhook
src/app/api/cron/[job]      daily | sync | cleanup
src/app/feed/google.xml     Merchant Center feed
src/db/schema.ts            database schema (Drizzle)        drizzle/  SQL migrations
src/lib/orders.ts           pricing a bag, order creation, stock reservation, payment settlement, vendor routing
src/lib/vendors/            sunsky.ts · feed.ts (BrandsGateway/CSV) · sync.ts
src/lib/tasks.ts            recurring to-dos, daily digests     src/lib/rbac.ts  panel access
src/lib/policies.ts         policy page content                 src/lib/settings.ts  store settings
scripts/seed.ts             initial data                         scripts/cron.ts  CLI jobs
```

Schema changes: edit `src/db/schema.ts` → `npx drizzle-kit generate` → commit the new SQL → `npx drizzle-kit migrate` on the server.
