// PM2 process file for a VPS:  pm2 start ecosystem.config.cjs && pm2 save
module.exports = {
  apps: [{
    name: "luxeholic",
    cwd: __dirname + "/.next/standalone",
    script: "server.js",
    env: { NODE_ENV: "production", PORT: 3000, HOSTNAME: "127.0.0.1" },
    instances: 1,
    max_memory_restart: "700M",
  }],
};
