import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  output: "standalone", // small self-contained server for VPS / cPanel Node hosting
  poweredByHeader: false,
  images: {
    // Vendor CDNs (SunSky / BrandsGateway) + your own uploads
    remotePatterns: [
      { protocol: "https", hostname: "**.sunsky-online.com" },
      { protocol: "https", hostname: "**.brandsgateway.com" },
      { protocol: "https", hostname: "**.luxeholic.in" },
    ],
  },
  experimental: { serverActions: { bodySizeLimit: "8mb" } }, // CSV uploads from the Marketing panel
  serverExternalPackages: ["pg", "@electric-sql/pglite"],
  async headers() {
    return [{
      source: "/(.*)",
      headers: [
        { key: "X-Content-Type-Options", value: "nosniff" },
        { key: "Referrer-Policy", value: "strict-origin-when-cross-origin" },
        { key: "X-Frame-Options", value: "SAMEORIGIN" },
        { key: "Permissions-Policy", value: "camera=(), microphone=(), geolocation=()" },
        { key: "Strict-Transport-Security", value: "max-age=63072000; includeSubDomains; preload" },
      ],
    }];
  },
};
export default nextConfig;
